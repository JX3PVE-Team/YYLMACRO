BKTest = BKTest or {}

BKTest.bCheckBoxOn1 = true
BKTest.bCheckBoxOn2 = false
BKTest.bCheckBoxOn3 = true

BKTest.nRadioValue = 1

BKTest.szEditBox = "����һ���ı�"
BKTest.nSliderValue = 25
BKTest.tColorValue = {0, 255, 64}

RegisterCustomData("BKTest.bCheckBoxOn1")
RegisterCustomData("BKTest.bCheckBoxOn2")
RegisterCustomData("BKTest.bCheckBoxOn3")
RegisterCustomData("BKTest.nRadioValue")
RegisterCustomData("BKTest.szEditBox")
RegisterCustomData("BKTest.nSliderValue")
RegisterCustomData("BKTest.tColorValue")


local tConfig = {
	szName = "AddonName",
	szTitle = "ע��ʵ��",
	szAuthor = "������",
	szVersion = "1.0.0",
	szKey = "test",
	dwIcon = 3406,
	szClass = "Other",
	tWidget = {
		{
			name = "AN1", type = "Button", w = 91, x = 0, y = 0, text = "���԰�ť1",
			callback = function()
				--EasyTestAddon:Open()
			end
		},{
			name = "AN1_1", type = "Button", w = 91, x = 100, y = 0, text = "���԰�ť2",
			callback = function()
				Output(BKTest)
			end
		},{
			name = "AN1_2", type = "Button", w = 91, x = 200, y = 0, text = "���԰�ť3",
			enable = function()
				return BKTest.bCheckBoxOn1
			end,
			callback = function()
				Output(BKTest)
			end
		},{
			name = "AN2", type = "CheckBox", w = 100, x = 0, y = 40, text = "��ѡ��1",
			default = function()
				return BKTest.bCheckBoxOn1
			end,
			callback = function(enabled)
				BKTest.bCheckBoxOn1 = enabled
			end
		},{
			name = "AN3", type = "CheckBox", w = 100, x = 100, y = 40, text = "��ѡ��2",
			default = function()
				return BKTest.bCheckBoxOn2
			end,
			callback = function(enabled)
				BKTest.bCheckBoxOn2 = enabled
			end
		},{
			name = "AN4", type = "CheckBox",w = 100, x = 200, y = 40, text = "��ѡ��3",
			default = function()
				return BKTest.bCheckBoxOn3
			end,
			callback = function(enabled)
				BKTest.bCheckBoxOn3 = enabled
			end
		},{
			name = "AN5", type = "RadioBox", w = 100, x = 0, y = 80, text = "��ѡ��1", group = "test",
			default = function()
				return BKTest.nRadioValue == 1
			end,
			callback = function(enabled)
				if enabled then
					BKTest.nRadioValue = 1
				end
			end
		},{
			name = "AN6", type = "RadioBox", w = 100, x = 100, y = 80, text = "��ѡ��2", group = "test",
			default = function()
				return BKTest.nRadioValue == 2
			end,
			callback = function(enabled)
				if enabled then
					BKTest.nRadioValue = 2
				end
			end
		},{
			name = "AN7", type = "RadioBox", w = 100, x = 200, y = 80, text = "��ѡ��3", group = "test",
			enable = function()
				return BKTest.bCheckBoxOn2
			end,
			default = function()
				return BKTest.nRadioValue == 3
			end,
			callback = function(enabled)
				if enabled then
					BKTest.nRadioValue = 3
				end
			end
		},{
			name = "AN8", type = "ComboBox", w = 150, x = 0, y = 120, text = "������",
			enable = function()
				return BKTest.bCheckBoxOn3
			end,
			callback = function(m)
				table.insert(m,{szOption = "���Բ˵�1"})
				table.insert(m,{szOption = "���Բ˵�2"})
				PopupMenu(m)
			end
		},{
			name = "AN9", type = "ColorBox", w = 100, h = 25, x = 170, y = 120, text = "��ɫѡ����",
			default = function()
				return BKTest.tColorValue
			end,
			callback = function(value)
				BKTest.tColorValue = value
			end
		},{
			name = "AN10", type = "Edit",w = 300, x = 0, y = 160,
			enable = function()
				return BKTest.bCheckBoxOn3
			end,
			default = function()
				return BKTest.szEditBox
			end,
			callback = function(value)
				BKTest.szEditBox = value
			end
		},{
			name = "AN11", type = "Text", w = 80, h = 28, x = 0, y = 200, text = "���ǻ�����",
		},{
			name = "AN12", type = "CSlider", w = 160, x = 85, y = 200, min = 0, max = 100, step = 100, unit = "%",
			enable = function()
				return BKTest.bCheckBoxOn3
			end,
			default = function()
				return BKTest.nSliderValue
			end,
			callback = function(value)
				BKTest.nSliderValue = value
			end
		},
	},
}
BK:RegisterPanel(tConfig)

--����ע��ؼ�ʵ��
local tConfig2 = {
	szName = "AddonName2",
	szTitle = "ע��ʵ��2",
	szAuthor = "������",
	szVersion = "1.0.0",
	szKey = "test",
	dwIcon = 3406,
	szClass = "Other",
	tWidget = {},
}
for i = 1, 40 do
	local t = {
		name = "AN2_"..i,
		type = "CheckBox",
		w = 100,
		x = ((i - 1) % 5) * 100,
		y = math.floor((i - 1) / 5) * 40,
		text = "��ѡ��_"..i,
		default = function()
			return false
		end,
		callback = function(enabled)
			Output(enabled)
		end
	}
	table.insert(tConfig2.tWidget, t)
end
BK:RegisterPanel(tConfig2)

do
	for i = 1, 10 do
		local cfg = {
			szName = "TestA" .. i,
			szTitle = "����" .. i,
			szAuthor = "������",
			szVersion = "1.0.0",
			szKey = "test",
			dwIcon = 3019 + i,
			szClass = "UI",
			tWidget = {
				{
					name = "ANE"..i, type = "Button", w = 91, x = 0, y = 0, text = "���԰�ť"..i,
					callback = function()
						Output("111")
					end
				}
			},
		}
		BK:RegisterPanel(cfg)
	end
end
