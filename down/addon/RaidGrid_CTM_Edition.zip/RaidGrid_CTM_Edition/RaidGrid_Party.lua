RaidGrid_Party = {}
RaidGrid_Party.bDrag = false
RaidGrid_Party.tHPBarColor = {0, 200, 72}; 				RegisterCustomData("RaidGrid_Party.tHPBarColor")
RaidGrid_Party.tDistanceLevel = {8, 20, 24, 28, 999};		RegisterCustomData("RaidGrid_Party.tDistanceLevel")
RaidGrid_Party.tDistanceColorLevel = {1, 2, 3, 4, 5};		RegisterCustomData("RaidGrid_Party.tDistanceColorLevel")
RaidGrid_Party.tDistanceColor = 
{
	{0, 170, 140},
	{0, 180, 52},
	{230, 170, 40},
	{230, 110, 230},
	{230, 80, 80},
	{128, 128, 128},
	{192, 192, 192},
	{255, 255, 255},
};
RaidGrid_Party.tLifeColor = {}
RaidGrid_Party.tOrgW = {}
RaidGrid_Party.fScaleX = 1;								RegisterCustomData("RaidGrid_Party.fScaleX")
RaidGrid_Party.fScaleY = 1;								RegisterCustomData("RaidGrid_Party.fScaleY")
RaidGrid_Party.fScaleFont = 1;							RegisterCustomData("RaidGrid_Party.fScaleFont")
RaidGrid_Party.fScaleIcon = 1;							RegisterCustomData("RaidGrid_Party.fScaleIcon")
RaidGrid_Party.fScaleShadowX = 1;						RegisterCustomData("RaidGrid_Party.fScaleShadowX")
RaidGrid_Party.fScaleShadowY = 1;						RegisterCustomData("RaidGrid_Party.fScaleShadowY")

RaidGrid_Party.dwLastTempTargetId = 0
RaidGrid_Party.bTempTargetEnable = true;				RegisterCustomData("RaidGrid_Party.bTempTargetEnable")
RaidGrid_Party.Shadow = {
	bLife = false,
	bMana = false,
	a = 240,
	d = 1,
}
RegisterCustomData("RaidGrid_Party.Shadow")

local szIniFile = "Interface/RaidGrid_CTM_Edition/RaidGrid_Party.ini"

function RaidGrid_Party.IsInRaid() --����Ƿ��ڶ�����
	local player = GetClientPlayer()
	if not player or not player.IsInParty() then
		return
	end
	
	local team = GetClientTeam()
	if not team then
		return
	end	
	
	return team.nGroupNum == 5
end

function RaidGrid_Party.OnAddOrDeleteMember(dwMemberID, nGroupIndex) --���ӻ�ɾ����Ա
	local tMemberInfo, team = RaidGrid_Party.GetTeamMemberInfo(dwMemberID)
	if not tMemberInfo then
		return
	end

	if nGroupIndex > 0 and not RaidGrid_Party.IsInRaid() then
		return
	end

	local frame = RaidGrid_Party.GetPartyPanel(nGroupIndex)
	if not frame then
		frame = RaidGrid_Party.CreateNewPartyPanel(nGroupIndex)
	end
	if RaidGrid_CTM_Edition.bShowRaid then
		frame:Show()
	else
		frame:Hide()
	end

	local tGroupInfo = team.GetGroupInfo(nGroupIndex)
	local nMemberCount = 0
	for i = 0, 4 do
		if tGroupInfo.MemberList[i + 1] then
			local dwMemberID = tGroupInfo.MemberList[i + 1]
			RaidGrid_Party.ShowHandleRoleInGroup(i, nGroupIndex, dwMemberID)
			nMemberCount = nMemberCount + 1
		else
			RaidGrid_Party.ClearHandleRoleInGroup(i, nGroupIndex)
		end
	end

	if RaidGrid_CTM_Edition.bShowAllMemberGrid then
		frame:SetSize(128 * RaidGrid_Party.fScaleX, 235 * RaidGrid_Party.fScaleY)
		frame:Lookup("", "Handle_BG/Shadow_BG"):SetSize(120 * RaidGrid_Party.fScaleX, 228 * RaidGrid_Party.fScaleY)
		frame:Lookup("", "Handle_BG/Image_BG_L"):SetSize(15 * RaidGrid_Party.fScaleX, 205 * RaidGrid_Party.fScaleY)	
		frame:Lookup("", "Handle_BG/Image_BG_R"):SetSize(15 * RaidGrid_Party.fScaleX, 205 * RaidGrid_Party.fScaleY)	
		frame:Lookup("", "Handle_BG/Image_BG_BL"):SetRelPos(0, 220 * RaidGrid_Party.fScaleY)
		frame:Lookup("", "Handle_BG/Image_BG_B"):SetRelPos(15 * RaidGrid_Party.fScaleX, 220 * RaidGrid_Party.fScaleY)
		frame:Lookup("", "Handle_BG/Image_BG_BR"):SetRelPos(113 * RaidGrid_Party.fScaleX, 220 * RaidGrid_Party.fScaleY)
		frame:Lookup("", "Handle_BG/Text_GroupIndex"):SetRelPos(0, 216 * RaidGrid_Party.fScaleY)	
	else
		frame:SetSize(128 * RaidGrid_Party.fScaleX, (235 - (5 - nMemberCount) * 42) * RaidGrid_Party.fScaleY)
		frame:Lookup("", "Handle_BG/Shadow_BG"):SetSize(120 * RaidGrid_Party.fScaleX, (228 - (5 - nMemberCount) * 42) * RaidGrid_Party.fScaleY)
		frame:Lookup("", "Handle_BG/Image_BG_L"):SetSize(15 * RaidGrid_Party.fScaleX, (205 - (5 - nMemberCount) * 42) * RaidGrid_Party.fScaleY)	
		frame:Lookup("", "Handle_BG/Image_BG_R"):SetSize(15 * RaidGrid_Party.fScaleX, (205 - (5 - nMemberCount) * 42) * RaidGrid_Party.fScaleY)	
		frame:Lookup("", "Handle_BG/Image_BG_BL"):SetRelPos(0, (220 - (5 - nMemberCount) * 42) * RaidGrid_Party.fScaleY)
		frame:Lookup("", "Handle_BG/Image_BG_B"):SetRelPos(15 * RaidGrid_Party.fScaleX, (220 - (5 - nMemberCount) * 42) * RaidGrid_Party.fScaleY)
		frame:Lookup("", "Handle_BG/Image_BG_BR"):SetRelPos(113 * RaidGrid_Party.fScaleX, (220 - (5 - nMemberCount) * 42) * RaidGrid_Party.fScaleY)
		frame:Lookup("", "Handle_BG/Text_GroupIndex"):SetRelPos(0, (216 - (5 - nMemberCount) * 42) * RaidGrid_Party.fScaleY)	
	end
	frame:Lookup("", "Handle_BG"):FormatAllItemPos()
end

------------------------------------------------------------------------------------------------------------
--��ԱѪ������
------------------------------------------------------------------------------------------------------------
function RaidGrid_Party.UpdateMemberDistance() --��Ա�������
	local player = GetClientPlayer()
	
	for i = 0, 4 do
		for nMemberIndex = 0, 4 do
			local handleRole = RaidGrid_Party.GetHandleRoleInGroup(nMemberIndex, i)
			if handleRole and handleRole.dwMemberID then
				local textDistance = handleRole:Lookup("Handle_Common/Text_Distance")
				local playerMember = GetPlayer(handleRole.dwMemberID)
				local imageDirFace = handleRole:Lookup("Image_DirFace")
				
				if not playerMember then
					if RaidGrid_CTM_Edition.bShowDistance then
						textDistance:SetText("��")
						textDistance:SetFontColor(128, 128, 128)
					else
						textDistance:SetText("")
					end
					if RaidGrid_CTM_Edition.bColorHPBarWithDistance then
						local tMemberInfo, team = RaidGrid_Party.GetTeamMemberInfo(handleRole.dwMemberID)
						if tMemberInfo and tMemberInfo.bIsOnLine then
							RaidGrid_Party.tLifeColor[handleRole.dwMemberID] = {192, 192, 192}
						else
							RaidGrid_Party.tLifeColor[handleRole.dwMemberID] = {128, 128, 128}
						end
						RaidGrid_Party.RedrawHandleRoleHPnMP(handleRole.dwMemberID)
					end
					imageDirFace:Hide()
				elseif player.dwID == handleRole.dwMemberID then
					if RaidGrid_CTM_Edition.bColorHPBarWithDistance then
						RaidGrid_Party.tLifeColor[handleRole.dwMemberID] = {RaidGrid_Party.tHPBarColor[1], RaidGrid_Party.tHPBarColor[2], RaidGrid_Party.tHPBarColor[3]}
						RaidGrid_Party.RedrawHandleRoleHPnMP(handleRole.dwMemberID)
					end
					textDistance:SetText("")
					imageDirFace:Hide()
				else
					local tArrowDelay = {2, 3, 5, 8, 12}
					local nArrowDelay = tArrowDelay[3]
					if RaidGrid_CTM_Edition.bShowDistance or RaidGrid_CTM_Edition.bColorHPBarWithDistance then
						local nDist2d = math.floor(((playerMember.nX - player.nX) ^ 2 + (playerMember.nY - player.nY) ^ 2) ^ 0.5) / 64
						for nDistLevel = 1, 5 do
							if nDist2d <= RaidGrid_Party.tDistanceLevel[nDistLevel] then
								nArrowDelay = tArrowDelay[nDistLevel]
								if RaidGrid_CTM_Edition.bShowDistance then
									if RaidGrid_CTM_Edition.bFloatNumber then
										textDistance:SetText(string.format("%.1f", nDist2d))
									else
										textDistance:SetText(math.floor(nDist2d))
									end
									textDistance:SetFontColor(255, 210, 255)
								else
									textDistance:SetText("")
								end
								if RaidGrid_CTM_Edition.bColorHPBarWithDistance then
									RaidGrid_Party.tLifeColor[handleRole.dwMemberID] = {
									RaidGrid_Party.tDistanceColor[RaidGrid_Party.tDistanceColorLevel[nDistLevel]][1],
									RaidGrid_Party.tDistanceColor[RaidGrid_Party.tDistanceColorLevel[nDistLevel]][2],
									RaidGrid_Party.tDistanceColor[RaidGrid_Party.tDistanceColorLevel[nDistLevel]][3]}
									RaidGrid_Party.RedrawHandleRoleHPnMP(handleRole.dwMemberID)
								end
								break
							end
						end
					end
					
					local bShowDirFace = RaidGrid_CTM_Edition.bShowDirFace
					local _, dwTargetID = player.GetTarget()
					if RaidGrid_CTM_Edition.bOnlySelectDirFace and dwTargetID ~= handleRole.dwMemberID then
						bShowDirFace = false
					end
					bShowDirFace = false--��ʱȡ��
					if bShowDirFace then
						imageDirFace:Show()
						local fYaw = Camera_GetYawPitchRoll()
						local nMyCameraFace = math.floor(255 - (fYaw / (3.1415927 * 2)) * 255 + 64)
						if nMyCameraFace > 254 then
							nMyCameraFace = nMyCameraFace - 255
						end
						local nTargetDir = GetLogicDirection(playerMember.nX - player.nX, playerMember.nY - player.nY)
						local nDirDiff = nMyCameraFace - nTargetDir
						if nDirDiff < 0 then
							nDirDiff = nDirDiff + 255
						end

						local nX, nY = 0, 0
						if nDirDiff <= 31 then
							nY = 0;		nX = 62 + 62 * (nDirDiff / 32)
						elseif nDirDiff <= 63 then
							nX = 123;	nY = 18 * ((nDirDiff - 31) / 32)
						elseif nDirDiff <= 95 then
							nX = 123;	nY = 18 + 18 * ((nDirDiff - 63) / 32)
						elseif nDirDiff <= 127 then
							nY = 36;	nX = 123 - 62 * ((nDirDiff - 95) / 32)
						elseif nDirDiff <= 159 then
							nY = 36;	nX = 62 - 62 * ((nDirDiff - 127) / 32)
						elseif nDirDiff <= 191 then
							nX = 0;		nY = 36 - 18 * ((nDirDiff - 159) / 32)
						elseif nDirDiff <= 223 then
							nX = 0;		nY = 18 - 18 * ((nDirDiff - 191) / 32)
						elseif nDirDiff <= 255 then
							nY = 0;		nX = 62 * ((nDirDiff - 223) / 32)
						end
						
						local nRotate = (nDirDiff - 64) * 6.2832 / 255
						nX, nY = nX - 12, nY - 9
						local nFrame = imageDirFace:GetFrame()
						if RaidGrid_CTM_Edition.bFlashArrow and RaidGrid_CTM_Edition.nSteper % nArrowDelay == 0 then
							if nFrame == 48 then
								imageDirFace:SetFrame(49)
							elseif nFrame == 49 then
								imageDirFace:SetFrame(47)
							elseif nFrame == 47 then
								imageDirFace:SetFrame(199)
								imageDirFace:SetSize(8 * RaidGrid_Party.fScaleX, 8 * RaidGrid_Party.fScaleY)
							elseif nFrame == 199 then
								imageDirFace:SetFrame(48)					
								imageDirFace:SetSize(16 * RaidGrid_Party.fScaleX, 16 * RaidGrid_Party.fScaleY)
							end
						end
						if imageDirFace:GetFrame() == 199 then
							nRotate = nRotate + 0.785
							nX, nY = nX + 5, nY + 4						
						end
						imageDirFace:SetRotate(nRotate)
						imageDirFace:SetRelPos(nX * RaidGrid_Party.fScaleX, nY * RaidGrid_Party.fScaleY)
						imageDirFace:Show()
						handleRole:FormatAllItemPos()
					else
						imageDirFace:Hide()
					end
				end
			end
		end
	end
end

local tMarkerImageList = {66, 67, 73, 74, 75, 76, 77, 78, 81, 82} --���ͼ���
function RaidGrid_Party.UpdateMarkImage() --���ͼ�����
	local team = GetClientTeam()
	local tPartyMark = team.GetTeamMark()
	if not tPartyMark then
		return
	end
	
	for i = 0, 4 do
		for nMemberIndex = 0, 4 do
			local handleRole = RaidGrid_Party.GetHandleRoleInGroup(nMemberIndex, i)
			if handleRole then
				local nMarkImageIndex = nil
				if handleRole.dwMemberID then
					nMarkImageIndex = tPartyMark[handleRole.dwMemberID]
				end
				if nMarkImageIndex and tMarkerImageList[nMarkImageIndex] and RaidGrid_CTM_Edition.bShowMark then
					local imageMark = handleRole:Lookup("Handle_Icons/Image_MarkImage")
					imageMark:SetFrame(tMarkerImageList[nMarkImageIndex])
					imageMark:Show()
					imageMark:SetAlpha(250)
					imageMark.nFlashDegSpeed = -1
				else
					local imageMark = handleRole:Lookup("Handle_Icons/Image_MarkImage")
					imageMark:Hide()
				end
			end
		end
	end
end

function RaidGrid_Party.UpdateMarkImageAlpha() --���ͼ��ALPHA����
	if not RaidGrid_CTM_Edition.bFlashMark then
		return
	end
	for i = 0, 4 do
		for nMemberIndex = 0, 4 do
			local handleRole = RaidGrid_Party.GetHandleRoleInGroup(nMemberIndex, i)
			if handleRole then
				local imageMark = handleRole:Lookup("Handle_Icons/Image_MarkImage")
				if imageMark:IsVisible() then
					local nAlpha = imageMark:GetAlpha()
					local nAlphaDiff = 0
					if nAlpha <= 10 then
						imageMark.nFlashDegSpeed = 1
					elseif nAlpha >= 250 then
						imageMark.nFlashDegSpeed = -1
					end
					if nAlpha >= 240 then
						nAlphaDiff = imageMark.nFlashDegSpeed * 1
					else
						nAlphaDiff = imageMark.nFlashDegSpeed * 40
					end
					imageMark:SetAlpha(nAlpha + nAlphaDiff)
				end
			end
		end
	end
end

function RaidGrid_Party.RedrawTargetSelectImage(bForceHide)  --�ػ�Ŀ��ѡ��ͼ��
	if not RaidGrid_CTM_Edition.bShowSelectImage and not RaidGrid_CTM_Edition.bShowTargetTargetAni and not bForceHide then
		return
	end
	local player = GetClientPlayer()
	if not player then
		return
	end
	local _, dwTargetID = player.GetTarget()
	local target = GetNpc(dwTargetID)
	if IsPlayer(dwTargetID) then
		target = GetPlayer(dwTargetID)
	end

	local targetTarget = nil
	if target then
		local _, dwTargetTargetID = target.GetTarget()
		targetTarget = GetNpc(dwTargetTargetID)
		if IsPlayer(dwTargetTargetID) then
			targetTarget = GetPlayer(dwTargetTargetID)
		end
	end

	for nGroupIndex = 0, 4 do
		for nMemberIndex = 0, 4 do
			local handleRole = RaidGrid_Party.GetHandleRoleInGroup(nMemberIndex, nGroupIndex)
			if handleRole and handleRole.dwMemberID then
				local imageSelected = handleRole:Lookup("Image_Selected")
				if not bForceHide and RaidGrid_CTM_Edition.bShowSelectImage and target and target.dwID == handleRole.dwMemberID then
					imageSelected:Show()
				else
					imageSelected:Hide()
				end
				
				local aniTargetTarget = handleRole:Lookup("Animate_TargetTarget")
				if not bForceHide and RaidGrid_CTM_Edition.bShowTargetTargetAni and target and targetTarget and targetTarget.dwID == handleRole.dwMemberID then
					aniTargetTarget:Show()
				else
					aniTargetTarget:Hide()
				end				
			end
		end
	end
end

function RaidGrid_Party.RedrawHandleRoleInfoEx(dwMemberID)  --�ػ洦����ɫ��ϢEX
	local nMemberIndex, nGroupIndex = RaidGrid_Party.GetMemberIndexInGroup(dwMemberID)
	if not nMemberIndex then
		return
	end
	
	local handleRole = RaidGrid_Party.GetHandleRoleInGroup(nMemberIndex, nGroupIndex)
	if not handleRole then
		return
	end
	
	local tMemberInfo, team = RaidGrid_Party.GetTeamMemberInfo(dwMemberID)
	if not tMemberInfo then
		return
	end

	local textLife = handleRole:Lookup("Handle_Common/Text_Life")	
	local nRed, nGreen, nBlue, dwForceID = RaidGrid_Party.GetCharacterColor(dwMemberID, tMemberInfo.dwForceID)
	if not tMemberInfo.bIsOnLine then
		RaidGrid_Party.tLifeColor[dwMemberID] = {128, 128, 128}
		--RaidGrid_Party.RedrawHandleRoleHPnMP(dwMemberID)
		textLife:SetFontColor(128, 128, 128)
		textLife:SetText("����")
	elseif tMemberInfo.bDeathFlag then
		RaidGrid_Party.tLifeColor[dwMemberID] = {255, 0, 0}
		--RaidGrid_Party.RedrawHandleRoleHPnMP(dwMemberID)
		textLife:SetFontColor(255, 0, 0)
		textLife:SetText("����")
	else
		local nRedOnline, nGreenOnline, nBlueOnline = RaidGrid_Party.tHPBarColor[1], RaidGrid_Party.tHPBarColor[2], RaidGrid_Party.tHPBarColor[3]
		if not RaidGrid_CTM_Edition.bColorHPBarWithDistance then
			RaidGrid_Party.tLifeColor[dwMemberID] = {nRedOnline, nGreenOnline, nBlueOnline}
			--RaidGrid_Party.RedrawHandleRoleHPnMP(dwMemberID)
		end
		textLife:SetFontColor(255, 255, 255)
	end

	local textName = handleRole:Lookup("Text_Name_2")
	textName:SetText(tMemberInfo.szName)
	if RaidGrid_CTM_Edition.bColoredName then
		textName:SetFontColor(nRed, nGreen, nBlue)
	else
		textName:SetFontColor(255, 255, 255)
	end
	
	RaidGrid_Party.RedrawMemberCampImage(handleRole, tMemberInfo.nCamp)
end

function RaidGrid_Party.RedrawHandleRoleInfo(dwMemberID)  --�ػ洦����ɫ��Ϣ
	local nMemberIndex, nGroupIndex = RaidGrid_Party.GetMemberIndexInGroup(dwMemberID)
	if not nMemberIndex then
		return
	end
	
	local handleRole = RaidGrid_Party.GetHandleRoleInGroup(nMemberIndex, nGroupIndex)
	if not handleRole then
		return
	end
	
	local tMemberInfo, team = RaidGrid_Party.GetTeamMemberInfo(dwMemberID)
	if not tMemberInfo then
		return
	end
	
	local imageLeader = handleRole:Lookup("Handle_Icons/Image_Leader")
	if team.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.LEADER) == dwMemberID then
		imageLeader:Show()
	else
		imageLeader:Hide()
	end
	
	local imageLooter = handleRole:Lookup("Handle_Icons/Image_Looter")
	if team.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.DISTRIBUTE) == dwMemberID then
		imageLooter:Show()
	else
		imageLooter:Hide()
	end
	
	local imageMarker = handleRole:Lookup("Handle_Icons/Image_Marker")
	if team.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.MARK) == dwMemberID then
		imageMarker:Show()
	else
		imageMarker:Hide()
	end
	
	local imageMatrixcore = handleRole:Lookup("Handle_Icons/Image_Matrix")
	imageMatrixcore:Hide()
	for i = 0, math.min(4, team.nGroupNum - 1) do
		local tGroupInfo = team.GetGroupInfo(i)
		if tGroupInfo and tGroupInfo.MemberList and #tGroupInfo.MemberList > 0 and tGroupInfo.dwFormationLeader == dwMemberID then
			imageMatrixcore:Show()
			break;
		end
	end
	
	RaidGrid_Party.RedrawMemberCampImage(handleRole, tMemberInfo.nCamp)
	
	local imageForce = handleRole:Lookup("Handle_Icons/Image_Force")
	local imageKungfu = handleRole:Lookup("Handle_Icons/Image_Kungfu")
	local dwMountKungfuID = tMemberInfo.dwMountKungfuID
	local dwForceID = tMemberInfo.dwForceID
	if dwMountKungfuID then
		RaidGrid_CTM_Edition.bIsSynKungfu = true
	end
	if RaidGrid_CTM_Edition.bShowForceIcon or RaidGrid_CTM_Edition.bShowKungfuIcon then
		if dwMountKungfuID and RaidGrid_CTM_Edition.bShowKungfuIcon then
			local nIconID = Table_GetSkillIconID(dwMountKungfuID, 0)
			if nIconID then
				imageKungfu:FromIconID(nIconID)
				if RaidGrid_Party.fScaleX ~= RaidGrid_Party.fScaleY then
					local szImageSize = 28
					if RaidGrid_Party.fScaleX > RaidGrid_Party.fScaleY then
						szImageSize = szImageSize * RaidGrid_Party.fScaleY
						imageKungfu:SetSize(szImageSize, szImageSize)
					else
						szImageSize = szImageSize * RaidGrid_Party.fScaleX
						imageKungfu:SetSize(szImageSize, szImageSize)
					end
				end
				imageKungfu:Show()
			else
				imageKungfu:Hide()
			end
			imageForce:Hide()
		else
			local tForceID2Frame = {
				[0] = 64,
				[1] = 59,
				[2] = 63,
				[3] = 62,
				[4] = 49,
				[5] = 56,
				[6] = 107,
				[7] = 108,
				[8] = 88,
				[9] = 110,
				[10] = 109
			}
			if tForceID2Frame[dwForceID] then
				imageForce:SetFrame(tForceID2Frame[dwForceID])				
				if RaidGrid_Party.fScaleX ~= RaidGrid_Party.fScaleY then
					local szImageSize = 28
					if RaidGrid_Party.fScaleX > RaidGrid_Party.fScaleY then
						szImageSize = szImageSize * RaidGrid_Party.fScaleY
						imageForce:SetSize(szImageSize, szImageSize)
					else
						szImageSize = szImageSize * RaidGrid_Party.fScaleX
						imageForce:SetSize(szImageSize, szImageSize)
					end
				end
				imageForce:Show()
			else
				imageForce:Hide()
			end
			imageKungfu:Hide()
		end
	else
		imageForce:Hide()
		imageKungfu:Hide()
	end
	
	for i = 0, 8 do
		local imageForceBG = handleRole:Lookup("Handle_Common/Image_BG_Force" .. i)
		local dwForceID_Clone = dwForceID
		if not RaidGrid_CTM_Edition.bColoredGrid then
			dwForceID_Clone = -1
		end
		if imageForceBG then
			if i == dwForceID_Clone then
				imageForceBG:Show()
			else
				imageForceBG:Hide()
			end
		end
		imageForceBG = handleRole:Lookup("Handle_Common/Image_BG_Force")
		if dwForceID_Clone == -1 then
			imageForceBG:Show()
		end
	end
end

function RaidGrid_Party.RedrawMemberCampImage(handleRole, nCamp)  --�ػ��Ա��Ӫͼ��
	if not handleRole then
		return
	end
	local tcamp = {
		["ALL"] = -1;
		["NEUTRAL"] = 0;
		["GOOD"] = 1;--CAMP.GOOD
		["EVIL"] = 2;
	}
	local imageCamp = handleRole:Lookup("Handle_Icons/Image_Camp")
	local nFrame = 7
	if not nCamp or not RaidGrid_CTM_Edition.bShowCampIcon then
		imageCamp:Hide()
		imageCamp.nFrame = -1
	elseif nCamp == tcamp.GOOD then
		imageCamp:Show()
		if nFrame ~= (imageCamp.nFrame or -1) then
			imageCamp.nFrame = 7
			imageCamp:SetFrame(imageCamp.nFrame)
		end
	elseif nCamp == tcamp.EVIL then
		imageCamp:Show()
		if nFrame ~= (imageCamp.nFrame or -1) then
			imageCamp.nFrame = 5
			imageCamp:SetFrame(imageCamp.nFrame)
		end
	else
		imageCamp:Hide()
		imageCamp.nFrame = -1
	end
end

function RaidGrid_Party.RedrawAllFadeHP(bForceHide)  --�ػ浱ǰѪ��
	if not RaidGrid_CTM_Edition.bHPHitAlert and not bForceHide then
		return
	end
	
	for nGroupIndex = 0, 4 do
		for nMemberIndex = 0, 4 do
			local handleRole = RaidGrid_Party.GetHandleRoleInGroup(nMemberIndex, nGroupIndex)
			if handleRole and handleRole.dwMemberID then
				local shadowLifeFade = handleRole:Lookup("Handle_Common/Shadow_Life_Fade")
				local nFadeAlpha = math.max(shadowLifeFade:GetAlpha() - 10, 0)
				if bForceHide then
					nFadeAlpha = 0
				end
				shadowLifeFade:SetAlpha(nFadeAlpha)
			end
		end
	end
end

function RaidGrid_Party.RedrawHandleRoleHPnMP(dwMemberID)  --HP&MP���
	local nMemberIndex, nGroupIndex = RaidGrid_Party.GetMemberIndexInGroup(dwMemberID)
	if not nMemberIndex then
		return
	end

	local handleRole = RaidGrid_Party.GetHandleRoleInGroup(nMemberIndex, nGroupIndex)
	if not handleRole then
		return
	end

	local tMemberInfo, team = RaidGrid_Party.GetTeamMemberInfo(dwMemberID)
	if not tMemberInfo then
		return
	end

	local nHPHeight = 24
	local nMPHeight = 14
	if RaidGrid_CTM_Edition.bLowMPBar then
		nHPHeight = 29
		nMPHeight = 9
	end

	local playerMember = GetPlayer(dwMemberID)
	local shadowMana = handleRole:Lookup("Handle_Common/Shadow_Mana")
	local nManaShow = 0
	local nPercentage = nil
	local r, g, b = 255, 255, 255
	if playerMember and playerMember.dwForceID == 8 and playerMember.nCurrentRage and playerMember.nMaxRage then --������ͼ
		local nCurrentRage = playerMember.nCurrentRage
		local nMaxRage = playerMember.nMaxRage
		local nRagePercentage = nCurrentRage / nMaxRage
		if nMaxRage <= 100 then
			r, g, b = 255, 110, 0
		else
			r, g, b = 255, 170, 0
		end
		nPercentage = nRagePercentage
		nManaShow = nCurrentRage
		--[[
	elseif playerMember and playerMember.dwForceID == 10 and playerMember.nCurrentSunEnergy and playerMember.nMaxSunEnergy and playerMember.nCurrentSunEnergy > 0 then --������ͼ
		local nCurrentSunEnergy = playerMember.nCurrentSunEnergy
		local nMaxSunEnergy = playerMember.nMaxSunEnergy
		local nRagePercentage = nCurrentSunEnergy / nMaxSunEnergy
		if nMaxSunEnergy <= 100 then
			r, g, b = 255, 110, 0
		else
			r, g, b = 255, 170, 0
		end
		nPercentage = nRagePercentage
		nManaShow = nCurrentSunEnergy
		--]]
	elseif playerMember and playerMember.dwForceID == 7 and playerMember.nCurrentEnergy and playerMember.nMaxEnergy and playerMember.nCurrentEnergy > 0 then --���ֵ��ͼ
		local nCurrentEnergy = playerMember.nCurrentEnergy
		local nMaxEnergy = playerMember.nMaxEnergy
		local nEnergyPercentage = nCurrentEnergy / nMaxEnergy
		r, g, b = (192 + nEnergyPercentage * (255 - 192)), (192 + nEnergyPercentage * (255 - 192)), 250
		nPercentage = nEnergyPercentage
		nManaShow = nCurrentEnergy
	else
		local nManaPercentage = tMemberInfo.nCurrentMana / tMemberInfo.nMaxMana
		r, g, b = 0, 96, 255
		nPercentage = nManaPercentage
		nManaShow = tMemberInfo.nCurrentMana
	end
	if not nPercentage or nPercentage < 0 or nPercentage > 1 then nPercentage = 1 end
	RaidGrid_Party.RedrawTriangleFan(shadowMana, 121 * RaidGrid_Party.fScaleX * nPercentage, nMPHeight * RaidGrid_Party.fScaleY, r, g, b,RaidGrid_Party.Shadow.bMana)

	local nLifePercentage = tMemberInfo.nCurrentLife / tMemberInfo.nMaxLife
	local shadowLife = handleRole:Lookup("Handle_Common/Shadow_Life")
	local shadowLifeFade = handleRole:Lookup("Handle_Common/Shadow_Life_Fade")
	local shadowLifeWarn = handleRole:Lookup("Handle_Common/Shadow_Life_Warn")
	if not RaidGrid_Party.tOrgW[dwMemberID] then
		RaidGrid_Party.tOrgW[dwMemberID] = 121 * RaidGrid_Party.fScaleX
	end
	local nNewW = 121 * nLifePercentage * RaidGrid_Party.fScaleX
	if not RaidGrid_Party.tLifeColor[dwMemberID] then
		RaidGrid_Party.tLifeColor[dwMemberID] = {255,255,255}
	end

	RaidGrid_Party.RedrawTriangleFan(shadowLife, nNewW, nHPHeight * RaidGrid_Party.fScaleY, RaidGrid_Party.tLifeColor[dwMemberID][1], RaidGrid_Party.tLifeColor[dwMemberID][2], RaidGrid_Party.tLifeColor[dwMemberID][3],RaidGrid_Party.Shadow.bLife)
	
	-- ����Ч����ʾ
	if RaidGrid_CTM_Edition.bHPHitAlert then
		local nOrgFadeW = shadowLifeFade:GetSize()
		local nFadeAlpha = shadowLifeFade:GetAlpha()
		local nDiff = nOrgFadeW - RaidGrid_Party.tOrgW[dwMemberID]
		local nNewFadeW = RaidGrid_Party.tOrgW[dwMemberID]
		
		if nNewW < RaidGrid_Party.tOrgW[dwMemberID] then
			if nFadeAlpha <= 0 then
				nNewFadeW = RaidGrid_Party.tOrgW[dwMemberID]
			else
				nNewFadeW = nOrgFadeW
			end
			shadowLifeFade:SetAlpha(240)
		else
			if nFadeAlpha <= 0 then
				nNewFadeW = nNewW
			else
				nNewFadeW = nNewW + nDiff
			end
		end
		if nNewFadeW >= 121 * RaidGrid_Party.fScaleX then
			nNewFadeW = 121 * RaidGrid_Party.fScaleX
		end
		shadowLifeFade:SetSize(nNewFadeW, nHPHeight * RaidGrid_Party.fScaleY)
	else
		shadowLifeFade:SetSize(0, nHPHeight * RaidGrid_Party.fScaleY)
	end

	RaidGrid_Party.tOrgW[dwMemberID] = nNewW

	-- ������ɫѪ��
	if RaidGrid_CTM_Edition.bHPColorBar then
		if nLifePercentage <= 0.3 then
			shadowLifeWarn:SetColorRGB(255, 0, 0)
		elseif nLifePercentage <= 0.45 then
			shadowLifeWarn:SetColorRGB(255, 100, 0)
		elseif nLifePercentage <= 0.6 then
			shadowLifeWarn:SetColorRGB(255, 255, 0)
		elseif nLifePercentage <= 0.8 then
			shadowLifeWarn:SetColorRGB(100, 255, 0)
		else
			shadowLifeWarn:SetColorRGB(0, 255, 0)
		end
		shadowLifeWarn:SetSize(nNewW, 2 * RaidGrid_Party.fScaleY)
	else
		shadowLifeWarn:SetSize(0, 2 * RaidGrid_Party.fScaleY)
	end
	
	-- Ѫ����ʾ
	local textLife = handleRole:Lookup("Handle_Common/Text_Life")
	if tMemberInfo.bDeathFlag or not tMemberInfo.bIsOnLine then
	elseif not RaidGrid_CTM_Edition.nHPShownMode or RaidGrid_CTM_Edition.nHPShownMode == 0 then
		textLife:SetText("")
	elseif RaidGrid_CTM_Edition.nHPShownMode == 1 then
		local nShownLife = tMemberInfo.nMaxLife - tMemberInfo.nCurrentLife
		if nShownLife > 0 then
			textLife:SetText("-" .. nShownLife)
		else
			textLife:SetText("")
		end
	elseif RaidGrid_CTM_Edition.nHPShownMode == 2 then
		textLife:SetText(tMemberInfo.nCurrentLife)
	elseif RaidGrid_CTM_Edition.nHPShownMode == 3 then
		if RaidGrid_CTM_Edition.bFloatNumber then
			textLife:SetText(string.format("%.1f", nLifePercentage * 100) .. "%")
		else
			textLife:SetText(math.floor(nLifePercentage * 100) .. "%")
		end
	end
	
	-- ����ʾ
	local textMana = handleRole:Lookup("Handle_Common/Text_Mana")
	if not RaidGrid_CTM_Edition.nShowMP then
		textMana:SetText("")
	else
		textMana:SetText(nManaShow)
	end
end

function RaidGrid_Party.GetTeamMemberInfo(dwMemberID)	--��ó�Ա��Ϣ
	local player = GetClientPlayer()
	if not player or not player.IsInParty() or not player.IsPlayerInMyParty(dwMemberID) then
		return
	end

	local team = GetClientTeam()
	if not team then
		return
	end	

	local tMemberInfo = nil
	local tMemberInfo = team.GetMemberInfo(dwMemberID)
	if not tMemberInfo then
		return
	end

	tMemberInfo.nX = tMemberInfo.nPosX
	tMemberInfo.nY = tMemberInfo.nPosY
	return tMemberInfo, team
end

------------------------------------------------------------------------------------------------------------
--��Ա�������
------------------------------------------------------------------------------------------------------------
function RaidGrid_Party.InitReadyCheckCover()	--��Ա������ʾ
	if not GetClientPlayer().IsInParty() then
		return
	end
	
	local team = GetClientTeam()
	if team.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.LEADER) ~= GetClientPlayer().dwID then
		return
	end
	--[[
	if not RaidPanel or not RaidPanel.StartReadyConfirm then
		return
	end	
	RaidPanel.StartReadyConfirm()
	--]]
	Send_RaidReadyConfirm()
	
	for nGroupIndex = 0, 4 do
		for nMemberIndex = 0, 4 do
			local handleRole = RaidGrid_Party.GetHandleRoleInGroup(nMemberIndex, nGroupIndex)
			if handleRole then
				local imageReadyCover = handleRole:Lookup("Image_ReadyCover")
				local imageNotReady = handleRole:Lookup("Image_NotReady")
				local aniReady = handleRole:Lookup("Animate_Ready")
				
				if handleRole.dwMemberID and handleRole.dwMemberID ~= GetClientPlayer().dwID then
					local tMemberInfo, team = RaidGrid_Party.GetTeamMemberInfo(handleRole.dwMemberID)
					if tMemberInfo and tMemberInfo.bIsOnLine then
						imageReadyCover:Show()
						imageReadyCover:SetAlpha(255)
						imageNotReady:Hide()
						aniReady:Hide()
					else
						imageReadyCover:Hide()
						imageNotReady:Hide()
						aniReady:Hide()
					end
				else
					imageReadyCover:Hide()
					imageNotReady:Hide()
					aniReady:Hide()
				end
			end
		end
	end
end

function RaidGrid_Party.ClearReadyCheckCover()	--���������ʾ
	for nGroupIndex = 0, 4 do
		for nMemberIndex = 0, 4 do
			local handleRole = RaidGrid_Party.GetHandleRoleInGroup(nMemberIndex, nGroupIndex)
			if handleRole then
				local imageReadyCover = handleRole:Lookup("Image_ReadyCover")
				local imageNotReady = handleRole:Lookup("Image_NotReady")
				local aniReady = handleRole:Lookup("Animate_Ready")
				imageReadyCover:Hide()
				imageNotReady:Hide()
				aniReady:Hide()
			end
		end
	end
end

function RaidGrid_Party.UpdateReadyCheckCover(dwMemberID, nReadyState)	--���¾�����ʾ
	local nMemberIndex, nGroupIndex = RaidGrid_Party.GetMemberIndexInGroup(dwMemberID)
	if not nMemberIndex then
		return
	end
	
	local handleRole = RaidGrid_Party.GetHandleRoleInGroup(nMemberIndex, nGroupIndex)
	if not handleRole then
		return
	end
	
	local imageNotReady = handleRole:Lookup("Image_NotReady")
	local aniReady = handleRole:Lookup("Animate_Ready")
	if nReadyState == 1 then
		imageNotReady:Hide()
		if RaidGrid_CTM_Edition.bCheckReadyFlash then
			aniReady:Show()
			aniReady:SetAlpha(255)
		else
			aniReady:Hide()
		end
	else
		aniReady:Hide()
		imageNotReady:Show()
	end
end

function RaidGrid_Party.UpdateReadyCheckFade(bForceHide)	--���¾����������
	if not RaidGrid_CTM_Edition.bCheckReadyFlash and not bForceHide then
		return
	end
	if not GetClientPlayer().IsInParty() then
		return
	end
	local team = GetClientTeam()
	if team.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.LEADER) ~= GetClientPlayer().dwID then
		return
	end

	for nGroupIndex = 0, 4 do
		for nMemberIndex = 0, 4 do
			local handleRole = RaidGrid_Party.GetHandleRoleInGroup(nMemberIndex, nGroupIndex)
			if handleRole then
				local imageReadyCover = handleRole:Lookup("Image_ReadyCover")
				local imageNotReady = handleRole:Lookup("Image_NotReady")
				local aniReady = handleRole:Lookup("Animate_Ready")
				if aniReady:IsVisible() then
					aniReady:SetAlpha(math.max(aniReady:GetAlpha() - 15, 0))
					imageReadyCover:SetAlpha(math.max(imageReadyCover:GetAlpha() - 30, 0))
				end
				if bForceHide or (aniReady:GetAlpha() <= 0 and imageReadyCover:GetAlpha() <= 0) then
					imageReadyCover:Hide()
					imageNotReady:Hide()
					aniReady:Hide()
				end		
			end
		end
	end
end

function RaidGrid_Party.UpdateTeamCasting(bForceHide)	--������Ա�ͷ�
	if (not GetClientPlayer().IsInParty() or not RaidGrid_CTM_Edition.bShowTeamateCasting) and not bForceHide then
		return
	end

	local nCBHeight = 13
	if RaidGrid_CTM_Edition.bLowMPBar then
		nCBHeight = 8
	end

	for nGroupIndex = 0, 4 do
		for nMemberIndex = 0, 4 do
			local handleRole = RaidGrid_Party.GetHandleRoleInGroup(nMemberIndex, nGroupIndex)
			if handleRole and handleRole.dwMemberID then
				local player = GetPlayer(handleRole.dwMemberID)
				if player then
					local handleCasting = handleRole:Lookup("Handle_CastingBar")
					local bPrePare, dwSkillID, dwSkillLevel, fCastPercent = player.GetSkillPrepareState()
					if not bPrePare or bForceHide then
						handleCasting:Hide()
					else
						handleCasting:Show()
						local nIconID = Table_GetSkillIconID(dwSkillID, dwSkillLevel)
						local box = handleCasting:Lookup("Box_CastingIcon")
						box:SetObjectIcon(nIconID or 1435)
						
						local imageCasting = handleCasting:Lookup("Image_CastP")
						imageCasting:SetSize(102 * fCastPercent * RaidGrid_Party.fScaleX, nCBHeight * RaidGrid_Party.fScaleY)
						
						local imageCastingEnd = handleCasting:Lookup("Image_CastPEnd")
						local _, nCastingEndY = imageCastingEnd:GetRelPos()
						imageCastingEnd:SetRelPos((10 + 99 * fCastPercent) * RaidGrid_Party.fScaleX, nCastingEndY)

						local aniCastingEnd = handleCasting:Lookup("Animate_CastPEnd")
						_, nCastingEndY = aniCastingEnd:GetRelPos()
						aniCastingEnd:SetRelPos((14 + 99 * fCastPercent) * RaidGrid_Party.fScaleX, nCastingEndY)
						
						handleCasting:FormatAllItemPos()					
					end
				end
			end
		end
	end
end

------------------------------------------------------------------------------------------------------------
--[[ѡ�����&��Ա����]]
------------------------------------------------------------------------------------------------------------
function RaidGrid_Party.ShowHandleRoleInGroup(nIndex, nGroupIndex, dwMemberID) --��ʾ������
	local handleRole = RaidGrid_Party.GetHandleRoleInGroup(nIndex, nGroupIndex)
	if not handleRole then
		return
	end

	handleRole.dwMemberID = dwMemberID
	handleRole:Lookup("Handle_Common"):Show()
	handleRole:Lookup("Handle_Buff_Boxes"):Show()
	handleRole:Lookup("Handle_Icons"):Show()
	
	handleRole:Lookup("Image_Selected"):Hide()
	handleRole:Lookup("Animate_TargetTarget"):Hide()
	
	handleRole:Lookup("Image_BG_Slot"):Hide()
end

function RaidGrid_Party.ClearHandleRoleInGroup(nIndex, nGroupIndex) --���������
	local handleRole = RaidGrid_Party.GetHandleRoleInGroup(nIndex, nGroupIndex)
	if not handleRole then
		return
	end

	handleRole.dwMemberID = nil
	handleRole:Lookup("Handle_Common"):Hide()
	handleRole:Lookup("Handle_Icons"):Hide()
	
	handleRole:Lookup("Image_Selected"):Hide()
	handleRole:Lookup("Animate_TargetTarget"):Hide()
	handleRole:Lookup("Animate_TargetTarget"):SetAlpha(170)
	
	if RaidGrid_CTM_Edition.bShowAllMemberGrid then
		handleRole:Lookup("Image_BG_Slot"):Show()
	else
		handleRole:Lookup("Image_BG_Slot"):Hide()
	end
	
	handleRole:Lookup("Image_DirFace"):Hide()
	
	handleRole:Lookup("Image_ReadyCover"):Hide()
	handleRole:Lookup("Image_NotReady"):Hide()
	handleRole:Lookup("Animate_Ready"):Hide()
	
	handleRole:Lookup("Handle_CastingBar"):Hide()
	
	local handleBoxes = handleRole:Lookup("Handle_Buff_Boxes")
	for i = 1, 4 do
		local box = handleBoxes:Lookup("Box_" .. i)
		local shadow = handleBoxes:Lookup("Shadow_BuffColor_" .. i)
		local text = handleBoxes:Lookup("Text_Time_" .. i)
		text:Hide()
		shadow:Hide()
		box:Hide()
		box.tInfo = nil
	end
	handleBoxes:Hide()
end

function RaidGrid_Party.GetMemberIndexInGroup(dwMemberID)	--����������
	for nGroupIndex = 0, 4 do
		for i = 0, 4 do
			local handleRole = RaidGrid_Party.GetHandleRoleInGroup(i, nGroupIndex)
			if handleRole and handleRole.dwMemberID == dwMemberID then
				return i, nGroupIndex
			end
		end
	end
end

function RaidGrid_Party.GetHandleRoleInGroup(nIndex, nGroupIndex)	--���ѡ�еĶ����Ա
	local frame = RaidGrid_Party.GetPartyPanel(nGroupIndex)
	if not frame then
		return
	end

	if not nIndex or nIndex < 0 or nIndex > 4 then
		return
	end
	return frame.tHandleRoles[nIndex]
end

function RaidGrid_Party.GetCharacterColor(dwCharacterID, dwForceID) --��ó�Ա��ɫ
	local player = GetClientPlayer()
	if not player then
		return 128, 128, 128, 0
	end
	if not IsPlayer(dwCharacterID) then
		return 168, 168, 168, 0
	end
	
	if not dwForceID then
		local target = GetPlayer(dwCharacterID)
		if not target then
			return 128, 128, 128, 0
		end
		
		dwForceID = target.dwForceID
		if not dwForceID then
			return 168, 168, 168, 0
		end
	end

	if dwForceID == 0 then		-- ��
		return 255, 255, 255, dwForceID
	elseif dwForceID == 1 then	-- ����
		return 255, 255, 170, dwForceID
	elseif dwForceID == 2 then	-- ��
		return 175, 25, 255, dwForceID
	elseif dwForceID == 3 then	-- ���
		return 250, 75, 100, dwForceID
	elseif dwForceID == 4 then	-- ����
		return 148, 178, 255, dwForceID  
	elseif dwForceID == 5 then	-- ����
		return 255, 125, 255, dwForceID
	elseif dwForceID == 6 then	-- �嶾
		return 140, 80, 255, dwForceID
	elseif dwForceID == 7 then  -- ����
		return 0, 128, 192, dwForceID
	elseif dwForceID == 8 then	-- �ؽ�
		return 255, 200, 0, dwForceID
	elseif dwForceID == 9 then	-- ؤ��
		return 185, 125, 60, dwForceID	
	elseif dwForceID == 10 then	-- ����
		return 240, 50	, 200, dwForceID
	end
	return 168, 168, 168, 0
end

function RaidGrid_Party.SetTarget(dwTargetID)	--����Ŀ��
	local nType = TARGET.NPC
	if not dwTargetID or (dwTargetID <= 0) then
		nType = TARGET.NO_TARGET
		dwTargetID = 0
	elseif IsPlayer(dwTargetID) then
		nType = TARGET.PLAYER
	end
	if SetTarget then
		local as0, as1 = arg0, arg1
		SetTarget(nType, dwTargetID)
		arg0, arg1 = as0, as1
	elseif SelectTarget then
		SelectTarget(nType, dwTargetID)
	end
end

function RaidGrid_Party.SetTempTarget(dwMemberID, bEnter)
	if not RaidGrid_Party.bTempTargetEnable then
		return
	end
	local player = GetClientPlayer()
	if not player then
		return
	end
	if not dwMemberID or dwMemberID <= 0 then
		return
	end
	local tarType, tardwID = player.GetTarget()
	if bEnter then
		RaidGrid_Party.dwLastTempTargetId = tardwID
		if dwMemberID ~= tardwID then
			if player.dwID == dwMemberID then
				--Player.OnItemLButtonDown()
				if IsCtrlKeyDown() then
					RaidGrid_Party.SetTarget(dwMemberID)
				end
			else
				RaidGrid_Party.SetTarget(dwMemberID)
			end
		end
	else
		if RaidGrid_Party.dwLastTempTargetId then
			if (dwMemberID == tardwID or tardwID <= 0) and RaidGrid_Party.dwLastTempTargetId ~= tardwID then
				if player.dwID == RaidGrid_Party.dwLastTempTargetId then
					RaidGrid_Party.SetTarget(RaidGrid_Party.dwLastTempTargetId)
				elseif RaidGrid_Party.dwLastTempTargetId > 0 then
					RaidGrid_Party.SetTarget(RaidGrid_Party.dwLastTempTargetId)
				else
					RaidGrid_Party.SetTarget(-1)
				end
			end
		end
		--RaidGrid_Party.dwLastTempTargetId = 0
	end
end


function RaidGrid_Party.RedrawTriangleFan(shadow, x, y, r, g, b,bPureColour) --�ػ�������
	shadow:SetTriangleFan(true)
	shadow:ClearTriangleFanPoint()
	local a = RaidGrid_Party.Shadow.a
	local d = RaidGrid_Party.Shadow.d
	if not bPureColour then
		shadow:AppendTriangleFanPoint(	0,	0,	64,	64,	64,	a) --x,y,r,g,b,alpha
		shadow:AppendTriangleFanPoint(	x,	0,	64,	64,	64,	a)
		shadow:AppendTriangleFanPoint(	x,	y,	r,	g,	b,	a)
		shadow:AppendTriangleFanPoint(	0,	y,	r,	g,	b,	a)
	else
		local r2 = math.ceil(r*d)
		local g2 = math.ceil(g*d)
		local b2 = math.ceil(b*d)
		shadow:AppendTriangleFanPoint(	0,	0,	r2,	g2,	b2,	a) --x,y,r,g,b,alpha
		shadow:AppendTriangleFanPoint(	x,	0,	r2,	g2,	b2,	a)
		shadow:AppendTriangleFanPoint(	x,	y,	r2,	g2,	b2,	a)
		shadow:AppendTriangleFanPoint(	0,	y,	r2,	g2,	b2,	a)	
	end
end



------------------------------------------------------------------------------------------------------------
--������
------------------------------------------------------------------------------------------------------------
function RaidGrid_Party.GetPartyPanel(nIndex) --���������
	if not nIndex or nIndex < 0 or nIndex > 4 then
		return
	end
	return Station.Lookup("Normal/RaidGrid_Party_" .. nIndex)
end

function RaidGrid_Party.AutoLinkAllPanel2()	--�Զ������������2
	local player = GetClientPlayer()
	if not player or not player.IsInParty() then
		return
	end
	
	local team = GetClientTeam()
	if not team then
		return
	end	

	local frameMain = Station.Lookup("Normal/RaidGrid_CTM_Edition")
	if not frameMain then
		return
	end
	local nX, nY = frameMain:GetRelPos()
	nY = nY + 24
	
	local nShownCount = 0
	local tPosnSize = {[-1] = {nX = nX, nY = nY, nW = 0, nH = 0}}
	local nGroupNum = team.nGroupNum
	for i = 0, nGroupNum - 1 do
		local framePartyPanel = RaidGrid_Party.GetPartyPanel(i)
		if framePartyPanel and (RaidGrid_CTM_Edition.bShowAllPanel or RaidGrid_Party.IsPartyOpened(i)) then
			local tGroupInfo = team.GetGroupInfo(i)
			local nMemberCount = #tGroupInfo.MemberList
			local nW, nH = 128 * RaidGrid_Party.fScaleX, (235 - (5 - nMemberCount) * 42) * RaidGrid_Party.fScaleY + 1
			framePartyPanel:SetSize(nW, nH)
			
			if nShownCount < RaidGrid_CTM_Edition.nAutoLinkMode then
				tPosnSize[nShownCount] = {nX = nX + (128 * RaidGrid_Party.fScaleX * nShownCount), nY = nY, nW = nW, nH = nH}
			else
				local nUpperIndex = math.min(nShownCount - RaidGrid_CTM_Edition.nAutoLinkMode, RaidGrid_CTM_Edition.nAutoLinkMode - 1)
				local tPS = tPosnSize[nUpperIndex] or {nH = 235 * RaidGrid_Party.fScaleY}
				tPosnSize[nShownCount] = {
					nX = nX + (128 * RaidGrid_Party.fScaleX * (nShownCount - RaidGrid_CTM_Edition.nAutoLinkMode)),
					nY = nY + tPosnSize[nUpperIndex].nH,
					nW = nW,
					nH = nH}
			end
			RaidGrid_CTM_Edition.SetPartyPanelPos(i, tPosnSize[nShownCount].nX, tPosnSize[nShownCount].nY)
			nShownCount = nShownCount + 1
		end
	end
end

function RaidGrid_Party.AutoLinkAllPanel() --�Զ������������
	local frameMain = Station.Lookup("Normal/RaidGrid_CTM_Edition")
	if not frameMain then
		return
	end
	local nX, nY = frameMain:GetRelPos()
	nY = nY + 24
	local nShownCount = 0
	local tPosnSize = {[-1] = {nX = nX, nY = nY, nW = 0, nH = 0}}
	
	for i = 0, 4 do
		local framePartyPanel = RaidGrid_Party.GetPartyPanel(i)
		if framePartyPanel and (RaidGrid_CTM_Edition.bShowAllPanel or RaidGrid_Party.IsPartyOpened(i)) then
			local nW, nH = framePartyPanel:GetSize()
			--_, nH = framePartyPanel:Lookup("", "Handle_BG/Image_BG_B"):GetRelPos()
			--nH = nH + 16
			--framePartyPanel:SetSize(nW, nH)
			
			if nShownCount < RaidGrid_CTM_Edition.nAutoLinkMode then
				tPosnSize[nShownCount] = {nX = nX + (128 * RaidGrid_Party.fScaleX * nShownCount), nY = nY, nW = nW, nH = nH}
			else
				local nUpperIndex = math.min(nShownCount - RaidGrid_CTM_Edition.nAutoLinkMode, RaidGrid_CTM_Edition.nAutoLinkMode - 1)
				local tPS = tPosnSize[nUpperIndex] or {nH = 235 * RaidGrid_Party.fScaleY}
				tPosnSize[nShownCount] = {
					nX = nX + (128 * RaidGrid_Party.fScaleX * (nShownCount - RaidGrid_CTM_Edition.nAutoLinkMode)),
					nY = nY + tPosnSize[nUpperIndex].nH,
					nW = nW,
					nH = nH}
			end
			RaidGrid_CTM_Edition.SetPartyPanelPos(i, tPosnSize[nShownCount].nX, tPosnSize[nShownCount].nY)
			nShownCount = nShownCount + 1
		end
	end
end

local nDragGroupID = nil			-- �϶���ԴС�����
local dwDragMemberID = nil			-- �϶��Ľ�ɫID
local bLastShowAllMemberGrid = nil
function RaidGrid_Party.CreateNewPartyPanel(nIndex) --�����µ�С�����
	local frame = RaidGrid_Party.GetPartyPanel(nIndex)
	if frame then
		Wnd.CloseWindow(frame:GetName())
	end
	frame = Wnd.OpenWindow("Interface\\RaidGrid_CTM_Edition\\RaidGrid_Party.ini", "RaidGrid_Party_" .. nIndex)

	local textGroup = frame:Lookup("", "Handle_BG/Text_GroupIndex")
	textGroup:SetFontScale(RaidGrid_Party.fScaleFont)
	local tGroupName = {[0] = "һ", [1] = "��", [2] = "��", [3] = "��", [4] = "��"}
	if textGroup and tGroupName[nIndex] then
		textGroup:SetText(tGroupName[nIndex])
	end
	
	-- ��ʼ������
	frame.tHandleRoles = {}
	local handleRoles = frame:Lookup("", "Handle_Roles")
	for i = 0, 4 do
		local handleRole = handleRoles:AppendItemFromIni(szIniFile, "Handle_RoleDummy", "Handle_Role_" .. i)
		frame.tHandleRoles[i] = handleRole
		handleRole:SetRelPos(5, i * 42 + 10)
		handleRole:Show()
		
		local handleBoxes = handleRole:Lookup("Handle_Buff_Boxes")
		if handleBoxes then
			for j = 1, 4 do
				local box = handleBoxes:Lookup("Box_" .. j)
				local shadow = handleBoxes:Lookup("Shadow_BuffColor_" .. j)
				local text = handleBoxes:Lookup("Text_Time_" .. j)
				box:SetObject(1,0)
				box:ClearObjectIcon()
				box:SetObjectIcon(1435)
				box:SetOverTextPosition(0, ITEM_POSITION.RIGHT_BOTTOM)
				box:SetOverTextFontScheme(0, 15)
				box:SetOverText(0, "")
				box:Hide()
				shadow:Hide()
				text:Hide()
				text:SetFontScale(RaidGrid_Party.fScaleFont * 0.8)
			end
		end
		
		local boxCasting = handleRole:Lookup("Handle_CastingBar/Box_CastingIcon")
		boxCasting:Show()
		boxCasting:SetObject(1,0)
		boxCasting:ClearObjectIcon()
		boxCasting:SetAlpha(180)
		
		if RaidGrid_CTM_Edition.bLowMPBar then
			local shadowMana = handleRole:Lookup("Handle_Common/Shadow_Mana")
			local shadowLife = handleRole:Lookup("Handle_Common/Shadow_Life")
			local shadowLifeFade = handleRole:Lookup("Handle_Common/Shadow_Life_Fade")
			local shadowLifeWarn = handleRole:Lookup("Handle_Common/Shadow_Life_Warn")
			local imageCasting = handleRole:Lookup("Handle_CastingBar/Image_CastP")
			shadowMana:SetRelPos(-2, 29)
			shadowLifeFade:SetSize(121, 29)
			shadowLifeWarn:SetRelPos(-2, 28)
			imageCasting:SetRelPos(16, 29)
			imageCasting:SetSize(102, 8)
			handleRole:FormatAllItemPos()
		end
		--------------------------------------------------------------------------------------
		
		local textLife = handleRole:Lookup("Handle_Common/Text_Life")
		textLife:SetFontScale(RaidGrid_Party.fScaleFont)
		local textMana = handleRole:Lookup("Handle_Common/Text_Mana")
		textMana:SetFontScale(RaidGrid_Party.fScaleFont)
		local textDistance = handleRole:Lookup("Handle_Common/Text_Distance")
		textDistance:SetFontScale(RaidGrid_Party.fScaleFont)
		local textName = handleRole:Lookup("Handle_Common/Text_Name")
		textName:SetFontScale(RaidGrid_Party.fScaleFont)
		local textName2 = handleRole:Lookup("Text_Name_2")
		textName2:SetFontScale(RaidGrid_Party.fScaleFont)
		
		RaidGrid_Party.ClearHandleRoleInGroup(i, nIndex)
		
		handleRole.nGroupIndex = nIndex

		handleRole.OnItemLButtonDrag = function()
			local szName = this:GetName()
			local team = GetClientTeam()
			local player = GetClientPlayer()
			if RaidGrid_Party.IsInRaid() and (not IsAltKeyDown() and RaidGrid_CTM_Edition.bAltNeededForDrag) or not szName:match("Handle_Role_") or not team or not player.IsInParty() or team.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.LEADER) ~= player.dwID then
				return
			end
			bLastShowAllMemberGrid = RaidGrid_CTM_Edition.bShowAllMemberGrid
			RaidGrid_CTM_Edition.bShowAllMemberGrid = true
			
			nDragGroupID = this.nGroupIndex
			dwDragMemberID = this.dwMemberID
			if not dwDragMemberID then
				return
			end
			
			RaidGrid_Party.bDrag = true
			RaidGrid_Party.ReloadRaidPanel()
			for i = 0, 4 do
				local frameParty = RaidGrid_Party.GetPartyPanel(i)
				if frameParty then
					frameParty:Show()
				end
			end
			RaidGrid_CTM_Edition.OpenRaidDragPanel(dwDragMemberID)
			RaidGrid_Party.AutoLinkAllPanel()
		end

		handleRole.OnItemLButtonDragEnd = function()
			local szName = this:GetName()
			local team = GetClientTeam()
			local player = GetClientPlayer()
			if RaidGrid_Party.IsInRaid() and not RaidGrid_Party.bDrag or not szName:match("Handle_Role_") or not team or not player.IsInParty() or team.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.LEADER) ~= player.dwID then
				RaidGrid_CTM_Edition.bShowAllMemberGrid = bLastShowAllMemberGrid
				nDragGroupID = nil
				dwDragMemberID = nil
				RaidGrid_CTM_Edition.CloseRaidDragPanel()
				if RaidGrid_Party.bDrag then
					RaidGrid_Party.ReloadRaidPanel()
				end
				return
			end
			RaidGrid_Party.bDrag = false	
			RaidGrid_CTM_Edition.bShowAllMemberGrid = bLastShowAllMemberGrid		
			local nTargetGroup = this.nGroupIndex
			local dwTargetMemberID = this.dwMemberID or 0
			
			if nDragGroupID and dwDragMemberID then
				team.ChangeMemberGroup(dwDragMemberID, nTargetGroup, dwTargetMemberID)
			end
			
			if dwTargetMemberID == dwDragMemberID then
				RaidGrid_Party.ReloadRaidPanel()
			end
			nDragGroupID = nil
			dwDragMemberID = nil
			RaidGrid_CTM_Edition.CloseRaidDragPanel()
		end

		handleRole.OnItemMouseEnter = function()
			local nX, nY = this:GetRoot():GetAbsPos()
			local nW, nH = this:GetRoot():GetSize()
			RaidGrid_CTM_Edition.OutputTeamMemberTip(this.dwMemberID, {nX, nY + 5, nW, nH})
			RaidGrid_Party.SetTempTarget(this.dwMemberID, true)
		end
		handleRole.OnItemMouseLeave = function()
			HideTip()
			RaidGrid_Party.SetTempTarget(this.dwMemberID, false)
		end
		
		handleRole.OnItemLButtonClick = function()
			local szName = this:GetName()
			local player = GetClientPlayer()
			if not player then
				return
			end
			
			if szName:match("Handle_Role_") then
				local dwMemberID = this.dwMemberID
				if not dwMemberID or dwMemberID <= 0 or not IsPlayer(dwMemberID) then
					return
				end
				
				local player = GetPlayer(dwMemberID)
				if not player then
					player = RaidGrid_Party.GetTeamMemberInfo(dwMemberID)
				end
	
				if IsCtrlKeyDown() then
					--if IsGMPanelReceivePlayer(player.dwID) then
						--GMPanel_LinkPlayerID(player.dwID)
					--else
						RaidGrid_CTM_Edition.EditBox_AppendLinkPlayer(player.szName)
					--end
				else
					RaidGrid_Party.SetTarget(dwMemberID)
					RaidGrid_Party.dwLastTempTargetId = dwMemberID
				end
			end
		end
		
		handleRole.OnItemRButtonClick = function()
			local szName = this:GetName()
			local team = GetClientTeam()
			if not team then
				return
			end
			
			if szName:match("Handle_Role_") then
				local tMenu = {}
				local player = GetClientPlayer()
				local dwMemberID = handleRole.dwMemberID
				
				if dwMemberID and player.IsInParty() then
					if team.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.LEADER) == player.dwID then
						RaidGrid_CTM_Edition.InsertChangeGroupMenu(tMenu, dwMemberID)
					end
					
					if dwMemberID ~= player.dwID then
						InsertTeammateMenu(tMenu, dwMemberID)
						--RaidGrid_CTM_Edition.InsertTeammateMenu(tMenu, dwMemberID)
					--else
						--InsertPlayerMenu(tMenu)
						--table.insert(tMenu, Player_GetAddonMenu())
						--RaidGrid_CTM_Edition.InsertSelfMenu(tMenu, dwMemberID)
					end
			
					if tMenu and #tMenu > 0 then
						PopupMenu(tMenu)
					end
				end
			end
		end
	end
	handleRoles:FormatAllItemPos()
	
	local handleDummy = frame:Lookup("", "Handle_Dummy/Handle_RoleDummy")
	if handleDummy then
		handleDummy:Hide()
	end
	
	frame:Scale(RaidGrid_Party.fScaleX, RaidGrid_Party.fScaleY)
	
	return frame
end

function RaidGrid_Party.CreateAllNewPartyPanel() --���������µ�С�����
	for i = 0, 4 do
		RaidGrid_Party.CreateNewPartyPanel(i)
	end
end

function RaidGrid_Party.ReloadRaidPanel()	--�����Ŷ����

	if RaidGrid_CTM_Edition.bShowRaid then
		if not RaidGrid_CTM_Edition.bRaidEnable or (RaidGrid_CTM_Edition.bShowInRaid and not RaidGrid_Party.IsInRaid()) then
			RaidGrid_CTM_Edition.bShowRaid = false
		end
	elseif RaidGrid_CTM_Edition.bRaidEnable then
		if not RaidGrid_CTM_Edition.bShowInRaid or RaidGrid_Party.IsInRaid() then
			RaidGrid_CTM_Edition.bShowRaid = true
		end
	end
	
	if not RaidGrid_CTM_Edition.bShowRaid then
		RaidGrid_CTM_Edition.TeammatePanel_Switch(true)
	end

	if RaidGrid_CTM_Edition.bAutoHideCTM then
		if not RaidGrid_CTM_Edition.bShowRaid or not GetClientPlayer().IsInParty() then
			RaidGrid_CTM_Edition.ClosePanel()
		else
			RaidGrid_CTM_Edition.ShowPanel()
		end
	end

	if not RaidGrid_Party.bDrag then
		RaidGrid_Party.CreateAllNewPartyPanel()
	end

	local team = GetClientTeam()
	for i = 0, 4 do
		local tGroupInfo = nil
		if math.min(4, team.nGroupNum - 1) >= i then
			tGroupInfo = team.GetGroupInfo(i)
		end
		if tGroupInfo and tGroupInfo.MemberList and #tGroupInfo.MemberList > 0 and math.min(4, team.nGroupNum - 1) >= i then
			local tMemberList = tGroupInfo.MemberList
			for nMemberIndex = 1, 5 do
				local dwMemberID = tMemberList[nMemberIndex]
				RaidGrid_Party.OnAddOrDeleteMember(dwMemberID, i)
				RaidGrid_Party.RedrawHandleRoleHPnMP(dwMemberID)
				RaidGrid_Party.RedrawHandleRoleInfo(dwMemberID)
				RaidGrid_Party.RedrawHandleRoleInfoEx(dwMemberID)
			end
		elseif not RaidGrid_CTM_Edition.bShowAllPanel then
			local frameParty = RaidGrid_Party.GetPartyPanel(i)
			frameParty:Hide()
		end
		
		if not RaidGrid_CTM_Edition.bShowRaid then
			local frameParty = RaidGrid_Party.GetPartyPanel(i)
			frameParty:Hide()
		end
	end

	for i = 0, 4 do
		RaidGrid_CTM_Edition.SetPartyPanelPos(i, RaidGrid_CTM_Edition.tLastPartyPanelLoc[i+1].nX, RaidGrid_CTM_Edition.tLastPartyPanelLoc[i+1].nY)
	end
	RaidGrid_Party.UpdateMarkImage()
	
	if RaidGrid_CTM_Edition.bAutoLinkAllPanel then
		RaidGrid_Party.AutoLinkAllPanel()
	end
end

function RaidGrid_Party.ClosePartyPanel(nIndex, bClose) --�ر�������
	local frame = RaidGrid_Party.GetPartyPanel(nIndex)
	if frame then
		if bClose then
			Wnd.CloseWindow(frame:GetName())
		else
			frame:Hide()
		end
	end
end

function RaidGrid_Party.IsPartyOpened(nIndex)	--�������Ƿ��
	local frame = RaidGrid_Party.GetPartyPanel(nIndex)
	if frame then
		return frame:IsVisible()
	end
end