JunePony_LoadPos =
{
  [1] = 
  {
    ["PosY"] = "51708",
    ["dwMapID"] = 9,
    ["szFinder"] = "���ŷ���",
    ["szPony"] = "���",
    ["PosX"] = "24376",
  },
  [2] = 
  {
    ["PosY"] = "20040",
    ["dwMapID"] = 9,
    ["szFinder"] = "������",
    ["szPony"] = "���",
    ["PosX"] = "55784",
  },
  [4] = 
  {
    ["PosY"] = 34597,
    ["dwMapID"] = 9,
    ["szFinder"] = "����@��������",
    ["szPony"] = "����/���",
    ["PosX"] = 6335,
  },
  [8] = 
  {
    ["PosY"] = "39939",
    ["dwMapID"] = 9,
    ["PosX"] = "38980",
    ["szPony"] = "���",
    ["szFinder"] = "��������",
  },
  [16] = 
  {
    ["PosY"] = "4819",
    ["dwMapID"] = 9,
    ["PosX"] = "31354",
    ["szPony"] = "���",
    ["szFinder"] = "��١����",
  },
  [32] = 
  {
    ["PosY"] = "32982",
    ["dwMapID"] = 9,
    ["szFinder"] = "׷������",
    ["szPony"] = "���",
    ["PosX"] = "47818",
  },
  [64] = 
  {
    ["PosY"] = "49224",
    ["dwMapID"] = 12,
    ["szFinder"] = "С����",
    ["szPony"] = "����",
    ["PosX"] = "22528",
  },
  [128] = 
  {
    ["PosY"] = "54460",
    ["dwMapID"] = 21,
    ["PosX"] = "56557",
    ["szPony"] = "����",
    ["szFinder"] = "����ǳ��",
  },
  [256] = 
  {
    ["PosY"] = "21418",
    ["dwMapID"] = 100,
    ["PosX"] = "116060",
    ["szPony"] = "����",
    ["szFinder"] = "��ң��",
  },
  [512] = 
  {
    ["PosY"] = "19760",
    ["dwMapID"] = 30,
    ["szFinder"] = "�˺�����",
    ["szPony"] = "����",
    ["PosX"] = "87947",
  },
  [513] = 
  {
    ["PosY"] = "13912",
    ["dwMapID"] = 30,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "28957",
  },
  [257] = 
  {
    ["PosY"] = "18410",
    ["dwMapID"] = 100,
    ["szFinder"] = "��Ѫ��筴�",
    ["szPony"] = "����",
    ["PosX"] = "98947",
  },
  [514] = 
  {
    ["PosY"] = "7435",
    ["dwMapID"] = 30,
    ["szFinder"] = "���",
    ["szPony"] = "����",
    ["PosX"] = "74532",
  },
  [129] = 
  {
    ["PosY"] = "65810",
    ["dwMapID"] = 21,
    ["PosX"] = "63261",
    ["szPony"] = "����",
    ["szFinder"] = "Ҷ΢��",
  },
  [258] = 
  {
    ["PosY"] = "121530",
    ["dwMapID"] = 100,
    ["szFinder"] = "���Ѳ���",
    ["szPony"] = "����",
    ["PosX"] = "59604",
  },
  [516] = 
  {
    ["PosY"] = "6720",
    ["dwMapID"] = 100,
    ["szFinder"] = "ɱ����С��",
    ["szPony"] = "����",
    ["PosX"] = "116065",
  },
  [517] = 
  {
    ["PosY"] = "51120",
    ["dwMapID"] = 100,
    ["szFinder"] = "�������",
    ["szPony"] = "����",
    ["PosX"] = "28225",
  },
  [259] = 
  {
    ["PosY"] = "118560",
    ["dwMapID"] = 100,
    ["PosX"] = "93777",
    ["szPony"] = "����",
    ["szFinder"] = "����֮",
  },
  [518] = 
  {
    ["PosY"] = "61421",
    ["dwMapID"] = 100,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "14552",
  },
  [65] = 
  {
    ["PosY"] = "19474",
    ["dwMapID"] = 12,
    ["szFinder"] = "С��",
    ["szPony"] = "����",
    ["PosX"] = "62564",
  },
  [130] = 
  {
    ["PosY"] = "49948",
    ["dwMapID"] = 21,
    ["szFinder"] = "�������",
    ["szPony"] = "����",
    ["PosX"] = "69326",
  },
  [260] = 
  {
    ["PosY"] = "56851",
    ["dwMapID"] = 100,
    ["szFinder"] = "�������",
    ["szPony"] = "����",
    ["PosX"] = "6619",
  },
  [520] = 
  {
    ["PosY"] = "17826",
    ["dwMapID"] = 100,
    ["szFinder"] = "�����ᰮ",
    ["szPony"] = "����",
    ["PosX"] = "60298",
  },
  [521] = 
  {
    ["PosY"] = "111020",
    ["dwMapID"] = 100,
    ["szFinder"] = "���Ѳ���",
    ["szPony"] = "����",
    ["PosX"] = "29035",
  },
  [261] = 
  {
    ["PosY"] = "89394",
    ["dwMapID"] = 100,
    ["szFinder"] = "һ�����",
    ["szPony"] = "����",
    ["PosX"] = "119348",
  },
  [522] = 
  {
    ["PosY"] = "77304",
    ["dwMapID"] = 100,
    ["szFinder"] = "л����",
    ["szPony"] = "����",
    ["PosX"] = "68852",
  },
  [131] = 
  {
    ["PosY"] = "38060",
    ["dwMapID"] = 21,
    ["szFinder"] = "�������",
    ["szPony"] = "����",
    ["PosX"] = "64505",
  },
  [262] = 
  {
    ["PosY"] = "61520",
    ["dwMapID"] = 100,
    ["szFinder"] = "��Ѫ��筴�",
    ["szPony"] = "����",
    ["PosX"] = "69303",
  },
  [524] = 
  {
    ["PosY"] = "10755",
    ["dwMapID"] = 100,
    ["szFinder"] = "��İ��",
    ["szPony"] = "����",
    ["PosX"] = "48552",
  },
  [525] = 
  {
    ["PosY"] = "37648",
    ["dwMapID"] = 100,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "95641",
  },
  [263] = 
  {
    ["PosY"] = "23381",
    ["dwMapID"] = 100,
    ["szFinder"] = "һ�궾��",
    ["szPony"] = "����",
    ["PosX"] = "102014",
  },
  [33] = 
  {
    ["PosY"] = "52400",
    ["dwMapID"] = 9,
    ["szFinder"] = "�ӽ�������",
    ["szPony"] = "���",
    ["PosX"] = "29450",
  },
  [66] = 
  {
    ["PosY"] = "29684",
    ["dwMapID"] = 12,
    ["PosX"] = "70185",
    ["szPony"] = "����",
    ["szFinder"] = "��Ҷ����",
  },
  [132] = 
  {
    ["PosY"] = "42916",
    ["dwMapID"] = 21,
    ["szFinder"] = "����",
    ["szPony"] = "����",
    ["PosX"] = "38017",
  },
  [264] = 
  {
    ["PosY"] = "10726",
    ["dwMapID"] = 100,
    ["PosX"] = "90004",
    ["szPony"] = "����",
    ["szFinder"] = "ɽʯ����",
  },
  [528] = 
  {
    ["PosY"] = "114116",
    ["dwMapID"] = 100,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "68921",
  },
  [529] = 
  {
    ["PosY"] = "10492",
    ["dwMapID"] = 100,
    ["szFinder"] = "������",
    ["szPony"] = "����",
    ["PosX"] = "115550",
  },
  [265] = 
  {
    ["PosY"] = "29507",
    ["dwMapID"] = 100,
    ["szFinder"] = "����һ˭ǳЦ",
    ["szPony"] = "����",
    ["PosX"] = "104457",
  },
  [530] = 
  {
    ["PosY"] = "107212",
    ["dwMapID"] = 100,
    ["szFinder"] = "л����",
    ["szPony"] = "����",
    ["PosX"] = "51376",
  },
  [133] = 
  {
    ["PosY"] = "5388",
    ["dwMapID"] = 21,
    ["szFinder"] = "��ң��",
    ["szPony"] = "����",
    ["PosX"] = "61804",
  },
  [266] = 
  {
    ["PosY"] = "111897",
    ["dwMapID"] = 100,
    ["szFinder"] = "������",
    ["szPony"] = "����",
    ["PosX"] = "50833",
  },
  [532] = 
  {
    ["PosY"] = "81576",
    ["dwMapID"] = 100,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "69530",
  },
  [533] = 
  {
    ["PosY"] = "3681",
    ["dwMapID"] = 100,
    ["szFinder"] = "��������",
    ["szPony"] = "����",
    ["PosX"] = "67899",
  },
  [267] = 
  {
    ["PosY"] = "108322",
    ["dwMapID"] = 100,
    ["szFinder"] = "������������",
    ["szPony"] = "����",
    ["PosX"] = "105343",
  },
  [534] = 
  {
    ["PosY"] = "5059",
    ["dwMapID"] = 100,
    ["szFinder"] = "���̃�",
    ["szPony"] = "����",
    ["PosX"] = "73707",
  },
  [67] = 
  {
    ["PosY"] = "30839",
    ["dwMapID"] = 12,
    ["szFinder"] = "Ľ����",
    ["szPony"] = "����",
    ["PosX"] = "63712",
  },
  [134] = 
  {
    ["PosY"] = "27248",
    ["dwMapID"] = 21,
    ["szFinder"] = "ҹҹҹҹ����",
    ["szPony"] = "����",
    ["PosX"] = "87412",
  },
  [268] = 
  {
    ["PosY"] = "100380",
    ["dwMapID"] = 100,
    ["szFinder"] = "��и���å",
    ["szPony"] = "����",
    ["PosX"] = "53243",
  },
  [536] = 
  {
    ["PosY"] = "52559",
    ["dwMapID"] = 100,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "32817",
  },
  [537] = 
  {
    ["PosY"] = "91460",
    ["dwMapID"] = 100,
    ["szFinder"] = "����",
    ["szPony"] = "����",
    ["PosX"] = "12102",
  },
  [269] = 
  {
    ["PosY"] = "15202",
    ["dwMapID"] = 100,
    ["szFinder"] = "С��",
    ["szPony"] = "����",
    ["PosX"] = "100978",
  },
  [538] = 
  {
    ["PosY"] = "90238",
    ["dwMapID"] = 100,
    ["szFinder"] = "л����",
    ["szPony"] = "����",
    ["PosX"] = "73037",
  },
  [135] = 
  {
    ["PosY"] = "25454",
    ["dwMapID"] = 21,
    ["szFinder"] = "�ǷϹ���",
    ["szPony"] = "����",
    ["PosX"] = "52546",
  },
  [270] = 
  {
    ["PosY"] = "44112",
    ["dwMapID"] = 100,
    ["szFinder"] = "���͹�ͷ",
    ["szPony"] = "����",
    ["PosX"] = "28525",
  },
  [540] = 
  {
    ["PosY"] = "104046",
    ["dwMapID"] = 100,
    ["szFinder"] = "л����",
    ["szPony"] = "����",
    ["PosX"] = "8412",
  },
  [541] = 
  {
    ["PosY"] = "104811",
    ["dwMapID"] = 100,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "116455",
  },
  [17] = 
  {
    ["PosY"] = "43395",
    ["dwMapID"] = 9,
    ["PosX"] = "13514",
    ["szPony"] = "���",
    ["szFinder"] = "�ǲ�˦",
  },
  [34] = 
  {
    ["PosY"] = "80594",
    ["dwMapID"] = 9,
    ["szFinder"] = "���ƿ���",
    ["szPony"] = "���",
    ["PosX"] = "50908",
  },
  [68] = 
  {
    ["PosY"] = "42227",
    ["dwMapID"] = 12,
    ["szFinder"] = "������",
    ["szPony"] = "����",
    ["PosX"] = "39753",
  },
  [136] = 
  {
    ["PosY"] = "44488",
    ["dwMapID"] = 21,
    ["szFinder"] = "ʱ��",
    ["szPony"] = "����",
    ["PosX"] = "8526",
  },
  [272] = 
  {
    ["PosY"] = "55379",
    ["dwMapID"] = 100,
    ["szFinder"] = "ޱϦ��",
    ["szPony"] = "����",
    ["PosX"] = "23845",
  },
  [544] = 
  {
    ["PosY"] = "27990",
    ["dwMapID"] = 100,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "77462",
  },
  [545] = 
  {
    ["PosY"] = "87736",
    ["dwMapID"] = 100,
    ["szFinder"] = "����֮",
    ["szPony"] = "����",
    ["PosX"] = "67143",
  },
  [273] = 
  {
    ["PosY"] = "62278",
    ["dwMapID"] = 100,
    ["PosX"] = "64443",
    ["szPony"] = "����",
    ["szFinder"] = "��Ҷ����",
  },
  [546] = 
  {
    ["PosY"] = "47848",
    ["dwMapID"] = 100,
    ["szFinder"] = "���Ѳ���",
    ["szPony"] = "����",
    ["PosX"] = "29248",
  },
  [137] = 
  {
    ["PosY"] = "4279",
    ["dwMapID"] = 21,
    ["szFinder"] = "��ң��",
    ["szPony"] = "����",
    ["PosX"] = "26931",
  },
  [274] = 
  {
    ["PosY"] = "42408",
    ["dwMapID"] = 101,
    ["szFinder"] = "����֮",
    ["szPony"] = "����",
    ["PosX"] = "8360",
  },
  [548] = 
  {
    ["PosY"] = "119702",
    ["dwMapID"] = 100,
    ["szFinder"] = "����֮",
    ["szPony"] = "����",
    ["PosX"] = "105833",
  },
  [549] = 
  {
    ["PosY"] = "6119",
    ["dwMapID"] = 100,
    ["szFinder"] = "����@��������",
    ["szPony"] = "����",
    ["PosX"] = "62383",
  },
  [275] = 
  {
    ["PosY"] = "46708",
    ["dwMapID"] = 101,
    ["PosX"] = "16083",
    ["szPony"] = "����",
    ["szFinder"] = "�ڴ�������",
  },
  [550] = 
  {
    ["PosY"] = "101487",
    ["dwMapID"] = 100,
    ["szFinder"] = "�ݵ�Ѿͷ",
    ["szPony"] = "����",
    ["PosX"] = "31080",
  },
  [69] = 
  {
    ["PosY"] = "47194",
    ["dwMapID"] = 12,
    ["szFinder"] = "����@��������",
    ["szPony"] = "����",
    ["PosX"] = "44118",
  },
  [138] = 
  {
    ["PosY"] = "15460",
    ["dwMapID"] = 21,
    ["szFinder"] = "���Ŷ��",
    ["szPony"] = "����",
    ["PosX"] = "61407",
  },
  [276] = 
  {
    ["PosY"] = "5863",
    ["dwMapID"] = 101,
    ["szFinder"] = "�����",
    ["szPony"] = "����",
    ["PosX"] = "80628",
  },
  [552] = 
  {
    ["PosY"] = "96870",
    ["dwMapID"] = 100,
    ["szFinder"] = "�����Ƹ�",
    ["szPony"] = "����",
    ["PosX"] = "10639",
  },
  [553] = 
  {
    ["PosY"] = "106992",
    ["dwMapID"] = 100,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "72986",
  },
  [277] = 
  {
    ["PosY"] = "26532",
    ["dwMapID"] = 101,
    ["szFinder"] = "Ľ������",
    ["szPony"] = "����",
    ["PosX"] = "123179",
  },
  [554] = 
  {
    ["PosY"] = "6639",
    ["dwMapID"] = 101,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "47212",
  },
  [139] = 
  {
    ["PosY"] = "24246",
    ["dwMapID"] = 21,
    ["PosX"] = "58015",
    ["szPony"] = "����",
    ["szFinder"] = "�����",
  },
  [278] = 
  {
    ["PosY"] = "46286",
    ["dwMapID"] = 101,
    ["szFinder"] = "�������",
    ["szPony"] = "����",
    ["PosX"] = "10613",
  },
  [556] = 
  {
    ["PosY"] = "14808",
    ["dwMapID"] = 101,
    ["szFinder"] = "������",
    ["szPony"] = "����",
    ["PosX"] = "44707",
  },
  [557] = 
  {
    ["PosY"] = "11448",
    ["dwMapID"] = 101,
    ["szFinder"] = "л����",
    ["szPony"] = "����",
    ["PosX"] = "82410",
  },
  [279] = 
  {
    ["PosY"] = "39059",
    ["dwMapID"] = 101,
    ["PosX"] = "110314",
    ["szPony"] = "����",
    ["szFinder"] = "���",
  },
  [35] = 
  {
    ["PosY"] = "33722",
    ["dwMapID"] = 10,
    ["szFinder"] = "��һ��",
    ["szPony"] = "���",
    ["PosX"] = "48742",
  },
  [70] = 
  {
    ["PosY"] = "63461",
    ["dwMapID"] = 12,
    ["szFinder"] = "˾ͽ����",
    ["szPony"] = "����",
    ["PosX"] = "20799",
  },
  [140] = 
  {
    ["PosY"] = "41483",
    ["dwMapID"] = 21,
    ["szFinder"] = "�������",
    ["szPony"] = "����",
    ["PosX"] = "72658",
  },
  [280] = 
  {
    ["PosY"] = "106345",
    ["dwMapID"] = 101,
    ["PosX"] = "69092",
    ["szPony"] = "����",
    ["szFinder"] = "�Ƽ����",
  },
  [560] = 
  {
    ["PosY"] = "103391",
    ["dwMapID"] = 101,
    ["szFinder"] = "ˬ���˾�ˣ��",
    ["szPony"] = "����",
    ["PosX"] = "67230",
  },
  [561] = 
  {
    ["PosY"] = "34307",
    ["dwMapID"] = 101,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "121988",
  },
  [281] = 
  {
    ["PosY"] = "26534",
    ["dwMapID"] = 101,
    ["szFinder"] = "�������",
    ["szPony"] = "����",
    ["PosX"] = "32500",
  },
  [562] = 
  {
    ["PosY"] = "99463",
    ["dwMapID"] = 101,
    ["szFinder"] = "����֮",
    ["szPony"] = "����",
    ["PosX"] = "71830",
  },
  [141] = 
  {
    ["PosY"] = "58587",
    ["dwMapID"] = 21,
    ["szFinder"] = "����ҹ��",
    ["szPony"] = "����",
    ["PosX"] = "66552",
  },
  [282] = 
  {
    ["PosY"] = "40857",
    ["dwMapID"] = 101,
    ["szFinder"] = "��С��",
    ["szPony"] = "����",
    ["PosX"] = "93260",
  },
  [564] = 
  {
    ["PosY"] = "94603",
    ["dwMapID"] = 101,
    ["szFinder"] = "����Ȼ",
    ["szPony"] = "����",
    ["PosX"] = "72815",
  },
  [565] = 
  {
    ["PosY"] = "33513",
    ["dwMapID"] = 101,
    ["szFinder"] = "��������",
    ["szPony"] = "����",
    ["PosX"] = "95162",
  },
  [283] = 
  {
    ["PosY"] = "102285",
    ["dwMapID"] = 101,
    ["szFinder"] = "����",
    ["szPony"] = "����",
    ["PosX"] = "48333",
  },
  [566] = 
  {
    ["PosY"] = "52314",
    ["dwMapID"] = 101,
    ["szFinder"] = "�����",
    ["szPony"] = "����",
    ["PosX"] = "8754",
  },
  [71] = 
  {
    ["PosY"] = "15180",
    ["dwMapID"] = 12,
    ["szFinder"] = "��ң��",
    ["szPony"] = "����",
    ["PosX"] = "25730",
  },
  [142] = 
  {
    ["PosY"] = "24950",
    ["dwMapID"] = 21,
    ["PosX"] = "61313",
    ["szPony"] = "����",
    ["szFinder"] = "�˱���",
  },
  [284] = 
  {
    ["PosY"] = "82572",
    ["dwMapID"] = 101,
    ["szFinder"] = "л����",
    ["szPony"] = "����",
    ["PosX"] = "83000",
  },
  [568] = 
  {
    ["PosY"] = "53215",
    ["dwMapID"] = 101,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "13848",
  },
  [569] = 
  {
    ["PosY"] = "58262",
    ["dwMapID"] = 104,
    ["szFinder"] = "���ɶ�",
    ["szPony"] = "���ɳ",
    ["PosX"] = "59815",
  },
  [285] = 
  {
    ["PosY"] = "109423",
    ["dwMapID"] = 101,
    ["szFinder"] = "��������",
    ["szPony"] = "����",
    ["PosX"] = "51478",
  },
  [570] = 
  {
    ["PosY"] = "94748",
    ["dwMapID"] = 104,
    ["szFinder"] = "л����",
    ["szPony"] = "���ɳ",
    ["PosX"] = "74156",
  },
  [143] = 
  {
    ["PosY"] = 45244,
    ["dwMapID"] = 21,
    ["PosX"] = 73112,
    ["szPony"] = "����",
    ["szFinder"] = "����@��������",
  },
  [286] = 
  {
    ["PosY"] = "3981",
    ["dwMapID"] = 101,
    ["szFinder"] = "�������",
    ["szPony"] = "����",
    ["PosX"] = "87070",
  },
  [572] = 
  {
    ["PosY"] = "105317",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "55178",
  },
  [9] = 
  {
    ["PosY"] = "5270",
    ["dwMapID"] = 9,
    ["szFinder"] = "��������",
    ["szPony"] = "���",
    ["PosX"] = "46524",
  },
  [18] = 
  {
    ["PosY"] = "75368",
    ["dwMapID"] = 9,
    ["szFinder"] = "�������",
    ["szPony"] = "����/���",
    ["PosX"] = "52353",
  },
  [36] = 
  {
    ["PosY"] = "8780",
    ["dwMapID"] = 10,
    ["PosX"] = "22667",
    ["szPony"] = "���",
    ["szFinder"] = "С��",
  },
  [72] = 
  {
    ["PosY"] = 35377,
    ["dwMapID"] = 12,
    ["szFinder"] = "����@��������",
    ["szPony"] = "����",
    ["PosX"] = 78872,
  },
  [144] = 
  {
    ["PosY"] = "7032",
    ["dwMapID"] = 21,
    ["PosX"] = "30819",
    ["szPony"] = "����",
    ["szFinder"] = "����֮�¹�",
  },
  [288] = 
  {
    ["PosY"] = "88244",
    ["dwMapID"] = 101,
    ["szFinder"] = "�������",
    ["szPony"] = "����",
    ["PosX"] = "18152",
  },
  [576] = 
  {
    ["PosY"] = "49120",
    ["dwMapID"] = 104,
    ["szFinder"] = "л����",
    ["szPony"] = "���ɳ",
    ["PosX"] = "93446",
  },
  [577] = 
  {
    ["PosY"] = "103094",
    ["dwMapID"] = 104,
    ["szFinder"] = "����֮",
    ["szPony"] = "���ɳ",
    ["PosX"] = "97610",
  },
  [289] = 
  {
    ["PosY"] = "29854",
    ["dwMapID"] = 101,
    ["szFinder"] = "�״�",
    ["szPony"] = "����",
    ["PosX"] = "66699",
  },
  [578] = 
  {
    ["PosY"] = "41424",
    ["dwMapID"] = 104,
    ["szFinder"] = "л����",
    ["szPony"] = "���ɳ",
    ["PosX"] = "55028",
  },
  [145] = 
  {
    ["PosY"] = 56401,
    ["dwMapID"] = 21,
    ["szFinder"] = "����@��������",
    ["szPony"] = "����",
    ["PosX"] = 41639,
  },
  [290] = 
  {
    ["PosY"] = "81545",
    ["dwMapID"] = 101,
    ["szFinder"] = "ת˲�Կ�",
    ["szPony"] = "����",
    ["PosX"] = "7248",
  },
  [580] = 
  {
    ["PosY"] = "118825",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "30948",
  },
  [581] = 
  {
    ["PosY"] = "85675",
    ["dwMapID"] = 104,
    ["szFinder"] = "����֮",
    ["szPony"] = "���ɳ",
    ["PosX"] = "54646",
  },
  [291] = 
  {
    ["PosY"] = 108890,
    ["dwMapID"] = 101,
    ["szFinder"] = "����@��������",
    ["szPony"] = "����",
    ["PosX"] = 62374,
  },
  [582] = 
  {
    ["PosY"] = "95668",
    ["dwMapID"] = 104,
    ["szFinder"] = "�ӽ�������",
    ["szPony"] = "���ɳ",
    ["PosX"] = "26745",
  },
  [73] = 
  {
    ["PosY"] = "36282",
    ["dwMapID"] = 12,
    ["szFinder"] = "ڤ��",
    ["szPony"] = "����",
    ["PosX"] = "48335",
  },
  [146] = 
  {
    ["PosY"] = "54407",
    ["dwMapID"] = 21,
    ["PosX"] = "87890",
    ["szPony"] = "����",
    ["szFinder"] = "л�ն�",
  },
  [292] = 
  {
    ["PosY"] = "90937",
    ["dwMapID"] = 101,
    ["szFinder"] = "һ�����",
    ["szPony"] = "����",
    ["PosX"] = "77601",
  },
  [584] = 
  {
    ["PosY"] = "11992",
    ["dwMapID"] = 104,
    ["szFinder"] = "л����",
    ["szPony"] = "���ɳ",
    ["PosX"] = "83898",
  },
  [585] = 
  {
    ["PosY"] = "71176",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "30715",
  },
  [293] = 
  {
    ["PosY"] = "50202",
    ["dwMapID"] = 101,
    ["szFinder"] = "��������",
    ["szPony"] = "����",
    ["PosX"] = "117187",
  },
  [586] = 
  {
    ["PosY"] = "27130",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "36273",
  },
  [147] = 
  {
    ["PosY"] = "57241",
    ["dwMapID"] = 21,
    ["szFinder"] = "������ǻ�",
    ["szPony"] = "����",
    ["PosX"] = "89823",
  },
  [294] = 
  {
    ["PosY"] = "48148",
    ["dwMapID"] = 101,
    ["szFinder"] = "˾ͽ����",
    ["szPony"] = "����",
    ["PosX"] = "122513",
  },
  [588] = 
  {
    ["PosY"] = "103712",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "38541",
  },
  [589] = 
  {
    ["PosY"] = "65435",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "107320",
  },
  [295] = 
  {
    ["PosY"] = "43952",
    ["dwMapID"] = 101,
    ["szFinder"] = "���",
    ["szPony"] = "����",
    ["PosX"] = "122102",
  },
  [37] = 
  {
    ["PosY"] = "9922",
    ["dwMapID"] = 10,
    ["szFinder"] = "����",
    ["szPony"] = "���",
    ["PosX"] = "36356",
  },
  [74] = 
  {
    ["PosY"] = "27693",
    ["dwMapID"] = 12,
    ["szFinder"] = "����",
    ["szPony"] = "����",
    ["PosX"] = "33713",
  },
  [148] = 
  {
    ["PosY"] = "52693",
    ["dwMapID"] = 21,
    ["PosX"] = "61055",
    ["szPony"] = "����",
    ["szFinder"] = "��誳�",
  },
  [296] = 
  {
    ["PosY"] = "10852",
    ["dwMapID"] = 104,
    ["szFinder"] = "Ϫ����",
    ["szPony"] = "���ɳ",
    ["PosX"] = "70575",
  },
  [592] = 
  {
    ["PosY"] = "107271",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "24118",
  },
  [593] = 
  {
    ["PosY"] = "58633",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "27354",
  },
  [297] = 
  {
    ["PosY"] = "24930",
    ["dwMapID"] = 104,
    ["szFinder"] = "���",
    ["szPony"] = "���ɳ",
    ["PosX"] = "88192",
  },
  [594] = 
  {
    ["PosY"] = "108866",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "34342",
  },
  [149] = 
  {
    ["PosY"] = "34361",
    ["dwMapID"] = 21,
    ["szFinder"] = "�����",
    ["szPony"] = "����",
    ["PosX"] = "6144",
  },
  [298] = 
  {
    ["PosY"] = "92738",
    ["dwMapID"] = 104,
    ["szFinder"] = "����һ�ѽ�",
    ["szPony"] = "���ɳ",
    ["PosX"] = "16316",
  },
  [596] = 
  {
    ["PosY"] = "25057",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "109061",
  },
  [597] = 
  {
    ["PosY"] = "23487",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "35581",
  },
  [299] = 
  {
    ["PosY"] = "84976",
    ["dwMapID"] = 104,
    ["szFinder"] = "��������",
    ["szPony"] = "���ɳ",
    ["PosX"] = "90868",
  },
  [598] = 
  {
    ["PosY"] = "77563",
    ["dwMapID"] = 104,
    ["szFinder"] = "����֮",
    ["szPony"] = "���ɳ",
    ["PosX"] = "56490",
  },
  [75] = 
  {
    ["PosY"] = "64066",
    ["dwMapID"] = 12,
    ["szFinder"] = "����",
    ["szPony"] = "����",
    ["PosX"] = "13526",
  },
  [150] = 
  {
    ["PosY"] = "43727",
    ["dwMapID"] = 21,
    ["szFinder"] = "���׿Ӱ",
    ["szPony"] = "����",
    ["PosX"] = "84522",
  },
  [300] = 
  {
    ["PosY"] = "85518",
    ["dwMapID"] = 104,
    ["PosX"] = "71274",
    ["szPony"] = "���ɳ",
    ["szFinder"] = "����������",
  },
  [600] = 
  {
    ["PosY"] = "81334",
    ["dwMapID"] = 104,
    ["szFinder"] = "����֮",
    ["szPony"] = "���ɳ",
    ["PosX"] = "48890",
  },
  [601] = 
  {
    ["PosY"] = "59389",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "76399",
  },
  [301] = 
  {
    ["PosY"] = 90182,
    ["dwMapID"] = 104,
    ["szFinder"] = "����@��������",
    ["szPony"] = "���ɳ",
    ["PosX"] = 23265,
  },
  [602] = 
  {
    ["PosY"] = "64663",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "39568",
  },
  [151] = 
  {
    ["PosY"] = "32608",
    ["dwMapID"] = 21,
    ["szFinder"] = "����",
    ["szPony"] = "����",
    ["PosX"] = "43612",
  },
  [302] = 
  {
    ["PosY"] = "64666",
    ["dwMapID"] = 104,
    ["szFinder"] = "���಻��",
    ["szPony"] = "���ɳ",
    ["PosX"] = "112049",
  },
  [604] = 
  {
    ["PosY"] = "24128",
    ["dwMapID"] = 104,
    ["szFinder"] = "�����",
    ["szPony"] = "���ɳ",
    ["PosX"] = "31901",
  },
  [605] = 
  {
    ["PosY"] = "54096",
    ["dwMapID"] = 104,
    ["szFinder"] = "��Ѿͷ",
    ["szPony"] = "���ɳ",
    ["PosX"] = "25474",
  },
  [19] = 
  {
    ["PosY"] = "9583",
    ["dwMapID"] = 9,
    ["PosX"] = "61715",
    ["szPony"] = "���",
    ["szFinder"] = "��С��",
  },
  [38] = 
  {
    ["PosY"] = "10974",
    ["dwMapID"] = 10,
    ["szFinder"] = "һ������һ",
    ["szPony"] = "���",
    ["PosX"] = "47778",
  },
  [76] = 
  {
    ["PosY"] = "28033",
    ["dwMapID"] = 12,
    ["szFinder"] = "�����",
    ["szPony"] = "����",
    ["PosX"] = "83947",
  },
  [152] = 
  {
    ["PosY"] = "31124",
    ["dwMapID"] = 21,
    ["PosX"] = "35006",
    ["szPony"] = "����",
    ["szFinder"] = "�ӳ���ѩ",
  },
  [304] = 
  {
    ["PosY"] = "8704",
    ["dwMapID"] = 104,
    ["PosX"] = "86007",
    ["szPony"] = "���ɳ",
    ["szFinder"] = "��֮���",
  },
  [608] = 
  {
    ["PosY"] = "73704",
    ["dwMapID"] = 104,
    ["szFinder"] = "����֮",
    ["szPony"] = "���ɳ",
    ["PosX"] = "33543",
  },
  [609] = 
  {
    ["PosY"] = "70980",
    ["dwMapID"] = 104,
    ["szFinder"] = "л����",
    ["szPony"] = "���ɳ",
    ["PosX"] = "91292",
  },
  [305] = 
  {
    ["PosY"] = "92580",
    ["dwMapID"] = 104,
    ["szFinder"] = "���Ϸ���",
    ["szPony"] = "���ɳ",
    ["PosX"] = "57894",
  },
  [610] = 
  {
    ["PosY"] = "86997",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "58311",
  },
  [153] = 
  {
    ["PosY"] = "48707",
    ["dwMapID"] = 21,
    ["PosX"] = "73490",
    ["szPony"] = "����",
    ["szFinder"] = "�������",
  },
  [306] = 
  {
    ["PosY"] = "10896",
    ["dwMapID"] = 104,
    ["szFinder"] = "������",
    ["szPony"] = "���ɳ",
    ["PosX"] = "52295",
  },
  [612] = 
  {
    ["PosY"] = "72652",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "94606",
  },
  [613] = 
  {
    ["PosY"] = "23518",
    ["dwMapID"] = 104,
    ["szFinder"] = "�������",
    ["szPony"] = "���ɳ",
    ["PosX"] = "79140",
  },
  [307] = 
  {
    ["PosY"] = "91737",
    ["dwMapID"] = 104,
    ["szFinder"] = "���",
    ["szPony"] = "���ɳ",
    ["PosX"] = "101146",
  },
  [614] = 
  {
    ["PosY"] = "73939",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "26545",
  },
  [77] = 
  {
    ["PosY"] = "64373",
    ["dwMapID"] = 12,
    ["PosX"] = "26717",
    ["szPony"] = "����",
    ["szFinder"] = "һ��С��һ",
  },
  [154] = 
  {
    ["PosY"] = "58244",
    ["dwMapID"] = 21,
    ["szFinder"] = "����",
    ["szPony"] = "����",
    ["PosX"] = "10916",
  },
  [308] = 
  {
    ["PosY"] = "103200",
    ["dwMapID"] = 104,
    ["szFinder"] = "����",
    ["szPony"] = "���ɳ",
    ["PosX"] = "78112",
  },
  [616] = 
  {
    ["PosY"] = "122622",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "68053",
  },
  [617] = 
  {
    ["PosY"] = "82522",
    ["dwMapID"] = 104,
    ["szFinder"] = "��ز��ز",
    ["szPony"] = "���ɳ",
    ["PosX"] = "19145",
  },
  [309] = 
  {
    ["PosY"] = "108545",
    ["dwMapID"] = 104,
    ["szFinder"] = "һ������һ",
    ["szPony"] = "���ɳ",
    ["PosX"] = "92685",
  },
  [618] = 
  {
    ["PosY"] = "27066",
    ["dwMapID"] = 104,
    ["szFinder"] = "л����",
    ["szPony"] = "���ɳ",
    ["PosX"] = "78600",
  },
  [155] = 
  {
    ["PosY"] = "68487",
    ["dwMapID"] = 21,
    ["szFinder"] = "ɱ����С��",
    ["szPony"] = "����",
    ["PosX"] = "53959",
  },
  [310] = 
  {
    ["PosY"] = "32885",
    ["dwMapID"] = 104,
    ["szFinder"] = "ӣ������",
    ["szPony"] = "���ɳ",
    ["PosX"] = "73687",
  },
  [620] = 
  {
    ["PosY"] = "83710",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "27455",
  },
  [621] = 
  {
    ["PosY"] = "100300",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "34111",
  },
  [311] = 
  {
    ["PosY"] = "49308",
    ["dwMapID"] = 104,
    ["szFinder"] = "����ᳪ",
    ["szPony"] = "���ɳ",
    ["PosX"] = "73131",
  },
  [39] = 
  {
    ["PosY"] = "76157",
    ["dwMapID"] = 10,
    ["PosX"] = "51651",
    ["szPony"] = "���",
    ["szFinder"] = "�������",
  },
  [78] = 
  {
    ["PosY"] = "22327",
    ["dwMapID"] = 12,
    ["szFinder"] = "Ľ����",
    ["szPony"] = "����",
    ["PosX"] = "81490",
  },
  [156] = 
  {
    ["PosY"] = "12874",
    ["dwMapID"] = 21,
    ["szFinder"] = "��İ����",
    ["szPony"] = "����",
    ["PosX"] = "46447",
  },
  [312] = 
  {
    ["PosY"] = "33871",
    ["dwMapID"] = 9,
    ["szFinder"] = "ɱ����С��",
    ["szPony"] = "����/���",
    ["PosX"] = "25528",
  },
  [624] = 
  {
    ["PosY"] = "96749",
    ["dwMapID"] = 105,
    ["szFinder"] = "����",
    ["szPony"] = "����/���",
    ["PosX"] = "61727",
  },
  [625] = 
  {
    ["PosY"] = "73210",
    ["dwMapID"] = 105,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "22890",
  },
  [313] = 
  {
    ["PosY"] = "8325",
    ["dwMapID"] = 9,
    ["szFinder"] = "��ɽ��ʥ",
    ["szPony"] = "���",
    ["PosX"] = "17175",
  },
  [626] = 
  {
    ["PosY"] = "56968",
    ["dwMapID"] = 105,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "21063",
  },
  [157] = 
  {
    ["PosY"] = "54589",
    ["dwMapID"] = 22,
    ["szFinder"] = "��������",
    ["szPony"] = "����",
    ["PosX"] = "96770",
  },
  [314] = 
  {
    ["PosY"] = "45336",
    ["dwMapID"] = 9,
    ["szFinder"] = "������ǻ�",
    ["szPony"] = "���",
    ["PosX"] = "5653",
  },
  [628] = 
  {
    ["PosY"] = "46179",
    ["dwMapID"] = 105,
    ["szFinder"] = "���ɶ�",
    ["szPony"] = "���ɳ/����/����/����/����/���",
    ["PosX"] = "69281",
  },
  [629] = 
  {
    ["PosY"] = "38339",
    ["dwMapID"] = 105,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "40532",
  },
  [315] = 
  {
    ["PosY"] = "25217",
    ["dwMapID"] = 9,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "3971",
  },
  [630] = 
  {
    ["PosY"] = "70676",
    ["dwMapID"] = 105,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "28126",
  },
  [79] = 
  {
    ["PosY"] = "3891",
    ["dwMapID"] = 12,
    ["szFinder"] = "���л�Ӱ",
    ["szPony"] = "����",
    ["PosX"] = "35553",
  },
  [158] = 
  {
    ["PosY"] = 80313,
    ["dwMapID"] = 22,
    ["szFinder"] = "����@��������",
    ["szPony"] = "����",
    ["PosX"] = 44438,
  },
  [316] = 
  {
    ["PosY"] = "14049",
    ["dwMapID"] = 9,
    ["szFinder"] = "����",
    ["szPony"] = "���",
    ["PosX"] = "57311",
  },
  [632] = 
  {
    ["PosY"] = "71295",
    ["dwMapID"] = 105,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "15598",
  },
  [633] = 
  {
    ["PosY"] = "50792",
    ["dwMapID"] = 105,
    ["szFinder"] = "����֮",
    ["szPony"] = "���ɳ/����/����/����/����/���",
    ["PosX"] = "9422",
  },
  [317] = 
  {
    ["PosY"] = "25744",
    ["dwMapID"] = 9,
    ["szFinder"] = "������",
    ["szPony"] = "���",
    ["PosX"] = "11906",
  },
  [634] = 
  {
    ["PosY"] = "31935",
    ["dwMapID"] = 105,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "38226",
  },
  [159] = 
  {
    ["PosY"] = "51249",
    ["dwMapID"] = 22,
    ["szFinder"] = "һ����",
    ["szPony"] = "����",
    ["PosX"] = "79717",
  },
  [318] = 
  {
    ["PosY"] = "38804",
    ["dwMapID"] = 9,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "50180",
  },
  [5] = 
  {
    ["PosY"] = "39770",
    ["dwMapID"] = 9,
    ["PosX"] = "64790",
    ["szPony"] = "���",
    ["szFinder"] = "���鲻ϧ",
  },
  [10] = 
  {
    ["PosY"] = "29635",
    ["dwMapID"] = 9,
    ["szFinder"] = "��ǳ��",
    ["szPony"] = "���",
    ["PosX"] = "54981",
  },
  [20] = 
  {
    ["PosY"] = "26787",
    ["dwMapID"] = 9,
    ["szFinder"] = "�ĳ���",
    ["szPony"] = "���",
    ["PosX"] = "8685",
  },
  [40] = 
  {
    ["PosY"] = "9578",
    ["dwMapID"] = 10,
    ["szFinder"] = "��֬Ѿͷ",
    ["szPony"] = "���",
    ["PosX"] = "41271",
  },
  [80] = 
  {
    ["PosY"] = "27583",
    ["dwMapID"] = 12,
    ["PosX"] = "37588",
    ["szPony"] = "����",
    ["szFinder"] = "̮��������",
  },
  [160] = 
  {
    ["PosY"] = "77000",
    ["dwMapID"] = 22,
    ["PosX"] = "77125",
    ["szPony"] = "����",
    ["szFinder"] = "����",
  },
  [320] = 
  {
    ["PosY"] = "12835",
    ["dwMapID"] = 9,
    ["szFinder"] = "������",
    ["szPony"] = "���",
    ["PosX"] = "60345",
  },
  [321] = 
  {
    ["PosY"] = "40119",
    ["dwMapID"] = 9,
    ["szFinder"] = "��ŵ",
    ["szPony"] = "���",
    ["PosX"] = "17119",
  },
  [161] = 
  {
    ["PosY"] = "38662",
    ["dwMapID"] = 22,
    ["szFinder"] = "�������",
    ["szPony"] = "����",
    ["PosX"] = "18827",
  },
  [322] = 
  {
    ["PosY"] = "14353",
    ["dwMapID"] = 9,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "54024",
  },
  [323] = 
  {
    ["PosY"] = "14398",
    ["dwMapID"] = 9,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "15089",
  },
  [81] = 
  {
    ["PosY"] = "45819",
    ["dwMapID"] = 12,
    ["szFinder"] = "����@��������",
    ["szPony"] = "����",
    ["PosX"] = "39578",
  },
  [162] = 
  {
    ["PosY"] = "64552",
    ["dwMapID"] = 22,
    ["szFinder"] = "����",
    ["szPony"] = "����",
    ["PosX"] = "49406",
  },
  [324] = 
  {
    ["PosY"] = "47864",
    ["dwMapID"] = 9,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "36075",
  },
  [325] = 
  {
    ["PosY"] = "10117",
    ["dwMapID"] = 9,
    ["szFinder"] = "���Ѳ���",
    ["szPony"] = "���",
    ["PosX"] = "20977",
  },
  [163] = 
  {
    ["PosY"] = "75551",
    ["dwMapID"] = 22,
    ["szFinder"] = "��ɽ����",
    ["szPony"] = "����",
    ["PosX"] = "80678",
  },
  [326] = 
  {
    ["PosY"] = "3600",
    ["dwMapID"] = 9,
    ["szFinder"] = "�����",
    ["szPony"] = "���",
    ["PosX"] = "57205",
  },
  [327] = 
  {
    ["PosY"] = "56242",
    ["dwMapID"] = 9,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "36573",
  },
  [41] = 
  {
    ["PosY"] = "15086",
    ["dwMapID"] = 10,
    ["PosX"] = "22138",
    ["szPony"] = "���",
    ["szFinder"] = "���",
  },
  [82] = 
  {
    ["PosY"] = 27794,
    ["dwMapID"] = 12,
    ["PosX"] = 73562,
    ["szPony"] = "����",
    ["szFinder"] = "����@��������",
  },
  [164] = 
  {
    ["PosY"] = "70788",
    ["dwMapID"] = 22,
    ["PosX"] = "43661",
    ["szPony"] = "����",
    ["szFinder"] = "С��",
  },
  [328] = 
  {
    ["PosY"] = "32889",
    ["dwMapID"] = 9,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "19514",
  },
  [329] = 
  {
    ["PosY"] = "12558",
    ["dwMapID"] = 9,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "24472",
  },
  [165] = 
  {
    ["PosY"] = "66270",
    ["dwMapID"] = 22,
    ["szFinder"] = "һ������һ",
    ["szPony"] = "����",
    ["PosX"] = "99764",
  },
  [330] = 
  {
    ["PosY"] = "88077",
    ["dwMapID"] = 9,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "44972",
  },
  [331] = 
  {
    ["PosY"] = "80064",
    ["dwMapID"] = 10,
    ["szFinder"] = "˾��ϧ��",
    ["szPony"] = "���",
    ["PosX"] = "50609",
  },
  [83] = 
  {
    ["PosY"] = "60506",
    ["dwMapID"] = 12,
    ["szFinder"] = "���",
    ["szPony"] = "����",
    ["PosX"] = "81781",
  },
  [166] = 
  {
    ["PosY"] = "75800",
    ["dwMapID"] = 22,
    ["szFinder"] = "񶺮",
    ["szPony"] = "����",
    ["PosX"] = "55875",
  },
  [332] = 
  {
    ["PosY"] = "44248",
    ["dwMapID"] = 10,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "19060",
  },
  [333] = 
  {
    ["PosY"] = "91012",
    ["dwMapID"] = 10,
    ["szFinder"] = "���Ѳ���",
    ["szPony"] = "���",
    ["PosX"] = "34933",
  },
  [167] = 
  {
    ["PosY"] = "20179",
    ["dwMapID"] = 22,
    ["szFinder"] = "���ͷ�����",
    ["szPony"] = "����",
    ["PosX"] = "69560",
  },
  [334] = 
  {
    ["PosY"] = "39133",
    ["dwMapID"] = 10,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "46389",
  },
  [21] = 
  {
    ["PosY"] = 8058,
    ["dwMapID"] = 9,
    ["PosX"] = 36280,
    ["szPony"] = "���",
    ["szFinder"] = "����@��������",
  },
  [42] = 
  {
    ["PosY"] = "93691",
    ["dwMapID"] = 10,
    ["szFinder"] = "Īа�ὣ",
    ["szPony"] = "���",
    ["PosX"] = "36699",
  },
  [84] = 
  {
    ["PosY"] = "14829",
    ["dwMapID"] = 12,
    ["szFinder"] = "���˯����",
    ["szPony"] = "����",
    ["PosX"] = "31332",
  },
  [168] = 
  {
    ["PosY"] = "40858",
    ["dwMapID"] = 22,
    ["szFinder"] = "����",
    ["szPony"] = "����",
    ["PosX"] = "12670",
  },
  [336] = 
  {
    ["PosY"] = "15843",
    ["dwMapID"] = 10,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "40904",
  },
  [337] = 
  {
    ["PosY"] = "36700",
    ["dwMapID"] = 10,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "14581",
  },
  [169] = 
  {
    ["PosY"] = "78933",
    ["dwMapID"] = 22,
    ["PosX"] = "86339",
    ["szPony"] = "����",
    ["szFinder"] = "����",
  },
  [338] = 
  {
    ["PosY"] = "26629",
    ["dwMapID"] = 10,
    ["szFinder"] = "���ָ�ɮ",
    ["szPony"] = "���",
    ["PosX"] = "66559",
  },
  [339] = 
  {
    ["PosY"] = "46127",
    ["dwMapID"] = 10,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "27053",
  },
  [85] = 
  {
    ["PosY"] = 48257,
    ["dwMapID"] = 12,
    ["PosX"] = 73811,
    ["szPony"] = "����",
    ["szFinder"] = "����@��������",
  },
  [170] = 
  {
    ["PosY"] = "17132",
    ["dwMapID"] = 22,
    ["szFinder"] = "�̽�������",
    ["szPony"] = "����",
    ["PosX"] = "75140",
  },
  [340] = 
  {
    ["PosY"] = "78907",
    ["dwMapID"] = 10,
    ["szFinder"] = "һ��ɵ��",
    ["szPony"] = "���",
    ["PosX"] = "18158",
  },
  [341] = 
  {
    ["PosY"] = "7886",
    ["dwMapID"] = 10,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "27119",
  },
  [171] = 
  {
    ["PosY"] = "19512",
    ["dwMapID"] = 22,
    ["szFinder"] = "��������",
    ["szPony"] = "����",
    ["PosX"] = "88555",
  },
  [342] = 
  {
    ["PosY"] = "22086",
    ["dwMapID"] = 10,
    ["szFinder"] = "�����ǻ�",
    ["szPony"] = "���",
    ["PosX"] = "59946",
  },
  [343] = 
  {
    ["PosY"] = "51183",
    ["dwMapID"] = 10,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "32456",
  },
  [43] = 
  {
    ["PosY"] = "37357",
    ["dwMapID"] = 10,
    ["PosX"] = "51975",
    ["szPony"] = "���",
    ["szFinder"] = "���͹�ͷ",
  },
  [86] = 
  {
    ["PosY"] = 29980,
    ["dwMapID"] = 12,
    ["PosX"] = 20512,
    ["szPony"] = "����",
    ["szFinder"] = "����@��������",
  },
  [172] = 
  {
    ["PosY"] = "68216",
    ["dwMapID"] = 22,
    ["szFinder"] = "��ī��",
    ["szPony"] = "����",
    ["PosX"] = "49985",
  },
  [344] = 
  {
    ["PosY"] = "76859",
    ["dwMapID"] = 10,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "28799",
  },
  [345] = 
  {
    ["PosY"] = "44935",
    ["dwMapID"] = 10,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "35427",
  },
  [173] = 
  {
    ["PosY"] = "38079",
    ["dwMapID"] = 22,
    ["szFinder"] = "͹ҹ����Ϯ͹",
    ["szPony"] = "����",
    ["PosX"] = "53651",
  },
  [346] = 
  {
    ["PosY"] = "13935",
    ["dwMapID"] = 10,
    ["szFinder"] = "���",
    ["szPony"] = "���",
    ["PosX"] = "32228",
  },
  [347] = 
  {
    ["PosY"] = "70337",
    ["dwMapID"] = 10,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "52257",
  },
  [87] = 
  {
    ["PosY"] = "23019",
    ["dwMapID"] = 12,
    ["szFinder"] = "�������",
    ["szPony"] = "����",
    ["PosX"] = "32440",
  },
  [174] = 
  {
    ["PosY"] = "21122",
    ["dwMapID"] = 22,
    ["PosX"] = "85745",
    ["szPony"] = "����",
    ["szFinder"] = "����",
  },
  [348] = 
  {
    ["PosY"] = "32486",
    ["dwMapID"] = 10,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "63186",
  },
  [349] = 
  {
    ["PosY"] = "98067",
    ["dwMapID"] = 10,
    ["szFinder"] = "л����",
    ["szPony"] = "���",
    ["PosX"] = "58779",
  },
  [175] = 
  {
    ["PosY"] = "61796",
    ["dwMapID"] = 22,
    ["szFinder"] = "�����������",
    ["szPony"] = "����",
    ["PosX"] = "98661",
  },
  [350] = 
  {
    ["PosY"] = "38163",
    ["dwMapID"] = 12,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "10189",
  },
  [11] = 
  {
    ["PosY"] = "61383",
    ["dwMapID"] = 9,
    ["PosX"] = "42424",
    ["szPony"] = "���",
    ["szFinder"] = "Ľ����",
  },
  [22] = 
  {
    ["PosY"] = "46241",
    ["dwMapID"] = 9,
    ["szFinder"] = "���಻��",
    ["szPony"] = "���",
    ["PosX"] = "20568",
  },
  [44] = 
  {
    ["PosY"] = "69333",
    ["dwMapID"] = 10,
    ["szFinder"] = "����",
    ["szPony"] = "���",
    ["PosX"] = "59822",
  },
  [88] = 
  {
    ["PosY"] = "4505",
    ["dwMapID"] = 12,
    ["szFinder"] = "ɱ����С��",
    ["szPony"] = "����",
    ["PosX"] = "31583",
  },
  [176] = 
  {
    ["PosY"] = "37018",
    ["dwMapID"] = 22,
    ["szFinder"] = "ƫ������",
    ["szPony"] = "����",
    ["PosX"] = "48903",
  },
  [352] = 
  {
    ["PosY"] = "58660",
    ["dwMapID"] = 12,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "35377",
  },
  [353] = 
  {
    ["PosY"] = "28856",
    ["dwMapID"] = 12,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "41201",
  },
  [177] = 
  {
    ["PosY"] = "32698",
    ["dwMapID"] = 22,
    ["szFinder"] = "���������",
    ["szPony"] = "����",
    ["PosX"] = "43653",
  },
  [354] = 
  {
    ["PosY"] = "15569",
    ["dwMapID"] = 12,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "16823",
  },
  [355] = 
  {
    ["PosY"] = "36751",
    ["dwMapID"] = 12,
    ["szFinder"] = "���̃�",
    ["szPony"] = "����",
    ["PosX"] = "66655",
  },
  [89] = 
  {
    ["PosY"] = "10384",
    ["dwMapID"] = 12,
    ["szFinder"] = "С����",
    ["szPony"] = "����",
    ["PosX"] = "25123",
  },
  [178] = 
  {
    ["PosY"] = 18409,
    ["dwMapID"] = 22,
    ["PosX"] = 93915,
    ["szPony"] = "����",
    ["szFinder"] = "����@��������",
  },
  [356] = 
  {
    ["PosY"] = "32278",
    ["dwMapID"] = 12,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "67245",
  },
  [357] = 
  {
    ["PosY"] = "24974",
    ["dwMapID"] = 12,
    ["szFinder"] = "ᰳ�����",
    ["szPony"] = "����",
    ["PosX"] = "44051",
  },
  [179] = 
  {
    ["PosY"] = "40668",
    ["dwMapID"] = 22,
    ["szFinder"] = "ʮ�����Ǵ���",
    ["szPony"] = "����",
    ["PosX"] = "63864",
  },
  [358] = 
  {
    ["PosY"] = "29127",
    ["dwMapID"] = 12,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "51988",
  },
  [359] = 
  {
    ["PosY"] = "44570",
    ["dwMapID"] = 12,
    ["szFinder"] = "����",
    ["szPony"] = "����",
    ["PosX"] = "35263",
  },
  [45] = 
  {
    ["PosY"] = 25732,
    ["dwMapID"] = 10,
    ["szFinder"] = "����@��������",
    ["szPony"] = "���",
    ["PosX"] = 62952,
  },
  [90] = 
  {
    ["PosY"] = "9803",
    ["dwMapID"] = 12,
    ["szFinder"] = "�������",
    ["szPony"] = "����",
    ["PosX"] = "36844",
  },
  [180] = 
  {
    ["PosY"] = "56876",
    ["dwMapID"] = 22,
    ["szFinder"] = "��ү�ָ�",
    ["szPony"] = "����",
    ["PosX"] = "78398",
  },
  [360] = 
  {
    ["PosY"] = "19589",
    ["dwMapID"] = 12,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "67158",
  },
  [361] = 
  {
    ["PosY"] = "58671",
    ["dwMapID"] = 12,
    ["szFinder"] = "������",
    ["szPony"] = "����",
    ["PosX"] = "9422",
  },
  [181] = 
  {
    ["PosY"] = 67158,
    ["dwMapID"] = 22,
    ["szFinder"] = "����@��������",
    ["szPony"] = "����",
    ["PosX"] = 58792,
  },
  [362] = 
  {
    ["PosY"] = "47265",
    ["dwMapID"] = 12,
    ["szFinder"] = "����������",
    ["szPony"] = "����",
    ["PosX"] = "12608",
  },
  [363] = 
  {
    ["PosY"] = "25339",
    ["dwMapID"] = 12,
    ["szFinder"] = "Ī��",
    ["szPony"] = "����",
    ["PosX"] = "40357",
  },
  [91] = 
  {
    ["PosY"] = "44738",
    ["dwMapID"] = 12,
    ["szFinder"] = "�������",
    ["szPony"] = "����",
    ["PosX"] = "8674",
  },
  [182] = 
  {
    ["PosY"] = "65082",
    ["dwMapID"] = 22,
    ["szFinder"] = "�͹�������",
    ["szPony"] = "����",
    ["PosX"] = "81613",
  },
  [364] = 
  {
    ["PosY"] = "19216",
    ["dwMapID"] = 12,
    ["szFinder"] = "�׷㳾",
    ["szPony"] = "����",
    ["PosX"] = "50268",
  },
  [365] = 
  {
    ["PosY"] = "62495",
    ["dwMapID"] = 12,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "30440",
  },
  [183] = 
  {
    ["PosY"] = "75838",
    ["dwMapID"] = 22,
    ["szFinder"] = "Ҷ�",
    ["szPony"] = "����",
    ["PosX"] = "45158",
  },
  [366] = 
  {
    ["PosY"] = "48307",
    ["dwMapID"] = 12,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "7719",
  },
  [23] = 
  {
    ["PosY"] = "20906",
    ["dwMapID"] = 9,
    ["szFinder"] = "Ľ����",
    ["szPony"] = "���",
    ["PosX"] = "4201",
  },
  [46] = 
  {
    ["PosY"] = "21385",
    ["dwMapID"] = 10,
    ["szFinder"] = "��ң��",
    ["szPony"] = "���",
    ["PosX"] = "47280",
  },
  [92] = 
  {
    ["PosY"] = "22001",
    ["dwMapID"] = 12,
    ["szFinder"] = "����ʫ�黭��",
    ["szPony"] = "����",
    ["PosX"] = "55209",
  },
  [184] = 
  {
    ["PosY"] = "45601",
    ["dwMapID"] = 23,
    ["PosX"] = "66102",
    ["szPony"] = "���",
    ["szFinder"] = "����@��������",
  },
  [368] = 
  {
    ["PosY"] = "48738",
    ["dwMapID"] = 12,
    ["szFinder"] = "���ƿ���",
    ["szPony"] = "����",
    ["PosX"] = "57818",
  },
  [369] = 
  {
    ["PosY"] = "29134",
    ["dwMapID"] = 12,
    ["szFinder"] = "���Ѳ���",
    ["szPony"] = "����",
    ["PosX"] = "45235",
  },
  [185] = 
  {
    ["PosY"] = "38578",
    ["dwMapID"] = 23,
    ["PosX"] = "19853",
    ["szPony"] = "���",
    ["szFinder"] = "������΢",
  },
  [370] = 
  {
    ["PosY"] = "11454",
    ["dwMapID"] = 12,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "43979",
  },
  [371] = 
  {
    ["PosY"] = "4934",
    ["dwMapID"] = 12,
    ["szFinder"] = "��Ⱦ��֬Ѫ",
    ["szPony"] = "����",
    ["PosX"] = "58086",
  },
  [93] = 
  {
    ["PosY"] = 37046,
    ["dwMapID"] = 12,
    ["szFinder"] = "����@��������",
    ["szPony"] = "����",
    ["PosX"] = 35979,
  },
  [186] = 
  {
    ["PosY"] = "44596",
    ["dwMapID"] = 23,
    ["szFinder"] = "����",
    ["szPony"] = "���",
    ["PosX"] = "83604",
  },
  [372] = 
  {
    ["PosY"] = "61081",
    ["dwMapID"] = 12,
    ["szFinder"] = "��С��",
    ["szPony"] = "����",
    ["PosX"] = "17227",
  },
  [373] = 
  {
    ["PosY"] = "20781",
    ["dwMapID"] = 12,
    ["szFinder"] = "��ŵ",
    ["szPony"] = "����",
    ["PosX"] = "18785",
  },
  [187] = 
  {
    ["PosY"] = "67153",
    ["dwMapID"] = 23,
    ["szFinder"] = "��ң��",
    ["szPony"] = "���",
    ["PosX"] = "90684",
  },
  [374] = 
  {
    ["PosY"] = "33304",
    ["dwMapID"] = 12,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "18477",
  },
  [375] = 
  {
    ["PosY"] = "40441",
    ["dwMapID"] = 12,
    ["szFinder"] = "�崿��",
    ["szPony"] = "����",
    ["PosX"] = "79982",
  },
  [47] = 
  {
    ["PosY"] = "46619",
    ["dwMapID"] = 10,
    ["szFinder"] = "��С��",
    ["szPony"] = "���",
    ["PosX"] = "30452",
  },
  [94] = 
  {
    ["PosY"] = "78695",
    ["dwMapID"] = 13,
    ["szFinder"] = "����һ˭ǳЦ",
    ["szPony"] = "����",
    ["PosX"] = "86080",
  },
  [188] = 
  {
    ["PosY"] = "60572",
    ["dwMapID"] = 23,
    ["szFinder"] = "��Ϯ�Ŀ�ʼ",
    ["szPony"] = "���",
    ["PosX"] = "45566",
  },
  [376] = 
  {
    ["PosY"] = "15009",
    ["dwMapID"] = 12,
    ["szFinder"] = "���ڳ���",
    ["szPony"] = "����",
    ["PosX"] = "81355",
  },
  [377] = 
  {
    ["PosY"] = "23825",
    ["dwMapID"] = 12,
    ["szFinder"] = "��Ҷ������",
    ["szPony"] = "����",
    ["PosX"] = "47533",
  },
  [189] = 
  {
    ["PosY"] = "48858",
    ["dwMapID"] = 23,
    ["szFinder"] = "��������",
    ["szPony"] = "���",
    ["PosX"] = "72184",
  },
  [378] = 
  {
    ["PosY"] = "32985",
    ["dwMapID"] = 12,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "27132",
  },
  [379] = 
  {
    ["PosY"] = "22354",
    ["dwMapID"] = 12,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "14108",
  },
  [95] = 
  {
    ["PosY"] = "15811",
    ["dwMapID"] = 13,
    ["szFinder"] = "��������¥",
    ["szPony"] = "����",
    ["PosX"] = "28174",
  },
  [190] = 
  {
    ["PosY"] = "12235",
    ["dwMapID"] = 23,
    ["szFinder"] = "˾ͽ����",
    ["szPony"] = "���",
    ["PosX"] = "8520",
  },
  [380] = 
  {
    ["PosY"] = "26656",
    ["dwMapID"] = 13,
    ["szFinder"] = "����",
    ["szPony"] = "����",
    ["PosX"] = "34601",
  },
  [381] = 
  {
    ["PosY"] = "82529",
    ["dwMapID"] = 13,
    ["szFinder"] = "�������",
    ["szPony"] = "����",
    ["PosX"] = "37722",
  },
  [191] = 
  {
    ["PosY"] = 28923,
    ["dwMapID"] = 23,
    ["PosX"] = 59660,
    ["szPony"] = "���",
    ["szFinder"] = "����@��������",
  },
  [382] = 
  {
    ["PosY"] = "80169",
    ["dwMapID"] = 13,
    ["szFinder"] = "����֮",
    ["szPony"] = "����",
    ["PosX"] = "33073",
  },
  [3] = 
  {
    ["PosY"] = "33588",
    ["dwMapID"] = 9,
    ["szFinder"] = "Ҷ΢��",
    ["szPony"] = "���",
    ["PosX"] = "36734",
  },
  [6] = 
  {
    ["PosY"] = "48571",
    ["dwMapID"] = 9,
    ["PosX"] = "7491",
    ["szPony"] = "���",
    ["szFinder"] = "������ǻ�",
  },
  [12] = 
  {
    ["PosY"] = "17111",
    ["dwMapID"] = 9,
    ["szFinder"] = "�崿��",
    ["szPony"] = "���",
    ["PosX"] = "3028",
  },
  [24] = 
  {
    ["PosY"] = "41906",
    ["dwMapID"] = 9,
    ["szFinder"] = "һ������һ",
    ["szPony"] = "���",
    ["PosX"] = "55528",
  },
  [48] = 
  {
    ["PosY"] = "56647",
    ["dwMapID"] = 10,
    ["szFinder"] = "������Ȼ����",
    ["szPony"] = "���",
    ["PosX"] = "15292",
  },
  [96] = 
  {
    ["PosY"] = "48156",
    ["dwMapID"] = 13,
    ["szFinder"] = "����@��������",
    ["szPony"] = "����",
    ["PosX"] = "89680",
  },
  [192] = 
  {
    ["PosY"] = "68551",
    ["dwMapID"] = 23,
    ["szFinder"] = "����",
    ["szPony"] = "���",
    ["PosX"] = "77795",
  },
  [384] = 
  {
    ["PosY"] = "57856",
    ["dwMapID"] = 13,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "89814",
  },
  [385] = 
  {
    ["PosY"] = "30457",
    ["dwMapID"] = 13,
    ["szFinder"] = "���Ѳ���",
    ["szPony"] = "����",
    ["PosX"] = "65187",
  },
  [193] = 
  {
    ["PosY"] = "71382",
    ["dwMapID"] = 23,
    ["szFinder"] = "���Ѳ���",
    ["szPony"] = "���",
    ["PosX"] = "87458",
  },
  [386] = 
  {
    ["PosY"] = "15685",
    ["dwMapID"] = 13,
    ["szFinder"] = "�崿��",
    ["szPony"] = "����",
    ["PosX"] = "52131",
  },
  [387] = 
  {
    ["PosY"] = "51534",
    ["dwMapID"] = 13,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "70963",
  },
  [97] = 
  {
    ["PosY"] = "43402",
    ["dwMapID"] = 13,
    ["szFinder"] = "ī��",
    ["szPony"] = "����",
    ["PosX"] = "39414",
  },
  [194] = 
  {
    ["PosY"] = "6896",
    ["dwMapID"] = 23,
    ["szFinder"] = "����@��������",
    ["szPony"] = "���",
    ["PosX"] = "62137",
  },
  [388] = 
  {
    ["PosY"] = "13357",
    ["dwMapID"] = 13,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "9611",
  },
  [389] = 
  {
    ["PosY"] = "69639",
    ["dwMapID"] = 13,
    ["szFinder"] = "ī��ŨŨ",
    ["szPony"] = "����",
    ["PosX"] = "49869",
  },
  [195] = 
  {
    ["PosY"] = "51590",
    ["dwMapID"] = 23,
    ["szFinder"] = "����",
    ["szPony"] = "���",
    ["PosX"] = "74815",
  },
  [390] = 
  {
    ["PosY"] = "59832",
    ["dwMapID"] = 13,
    ["szFinder"] = "һ������",
    ["szPony"] = "����",
    ["PosX"] = "65606",
  },
  [391] = 
  {
    ["PosY"] = "17167",
    ["dwMapID"] = 13,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "75979",
  },
  [49] = 
  {
    ["PosY"] = "92088",
    ["dwMapID"] = 10,
    ["szFinder"] = "��������",
    ["szPony"] = "���",
    ["PosX"] = "55789",
  },
  [98] = 
  {
    ["PosY"] = "17185",
    ["dwMapID"] = 13,
    ["szFinder"] = "Ҷ��",
    ["szPony"] = "����",
    ["PosX"] = "16692",
  },
  [196] = 
  {
    ["PosY"] = "35614",
    ["dwMapID"] = 23,
    ["szFinder"] = "����ʫ",
    ["szPony"] = "���",
    ["PosX"] = "61806",
  },
  [392] = 
  {
    ["PosY"] = "62592",
    ["dwMapID"] = 13,
    ["szFinder"] = "��Ѿͷ",
    ["szPony"] = "����",
    ["PosX"] = "58646",
  },
  [393] = 
  {
    ["PosY"] = "8979",
    ["dwMapID"] = 13,
    ["szFinder"] = "���̃�",
    ["szPony"] = "����",
    ["PosX"] = "70682",
  },
  [197] = 
  {
    ["PosY"] = "12673",
    ["dwMapID"] = 23,
    ["szFinder"] = "����ָ",
    ["szPony"] = "���",
    ["PosX"] = "49229",
  },
  [394] = 
  {
    ["PosY"] = "47027",
    ["dwMapID"] = 13,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "71217",
  },
  [395] = 
  {
    ["PosY"] = "33734",
    ["dwMapID"] = 13,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "47110",
  },
  [99] = 
  {
    ["PosY"] = "78553",
    ["dwMapID"] = 13,
    ["PosX"] = "38076",
    ["szPony"] = "����",
    ["szFinder"] = "��С��",
  },
  [198] = 
  {
    ["PosY"] = "90986",
    ["dwMapID"] = 23,
    ["szFinder"] = "���ֵ�����д",
    ["szPony"] = "���",
    ["PosX"] = "29538",
  },
  [396] = 
  {
    ["PosY"] = "44682",
    ["dwMapID"] = 13,
    ["szFinder"] = "����΢",
    ["szPony"] = "����",
    ["PosX"] = "52516",
  },
  [397] = 
  {
    ["PosY"] = "64722",
    ["dwMapID"] = 13,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "56020",
  },
  [199] = 
  {
    ["PosY"] = "79285",
    ["dwMapID"] = 23,
    ["szFinder"] = "���ŷ���",
    ["szPony"] = "���",
    ["PosX"] = "54957",
  },
  [398] = 
  {
    ["PosY"] = "41739",
    ["dwMapID"] = 13,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "47199",
  },
  [25] = 
  {
    ["PosY"] = "73754",
    ["dwMapID"] = 9,
    ["szFinder"] = "����",
    ["szPony"] = "���",
    ["PosX"] = "6532",
  },
  [50] = 
  {
    ["PosY"] = "14603",
    ["dwMapID"] = 10,
    ["szFinder"] = "��������",
    ["szPony"] = "���",
    ["PosX"] = "45120",
  },
  [100] = 
  {
    ["PosY"] = "59411",
    ["dwMapID"] = 13,
    ["PosX"] = "76304",
    ["szPony"] = "����",
    ["szFinder"] = "��誳�",
  },
  [200] = 
  {
    ["PosY"] = "19338",
    ["dwMapID"] = 23,
    ["szFinder"] = "Ľ����",
    ["szPony"] = "���",
    ["PosX"] = "85177",
  },
  [400] = 
  {
    ["PosY"] = "63202",
    ["dwMapID"] = 13,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "63803",
  },
  [401] = 
  {
    ["PosY"] = "14264",
    ["dwMapID"] = 13,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "59225",
  },
  [201] = 
  {
    ["PosY"] = "91781",
    ["dwMapID"] = 23,
    ["PosX"] = "48575",
    ["szPony"] = "���",
    ["szFinder"] = "ѩ����޹",
  },
  [402] = 
  {
    ["PosY"] = "27304",
    ["dwMapID"] = 21,
    ["szFinder"] = "��������",
    ["szPony"] = "����",
    ["PosX"] = "16718",
  },
  [403] = 
  {
    ["PosY"] = "44194",
    ["dwMapID"] = 21,
    ["szFinder"] = "����ϸ��",
    ["szPony"] = "����",
    ["PosX"] = "69365",
  },
  [101] = 
  {
    ["PosY"] = "62933",
    ["dwMapID"] = 13,
    ["szFinder"] = "�ڴ�������",
    ["szPony"] = "����",
    ["PosX"] = "4374",
  },
  [202] = 
  {
    ["PosY"] = 54534,
    ["dwMapID"] = 23,
    ["szFinder"] = "����@��������",
    ["szPony"] = "���",
    ["PosX"] = 48041,
  },
  [404] = 
  {
    ["PosY"] = "9960",
    ["dwMapID"] = 21,
    ["szFinder"] = "��������",
    ["szPony"] = "����",
    ["PosX"] = "43296",
  },
  [405] = 
  {
    ["PosY"] = "49839",
    ["dwMapID"] = 21,
    ["szFinder"] = "��Ҷ���",
    ["szPony"] = "����",
    ["PosX"] = "17366",
  },
  [203] = 
  {
    ["PosY"] = "9046",
    ["dwMapID"] = 23,
    ["szFinder"] = "���л�Ӱ",
    ["szPony"] = "���",
    ["PosX"] = "27347",
  },
  [406] = 
  {
    ["PosY"] = "25925",
    ["dwMapID"] = 21,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "78386",
  },
  [407] = 
  {
    ["PosY"] = "66982",
    ["dwMapID"] = 21,
    ["szFinder"] = "����ô����",
    ["szPony"] = "����",
    ["PosX"] = "73481",
  },
  [51] = 
  {
    ["PosY"] = "36324",
    ["dwMapID"] = 10,
    ["PosX"] = "35221",
    ["szPony"] = "���",
    ["szFinder"] = "¬�ȵ�",
  },
  [102] = 
  {
    ["PosY"] = "17726",
    ["dwMapID"] = 13,
    ["szFinder"] = "��������",
    ["szPony"] = "����",
    ["PosX"] = "84973",
  },
  [204] = 
  {
    ["PosY"] = "20788",
    ["dwMapID"] = 23,
    ["szFinder"] = "���Ѳ���",
    ["szPony"] = "���",
    ["PosX"] = "16774",
  },
  [408] = 
  {
    ["PosY"] = "50397",
    ["dwMapID"] = 21,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "79453",
  },
  [409] = 
  {
    ["PosY"] = "25040",
    ["dwMapID"] = 21,
    ["szFinder"] = "��С��",
    ["szPony"] = "����",
    ["PosX"] = "82105",
  },
  [205] = 
  {
    ["PosY"] = "4589",
    ["dwMapID"] = 23,
    ["szFinder"] = "��������",
    ["szPony"] = "���",
    ["PosX"] = "13827",
  },
  [410] = 
  {
    ["PosY"] = "61371",
    ["dwMapID"] = 21,
    ["szFinder"] = "��ң��ü",
    ["szPony"] = "����",
    ["PosX"] = "22124",
  },
  [411] = 
  {
    ["PosY"] = "28665",
    ["dwMapID"] = 21,
    ["szFinder"] = "һ����ӥ��һ",
    ["szPony"] = "����",
    ["PosX"] = "30084",
  },
  [103] = 
  {
    ["PosY"] = "60645",
    ["dwMapID"] = 13,
    ["szFinder"] = "��ң��",
    ["szPony"] = "����",
    ["PosX"] = "33413",
  },
  [206] = 
  {
    ["PosY"] = "12342",
    ["dwMapID"] = 23,
    ["szFinder"] = "����֮",
    ["szPony"] = "���",
    ["PosX"] = "27146",
  },
  [412] = 
  {
    ["PosY"] = "16297",
    ["dwMapID"] = 21,
    ["szFinder"] = "ͫȾ",
    ["szPony"] = "����",
    ["PosX"] = "42484",
  },
  [413] = 
  {
    ["PosY"] = "68863",
    ["dwMapID"] = 21,
    ["szFinder"] = "�޷�",
    ["szPony"] = "����",
    ["PosX"] = "64660",
  },
  [207] = 
  {
    ["PosY"] = "81797",
    ["dwMapID"] = 23,
    ["szFinder"] = "�Ǳ���",
    ["szPony"] = "���",
    ["PosX"] = "18887",
  },
  [414] = 
  {
    ["PosY"] = "16166",
    ["dwMapID"] = 21,
    ["szFinder"] = "����",
    ["szPony"] = "����",
    ["PosX"] = "79988",
  },
  [13] = 
  {
    ["PosY"] = "60158",
    ["dwMapID"] = 9,
    ["szFinder"] = "��Ѫ��筴�",
    ["szPony"] = "���",
    ["PosX"] = "4416",
  },
  [26] = 
  {
    ["PosY"] = "79850",
    ["dwMapID"] = 9,
    ["PosX"] = "43168",
    ["szPony"] = "���",
    ["szFinder"] = "��������",
  },
  [52] = 
  {
    ["PosY"] = "52951",
    ["dwMapID"] = 10,
    ["PosX"] = "13564",
    ["szPony"] = "���",
    ["szFinder"] = "���͵��",
  },
  [104] = 
  {
    ["PosY"] = "80780",
    ["dwMapID"] = 13,
    ["szFinder"] = "��ң��",
    ["szPony"] = "����",
    ["PosX"] = "93645",
  },
  [208] = 
  {
    ["PosY"] = "76531",
    ["dwMapID"] = 23,
    ["szFinder"] = "���䳾",
    ["szPony"] = "���",
    ["PosX"] = "40703",
  },
  [416] = 
  {
    ["PosY"] = "30447",
    ["dwMapID"] = 21,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "48142",
  },
  [417] = 
  {
    ["PosY"] = "49658",
    ["dwMapID"] = 21,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "8247",
  },
  [209] = 
  {
    ["PosY"] = 88597,
    ["dwMapID"] = 23,
    ["szFinder"] = "����@��������",
    ["szPony"] = "���",
    ["PosX"] = 54260,
  },
  [418] = 
  {
    ["PosY"] = "39376",
    ["dwMapID"] = 21,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "57090",
  },
  [419] = 
  {
    ["PosY"] = "20724",
    ["dwMapID"] = 21,
    ["szFinder"] = "�ĳ���",
    ["szPony"] = "����",
    ["PosX"] = "38178",
  },
  [105] = 
  {
    ["PosY"] = "32840",
    ["dwMapID"] = 13,
    ["szFinder"] = "�޷�",
    ["szPony"] = "����",
    ["PosX"] = "19089",
  },
  [210] = 
  {
    ["PosY"] = "15252",
    ["dwMapID"] = 23,
    ["szFinder"] = "īҹ˼ѩ",
    ["szPony"] = "���",
    ["PosX"] = "56083",
  },
  [420] = 
  {
    ["PosY"] = "32452",
    ["dwMapID"] = 21,
    ["szFinder"] = "��С��",
    ["szPony"] = "����",
    ["PosX"] = "80936",
  },
  [421] = 
  {
    ["PosY"] = "16432",
    ["dwMapID"] = 21,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "38443",
  },
  [211] = 
  {
    ["PosY"] = "42954",
    ["dwMapID"] = 23,
    ["PosX"] = "23652",
    ["szPony"] = "���",
    ["szFinder"] = "����ϵ����",
  },
  [422] = 
  {
    ["PosY"] = "45311",
    ["dwMapID"] = 21,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "62967",
  },
  [423] = 
  {
    ["PosY"] = "46684",
    ["dwMapID"] = 21,
    ["szFinder"] = "��С��",
    ["szPony"] = "����",
    ["PosX"] = "36053",
  },
  [53] = 
  {
    ["PosY"] = "91346",
    ["dwMapID"] = 10,
    ["szFinder"] = "���",
    ["szPony"] = "���",
    ["PosX"] = "20165",
  },
  [106] = 
  {
    ["PosY"] = "20069",
    ["dwMapID"] = 13,
    ["PosX"] = "7094",
    ["szPony"] = "����",
    ["szFinder"] = "������",
  },
  [212] = 
  {
    ["PosY"] = "33707",
    ["dwMapID"] = 23,
    ["szFinder"] = "����С����",
    ["szPony"] = "���",
    ["PosX"] = "12060",
  },
  [424] = 
  {
    ["PosY"] = "61630",
    ["dwMapID"] = 21,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "16889",
  },
  [425] = 
  {
    ["PosY"] = "14802",
    ["dwMapID"] = 21,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "71321",
  },
  [213] = 
  {
    ["PosY"] = 17822,
    ["dwMapID"] = 23,
    ["PosX"] = 7997,
    ["szPony"] = "���",
    ["szFinder"] = "����@��������",
  },
  [426] = 
  {
    ["PosY"] = "47493",
    ["dwMapID"] = 21,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "41050",
  },
  [427] = 
  {
    ["PosY"] = "27465",
    ["dwMapID"] = 21,
    ["szFinder"] = "�������",
    ["szPony"] = "����",
    ["PosX"] = "49600",
  },
  [107] = 
  {
    ["PosY"] = "35468",
    ["dwMapID"] = 13,
    ["szFinder"] = "����",
    ["szPony"] = "����",
    ["PosX"] = "10059",
  },
  [214] = 
  {
    ["PosY"] = "79314",
    ["dwMapID"] = 23,
    ["PosX"] = "48815",
    ["szPony"] = "���",
    ["szFinder"] = "�ӽ�������",
  },
  [428] = 
  {
    ["PosY"] = "57261",
    ["dwMapID"] = 21,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "13962",
  },
  [429] = 
  {
    ["PosY"] = "36919",
    ["dwMapID"] = 21,
    ["szFinder"] = "����ǹ���",
    ["szPony"] = "����",
    ["PosX"] = "78525",
  },
  [215] = 
  {
    ["PosY"] = 52572,
    ["dwMapID"] = 23,
    ["szFinder"] = "����@��������",
    ["szPony"] = "���",
    ["PosX"] = 7519,
  },
  [430] = 
  {
    ["PosY"] = "60624",
    ["dwMapID"] = 21,
    ["szFinder"] = "Ҷ����",
    ["szPony"] = "����",
    ["PosX"] = "39969",
  },
  [27] = 
  {
    ["PosY"] = "9273",
    ["dwMapID"] = 9,
    ["szFinder"] = "������",
    ["szPony"] = "���",
    ["PosX"] = "26981",
  },
  [54] = 
  {
    ["PosY"] = "82755",
    ["dwMapID"] = 10,
    ["szFinder"] = "����������@�屡����",
    ["szPony"] = "���",
    ["PosX"] = "22876",
  },
  [108] = 
  {
    ["PosY"] = "19540",
    ["dwMapID"] = 13,
    ["PosX"] = "31088",
    ["szPony"] = "����",
    ["szFinder"] = "����",
  },
  [216] = 
  {
    ["PosY"] = "80676",
    ["dwMapID"] = 23,
    ["PosX"] = "88353",
    ["szPony"] = "���",
    ["szFinder"] = "�������",
  },
  [432] = 
  {
    ["PosY"] = "14768",
    ["dwMapID"] = 21,
    ["szFinder"] = "�������",
    ["szPony"] = "����",
    ["PosX"] = "8755",
  },
  [433] = 
  {
    ["PosY"] = "22169",
    ["dwMapID"] = 22,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "64206",
  },
  [217] = 
  {
    ["PosY"] = "6026",
    ["dwMapID"] = 30,
    ["szFinder"] = "ɵ����",
    ["szPony"] = "����",
    ["PosX"] = "61407",
  },
  [434] = 
  {
    ["PosY"] = "21820",
    ["dwMapID"] = 22,
    ["szFinder"] = "���Ѳ���",
    ["szPony"] = "����",
    ["PosX"] = "53085",
  },
  [435] = 
  {
    ["PosY"] = "28719",
    ["dwMapID"] = 22,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "32050",
  },
  [109] = 
  {
    ["PosY"] = 55219,
    ["dwMapID"] = 13,
    ["szFinder"] = "����@��������",
    ["szPony"] = "����",
    ["PosX"] = 58027,
  },
  [218] = 
  {
    ["PosY"] = "7612",
    ["dwMapID"] = 30,
    ["szFinder"] = "Ĭ��Ц��Ȼ",
    ["szPony"] = "����",
    ["PosX"] = "101501",
  },
  [436] = 
  {
    ["PosY"] = "8795",
    ["dwMapID"] = 22,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "76046",
  },
  [437] = 
  {
    ["PosY"] = "71844",
    ["dwMapID"] = 22,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "10996",
  },
  [219] = 
  {
    ["PosY"] = "68569",
    ["dwMapID"] = 30,
    ["szFinder"] = "������",
    ["szPony"] = "����",
    ["PosX"] = "58636",
  },
  [438] = 
  {
    ["PosY"] = "41390",
    ["dwMapID"] = 22,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "31601",
  },
  [439] = 
  {
    ["PosY"] = "79068",
    ["dwMapID"] = 22,
    ["szFinder"] = "л����",
    ["szPony"] = "����",
    ["PosX"] = "73205",
  },
  [55] = 
  {
    ["PosY"] = "23759",
    ["dwMapID"] = 10,
    ["PosX"] = "23973",
    ["szPony"] = "���",
    ["szFinder"] = "��С��",
  },
  [110] = 
  {
    ["PosY"] = "24287",
    ["dwMapID"] = 13,
    ["szFinder"] = "��Сϧ",
    ["szPony"] = "����",
    ["PosX"] = "7390",
  },
  [220] = 
  {
    ["PosY"] = 14887,
    ["dwMapID"] = 30,
    ["szFinder"] = "����@��������",
    ["szPony"] = "����",
    ["PosX"] = 51281,
  },
  [440] = 
  {
    ["PosY"] = "43097",
    ["dwMapID"] = 22,
    ["szFinder"] = "���Ѳ���",
    ["szPony"] = "����",
    ["PosX"] = "67795",
  },
  [441] = 
  {
    ["PosY"] = "36738",
    ["dwMapID"] = 22,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "64023",
  },
  [221] = 
  {
    ["PosY"] = "57746",
    ["dwMapID"] = 30,
    ["PosX"] = "56691",
    ["szPony"] = "����",
    ["szFinder"] = "������Ӱ",
  },
  [442] = 
  {
    ["PosY"] = "79676",
    ["dwMapID"] = 22,
    ["szFinder"] = "��ң��ü",
    ["szPony"] = "����",
    ["PosX"] = "40998",
  },
  [443] = 
  {
    ["PosY"] = "42523",
    ["dwMapID"] = 22,
    ["szFinder"] = "�̹��",
    ["szPony"] = "����",
    ["PosX"] = "78721",
  },
  [111] = 
  {
    ["PosY"] = "72685",
    ["dwMapID"] = 13,
    ["PosX"] = "42548",
    ["szPony"] = "����",
    ["szFinder"] = "����д��",
  },
  [222] = 
  {
    ["PosY"] = "7960",
    ["dwMapID"] = 30,
    ["PosX"] = "27566",
    ["szPony"] = "����",
    ["szFinder"] = "ī��",
  },
  [444] = 
  {
    ["PosY"] = "62091",
    ["dwMapID"] = 22,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "40380",
  },
  [445] = 
  {
    ["PosY"] = "11752",
    ["dwMapID"] = 22,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "23616",
  },
  [223] = 
  {
    ["PosY"] = "27886",
    ["dwMapID"] = 30,
    ["szFinder"] = "�Ƶ���",
    ["szPony"] = "����",
    ["PosX"] = "98300",
  },
  [446] = 
  {
    ["PosY"] = "33043",
    ["dwMapID"] = 22,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "61307",
  },
  [7] = 
  {
    ["PosY"] = "43031",
    ["dwMapID"] = 9,
    ["szFinder"] = "���������",
    ["szPony"] = "���",
    ["PosX"] = "60038",
  },
  [14] = 
  {
    ["PosY"] = "84507",
    ["dwMapID"] = 9,
    ["PosX"] = "13241",
    ["szPony"] = "���",
    ["szFinder"] = "��Ѫ��筴�",
  },
  [28] = 
  {
    ["PosY"] = "10697",
    ["dwMapID"] = 9,
    ["szFinder"] = "�͹�������",
    ["szPony"] = "���",
    ["PosX"] = "12326",
  },
  [56] = 
  {
    ["PosY"] = 60798,
    ["dwMapID"] = 10,
    ["szFinder"] = "����@��������",
    ["szPony"] = "���",
    ["PosX"] = 65987,
  },
  [112] = 
  {
    ["PosY"] = "27470",
    ["dwMapID"] = 13,
    ["szFinder"] = "��Ӱ",
    ["szPony"] = "����",
    ["PosX"] = "29230",
  },
  [224] = 
  {
    ["PosY"] = 46145,
    ["dwMapID"] = 30,
    ["szFinder"] = "����@��������",
    ["szPony"] = "����",
    ["PosX"] = 51880,
  },
  [448] = 
  {
    ["PosY"] = "27404",
    ["dwMapID"] = 22,
    ["szFinder"] = "��С��",
    ["szPony"] = "����",
    ["PosX"] = "16198",
  },
  [449] = 
  {
    ["PosY"] = "72616",
    ["dwMapID"] = 23,
    ["szFinder"] = "�˺�����",
    ["szPony"] = "���",
    ["PosX"] = "25308",
  },
  [225] = 
  {
    ["PosY"] = "14634",
    ["dwMapID"] = 30,
    ["szFinder"] = "���᳾",
    ["szPony"] = "����",
    ["PosX"] = "98242",
  },
  [450] = 
  {
    ["PosY"] = "18924",
    ["dwMapID"] = 23,
    ["szFinder"] = "�˺�����",
    ["szPony"] = "���",
    ["PosX"] = "77475",
  },
  [451] = 
  {
    ["PosY"] = "87336",
    ["dwMapID"] = 23,
    ["szFinder"] = "��������",
    ["szPony"] = "���",
    ["PosX"] = "29288",
  },
  [113] = 
  {
    ["PosY"] = "9688",
    ["dwMapID"] = 13,
    ["PosX"] = "9331",
    ["szPony"] = "����",
    ["szFinder"] = "�޵�����ͷ",
  },
  [226] = 
  {
    ["PosY"] = "83968",
    ["dwMapID"] = 30,
    ["szFinder"] = "�������",
    ["szPony"] = "����",
    ["PosX"] = "64290",
  },
  [452] = 
  {
    ["PosY"] = "68475",
    ["dwMapID"] = 23,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "37138",
  },
  [453] = 
  {
    ["PosY"] = "51431",
    ["dwMapID"] = 23,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "84820",
  },
  [227] = 
  {
    ["PosY"] = "14187",
    ["dwMapID"] = 30,
    ["szFinder"] = "����������",
    ["szPony"] = "����",
    ["PosX"] = "41870",
  },
  [454] = 
  {
    ["PosY"] = "22492",
    ["dwMapID"] = 23,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "73133",
  },
  [455] = 
  {
    ["PosY"] = "54388",
    ["dwMapID"] = 23,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "10642",
  },
  [57] = 
  {
    ["PosY"] = "90171",
    ["dwMapID"] = 10,
    ["PosX"] = "24295",
    ["szPony"] = "���",
    ["szFinder"] = "��١����",
  },
  [114] = 
  {
    ["PosY"] = "77328",
    ["dwMapID"] = 13,
    ["szFinder"] = "Ҷ��",
    ["szPony"] = "����",
    ["PosX"] = "31585",
  },
  [228] = 
  {
    ["PosY"] = "58492",
    ["dwMapID"] = 30,
    ["szFinder"] = "����ң",
    ["szPony"] = "����",
    ["PosX"] = "49001",
  },
  [456] = 
  {
    ["PosY"] = "41853",
    ["dwMapID"] = 23,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "61634",
  },
  [457] = 
  {
    ["PosY"] = "40379",
    ["dwMapID"] = 23,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "38299",
  },
  [229] = 
  {
    ["PosY"] = "100586",
    ["dwMapID"] = 30,
    ["szFinder"] = "�������",
    ["szPony"] = "����",
    ["PosX"] = "88508",
  },
  [458] = 
  {
    ["PosY"] = "38536",
    ["dwMapID"] = 23,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "43826",
  },
  [459] = 
  {
    ["PosY"] = "95017",
    ["dwMapID"] = 23,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "48957",
  },
  [115] = 
  {
    ["PosY"] = "37611",
    ["dwMapID"] = 13,
    ["szFinder"] = "����ҹ��",
    ["szPony"] = "����",
    ["PosX"] = "14389",
  },
  [230] = 
  {
    ["PosY"] = "9557",
    ["dwMapID"] = 30,
    ["PosX"] = "40308",
    ["szPony"] = "����",
    ["szFinder"] = "Ľ����",
  },
  [460] = 
  {
    ["PosY"] = "25828",
    ["dwMapID"] = 23,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "53995",
  },
  [461] = 
  {
    ["PosY"] = "66863",
    ["dwMapID"] = 23,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "54422",
  },
  [231] = 
  {
    ["PosY"] = "31977",
    ["dwMapID"] = 30,
    ["szFinder"] = "��Խ���",
    ["szPony"] = "����",
    ["PosX"] = "87737",
  },
  [462] = 
  {
    ["PosY"] = "25093",
    ["dwMapID"] = 23,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "81780",
  },
  [29] = 
  {
    ["PosY"] = "30831",
    ["dwMapID"] = 9,
    ["szFinder"] = "һҶ����",
    ["szPony"] = "���",
    ["PosX"] = "6471",
  },
  [58] = 
  {
    ["PosY"] = "8849",
    ["dwMapID"] = 10,
    ["szFinder"] = "�������",
    ["szPony"] = "���",
    ["PosX"] = "30598",
  },
  [116] = 
  {
    ["PosY"] = "60766",
    ["dwMapID"] = 13,
    ["szFinder"] = "ĺ��ѩ",
    ["szPony"] = "����",
    ["PosX"] = "86809",
  },
  [232] = 
  {
    ["PosY"] = "60894",
    ["dwMapID"] = 30,
    ["szFinder"] = "������",
    ["szPony"] = "����",
    ["PosX"] = "57931",
  },
  [464] = 
  {
    ["PosY"] = "57580",
    ["dwMapID"] = 23,
    ["szFinder"] = "ת˲�Կ�",
    ["szPony"] = "���",
    ["PosX"] = "19503",
  },
  [465] = 
  {
    ["PosY"] = "60010",
    ["dwMapID"] = 23,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "22989",
  },
  [233] = 
  {
    ["PosY"] = "35796",
    ["dwMapID"] = 30,
    ["szFinder"] = "˾ͽ����",
    ["szPony"] = "����",
    ["PosX"] = "94290",
  },
  [466] = 
  {
    ["PosY"] = "66432",
    ["dwMapID"] = 23,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "70643",
  },
  [467] = 
  {
    ["PosY"] = "70277",
    ["dwMapID"] = 23,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "56053",
  },
  [117] = 
  {
    ["PosY"] = "69580",
    ["dwMapID"] = 13,
    ["szFinder"] = "��ز��ز",
    ["szPony"] = "����",
    ["PosX"] = "95148",
  },
  [234] = 
  {
    ["PosY"] = "11210",
    ["dwMapID"] = 30,
    ["PosX"] = "68562",
    ["szPony"] = "����",
    ["szFinder"] = "Խ�º�",
  },
  [468] = 
  {
    ["PosY"] = "9134",
    ["dwMapID"] = 23,
    ["szFinder"] = "���ŵ�С����",
    ["szPony"] = "���",
    ["PosX"] = "6702",
  },
  [469] = 
  {
    ["PosY"] = "23312",
    ["dwMapID"] = 23,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "23484",
  },
  [235] = 
  {
    ["PosY"] = "80087",
    ["dwMapID"] = 30,
    ["szFinder"] = "Ľ����",
    ["szPony"] = "����",
    ["PosX"] = "87077",
  },
  [470] = 
  {
    ["PosY"] = "40569",
    ["dwMapID"] = 23,
    ["szFinder"] = "��С��",
    ["szPony"] = "���",
    ["PosX"] = "7686",
  },
  [471] = 
  {
    ["PosY"] = "15489",
    ["dwMapID"] = 23,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "81911",
  },
  [59] = 
  {
    ["PosY"] = "57036",
    ["dwMapID"] = 10,
    ["PosX"] = "70778",
    ["szPony"] = "���",
    ["szFinder"] = "��С��",
  },
  [118] = 
  {
    ["PosY"] = "72732",
    ["dwMapID"] = 13,
    ["szFinder"] = "��С��",
    ["szPony"] = "����",
    ["PosX"] = "62844",
  },
  [236] = 
  {
    ["PosY"] = "19377",
    ["dwMapID"] = 30,
    ["PosX"] = "38601",
    ["szPony"] = "����",
    ["szFinder"] = "������",
  },
  [472] = 
  {
    ["PosY"] = "22415",
    ["dwMapID"] = 23,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "31915",
  },
  [473] = 
  {
    ["PosY"] = "22048",
    ["dwMapID"] = 30,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "28394",
  },
  [237] = 
  {
    ["PosY"] = "25181",
    ["dwMapID"] = 30,
    ["PosX"] = "91518",
    ["szPony"] = "����",
    ["szFinder"] = "Ҷ��·",
  },
  [474] = 
  {
    ["PosY"] = "94722",
    ["dwMapID"] = 30,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "91668",
  },
  [475] = 
  {
    ["PosY"] = "5984",
    ["dwMapID"] = 30,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "56924",
  },
  [119] = 
  {
    ["PosY"] = "10971",
    ["dwMapID"] = 13,
    ["szFinder"] = "��������",
    ["szPony"] = "����",
    ["PosX"] = "6367",
  },
  [238] = 
  {
    ["PosY"] = "93719",
    ["dwMapID"] = 30,
    ["szFinder"] = "Ҷ�Ӻ�",
    ["szPony"] = "����",
    ["PosX"] = "35819",
  },
  [476] = 
  {
    ["PosY"] = "56736",
    ["dwMapID"] = 30,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "70823",
  },
  [477] = 
  {
    ["PosY"] = "19235",
    ["dwMapID"] = 30,
    ["szFinder"] = "ת˲�Կ�",
    ["szPony"] = "����",
    ["PosX"] = "48239",
  },
  [239] = 
  {
    ["PosY"] = "9860",
    ["dwMapID"] = 30,
    ["szFinder"] = "��С��",
    ["szPony"] = "����",
    ["PosX"] = "14176",
  },
  [478] = 
  {
    ["PosY"] = "64579",
    ["dwMapID"] = 30,
    ["szFinder"] = "����ѩ",
    ["szPony"] = "����",
    ["PosX"] = "53307",
  },
  [15] = 
  {
    ["PosY"] = "54237",
    ["dwMapID"] = 9,
    ["szFinder"] = "ɱ����С��",
    ["szPony"] = "���",
    ["PosX"] = "26404",
  },
  [30] = 
  {
    ["PosY"] = "76859",
    ["dwMapID"] = 9,
    ["szFinder"] = "˾ͽ����",
    ["szPony"] = "���",
    ["PosX"] = "14718",
  },
  [60] = 
  {
    ["PosY"] = "16791",
    ["dwMapID"] = 12,
    ["PosX"] = "71031",
    ["szPony"] = "����",
    ["szFinder"] = "��֬Ѿͷ",
  },
  [120] = 
  {
    ["PosY"] = "62363",
    ["dwMapID"] = 13,
    ["szFinder"] = "�����",
    ["szPony"] = "����",
    ["PosX"] = "49180",
  },
  [240] = 
  {
    ["PosY"] = "100795",
    ["dwMapID"] = 30,
    ["PosX"] = "100080",
    ["szPony"] = "����",
    ["szFinder"] = "ϫ�������",
  },
  [480] = 
  {
    ["PosY"] = "29470",
    ["dwMapID"] = 30,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "5553",
  },
  [481] = 
  {
    ["PosY"] = "35213",
    ["dwMapID"] = 30,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "99146",
  },
  [241] = 
  {
    ["PosY"] = "8519",
    ["dwMapID"] = 30,
    ["szFinder"] = "���������",
    ["szPony"] = "����",
    ["PosX"] = "50022",
  },
  [482] = 
  {
    ["PosY"] = "10260",
    ["dwMapID"] = 30,
    ["szFinder"] = "�������",
    ["szPony"] = "����",
    ["PosX"] = "78423",
  },
  [255] = 
  {
    ["PosY"] = "61558",
    ["dwMapID"] = 100,
    ["PosX"] = "19041",
    ["szPony"] = "����",
    ["szFinder"] = "���Ѳ���",
  },
  [271] = 
  {
    ["PosY"] = "72372",
    ["dwMapID"] = 100,
    ["szFinder"] = "���Ѳ���",
    ["szPony"] = "����",
    ["PosX"] = "17349",
  },
  [483] = 
  {
    ["PosY"] = "74297",
    ["dwMapID"] = 30,
    ["szFinder"] = "�˺�����",
    ["szPony"] = "����",
    ["PosX"] = "12117",
  },
  [287] = 
  {
    ["PosY"] = "98576",
    ["dwMapID"] = 101,
    ["szFinder"] = "ֻӰ��",
    ["szPony"] = "����",
    ["PosX"] = "44038",
  },
  [121] = 
  {
    ["PosY"] = 72494,
    ["dwMapID"] = 13,
    ["PosX"] = 96535,
    ["szPony"] = "����",
    ["szFinder"] = "����@��������",
  },
  [242] = 
  {
    ["PosY"] = "85891",
    ["dwMapID"] = 30,
    ["szFinder"] = "������ǻ�",
    ["szPony"] = "����",
    ["PosX"] = "56507",
  },
  [484] = 
  {
    ["PosY"] = "100222",
    ["dwMapID"] = 30,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "16211",
  },
  [319] = 
  {
    ["PosY"] = "60308",
    ["dwMapID"] = 9,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "46089",
  },
  [335] = 
  {
    ["PosY"] = "36119",
    ["dwMapID"] = 10,
    ["szFinder"] = "��ľ",
    ["szPony"] = "���",
    ["PosX"] = "43159",
  },
  [485] = 
  {
    ["PosY"] = "95444",
    ["dwMapID"] = 30,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "83779",
  },
  [351] = 
  {
    ["PosY"] = "56200",
    ["dwMapID"] = 12,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "32889",
  },
  [622] = 
  {
    ["PosY"] = "89017",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "91991",
  },
  [243] = 
  {
    ["PosY"] = "48514",
    ["dwMapID"] = 30,
    ["szFinder"] = "���Ĺ�",
    ["szPony"] = "����",
    ["PosX"] = "78781",
  },
  [486] = 
  {
    ["PosY"] = "88290",
    ["dwMapID"] = 30,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "59463",
  },
  [619] = 
  {
    ["PosY"] = "29113",
    ["dwMapID"] = 104,
    ["szFinder"] = "����֮",
    ["szPony"] = "���ɳ",
    ["PosX"] = "46887",
  },
  [615] = 
  {
    ["PosY"] = "9326",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "59753",
  },
  [383] = 
  {
    ["PosY"] = "17791",
    ["dwMapID"] = 13,
    ["szFinder"] = "����ص�",
    ["szPony"] = "����",
    ["PosX"] = "55595",
  },
  [487] = 
  {
    ["PosY"] = "81821",
    ["dwMapID"] = 30,
    ["szFinder"] = "��������",
    ["szPony"] = "����",
    ["PosX"] = "95749",
  },
  [61] = 
  {
    ["PosY"] = "59449",
    ["dwMapID"] = 12,
    ["szFinder"] = "��������",
    ["szPony"] = "����",
    ["PosX"] = "73567",
  },
  [122] = 
  {
    ["PosY"] = "6943",
    ["dwMapID"] = 13,
    ["PosX"] = "12421",
    ["szPony"] = "����",
    ["szFinder"] = "���������",
  },
  [244] = 
  {
    ["PosY"] = "31749",
    ["dwMapID"] = 30,
    ["szFinder"] = "Ľ�ݾ���",
    ["szPony"] = "����",
    ["PosX"] = "99187",
  },
  [488] = 
  {
    ["PosY"] = "97634",
    ["dwMapID"] = 30,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "22045",
  },
  [607] = 
  {
    ["PosY"] = "68279",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "28410",
  },
  [415] = 
  {
    ["PosY"] = "43447",
    ["dwMapID"] = 21,
    ["szFinder"] = "�������",
    ["szPony"] = "����",
    ["PosX"] = "88584",
  },
  [431] = 
  {
    ["PosY"] = "31661",
    ["dwMapID"] = 21,
    ["szFinder"] = "ޱϦ��",
    ["szPony"] = "����",
    ["PosX"] = "40215",
  },
  [489] = 
  {
    ["PosY"] = "10983",
    ["dwMapID"] = 30,
    ["szFinder"] = "ɱ����С��",
    ["szPony"] = "����",
    ["PosX"] = "17441",
  },
  [447] = 
  {
    ["PosY"] = "20491",
    ["dwMapID"] = 22,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "56923",
  },
  [595] = 
  {
    ["PosY"] = "82590",
    ["dwMapID"] = 104,
    ["szFinder"] = "�ٵϿ���",
    ["szPony"] = "���ɳ",
    ["PosX"] = "78291",
  },
  [245] = 
  {
    ["PosY"] = "83030",
    ["dwMapID"] = 30,
    ["PosX"] = "78997",
    ["szPony"] = "����",
    ["szFinder"] = "����",
  },
  [490] = 
  {
    ["PosY"] = "15393",
    ["dwMapID"] = 30,
    ["szFinder"] = "��ԯ�䵤",
    ["szPony"] = "����",
    ["PosX"] = "66017",
  },
  [591] = 
  {
    ["PosY"] = "102035",
    ["dwMapID"] = 104,
    ["szFinder"] = "л����",
    ["szPony"] = "���ɳ",
    ["PosX"] = "53904",
  },
  [479] = 
  {
    ["PosY"] = "88382",
    ["dwMapID"] = 30,
    ["szFinder"] = "���Ѳ���",
    ["szPony"] = "����",
    ["PosX"] = "44865",
  },
  [495] = 
  {
    ["PosY"] = "83611",
    ["dwMapID"] = 30,
    ["szFinder"] = "л����",
    ["szPony"] = "����",
    ["PosX"] = "15487",
  },
  [491] = 
  {
    ["PosY"] = "99238",
    ["dwMapID"] = 30,
    ["szFinder"] = "����ҹ��",
    ["szPony"] = "����",
    ["PosX"] = "11776",
  },
  [583] = 
  {
    ["PosY"] = "20170",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "41637",
  },
  [123] = 
  {
    ["PosY"] = "11728",
    ["dwMapID"] = 13,
    ["szFinder"] = "�������",
    ["szPony"] = "����",
    ["PosX"] = "12905",
  },
  [246] = 
  {
    ["PosY"] = "78219",
    ["dwMapID"] = 100,
    ["szFinder"] = "����֮�¹�",
    ["szPony"] = "����",
    ["PosX"] = "16697",
  },
  [492] = 
  {
    ["PosY"] = "41717",
    ["dwMapID"] = 30,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "74801",
  },
  [463] = 
  {
    ["PosY"] = "9798",
    ["dwMapID"] = 23,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "59380",
  },
  [399] = 
  {
    ["PosY"] = "39325",
    ["dwMapID"] = 13,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "92870",
  },
  [367] = 
  {
    ["PosY"] = "44156",
    ["dwMapID"] = 12,
    ["szFinder"] = "��ŵ",
    ["szPony"] = "����",
    ["PosX"] = "31512",
  },
  [493] = 
  {
    ["PosY"] = "15171",
    ["dwMapID"] = 30,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "79279",
  },
  [573] = 
  {
    ["PosY"] = "84734",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "67824",
  },
  [571] = 
  {
    ["PosY"] = "68499",
    ["dwMapID"] = 104,
    ["szFinder"] = "�ݵ�Ѿͷ",
    ["szPony"] = "���ɳ",
    ["PosX"] = "98026",
  },
  [247] = 
  {
    ["PosY"] = "106494",
    ["dwMapID"] = 100,
    ["PosX"] = "61883",
    ["szPony"] = "����",
    ["szFinder"] = "��Ѫ��筴�",
  },
  [494] = 
  {
    ["PosY"] = "22916",
    ["dwMapID"] = 30,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "61288",
  },
  [567] = 
  {
    ["PosY"] = "29509",
    ["dwMapID"] = 101,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "120712",
  },
  [563] = 
  {
    ["PosY"] = "34017",
    ["dwMapID"] = 101,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "114928",
  },
  [559] = 
  {
    ["PosY"] = "31742",
    ["dwMapID"] = 101,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "90811",
  },
  [31] = 
  {
    ["PosY"] = "16649",
    ["dwMapID"] = 9,
    ["szFinder"] = "������ˮ",
    ["szPony"] = "���",
    ["PosX"] = "17453",
  },
  [62] = 
  {
    ["PosY"] = "13159",
    ["dwMapID"] = 12,
    ["szFinder"] = "����@��������",
    ["szPony"] = "����",
    ["PosX"] = "34121",
  },
  [124] = 
  {
    ["PosY"] = "22036",
    ["dwMapID"] = 21,
    ["szFinder"] = "������ǻ�",
    ["szPony"] = "����",
    ["PosX"] = "6436",
  },
  [248] = 
  {
    ["PosY"] = "68752",
    ["dwMapID"] = 100,
    ["szFinder"] = "ˮ����",
    ["szPony"] = "����",
    ["PosX"] = "42464",
  },
  [496] = 
  {
    ["PosY"] = "80773",
    ["dwMapID"] = 30,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "57250",
  },
  [303] = 
  {
    ["PosY"] = "90335",
    ["dwMapID"] = 104,
    ["PosX"] = "70973",
    ["szPony"] = "���ɳ",
    ["szFinder"] = "һ�����",
  },
  [510] = 
  {
    ["PosY"] = "27526",
    ["dwMapID"] = 30,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "55176",
  },
  [511] = 
  {
    ["PosY"] = "9089",
    ["dwMapID"] = 30,
    ["szFinder"] = "��ɽ��ʥ",
    ["szPony"] = "����",
    ["PosX"] = "62747",
  },
  [497] = 
  {
    ["PosY"] = "88595",
    ["dwMapID"] = 30,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "77007",
  },
  [547] = 
  {
    ["PosY"] = "93340",
    ["dwMapID"] = 100,
    ["szFinder"] = "�����",
    ["szPony"] = "����",
    ["PosX"] = "45905",
  },
  [543] = 
  {
    ["PosY"] = "86824",
    ["dwMapID"] = 100,
    ["szFinder"] = "�˺�����",
    ["szPony"] = "����",
    ["PosX"] = "82414",
  },
  [249] = 
  {
    ["PosY"] = "29939",
    ["dwMapID"] = 100,
    ["szFinder"] = "ɱ����С��",
    ["szPony"] = "����",
    ["PosX"] = "109591",
  },
  [498] = 
  {
    ["PosY"] = "68266",
    ["dwMapID"] = 30,
    ["szFinder"] = "�˺�����",
    ["szPony"] = "����",
    ["PosX"] = "84562",
  },
  [515] = 
  {
    ["PosY"] = "51418",
    ["dwMapID"] = 100,
    ["szFinder"] = "л����",
    ["szPony"] = "����",
    ["PosX"] = "116060",
  },
  [519] = 
  {
    ["PosY"] = "93639",
    ["dwMapID"] = 100,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "79794",
  },
  [535] = 
  {
    ["PosY"] = "51917",
    ["dwMapID"] = 100,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "16046",
  },
  [499] = 
  {
    ["PosY"] = "24216",
    ["dwMapID"] = 30,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "6076",
  },
  [523] = 
  {
    ["PosY"] = "71959",
    ["dwMapID"] = 100,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "12117",
  },
  [125] = 
  {
    ["PosY"] = "40816",
    ["dwMapID"] = 21,
    ["szFinder"] = "Ҷ��·",
    ["szPony"] = "����",
    ["PosX"] = "44968",
  },
  [250] = 
  {
    ["PosY"] = "74024",
    ["dwMapID"] = 100,
    ["szFinder"] = "��������",
    ["szPony"] = "����",
    ["PosX"] = "80500",
  },
  [500] = 
  {
    ["PosY"] = "101905",
    ["dwMapID"] = 30,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "21573",
  },
  [526] = 
  {
    ["PosY"] = "6271",
    ["dwMapID"] = 100,
    ["szFinder"] = "��С��",
    ["szPony"] = "����",
    ["PosX"] = "81047",
  },
  [527] = 
  {
    ["PosY"] = "85542",
    ["dwMapID"] = 100,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "111160",
  },
  [531] = 
  {
    ["PosY"] = "7953",
    ["dwMapID"] = 100,
    ["szFinder"] = "����΢",
    ["szPony"] = "����",
    ["PosX"] = "101951",
  },
  [501] = 
  {
    ["PosY"] = "83246",
    ["dwMapID"] = 30,
    ["szFinder"] = "ȹ��̫��",
    ["szPony"] = "����",
    ["PosX"] = "48936",
  },
  [539] = 
  {
    ["PosY"] = "80636",
    ["dwMapID"] = 100,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "81343",
  },
  [542] = 
  {
    ["PosY"] = "7164",
    ["dwMapID"] = 100,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "8488",
  },
  [251] = 
  {
    ["PosY"] = "10003",
    ["dwMapID"] = 100,
    ["szFinder"] = "Ҷ�Ӻ�",
    ["szPony"] = "����",
    ["PosX"] = "78161",
  },
  [502] = 
  {
    ["PosY"] = "8835",
    ["dwMapID"] = 30,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "55332",
  },
  [551] = 
  {
    ["PosY"] = "107677",
    ["dwMapID"] = 100,
    ["szFinder"] = "л����",
    ["szPony"] = "����",
    ["PosX"] = "17796",
  },
  [555] = 
  {
    ["PosY"] = "50172",
    ["dwMapID"] = 101,
    ["szFinder"] = "��Ҷ����",
    ["szPony"] = "����",
    ["PosX"] = "11804",
  },
  [558] = 
  {
    ["PosY"] = "23381",
    ["dwMapID"] = 101,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "68002",
  },
  [503] = 
  {
    ["PosY"] = "78784",
    ["dwMapID"] = 30,
    ["szFinder"] = "������",
    ["szPony"] = "����",
    ["PosX"] = "77155",
  },
  [63] = 
  {
    ["PosY"] = "58642",
    ["dwMapID"] = 12,
    ["szFinder"] = "���Ŷ��",
    ["szPony"] = "����",
    ["PosX"] = "42363",
  },
  [126] = 
  {
    ["PosY"] = "50550",
    ["dwMapID"] = 21,
    ["PosX"] = "12817",
    ["szPony"] = "����",
    ["szFinder"] = "Ҷ��·",
  },
  [252] = 
  {
    ["PosY"] = "41616",
    ["dwMapID"] = 100,
    ["szFinder"] = "��С��",
    ["szPony"] = "����",
    ["PosX"] = "9247",
  },
  [504] = 
  {
    ["PosY"] = "11333",
    ["dwMapID"] = 30,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "33209",
  },
  [574] = 
  {
    ["PosY"] = "50585",
    ["dwMapID"] = 104,
    ["szFinder"] = "�ݵ�Ѿͷ",
    ["szPony"] = "���ɳ",
    ["PosX"] = "101990",
  },
  [575] = 
  {
    ["PosY"] = "119083",
    ["dwMapID"] = 104,
    ["szFinder"] = "һͰ������",
    ["szPony"] = "���ɳ",
    ["PosX"] = "55235",
  },
  [579] = 
  {
    ["PosY"] = "50924",
    ["dwMapID"] = 104,
    ["szFinder"] = "����֮",
    ["szPony"] = "���ɳ",
    ["PosX"] = "55420",
  },
  [505] = 
  {
    ["PosY"] = "34707",
    ["dwMapID"] = 30,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "40455",
  },
  [587] = 
  {
    ["PosY"] = "16255",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "37449",
  },
  [590] = 
  {
    ["PosY"] = "54650",
    ["dwMapID"] = 104,
    ["szFinder"] = "������",
    ["szPony"] = "���ɳ",
    ["PosX"] = "75408",
  },
  [253] = 
  {
    ["PosY"] = "86586",
    ["dwMapID"] = 100,
    ["szFinder"] = "�������",
    ["szPony"] = "����",
    ["PosX"] = "10502",
  },
  [506] = 
  {
    ["PosY"] = "35388",
    ["dwMapID"] = 30,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "60658",
  },
  [599] = 
  {
    ["PosY"] = "109365",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "74920",
  },
  [603] = 
  {
    ["PosY"] = "116713",
    ["dwMapID"] = 104,
    ["szFinder"] = "����������",
    ["szPony"] = "���ɳ",
    ["PosX"] = "72949",
  },
  [606] = 
  {
    ["PosY"] = "71605",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "55385",
  },
  [507] = 
  {
    ["PosY"] = "8883",
    ["dwMapID"] = 30,
    ["szFinder"] = "ޱϦ��",
    ["szPony"] = "����",
    ["PosX"] = "35402",
  },
  [611] = 
  {
    ["PosY"] = "54991",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "65100",
  },
  [127] = 
  {
    ["PosY"] = "64438",
    ["dwMapID"] = 21,
    ["szFinder"] = "�쳾ŭ",
    ["szPony"] = "����",
    ["PosX"] = "30320",
  },
  [254] = 
  {
    ["PosY"] = "114702",
    ["dwMapID"] = 100,
    ["szFinder"] = "����",
    ["szPony"] = "����",
    ["PosX"] = "60394",
  },
  [508] = 
  {
    ["PosY"] = "61344",
    ["dwMapID"] = 30,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "52245",
  },
  [623] = 
  {
    ["PosY"] = "68719",
    ["dwMapID"] = 104,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "63773",
  },
  [627] = 
  {
    ["PosY"] = "43182",
    ["dwMapID"] = 105,
    ["szFinder"] = "����",
    ["szPony"] = "����/���",
    ["PosX"] = "59363",
  },
  [631] = 
  {
    ["PosY"] = "49198",
    ["dwMapID"] = 105,
    ["szFinder"] = "",
    ["szPony"] = "",
    ["PosX"] = "28699",
  },
  [509] = 
  {
    ["PosY"] = "28740",
    ["dwMapID"] = 30,
    ["szFinder"] = "����",
    ["szPony"] = "����",
    ["PosX"] = "78304",
  },
}