--Ģ����
BuffMonitor = {
	DefaultAnchor = {s = "CENTER", r = "CENTER",  x = 0, y = 0},
	Anchor = {s = "CENTER", r = "CENTER", x = 0, y = 0},
	bOn = true,
	bDragable = false,
	MonitorList = {
		--����
		[10021] = {
			[1] = {szName = "��������", dwIconID = 390, bOn = true,},
			[2] = {szName = "����ع��", dwIconID = 404, bOn = true,},
			[3] = {szName = "����ָ", dwIconID = 1514, bOn = true,},
			[4] = {szName = "�ɹ�", dwIconID = 1672, bOn = true,},
			[5] = {szName = "ܽ�ز���", dwIconID = 1514, bOn = false,},
		},
		--����
		[10175] = {
			[1] = {szName = "����", dwIconID = 2786, bOn = true,},
			[2] = {szName = "��Ӱ", dwIconID = 2785, bOn = true,},
			[3] = {szName = "�Х", dwIconID = 2784, bOn = true,},
			[4] = {szName = "Ы�Ŀݲ�", dwIconID = 2810, bOn = false,},
			[5] = {szName = "��Ӱ�ݲ�", dwIconID = 2812, bOn = false,},
			[6] = {szName = "������", dwIconID = 2776, bOn = true,},
			[7] = {szName = "���Ĺ�", dwIconID = 2777, bOn = false,},
			[8] = {szName = "�ݲй�", dwIconID = 2778, bOn = false,},
		},
		--����
		[10081] = {
			[1] = {szName = "����",	dwIconID = 2947, bOn = true},
		},
		--����
		[10015] = {
			[1] = {szName = "����", dwIconID = 617, bOn = true},
		},
		--����
		[10080] = {
			[1] = {szName = "����", dwIconID = 897, bOn = false,},
			[2] = {szName = "��Ԫ����", dwIconID = 913, bOn = false,},
			[3] = {szName = "��صͰ�", dwIconID = 1498, bOn = false,},
		},
		--�뾭
		[10028] = {
			[1] = {szName = "����", dwIconID = 1519, bOn = false,},
			[2] = {szName = "���໤��", dwIconID = 413, bOn = false,},
			[3] = {szName = "����", dwIconID = 1521, bOn = false,},
		},
		--����
		[10176] = {
			[1] = {szName = "�ݲй�", dwIconID = 2778, bOn = false,},
		},
		--����
		[10243] = {
			[1] = {szName = "�ȱ�", dwIconID = 4174, bOn = true,},
			[2] = {szName = "����", dwIconID = 4177, bOn = true,},
			[3] = {szName = "��ʥ", dwIconID = 3791, bOn = true,},
			[4] = {szName = "����", dwIconID = 3796, bOn = true,},
			[5] = {szName = "���", dwIconID = 3798, bOn = true,},
			[6] = {szName = "����", dwIconID = 3788, bOn = true,},
		},
		--����
		[10242] = {
			[1] = {szName = "����", dwIconID = 3796, bOn = false,},
			[2] = {szName = "����", dwIconID = 3843, bOn = false,},
		},
		--�׽
		[10003] = {
			[1] = {szName = "��ɨ����", dwIconID = 434, bOn = false,},
			[2] = {szName = "��ӽ�ɳ", dwIconID = 437, bOn = false,},
			[3] = {szName = "���̽Կ�", dwIconID = 424, bOn = false,},
		},
		--ϴ��
		[10002] = {
			[1] = {szName = "���سɷ�", dwIconID = 420, bOn = false,},
			[2] = {szName = "�ڷ�", dwIconID = 433, bOn = false,},
			[3] = {szName = "ִ��", dwIconID = 423, bOn = false,},
			[4] = {szName = "��ȥ����", dwIconID = 2962, bOn = false,},
			[5] = {szName = "��ӽ�ɳ", dwIconID = 437, bOn = false,},
		},
		--����
		[10062] = {
			[1] = {szName = "�Ʒ�", dwIconID = 647, bOn = false,},
			[2] = {szName = "����", dwIconID = 646, bOn = false,},
		},
		--��Ѫ
		[10026] = {
			[1] = {szName = "�Ʒ�", dwIconID = 647, bOn = false,},
			[2] = {szName = "����", dwIconID = 646, bOn = false,},
		},
		--����
		[10014] = {
			[1] = {szName = "���ǹ���", dwIconID = 1438, bOn = false},
			[2] = {szName = "�巽�о�", dwIconID = 1440, bOn = false},
			[3] = {szName = "���Ż���", dwIconID = 615, bOn = false},
		},
		--����
		[10225] = {
			[1] = {szName = "��Ѫ��", dwIconID = 3169, bOn = false},
		},
		--����
		[10224] = {
			[1] = {szName = "��Ѫ��", dwIconID = 3169, bOn = false},
		},
		--�ؽ�
		[10144] = {
			[1] = {szName = "����", dwIconID = 2366, bOn = false},
		},
		[10145] = {
			[1] = {szName = "����", dwIconID = 2366, bOn = false},
		},
		--ؤ��
		[10268] = {
			[1] = {szName = "��Ծ��Ԩ", dwIconID = 4900, bOn = false},
		},
	},
	handleBoxs = {},
}

--local szIniFile = "Interface/BuffMonitor/BuffMonitor.ini"

RegisterCustomData("BuffMonitor.Anchor")
RegisterCustomData("BuffMonitor.DefaultAnchor")
RegisterCustomData("BuffMonitor.bDragable")
RegisterCustomData("BuffMonitor.bOn")
RegisterCustomData("BuffMonitor.MonitorList")

function BuffMonitor.OnFrameCreate()
	this:RegisterEvent("SYS_MSG")
	this:RegisterEvent("DO_SKILL_CAST")
	this:RegisterEvent("CUSTOM_DATA_LOADED")
	this:RegisterEvent("BUFF_UPDATE")
	this:RegisterEvent("CUSTOM_UI_MODE_SET_DEFAULT")
	this:RegisterEvent("UI_SCALED")
end

function BuffMonitor.OnEvent(event)
	if event == "UI_SCALED" then
		BuffMonitor.UpdateAnchor(this)
		if BuffMonitor.bDragable then
			this:EnableDrag(true)
		else
			this:EnableDrag(false)
		end
	elseif event == "CUSTOM_DATA_LOADED"  then
		if BuffMonitor.bOn then
			this:Show()
		else
			this:Hide()
		end
		BuffMonitor.UpdateAnchor(this)
	elseif event == "CUSTOM_UI_MODE_SET_DEFAULT" then
		BuffMonitor.ResetAnchor(this)
	end
end


function BuffMonitor.OnFrameDrag()

end

function BuffMonitor.OnFrameDragEnd()
	this:CorrectPos()
	BuffMonitor.Anchor = GetFrameAnchor(this)
end

function BuffMonitor.ResetAnchor(frame)
	BuffMonitor.Anchor.s = BuffMonitor.DefaultAnchor.s
	BuffMonitor.Anchor.r = BuffMonitor.DefaultAnchor.r
	BuffMonitor.Anchor.x = BuffMonitor.DefaultAnchor.x
	BuffMonitor.Anchor.y = BuffMonitor.DefaultAnchor.y
	frame:SetPoint(BuffMonitor.Anchor.s,0,0,BuffMonitor.Anchor.r, BuffMonitor.Anchor.x , BuffMonitor.Anchor.y)
	frame:CorrectPos()
end

function BuffMonitor.UpdateAnchor(frame)
	frame:SetPoint(BuffMonitor.Anchor.s, 0, 0, BuffMonitor.Anchor.r, BuffMonitor.Anchor.x, BuffMonitor.Anchor.y)
	frame:CorrectPos()
end

function BuffMonitor.GetMenu()
	local dwKungFuID = GetClientPlayer().GetKungfuMount().dwSkillID
	local menu = {szOption = "Ŀ��״̬����"}

	local m_1 = {
		szOption = "������ʾ",
		bCheck = true,
		bChecked = BuffMonitor.bOn,
		fnAction = function()
			BuffMonitor.bOn = not BuffMonitor.bOn
			if BuffMonitor.bOn then
				Station.Lookup("Normal/BuffMonitor"):Show()
			else
				Station.Lookup("Normal/BuffMonitor"):Hide()
			end
		end,
	}
	local m_2 = {
		szOption = "λ������",
		bCheck = true,
		bChecked = not BuffMonitor.bDragable,
		fnAction = function()
			BuffMonitor.bDragable = not BuffMonitor.bDragable
			if BuffMonitor.bDragable then
				Station.Lookup("Normal/BuffMonitor"):EnableDrag(true)
				BuffMonitor.print("�����������һ�������ƶ�")
			else
				Station.Lookup("Normal/BuffMonitor"):EnableDrag(false)
			end
		end,
	}
	local m_3 = {szOption = "״̬����"}
	for i = 1, #BuffMonitor.MonitorList[dwKungFuID], 1 do
		local m = {
			szOption = BuffMonitor.MonitorList[dwKungFuID][i].szName,
			bCheck = true,
			bChecked = BuffMonitor.MonitorList[dwKungFuID][i].bOn,
			fnAction = function()
				BuffMonitor.MonitorList[dwKungFuID][i].bOn = not BuffMonitor.MonitorList[dwKungFuID][i].bOn
			end,
		}
		local m_edit = {
			szOption = "����ͼ��",
			fnAction = function()
				GetUserInput("����״̬ͼ��ID(Ϊ��ֵ)��", function(szText) BuffMonitor.MonitorList[dwKungFuID][i].dwIconID = szText end, nil, nil, nil, nil)
			end,
		}
		local m_delete = {
			szOption = "ɾ������",
			fnAction = function()
				table.remove(BuffMonitor.MonitorList[dwKungFuID], i)
			end,
		}
		table.insert(m, m_edit)
		table.insert(m, m_delete)
		table.insert(m_3, m)
	end
	local m_add = {
		szOption = "�Զ���״̬",
		fnAction = function()
			GetUserInput("������Ҫ���ӵ�״̬��", function(szText) table.insert(BuffMonitor.MonitorList[dwKungFuID], {szName = szText, bOn = true,}) end, nil, nil, nil, nil)
		end,
	}
	local m_4 = {
		szOption = "״̬ͼ���ѯ",
		fnAction = function()
			GetUserInput("������Ҫ��ѯ״̬��ID(ctrl+�������鿴)��", function(szText) BuffMonitor.GetBuffIconID(szText) end, nil, nil, nil, nil)
		end,
	}
	table.insert(menu, m_1)
	table.insert(menu, m_2)
	table.insert(menu, m_3)
	table.insert(menu,m_add)
	table.insert(menu, m_4)
	return menu
end


function BuffMonitor.OnFrameBreathe()
	local player = GetClientPlayer()
	if not player then
		return
	end
	local	frame = Station.Lookup("Normal/BuffMonitor")
	local handle = frame:Lookup("","")
	handle:Clear()
	BuffMonitor.InitBoxs()
	BuffMonitor.UpdataTargetBuffTime()
end

function BuffMonitor.InitBoxs()
	local	frame = Station.Lookup("Normal/BuffMonitor")
	local handle = frame:Lookup("","")
	local dwKungFuID = GetClientPlayer().GetKungfuMount().dwSkillID
	local count = 0
	for i = 1,#BuffMonitor.MonitorList[dwKungFuID], 1 do
		if BuffMonitor.MonitorList[dwKungFuID][i].bOn then
			count = count + 1
			local hBox = handle:AppendItemFromIni("Interface/BuffMonitor/BuffMonitor.ini", "Handle_Box", "handleBoxs_"..i)
			hBox.index = i
			hBox.box = hBox:Lookup("Box")
			hBox.boxImageBg = hBox:Lookup("Image_BoxBG")
			hBox.imageTimeBarBG = hBox:Lookup("Image_TimeBarBG")
			hBox.imageTimeBar = hBox:Lookup("Image_TimeBar")

			hBox.box:SetObject(1,0)
			hBox.box:SetObjectIcon(BuffMonitor.MonitorList[dwKungFuID][i].dwIconID)
			hBox.box:SetObjectCoolDown(1)
			hBox.box:SetOverText(0, "")
			hBox.box:SetOverText(1, "")
			--hBox.boxImageBg:Hide()
			hBox.imageTimeBarBG:Hide()
			hBox.imageTimeBar:SetFrame(25)
			hBox.imageTimeBar:SetPercentage(0)

			hBox:SetRelPos(52 * (count - 1), 0)
			hBox:Show()
			BuffMonitor.handleBoxs[i] = hBox
		end
	end
	handle:FormatAllItemPos()
end

function BuffMonitor.UpdataTargetBuffTime()
	local player = GetClientPlayer()
	local dwKungFuID = player.GetKungfuMount().dwSkillID
	local dwTargerType,dwTargerID = player.GetTarget()
	local target

	if IsPlayer(dwTargerID) then
		target = GetPlayer(dwTargerID)
	else
		target = GetNpc(dwTargerID)
	end

	if target then
		local tBuffList = target.GetBuffList() or {}
		for _,tBuff in pairs(tBuffList) do
			local tBuffName = Table_GetBuffName(tBuff.dwID,tBuff.nLevel)
			local tBuffTime,nCount = GetBuffTime(tBuff.dwID,tBuff.nLevel)
			for i = 1,#BuffMonitor.MonitorList[dwKungFuID], 1 do
				if tBuffName == BuffMonitor.MonitorList[dwKungFuID][i].szName and tBuff.dwSkillSrcID == player.dwID and BuffMonitor.MonitorList[dwKungFuID][i].bOn then
					local hBox = BuffMonitor.handleBoxs[i]
					local box = hBox.box
					local boxImageBg = hBox.boxImageBg
					local imageTimeBarBG = hBox.imageTimeBarBG
					local imageTimeBar = hBox.imageTimeBar

					local nTimeLeft = ("%.1f"):format(math.max(0, tBuff.nEndFrame - GetLogicFrameCount()) / 16)
					--hBox.boxImageBg:Show()
					--box:Show()

					box:SetOverTextPosition(1, ITEM_POSITION.LEFT_TOP)
					box:SetOverTextFontScheme(1, 15)
					box:SetOverText(1, nTimeLeft.."'")

					if tBuff.nStackNum == 1 then
						box:SetOverText(0, "")
					else
						box:SetOverTextPosition(0, ITEM_POSITION.RIGHT_BOTTOM)
						box:SetOverTextFontScheme(0, 15)
						box:SetOverText(0, tBuff.nStackNum)
					end

					box:SetObject(1,0)
					box:SetObjectIcon(Table_GetBuffIconID(tBuff.dwID,tBuff.nLevel))

					imageTimeBarBG:Show()

					local percent = nTimeLeft/(tBuffTime/16)
					if percent > 0.75 then
						imageTimeBar:SetFrame(25) --��ɫ
					elseif percent > 0.35 then
						imageTimeBar:SetFrame(26) --��ɫ
					else
						imageTimeBar:SetFrame(21) --��ɫ
					end
					imageTimeBar:SetPercentage(percent)
				end
			end
		end
	end
end

function BuffMonitor.print(msg)
	local szText = {{type = "text",text = msg},}
	local szFont = GetMsgFontString("MSG_SYS")
	OutputMessage("MSG_SYS", FormatString("<text>text=\"<Ŀ��״̬����> \" font=10 r=0 g=196 b=196</text><text>text=\"<D0> \"</text><D1><text>text=\"\n\" font=<D1></text>", msg, szFont), true)
end

function BuffMonitor.GetBuffIconID(dwID)
	local dwIconID = Table_GetBuffIconID(dwID,1)
	BuffMonitor.print("״̬ͼ��ID��"..dwIconID)
end

Player_AppendAddonMenu({function() return {BuffMonitor.GetMenu()} end})
Wnd.OpenWindow("Interface\\BuffMonitor\\BuffMonitor.ini", "BuffMonitor")
