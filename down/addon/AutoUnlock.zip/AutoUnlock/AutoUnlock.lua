AutoUnlock = {}
local bReady = false
local dwDoodadID = 0

function AutoUnlock.OnFrameBreathe()
	if bReady then
		local frame_lock = Station.Lookup("Normal/LockPanel")
		local frame_dialogue = Station.Lookup("Normal/DialoguePanel")
		if frame_lock and frame_lock:IsVisible() then
			AutoUnlock.AdjustUI(frame_lock)
			AutoUnlock.DoUnlock(frame_lock)
		else
			if not frame_dialogue or not frame_dialogue:IsVisible() then
				bReady = false
				InteractDoodad(dwDoodadID)
			end
		end
	end
end

function AutoUnlock.AdjustUI(frame)
	--move
	frame:SetRelPos(989,800)
	frame:SetSize(160,36)
	frame:Lookup("Btn_Lock_Open"):SetRelPos(0,0)
	frame:Lookup("", "Handle_Top"):Lookup("Text_RewardProvide"):SetRelPos(2, 45)
	frame:Lookup("", "Handle_Top"):Lookup("Text_SuccessRate"):SetRelPos(-20, -25)	
	frame:Lookup("", "Handle_Top"):Lookup("Image_LockNumber"):SetRelPos(160, -5)
	frame:Lookup("", "Handle_Top"):Lookup("Text_LockNumber"):SetRelPos(200, 25)	
	frame:Lookup("", "Handle_Top"):FormatAllItemPos()
	--hide
	frame:Lookup("ScrollBar_Lock"):Hide()
	frame:Lookup("", "Image_Bg1"):Hide()
	frame:Lookup("", "Image_Bg2"):Hide()
	frame:Lookup("", "Image_Bg3"):Hide()
	frame:Lookup("", "Image_Bg4"):Hide()
	frame:Lookup("", "Handle_Top"):Lookup("Image_SlideAdjustment"):Hide()
	frame:Lookup("", "Handle_Lock"):Hide()
	--change
	local hText1 = frame:Lookup("", "Handle_Top"):Lookup("Text_SuccessRate")
	hText1:SetFontScheme(200)
	
	local hText2 = frame:Lookup("", "Handle_Top"):Lookup("Text_RewardProvide")
	hText2:SetFontScheme(199)
	
	if not frame:Lookup("Btn_Lock_Open"):IsEnabled() then		
		hText2:SetText("���ڿ����С���")
	else
		hText2:SetText("����������ť")
	end
end

function AutoUnlock.DoUnlock(frame)
	local scrollbar = frame:Lookup("ScrollBar_Lock")
	local hText = frame:Lookup("", "Handle_Top"):Lookup("Text_SuccessRate")
	if scrollbar then
		if not hText:IsVisible() then
			scrollbar:SetScrollPos(100)
		else
			local text = hText:GetText()
			local text_value = string.sub(text, 10, 11)
			if text_value == "��" then
				Wnd.CloseWindow("LockPanel")
				InteractDoodad(dwDoodadID)
			end
			local tValue = 	{
										["һ"] = 10,
										["��"] = 20,
										["��"] = 30,
										["��"] = 40,
										["��"] = 50,
										["��"] = 60,
										["��"] = 70,
										["��"] = 80,
										["��"] = 90,
									}
			local nValue = tValue[text_value]
			if nValue then
				scrollbar:SetScrollPos(nValue)
			end
		end
	end
end

function AutoUnlock.OnOpenWindow()
	if string.find(arg1, "LOCK_PANEL") then
		bReady = true
		dwDoodadID = arg3
	end
end

RegisterEvent("OPEN_WINDOW", AutoUnlock.OnOpenWindow)
Wnd.OpenWindow("Interface/AutoUnlock/AutoUnlock.ini","AutoUnlock")