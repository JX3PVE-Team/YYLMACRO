function seArchHUD.Config()
    local menu = {szOption = "seArchHUD"}
	local menu_switch = {
						szOption = "����Ѫ������",
						bCheck = true,
						bChecked = seArchHUD.bSwitch,
						fnAction = function()
							seArchHUD.bSwitch = not seArchHUD.bSwitch
						end,
						fnAutoClose = function()return true end
						}
	local menu_fihgtshow = {szOption = "��ս������ʾ",
						bCheck = true,
						bChecked = seArchHUD.bFightShow,
						fnAction = function()
							seArchHUD.bFightShow = not seArchHUD.bFightShow
						end,
						fnAutoClose = function()return true end 
						}
         
	table.insert(menu, menu_switch)
	table.insert(menu, menu_fihgtshow)
	return menu
end

TraceButton_AppendAddonMenu({function()return{seArchHUD.Config()}end})
