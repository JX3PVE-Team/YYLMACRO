seArchHUD = {}
seArchHUD.DefaultAnchor = {s = "CENTER", r = "CENTER",  x = 0, y = 0}
seArchHUD.bSwitch = true
seArchHUD.bFightShow = false

RegisterCustomData("seArchHUD.bSwitch")
RegisterCustomData("seArchHUD.bFightShow")

local function print(...)
	local a = {...}
	for i, v in ipairs(a) do
		a[i] = tostring(v)
	end
	OutputMessage("MSG_SYS", "[seArchHUD] " .. table.concat(a, "\t").. "\n" )
end
function seArchHUD.OnFrameCreate()
	this:RegisterEvent("CUSTOM_DATA_LOADED")
	this:RegisterEvent("RENDER_FRAME_UPDATE")
	this:RegisterEvent("UI_SCALED")
	this:RegisterEvent("PLAYER_STATE_UPDATE")
	this:RegisterEvent("NPC_STATE_UPDATE")
	local frame = Station.Lookup("Lowest/seArchHUD")
	local handle = frame:Lookup("", "")
	seArchHUD.TargetHeath = handle:Lookup("Image_Lfore_T")
	seArchHUD.TargetHeath_bg = handle:Lookup("Image_Lbg_T")
	seArchHUD.MyHeath = handle:Lookup("Image_Lfore")
	seArchHUD.MyHeath_bg = handle:Lookup("Image_Lbg")
	seArchHUD.MyMana = handle:Lookup("Image_Rfore")
	seArchHUD.MyMana_bg = handle:Lookup("Image_Rbg")
	seArchHUD.Myextra = handle:Lookup("Image_extrafore")
	seArchHUD.Myextra_bg = handle:Lookup("Image_extrabg")
	seArchHUD.TargetCasting = handle:Lookup("Image_Rfore_T")
	seArchHUD.TargetCasting_bg = handle:Lookup("Image_Rbg_T")
	seArchHUD.Text_My_Health = handle:Lookup("Text_My_Health")
	seArchHUD.Text_My_Health:SetFontColor(0, 255, 0)
	seArchHUD.Text_My_Mana = handle:Lookup("Text_My_Mana")
	seArchHUD.Text_My_Mana:SetFontColor(0, 0, 255)
	seArchHUD.Text_T_Heath = handle:Lookup("Text_T_Heath")
	seArchHUD.Text_T_Heath:SetFontColor(255, 255, 0)
	seArchHUD.Text_T_Cast = handle:Lookup("Text_T_Cast")
	seArchHUD.Text_T_Cast:SetFontColor(255, 255, 0)
	seArchHUD.Text_My_Acc = handle:Lookup("Text_My_Acc")
	seArchHUD.Text_My_Acc:SetFontColor(255, 255, 0)
	seArchHUD.HideTargetFrame()
	seArchHUD.UpdateAnchor(this)
end
function seArchHUD.HideTargetFrame()
		seArchHUD.TargetHeath:Hide()
		seArchHUD.TargetHeath_bg:Hide()
		seArchHUD.TargetCasting:Hide()
		seArchHUD.TargetCasting_bg:Hide()
		seArchHUD.Text_T_Heath:Hide()
		seArchHUD.Text_T_Cast:Hide()
end
function seArchHUD.ShowTargetFrame()
		seArchHUD.TargetHeath:Show()
		seArchHUD.TargetHeath_bg:Show()
		seArchHUD.TargetCasting:Show()
		seArchHUD.TargetCasting_bg:Show()
		seArchHUD.Text_T_Heath:Show()
		seArchHUD.Text_T_Cast:Show()
end
function seArchHUD.HideMyFrame()
	seArchHUD.MyHeath:Hide()
	seArchHUD.MyHeath_bg:Hide()
	seArchHUD.MyMana:Hide()
	seArchHUD.MyMana_bg:Hide()
	seArchHUD.Myextra:Hide()
	seArchHUD.Myextra_bg:Hide()
	seArchHUD.Text_My_Health:Hide()
	seArchHUD.Text_My_Mana:Hide()
	seArchHUD.Text_My_Acc:Hide()
end
function seArchHUD.ShowMyFrame()
	seArchHUD.MyHeath:Show()
	seArchHUD.MyHeath_bg:Show()
	seArchHUD.MyMana:Show()
	seArchHUD.MyMana_bg:Show()
	seArchHUD.Myextra:Show()
	seArchHUD.Myextra_bg:Show()
	seArchHUD.Text_My_Health:Show()
	seArchHUD.Text_My_Mana:Show()
	seArchHUD.Text_My_Acc:Show()
end
function seArchHUD.OnFrameBreathe()
		local dwType, dwID = GetClientPlayer().GetTarget()
		if dwID == 0 then
				seArchHUD.HideTargetFrame()
				seArchHUD.dwID = dwID
				seArchHUD.dwType = dwType
				return
		end
		if dwID ~= seArchHUD.dwID or dwType ~= seArchHUD.dwType then
				seArchHUD.dwID = dwID
				seArchHUD.dwType = dwType
				seArchHUD.UpdateTargetData()
		end
		seArchHUD.UpdateCasting()
end
function seArchHUD.OnEvent(event)
		if event == "UI_SCALED" then
				seArchHUD.UpdateAnchor(this)
		elseif event == "PLAYER_STATE_UPDATE" then
				if arg0 == GetClientPlayer().dwID then
						seArchHUD.UpdatePlayerData()
				end
				local dwType, dwID = GetClientPlayer().GetTarget()
				if arg0 == dwID and dwType == TARGET.PLAYER then
						seArchHUD.UpdateTargetData()
				end
		elseif event == "NPC_STATE_UPDATE" then
				local dwType, dwID = GetClientPlayer().GetTarget()
				if arg0 == dwID and dwType == TARGET.NPC then
						seArchHUD.UpdateTargetData()
				end
		end
end
function seArchHUD.UpdatePlayerData()
		local hPlayer = GetClientPlayer()
		local MyAcc = ""
		if seArchHUD.bSwitch == false then seArchHUD.HideMyFrame()
		elseif seArchHUD.bFightShow == true and hPlayer.bFightState == false then seArchHUD.HideMyFrame()
		else
		seArchHUD.ShowMyFrame()
		seArchHUD.Text_My_Acc:Hide()
		seArchHUD.Myextra:Hide()
		seArchHUD.Myextra_bg:Hide()
		seArchHUD.Text_My_Health:SetText(""..tostring(hPlayer.nCurrentLife).."("..KeepTwoByteFloat(hPlayer.nCurrentLife / hPlayer.nMaxLife * 100).."%)")
		seArchHUD.MyHeath:SetPercentage(hPlayer.nCurrentLife/hPlayer.nMaxLife)	
		if hPlayer.dwForceID == 1 then
			local MyAcc = hPlayer.nAccumulateValue
				if MyAcc >= 3
					then MyAcc = 3
				end
			seArchHUD.Text_My_Acc:Show()
			seArchHUD.Text_My_Acc:SetText("����:"..tostring(MyAcc))
			seArchHUD.Text_My_Mana:SetText("".."("..KeepTwoByteFloat(hPlayer.nCurrentMana / hPlayer.nMaxMana * 100).."%)"..tostring(hPlayer.nCurrentMana))
			seArchHUD.MyMana:SetPercentage(hPlayer.nCurrentMana/hPlayer.nMaxMana)
		elseif hPlayer.dwForceID == 4 then
			local MyAcc = hPlayer.nAccumulateValue
				if MyAcc >= 10
					then MyAcc = 10
				end
			seArchHUD.Text_My_Acc:Show()
			seArchHUD.Text_My_Acc:SetText("��:"..tostring(MyAcc/2))
			seArchHUD.Text_My_Mana:SetText("".."("..KeepTwoByteFloat(hPlayer.nCurrentMana / hPlayer.nMaxMana * 100).."%)"..tostring(hPlayer.nCurrentMana))
			seArchHUD.MyMana:SetPercentage(hPlayer.nCurrentMana/hPlayer.nMaxMana)
		elseif hPlayer.dwForceID == 5 then
			local MyAcc = hPlayer.nAccumulateValue
				if MyAcc >= 10
					then MyAcc = 10
				end
			seArchHUD.Text_My_Acc:Show()
			seArchHUD.Text_My_Acc:SetText("����:"..tostring(MyAcc))
			seArchHUD.Text_My_Mana:SetText("".."("..KeepTwoByteFloat(hPlayer.nCurrentMana / hPlayer.nMaxMana * 100).."%)"..tostring(hPlayer.nCurrentMana))
			seArchHUD.MyMana:SetPercentage(hPlayer.nCurrentMana/hPlayer.nMaxMana)
		elseif hPlayer.dwForceID == 7 then
			seArchHUD.MyMana:FromUITex("Interface\\seArchHUD\\rRing.UITex", 2)
			seArchHUD.Text_My_Acc:Hide()
			seArchHUD.Text_My_Mana:SetFontColor(255, 255, 0)
			seArchHUD.Text_My_Mana:SetText(""..tostring(hPlayer.nCurrentEnergy).."/"..tostring(hPlayer.nMaxEnergy))
			seArchHUD.MyMana:SetPercentage(hPlayer.nCurrentEnergy/hPlayer.nMaxEnergy)
		elseif hPlayer.dwForceID == 8 then
			seArchHUD.MyMana:FromUITex("Interface\\seArchHUD\\rRing.UITex", 1)
			seArchHUD.Text_My_Acc:Hide()
			seArchHUD.Text_My_Mana:SetFontColor(255, 150, 0)
			seArchHUD.Text_My_Mana:SetText(""..tostring(hPlayer.nCurrentRage).."/"..tostring(hPlayer.nMaxRage))
			seArchHUD.MyMana:SetPercentage(hPlayer.nCurrentRage/hPlayer.nMaxRage)
		elseif hPlayer.dwForceID == 9 then
			seArchHUD.Text_My_Acc:Hide()
			seArchHUD.Text_My_Mana:SetText(KeepTwoByteFloat(hPlayer.nCurrentMana / hPlayer.nMaxMana * 100).."%")
			seArchHUD.MyMana:SetPercentage(hPlayer.nCurrentMana/hPlayer.nMaxMana)
		elseif hPlayer.dwForceID == 10 then
			seArchHUD.Myextra:Show()
			seArchHUD.Myextra_bg:Show()
			seArchHUD.Text_My_Acc:Hide()
			seArchHUD.Text_My_Mana:SetFontColor(255, 255, 0)		
			if hPlayer.nSunPowerValue == 1 then
				seArchHUD.Text_My_Mana:SetText("���գ�")
				seArchHUD.MyMana:FromUITex("Interface\\seArchHUD\\rRing.UITex", 1)
				seArchHUD.Myextra:FromUITex("Interface\\seArchHUD\\rRing.UITex", 1)
				seArchHUD.MyMana:SetPercentage(100)
				seArchHUD.Myextra:SetPercentage(100)
			elseif hPlayer.nMoonPowerValue == 1 then
				seArchHUD.MyMana:FromUITex("Interface\\seArchHUD\\rRing.UITex", 3)
				seArchHUD.Myextra:FromUITex("Interface\\seArchHUD\\rRing.UITex", 3)
				seArchHUD.Text_My_Mana:SetText("���£�")
				seArchHUD.MyMana:SetPercentage(100)
				seArchHUD.Myextra:SetPercentage(100)
			else		
				seArchHUD.MyMana:FromUITex("Interface\\seArchHUD\\rRing.UITex", 3)
				seArchHUD.Myextra:FromUITex("Interface\\seArchHUD\\rRing.UITex", 1)
				seArchHUD.MyMana:SetPercentage(hPlayer.nCurrentMoonEnergy/hPlayer.nMaxMoonEnergy)
				seArchHUD.Myextra:SetPercentage(hPlayer.nCurrentSunEnergy/hPlayer.nMaxSunEnergy)
				seArchHUD.Text_My_Mana:SetText("��:"..tostring(hPlayer.nCurrentSunEnergy/100).."|".."��:"..tostring(hPlayer.nCurrentMoonEnergy/100))
			end
		else
			seArchHUD.Text_My_Mana:SetText("".."("..KeepTwoByteFloat(hPlayer.nCurrentMana / hPlayer.nMaxMana * 100).."%)"..tostring(hPlayer.nCurrentMana))
			seArchHUD.MyMana:SetPercentage(hPlayer.nCurrentMana/hPlayer.nMaxMana)
		end
		end
end
function seArchHUD.UpdateTargetData()		
		local dwType, dwID = GetClientPlayer().GetTarget()
		local target = nil
		local szLife = ""
		local hPlayer = GetClientPlayer()
		if seArchHUD.bSwitch == false then seArchHUD.HideTargetFrame()
		elseif seArchHUD.bFightShow == true and hPlayer.bFightState == false then seArchHUD.HideTargetFrame()
		else seArchHUD.ShowTargetFrame()
		if dwType == TARGET.PLAYER then
				target = GetPlayer(dwID)
		elseif dwType == TARGET.NPC then
				target = GetNpc(dwID)
		end
		if target.nCurrentLife >= 100000000 then
			szLife = string.format("%.2f", target.nCurrentLife / 100000000) .. "��"
		elseif target.nCurrentLife >= 100000 then
			szLife = string.format("%.2f", target.nCurrentLife / 10000) .. "��"
		else
		szLife = target.nCurrentLife
		end
		seArchHUD.Text_T_Heath:SetText(""..tostring(szLife).."("..KeepTwoByteFloat(target.nCurrentLife / target.nMaxLife * 100).."%)")
		seArchHUD.TargetHeath:SetPercentage(target.nCurrentLife/target.nMaxLife)
		return szLife
		end
end
function seArchHUD.UpdateCasting()
		local dwType, dwID = GetClientPlayer().GetTarget()
		local target = nil
		if dwType == TARGET.PLAYER then
				target = GetPlayer(dwID)
		elseif dwType == TARGET.NPC then
				target = GetNpc(dwID)
		end
		if target then
				local bPrePare, dwSkillID, dwSkillLevel, fCastPercent = target.GetSkillPrepareState()
				local szSkillName = Table_GetSkillName(dwSkillID, dwSkillLevel)
				seArchHUD.TargetCasting:SetPercentage(fCastPercent)
				seArchHUD.Text_T_Cast:SetText(szSkillName)
		end
end
function seArchHUD.UpdateAnchor(frame)
		frame:SetPoint(seArchHUD.DefaultAnchor.s, 0, 0, seArchHUD.DefaultAnchor.r, seArchHUD.DefaultAnchor.x, seArchHUD.DefaultAnchor.y)
		frame:CorrectPos()
end
Wnd.OpenWindow("interface\\seArchHUD\\seArchHUD.ini", "seArchHUD")