
--	ExtraCD������ȴ��ʱ���ѣ�����BUFF����CD��ʱ��ʾ
-- 	������ʽ�����¼��֣�
-- 		1��Ŀ�����ϵ�BUFF����
-- 		2���Լ����ϵ�BUFF����
--	����ĳBUFF����������ഥ��һ��
--	��ʱ�����Ӹ�ʽʾ����
--		1����Ŀ�����ϴ�����6226-20-t
--		2�����������ϴ�����6229-10-s


ExtraCD = ExtraCD or {}

ExtraCD.tAnchor = { s = "CENTER", r = "CENTER", x = 200, y = 0 }

ExtraCD.tExtraData = {
	{6418, 30, "s"}, 
}

RegisterCustomData("ExtraCD.tAnchor ")
RegisterCustomData("ExtraCD.tExtraData")

local szIniFile = "interface\\ExtraCD\\ExtraCD.ini"

local EVENT_TIP_DEFAULT_TIME = 800
local EVENT_TIP_TIME_STAGE = { 250, 550, 800 }
local EVENT_TIP_SCALE_STAGE = { 0.0012, 0.005 }

local EXTRA_MENU_OPTIONS = { ["t"] = "Ŀ�괥��", ["s"] = "��������" }

function ExtraCD.OnFrameCreate()
	this:RegisterEvent("UI_SCALED")
	this:RegisterEvent("CUSTOM_DATA_LOADED")
	this:RegisterEvent("ON_ENTER_CUSTOM_UI_MODE")
	this:RegisterEvent("ON_LEAVE_CUSTOM_UI_MODE")
	this:RegisterEvent("BUFF_UPDATE")
	ExtraCD.hTotal = this:Lookup("", "")
	ExtraCD.hTotal:Clear()
end

function ExtraCD.OnEvent(szEvent)
	if szEvent == "UI_SCALED" or (szEvent == "CUSTOM_DATA_LOADED" and arg0 == "Role") then
		ExtraCD.UpdateAnchor(this)
	elseif szEvent == "ON_ENTER_CUSTOM_UI_MODE" or szEvent == "ON_LEAVE_CUSTOM_UI_MODE" then
		UpdateCustomModeWindow(this, "ExtraCD")
	elseif szEvent == "BUFF_UPDATE" then
		ExtraCD.OnBuffUpdate(arg0, arg1, arg4, arg8)
	end
end

function ExtraCD.OnFrameDragEnd()
	this:CorrectPos()
	ExtraCD.tAnchor = GetFrameAnchor(this)
end

function ExtraCD.UpdateAnchor(frame)
	local anchor = ExtraCD.tAnchor
	frame:SetPoint(anchor.s, 0, 0, anchor.r, anchor.x, anchor.y)
	frame:CorrectPos()
end

function ExtraCD.OnFrameBreathe()
	local handle = ExtraCD.hTotal
	local dwTime, nCount = GetTickCount(), handle:GetItemCount()
	for i = 0, nCount - 1, 1 do
		local hBox = handle:Lookup(i)
		if hBox then
			local nTop = dwTime - hBox.dwStartTime
			local nBottom =  hBox.dwLiveTime - nTop
			local bg = hBox:Lookup("Image")
			if nTop > hBox.dwLiveTime then
				handle:RemoveItem(i)
			else
				if nTop < EVENT_TIP_TIME_STAGE[2] then
					bg:Show()
					local scale = 1 - nTop * EVENT_TIP_SCALE_STAGE[1]
					bg:SetSize(bg.w * scale, bg.h * scale)
					bg:SetRelPos(bg.x + bg.w * (1 - scale) / 2, bg.y + bg.h * (1 - scale) / 2)
				elseif nBottom <= EVENT_TIP_TIME_STAGE[1] then
					bg:Hide()
					local box_f = hBox:Lookup("Box_F")
					box_f:Show()
					box_f:SetAlpha(nBottom / 2)
					hBox:Lookup("Text"):SetAlpha(nBottom / 2)
					local scale = (EVENT_TIP_TIME_STAGE[3] - nBottom) * EVENT_TIP_SCALE_STAGE[2]
					box_f:SetSize(box_f.w * scale, box_f.h * scale)
					box_f:SetRelPos(box_f.x - box_f.w * (scale - 1) / 2, box_f.y - box_f.h * (scale - 1) / 2)
				end
				local hText = hBox:Lookup("Cool")
				if not hText.nSpark or hText.nSpark == 7 then
					hText.nSpark = 0
					hText.bSpark = not hText.bSpark
				end
				hText.nSpark = hText.nSpark + 1
				if hText.bSpark then
					hText:SetFontColor(255, 255, 255)
				else
					hText:SetFontColor(255, 0, 0)
				end
				hText:SetText(("%d"):format(nBottom / 1000))
			end
			hBox:FormatAllItemPos()
		end
	end
	handle:FormatAllItemPos()
end

function ExtraCD.GetTipBox(handle, dwID)
	local nCount = handle:GetItemCount() - 1
	for i = 0, nCount, 1 do
		local hBox = handle:Lookup(i)
		if hBox.dwID == dwID then
			return hBox
		end
	end
	return nil
end

function ExtraCD.NewTipBox(dwID, dwLevel, nTime)
	local handle = ExtraCD.hTotal
	local hBox = ExtraCD.GetTipBox(handle, dwID)
	if not hBox then
		handle:AppendItemFromIni(szIniFile, "Handle_Box")
		local nCount = handle:GetItemCount() - 1
		hBox = handle:Lookup(nCount)
		handle:FormatAllItemPos()
	end
	hBox.dwID = dwID
	hBox.dwStartTime = GetTickCount()
	if not nTime or nTime < 0.8 then
		hBox.dwLiveTime = EVENT_TIP_DEFAULT_TIME
	else
		hBox.dwLiveTime = nTime * 1000
	end
	local box_f = hBox:Lookup("Box_F")
	box_f.x, box_f.y = box_f:GetRelPos()
	box_f.w, box_f.h = box_f:GetSize()
	box_f:SetObject(UI_OBJECT_NOT_NEED_KNOWN, dwID)
	box_f:SetObjectIcon(Table_GetBuffIconID(dwID, dwLevel))
	box_f:Hide()
	local box = hBox:Lookup("Box")
	box:SetObject(UI_OBJECT_NOT_NEED_KNOWN, dwID)
	box:SetObjectIcon(Table_GetBuffIconID(dwID, dwLevel))
	box:SetOverTextFontScheme(1, 15)
	box:SetOverTextPosition(1, ITEM_POSITION.LEFT_TOP)
	local bg = hBox:Lookup("Image")
	bg.x, bg.y = bg:GetRelPos()
	bg.w, bg.h = bg:GetSize()
	hBox:Lookup("Text"):SetText(Table_GetBuffName(dwID, dwLevel))
end

function ExtraCD.OnBuffUpdate(dwCaster, bDelete, dwID, dwLevel)
	if bDelete then return end
	if dwCaster == UI_GetClientPlayerID() then
		for k, v in pairs(ExtraCD.tExtraData) do
			if dwID == v[1] and v[3] == "s" then
				ExtraCD.NewTipBox(v[1], 1, v[2])
			end
		end
	else
		local target = GetTargetHandle(GetClientPlayer().GetTarget())
		if target and target.dwID == dwCaster then
			for k, v in pairs(target.GetBuffList() or {}) do
				for k2, v2 in pairs(ExtraCD.tExtraData) do
					if v.dwID == v2[1] and v2[3] == "t" then
						ExtraCD.NewTipBox(v.dwID, v.nLevel, v2[2])
					end
				end
			end
		end
	end
end

function ExtraCD.GetMenu()
	local menu = { szOption = "ExtraCD������ȴ��ʱ" }
	for k, v in pairs(ExtraCD.tExtraData) do
		local m = {
			szOption = Table_GetBuffName(v[1], 1),
			{
				szOption = EXTRA_MENU_OPTIONS["t"],
				bMCheck = true,
				bChecked = (v[3] == "t"),
				fnAction = function() v[3] = "t" end
			},
			{
				szOption = EXTRA_MENU_OPTIONS["s"],
				bMCheck = true,
				bChecked = (v[3] == "s"),
				fnAction = function() v[3] = "s" end
			},
			{ bDevide = true },
			{
				szOption = "ɾ������",
				fnAction = function()
					table.remove(ExtraCD.tExtraData, k)
				end
			}
		}
		table.insert(menu, m)
	end
	table.insert(menu, { bDevide = true })
	local m_add = {
		szOption = "���Ӽ�ʱ��",
		fnAction = function()
			GetUserInput("ID-ʱ��-����",  function(szText)
				local t = SplitString(szText, "-")
				table.insert(ExtraCD.tExtraData, {
					tonumber(t[1]),
					tonumber(t[2]),
					t[3]})
			end, nil, nil, nil, nil, nil)
		end
	}
	table.insert(menu, m_add)

	return menu
end

RegisterEvent("LOGIN_GAME", function()
 	local tMenu = {
 		function()
 			return {ExtraCD.GetMenu()}
 		end,
 	}
 	Player_AppendAddonMenu(tMenu)
end)

Wnd.OpenWindow(szIniFile, "ExtraCD")
