RecordGKP={
	EditList = {
		{ItemName = "��ϯȫ��",NpcName="����",Money="-2000"},
		{ItemName = "���ⲹ��",NpcName="����",Money="-500"},
		{ItemName = "�ϰ����",NpcName="ȫ��",Money="10000"},
	},
}
RegisterCustomData("RecordGKP.EditList")

function RecordGKP.UpdatCheck(hList)
	local Check=hList:Lookup("Handle_Image/Image_Check")
	Check:Hide()
	if hList.bCheck then
		Check:Show()
		hList:Lookup("Text_Name"):SetFontScheme(164)
		RecordGKP.PlayerID=hList.dwID
		RecordGKP.PlayerName=hList.szName
		--OutputMessage("MSG_SYS","��ѡ�� ["..RecordGKP.PlayerName.."] ! \n")
	else
		Check:Hide()
	end
end
function RecordGKP.Selected(hItem)
    if hItem then
        local hList = hItem:GetRoot():Lookup("","Handle_Message")
        local nCount = hList:GetItemCount() - 1
        for j=0, nCount, 1 do
        local hMember = hList:Lookup(j)
        local MemberCount = hMember:GetItemCount() - 1
        for i=1, MemberCount, 1 do
            local hI = hMember:Lookup(i)
            if hI.bCheck then
                hI.bCheck = false
				local TextName=hI:Lookup("Text_Name")
				if hI.bIsOnLine then
					TextName:SetFontScheme(162)
				else
					TextName:SetFontScheme(161)
				end
				if hI.szName==GetClientPlayer().szName then TextName:SetFontScheme(165) end
                RecordGKP.UpdatCheck(hI)
            end
        end
        end
        hItem.bCheck = true
        RecordGKP.UpdatCheck(hItem)
    end
end
function RecordGKP.RecordSave()
	local frame = Station.Lookup("Normal/RecordGKP")
	RecordGKP.ItemName = JuneGKP.toName(frame:Lookup("Edit_ItemName"):GetText())
	RecordGKP.NpcName = JuneGKP.toName(frame:Lookup("Edit_NpcName"):GetText())
	RecordGKP.ItemMoney = tonumber(frame:Lookup("Edit_Money"):GetText())
	if RecordGKP.PlayerName=="" or RecordGKP.ItemName=="" or RecordGKP.PlayerName==nil or RecordGKP.ItemName==nil then
		local msg = {
		szMessage = GetFormatText("�����Ա����Ʒ���Ʋ���Ϊ�գ�", 16),
		bRichText = true,
		szName = "RecordItemNameBagSure",
		{szOption = g_tStrings.STR_HOTKEY_SURE, nFont = 16},
		nil
		}
		MessageBox(msg)
		return
	end
	if RecordGKP.ItemMoney==nil then
		local msg = {
		szMessage = GetFormatText("�۸���д������ʹ��������д����ϯ�Ȳ�����������ǰ��Ӹ��š�-����", 16),
		bRichText = true,
		szName = "RecordItemMoneyBagSure",
		{szOption = g_tStrings.STR_HOTKEY_SURE, nFont = 16},
		nil
		}
		MessageBox(msg)
		return
	end
	local dwDistributerID = GetClientTeam().GetAuthorityInfo(TEAM_AUTHORITY_TYPE.DISTRIBUTE)
	local CurrTime = GetCurrentTime()
	if RecordGKP.message == "JuneLoot" then
		table.insert(JuneGKP.GKPList,{PlayerID=RecordGKP.PlayerID,PlayerName=RecordGKP.PlayerName,ItemID=JuneLoot.ItemID,ItemName=JuneLoot.ItemName,ItemUiId=JuneLoot.ItemUiId,ItemTabType=JuneLoot.ItemTabType,nCount=JuneLoot.nCount,ItemQuality=JuneLoot.ItemQuality,ItemMoney=RecordGKP.ItemMoney,NpcName=JuneLoot.NpcName,LootMap=GetClientPlayer().GetScene().dwMapID,dTime=CurrTime})
		if GetClientPlayer().dwID == dwDistributerID then
			JuneGKP.BgTalk(PLAYER_TALK_CHANNEL.RAID, "June_GKPLoot", RecordGKP.PlayerID, RecordGKP.PlayerName, JuneLoot.ItemID, JuneLoot.ItemName, JuneLoot.ItemUiId, JuneLoot.ItemTabType,JuneLoot.nCount,JuneLoot.ItemQuality,RecordGKP.ItemMoney,JuneLoot.NpcName,GetClientPlayer().GetScene().dwMapID,CurrTime)
		end
		local nNum=""
		if JuneLoot.nCount>1 then
			nNum="x"..var2str(JuneLoot.nCount)
		end
		if JuneGKP.recOut then
			GetClientPlayer().Talk(PLAYER_TALK_CHANNEL.RAID,"",{{type = "text",text="["..JuneLoot.ItemName.."]"..nNum.." ["..RecordGKP.PlayerName.."]��"..RecordGKP.ItemMoney.."��\n"}})
		end
	elseif RecordGKP.message == "GKPEdit" then
		local mframe = Station.Lookup("Normal/JuneGKP")
		local mpage = mframe:Lookup("PageSet_Total/Page_GKP")
		local mhList = mpage:Lookup("", "Handle_GKPList")
		local nCount = mhList:GetItemCount() - 1
		for i=0, nCount, 1 do
		    local hI = mhList:Lookup(i)
		    if hI.bSel then
				JuneGKP.GKPList[hI.dwID]["PlayerID"]=RecordGKP.PlayerID
				JuneGKP.GKPList[hI.dwID]["PlayerName"]=RecordGKP.PlayerName
				JuneGKP.GKPList[hI.dwID]["ItemMoney"]=RecordGKP.ItemMoney
				if GetClientPlayer().dwID == dwDistributerID then
					JuneGKP.BgTalk(PLAYER_TALK_CHANNEL.RAID, "June_GKPEdit", hI.Time, RecordGKP.PlayerID, RecordGKP.PlayerName, RecordGKP.ItemMoney)
				end
				break
			end
		end
	else
	    table.insert(JuneGKP.GKPList,{PlayerID=RecordGKP.PlayerID,PlayerName=RecordGKP.PlayerName,ItemName=RecordGKP.ItemName,ItemMoney=RecordGKP.ItemMoney,NpcName=RecordGKP.NpcName,LootMap=GetClientPlayer().GetScene().dwMapID,dTime=CurrTime})
		if GetClientPlayer().dwID == dwDistributerID then
			JuneGKP.BgTalk(PLAYER_TALK_CHANNEL.RAID, "June_GKPAdd", RecordGKP.PlayerID, RecordGKP.PlayerName, RecordGKP.ItemName, RecordGKP.ItemMoney,RecordGKP.NpcName,GetClientPlayer().GetScene().dwMapID,CurrTime)
		end
		if JuneGKP.recOut then
			GetClientPlayer().Talk(PLAYER_TALK_CHANNEL.RAID,"",{{type = "text",text="["..RecordGKP.ItemName.."] ["..RecordGKP.PlayerName.."]��"..RecordGKP.ItemMoney.."��\n"}})
		end
	end
	Wnd.CloseWindow("RecordGKP")
	JuneGKP.SaveFile("GKPList",JuneGKP.GKPList)
	local pframe = Station.Lookup("Normal/JuneGKP")
	if pframe then JuneGKP.UpdateGKP() end
end
function RecordGKP.UpdateMemberName()
	local frame = Station.Lookup("Normal/RecordGKP")
	local hList = frame:Lookup("","Handle_Message")
	local hTeam = GetClientTeam()
	local tPartyMark = hTeam.GetTeamMark() or {}
	RecordGKP.PlayerName=nil
	hList:Clear()
	local nGroupNum = hTeam.nGroupNum
	for nGroupID = 0, nGroupNum - 1 do
		local tGroupInfo = hTeam.GetGroupInfo(nGroupID)
		if nGroupNum > 1 and #tGroupInfo.MemberList > 0 then
			local hGroup = hList:AppendItemFromIni("interface/JuneGKP/RecordGKP.ini","Handle_Group")
			hGroup:Clear()
			hGroup.dwGroupID = nGroupID
			local hTitle = hGroup:AppendItemFromIni("interface/JuneGKP/RecordGKP.ini","Handle_Title")
			hTitle:Lookup("Text_Handle_Title"):SetText("С��" ..g_tStrings.STR_NUMBER[nGroupID + 1].."��")
			hTitle:Lookup("Text_Handle_Title"):SetFontScheme(27)
			for i, dwID in ipairs(tGroupInfo.MemberList) do
				local hMember = hGroup:AppendItemFromIni("interface/JuneGKP/RecordGKP.ini","Handle_Member")
				local hImage = hMember:Lookup("Handle_Image")
				hMember.dwID = dwID
				local tMemberInfo = hTeam.GetMemberInfo(hMember.dwID)
				local TextName=hMember:Lookup("Text_Name")
				TextName:SetText(tMemberInfo.szName)
				hMember.szName = tMemberInfo.szName
				hMember.bIsOnLine = tMemberInfo.bIsOnLine
				if tMemberInfo.bIsOnLine then
					TextName:SetFontScheme(162)
				else
					TextName:SetFontScheme(161)
				end
				if hMember.szName==GetClientPlayer().szName then TextName:SetFontScheme(165) end
				if RecordGKP.message == "JuneLoot" and tMemberInfo.szName==JuneLoot.LootName then
					hMember.bCheck = true
				elseif RecordGKP.message == "GKPEdit" then
					local mframe = Station.Lookup("Normal/JuneGKP")
					if not mframe then return Wnd.CloseWindow("RecordGKP") end
					local mpage = mframe:Lookup("PageSet_Total/Page_GKP")
					local mhList = mpage:Lookup("", "Handle_GKPList")
					local nCount = mhList:GetItemCount() - 1
					for i=0, nCount, 1 do
						local hI = mhList:Lookup(i)
						if hI.bSel and tMemberInfo.szName==JuneGKP.GKPList[hI.dwID]["PlayerName"] then
							hMember.bCheck = true
							break
						end
					end
				end
				RecordGKP.UpdatCheck(hMember)
				hGroup:FormatAllItemPos()
			end
		end
	end
	RecordGKP.UpdateScrollInfo(hList)
end
function RecordGKP.UpdateRecordPanel()
	local frame = Station.Lookup("Normal/RecordGKP")
	local hList = frame:Lookup("","Handle_Message")
	RecordGKP.UpdateMemberName()
	if RecordGKP.message == "JuneLoot" then
	    local textItemName = frame:Lookup("Edit_ItemName")
	    if JuneLoot.nCount>1 then
	        textItemName:SetText(JuneLoot.ItemName.."x"..var2str(JuneLoot.nCount))
        else
            textItemName:SetText(JuneLoot.ItemName)
        end
	    textItemName:SetFontColor(GetItemFontColorByQuality(JuneLoot.ItemQuality, false))
		textItemName:Enable(false)
		frame:Lookup("Btn_Item"):Hide()
	    frame:Lookup("Edit_NpcName"):SetText(JuneLoot.NpcName)
		frame:Lookup("Edit_NpcName"):Enable(false)
		local lMoney=0
		if JuneLoot.NorMoney[JuneLoot.ItemID] then
			lMoney=JuneLoot.NorMoney[JuneLoot.ItemID]
		end
		frame:Lookup("Edit_Money"):SetText(lMoney)
	elseif RecordGKP.message == "GKPEdit" then
		local mframe = Station.Lookup("Normal/JuneGKP")
		local mpage = mframe:Lookup("PageSet_Total/Page_GKP")
		local mhList = mpage:Lookup("", "Handle_GKPList")
		local nCount = mhList:GetItemCount() - 1
		for i=0, nCount, 1 do
		    local hI = mhList:Lookup(i)
		    if hI.bSel then
				local textItemName = frame:Lookup("Edit_ItemName")
				local ItemNum = JuneGKP.GKPList[hI.dwID]["nCount"]
				if ItemNum and ItemNum>1 then
				   textItemName:SetText(JuneGKP.GKPList[hI.dwID]["ItemName"].."x"..var2str(ItemNum))
				else
				   textItemName:SetText(JuneGKP.GKPList[hI.dwID]["ItemName"])
				end
				textItemName:SetFontColor(GetItemFontColorByQuality(JuneGKP.GKPList[hI.dwID]["ItemQuality"], false))
				textItemName:Enable(false)
				frame:Lookup("Btn_Item"):Hide()
				frame:Lookup("Edit_NpcName"):SetText(JuneGKP.GKPList[hI.dwID]["NpcName"])
				frame:Lookup("Edit_NpcName"):Enable(false)
				frame:Lookup("Edit_Money"):SetText(JuneGKP.GKPList[hI.dwID]["ItemMoney"])
				break
			end
		end
	else
		frame:Lookup("","Text_note"):SetText("��ϯ�ȶ���ۿ�ex:-2000")
		frame:Lookup("","Text_note"):Show()
	end
end
function RecordGKP.show(message)
	frame = Wnd.OpenWindow("interface/JuneGKP/RecordGKP.ini", "RecordGKP")
	frame:Show()
	RecordGKP.Anchor()
	RecordGKP.message=message
	if RecordGKP.message == "JuneLoot" or RecordGKP.message == "GKPEdit"  or RecordGKP.message == "Add" then
	    RecordGKP.UpdateRecordPanel()
	else
        RecordGKP.UpdateMemberName()
	end
end
function RecordGKP.Anchor()
	local mframe = Station.Lookup("Normal/JuneGKP")
	local frame = Station.Lookup("Normal/RecordGKP")
	if frame and mframe then
		local mX,mY = mframe:GetRelPos()
		frame:SetRelPos(mX-380,mY)
	end
end
function RecordGKP.UpdateScrollInfo(hList)
    hList:Sort()
    hList:FormatAllItemPos()
    local hFrame = hList:GetRoot()
    local scroll = hFrame:Lookup("Scroll_List")
    local wAll, hAll = hList:GetAllItemSize()
    local w, h = hList:GetSize()
    local nCountStep = math.ceil((hAll - h) / 10)

    scroll:SetStepCount(nCountStep)
    if nCountStep > 0 then
        scroll:Show()
        hFrame:Lookup("Btn_Up"):Show()
        hFrame:Lookup("Btn_Down"):Show()
    else
        scroll:Hide()
        hFrame:Lookup("Btn_Up"):Hide()
        hFrame:Lookup("Btn_Down"):Hide()
    end
end
function RecordGKP.OnScrollBarPosChanged()
    local hFrame = this:GetRoot()
    local nCurrentValue = this:GetScrollPos()
	local szName = this:GetName()
    if szName == "Scroll_List" then
        if nCurrentValue == 0 then
            hFrame:Lookup("Btn_Up"):Enable(false)
        else
            hFrame:Lookup("Btn_Up"):Enable(true)
        end
        if nCurrentValue == this:GetStepCount() then
            hFrame:Lookup("Btn_Down"):Enable(false)
        else
            hFrame:Lookup("Btn_Down"):Enable(true)
        end
        hFrame:Lookup("", "Handle_Message"):SetItemStartRelPos(0, - nCurrentValue * 10)
    end
end
function RecordGKP.OnLButtonDown()
    RecordGKP.OnLButtonHold()
end
function RecordGKP.OnLButtonHold()
    local szName = this:GetName()
	if  szName == "Btn_Cancel" or szName == "Btn_Close" then
        Wnd.CloseWindow("RecordGKP")
	elseif szName == "Btn_Sure" then
	    RecordGKP.RecordSave()
    elseif szName == "Btn_Up" then
        this:GetParent():Lookup("Scroll_List"):ScrollPrev()
    elseif szName == "Btn_Down" then
        this:GetParent():Lookup("Scroll_List"):ScrollNext()
    end
end
function RecordGKP.OnItemMouseWheel()
	local nDistance = Station.GetMessageWheelDelta()
	local szName = this:GetName()
	if szName == "Handle_Message" then
        local hFrame = this:GetRoot()
		hFrame:Lookup("Scroll_List"):ScrollNext(nDistance)
	end
    return 1
end
function RecordGKP.OnItemLButtonClick()
	local szName = this:GetName()
	if szName == "Handle_Member" then
	    RecordGKP.Selected(this)
	end
end
function RecordGKP.OnItemLButtonDown()
	local szName = this:GetName()
end
function RecordGKP.OnLButtonClick()
    local szName = this:GetName()
    if szName == "Btn_Item" then
		local frame = this:GetRoot()
		local hEdit = frame:Lookup("Edit_ItemName")
		local xA, yA = hEdit:GetAbsPos()
		local w, h = hEdit:GetSize()
		local menu =
		{
			nMiniWidth = w,
			x = xA, y = yA + h,
		}
		for i,v in ipairs(RecordGKP.EditList) do
			local subMenu = {
			szOption = v.ItemName,
			fnAction = function()
				frame:Lookup("Edit_ItemName"):SetText(v.ItemName)
				frame:Lookup("Edit_NpcName"):SetText(v.NpcName)
				frame:Lookup("Edit_Money"):SetText(v.Money)
			end,
			}
			table.insert(menu, subMenu)
		end
		if menu and #menu > 0 then
			PopupMenu(menu)
		end
    end
end
