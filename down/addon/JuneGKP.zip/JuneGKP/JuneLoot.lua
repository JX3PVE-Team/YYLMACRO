JuneLoot ={
dwDoodadID = nil,
ItemsTable = {},
frameSelf = nil,
HandleTotal = nil,
handleBox = nil,
HandleBG = nil,
Lplan = {},
NorMoney={},
tRollList = {},
dwRollItem = nil,
}
local szIniFile="Interface/JuneGKP/JuneLoot.ini"
function JuneLoot.ClearPanel()
	if not JuneLoot.frameSelf then
		return
	end
	if JuneLoot.handleBox then
		JuneLoot.handleBox:Clear()
	end
	if JuneLoot.HandleBG then
		JuneLoot.HandleBG:Clear()
	end
	JuneLoot.dwDoodadID = nil
	JuneLoot.ItemsTable = {}
end
function JuneLoot.OpenPanel()
	local frame = Station.Lookup("Normal/JuneLoot")
	if not frame then
		frame = Wnd.OpenWindow(szIniFile, "JuneLoot")
	end
	JuneLoot.frameSelf = frame
	JuneLoot.HandleTotal = frame:Lookup("", "")
	JuneLoot.handleBox = frame:Lookup("", "Handle_Box")
	JuneLoot.HandleBG = frame:Lookup("", "Handle_BG")
	frame:SetRelPos(JuneGKP.lootAnchor.nX,JuneGKP.lootAnchor.nY)
	frame:Show()
	frame:BringToTop()
end
function JuneLoot.GetForceColor(dwForceID)
	local szSchool = GetForceTitle(dwForceID)
	if szSchool == "����" then return 255,128,255
	elseif szSchool == "��" then return 128,128,192
	elseif szSchool == "���" then return 255,64,128
	elseif szSchool == "����" then return 255,128,64
	elseif szSchool == "�ؽ�" then return 255,255,0
	elseif szSchool == "����" then return 0,255,255
	elseif szSchool == "�嶾" then return 64,128,255
	elseif szSchool == "����" then return 0,255,0
	elseif szSchool == "����" then return 255,0,128
	elseif szSchool == "ؤ��" then return 128,64,64
	else return  255,255,255
	end
end
function JuneLoot.IsOpened()
	local frame = Station.Lookup("Normal/JuneLoot")
	if frame and frame:IsVisible() then
		return true
	end
	return false
end
function JuneLoot.ClosePanel()
	if not JuneLoot.IsOpened() then
		return
	end
	local frame = Station.Lookup("Normal/JuneLoot")
	frame:Hide()
end
function JuneLoot.MonitorSYS(szMsg)
	if JuneGKP.bRollMenu and JuneLoot.dwRollItem and JuneLoot.tRollList[JuneLoot.dwRollItem] and string.find(szMsg,".-����.-�㡣") then
		local szName,szRoll = string.match(szMsg,".*text=\"(.-)����(.-)�㡣")
		if szName and szRoll then
			local bInsert = true
			for i,v in pairs(JuneLoot.tRollList[JuneLoot.dwRollItem]) do
				if v.szName == szName then
					bInsert = false
					break
				end
			end
			if bInsert then
				table.insert(JuneLoot.tRollList[JuneLoot.dwRollItem],{szName = szName, nRoll = tonumber(szRoll)})
			end
		end
	end
end
function JuneLoot.OnFrameDragEnd()
	JuneGKP.lootAnchor.nX,JuneGKP.lootAnchor.nY = this:GetRelPos()
end
function JuneLoot.OnLButtonClick()
	local szName = this:GetName()
	if szName == "Btn_Close" then
		Wnd.CloseWindow("JuneLoot")
	end
end
function JuneLoot.OnItemMouseEnter()
	if this:GetType() == "Box" then
		this.bOver = true
		this:SetObjectMouseOver(1)
		if this:GetName():match("ItemBox_") then
			local x, y = this:GetAbsPos()
			local w, h = this:GetSize()
			local doodad = GetDoodad(this.dwDoodadID)
			if doodad then
				OutputItemTip(UI_OBJECT_ITEM_ONLY_ID, this.dwItemID, nil, nil, {x, y, w, h}, nil, "loot")
			else
				local szTip = GetFormatText(this.szItemName.."\n", 27)
				OutputTip(szTip, 400, {x, y, w, h})
			end
		end
	end
end
function JuneLoot.OnItemMouseLeave()
	HideTip()
	if this:GetName():match("ItemBox_") then
		this.bOver = false
		this:SetObjectMouseOver(0)
	end
end
function JuneLoot.OnItemRButtonClick()
	local itemBox = this
	if not itemBox:GetName():match("ItemBox_") then
		return
	end
    local player = GetClientPlayer()
	if IsCtrlKeyDown() then
		for i,v in pairs(JuneLoot.ItemsTable) do
			if v.dwItemID==itemBox.dwItemID then
				table.remove(JuneLoot.ItemsTable,i)
				local szImageName = itemBox:GetName():gsub("ItemBox_", "ImageBox_")
				JuneLoot.HandleBG:Lookup(szImageName):Hide()
				itemBox:Hide()
				JuneLoot.AdjustAllPosAndSize()
				break
			end
		end
		return
	end
	if IsShiftKeyDown() then
		if not JuneGKP.bTimeDown then
			JuneGKP.dItemID=itemBox.dwItemID
			JuneGKP.nLastNum=5
			JuneGKP.bTimeDown=true
		else
			JuneGKP.bTimeDown=false
		end
		return
	end
	local menu={}
	local tRollMenu1 = {szOption="Roll��",rgb = {255,255,0},fnAction=function()
		local doodad = GetDoodad(itemBox.dwDoodadID)
		if doodad then
			player.Talk(JuneGKP.TalkChannel,"",{{type = "item", item=itemBox.dwItemID},{type = "text", text=" ��ʼRoll�㣬Ҫ����� /roll �� \n"}})
		else
			player.Talk(JuneGKP.TalkChannel,"",{{type = "text", text="["..itemBox.szItemName.."] ��ʼRoll�㣬Ҫ����� /roll �� \n"}})
		end
		JuneLoot.tRollList[itemBox.dwItemID] = {}
		JuneLoot.dwRollItem = itemBox.dwItemID
		end}
	local tRollMenu2 = {szOption="��������",rgb = {255,255,0},fnAction=function()
			table.sort(JuneLoot.tRollList[itemBox.dwItemID],function(a, b) return a.nRoll < b.nRoll end)
			local doodad = GetDoodad(itemBox.dwDoodadID)
			if doodad then
				player.Talk(JuneGKP.TalkChannel,"",{{type = "item", item=itemBox.dwItemID},{type = "text", text="Roll���¼�� \n"}})
			else
				player.Talk(JuneGKP.TalkChannel,"",{{type = "text", text="["..itemBox.szItemName.."]Roll���¼�� \n"}})
			end
			for i,v in ipairs(JuneLoot.tRollList[itemBox.dwItemID]) do
				player.Talk(JuneGKP.TalkChannel,"",{{type = "text", text=""..v.nRoll .."--["..v.szName.."] \n"}})
			end
		end}
	if JuneGKP.bRollMenu then
		if JuneLoot.tRollList[itemBox.dwItemID] and not IsEmpty(JuneLoot.tRollList[itemBox.dwItemID]) then
			table.insert(menu,tRollMenu2)
		end
		table.insert(menu,tRollMenu1)
		table.insert(menu,{bDevide = true})
	end
	if JuneGKP.Lplan=="Ԥ�跽��1" then
		JuneLoot.Lplan=JuneGKP.Gplan.a
	elseif JuneGKP.Lplan=="Ԥ�跽��2" then
		JuneLoot.Lplan=JuneGKP.Gplan.b
	elseif JuneGKP.Lplan=="Ԥ�跽��3" then
		JuneLoot.Lplan=JuneGKP.Gplan.c
	elseif JuneGKP.Lplan=="Ԥ�跽��4" then
		JuneLoot.Lplan=JuneGKP.Gplan.d
	elseif JuneGKP.Lplan=="�Զ��巽��" then
		JuneLoot.Lplan=JuneGKP.Gplan.z
	end
	for _,gold in ipairs(JuneLoot.Lplan) do
		table.insert(menu,{szOption=var2str(gold).."��",fnAction=function()
		local doodad = GetDoodad(itemBox.dwDoodadID)
		if doodad then
			player.Talk(JuneGKP.TalkChannel,"",{{type = "item", item=itemBox.dwItemID},{type = "text", text=" "..var2str(gold).."�� ���ģ�Ҫ������ۡ� \n"}})
		else
			player.Talk(JuneGKP.TalkChannel,"",{{type = "text", text="["..itemBox.szItemName.."] "..var2str(gold).."�� ���ģ�Ҫ������ۡ� \n"}})
		end
		JuneLoot.NorMoney[itemBox.dwItemID]=gold
		end})
	end
	PopupMenu(menu)
end
function JuneLoot.OnItemLButtonClick()
    local player = GetClientPlayer()
	local itemBox = this
	if not itemBox:GetName():match("ItemBox_") then
		return
	end
	if IsCtrlKeyDown() then
		local item = GetItem(itemBox.dwItemID)
		if item then
			local szName = "["..GetItemNameByItemInfo(item).."]"
			local edit = Station.Lookup("Lowest2/EditBox/Edit_Input")
			edit:InsertObj(szName, {type = "iteminfo", text = szName, version = item.nVersion, tabtype = item.dwTabType, index = item.dwIndex})
			Station.SetFocusWindow(edit)
			return true
		end
		return
	end
    local doodad = GetDoodad(itemBox.dwDoodadID)
	if itemBox.bNeedDistribute then
		local aPartyMember = {}
		local hTeam = GetClientTeam()
		for nGroupID = 0, hTeam.nGroupNum - 1 do
			local tInfo = hTeam.GetGroupInfo(nGroupID)
			for nIndex,dwID in ipairs(tInfo.MemberList) do
				local aPlyer = hTeam.GetMemberInfo(dwID)
				aPlyer.dwID = dwID
				table.insert(aPartyMember, aPlyer)
			end
		end
		if aPartyMember then
			local dwItemID = itemBox.dwItemID
			local fAction = function(k)
				JuneLoot.LootName=k.szName
				JuneLoot.ItemID=dwItemID
				JuneLoot.ItemName=itemBox.szItemName
				JuneLoot.ItemUiId=itemBox.nItemUiId
				JuneLoot.ItemTabType=itemBox.dwItemTabType
				JuneLoot.nCount=itemBox.nItemNum
				JuneLoot.ItemQuality=itemBox.nItemQuality
				JuneLoot.NpcName=itemBox.szNpcName
				local dwDistributerID = GetClientTeam().GetAuthorityInfo(TEAM_AUTHORITY_TYPE.DISTRIBUTE)
				if doodad and dwDistributerID == player.dwID then
					local msg =
					{
						szMessage = FormatLinkString(
							g_tStrings.PARTY_DISTRIBUTE_ITEM_SURE,
							"font=162",
							GetFormatText("["..itemBox.szItemName.."]", "font=0"..GetItemFontColorByQuality(itemBox.nItemQuality, true)),
							GetFormatText("["..k.szName.."]", 165)
							),
						szName = "Distribute_Item_Sure"..dwItemID,
						bRichText = true,
						{szOption = g_tStrings.STR_HOTKEY_SURE, nFont = 16, fnAction = function()
							doodad.DistributeItem(dwItemID, k.dwID)
							local nNum=""
							if itemBox.nItemNum>1 then
								nNum="x"..var2str(itemBox.nItemNum).." "
							end
							if JuneGKP.disOut then
								player.Talk(JuneGKP.TalkChannel,"",{{type = "text", text="��������ѽ�"},{type = "item", item=itemBox.dwItemID},{type = "text", text=nNum.."�����["..k.szName.."]����ע����ա��� \n"}})
							end
							RecordGKP.show("JuneLoot")
							for i,v in pairs(JuneLoot.ItemsTable) do
								if v.dwItemID==dwItemID then
									table.remove(JuneLoot.ItemsTable,i)
									local szImageName = itemBox:GetName():gsub("ItemBox_", "ImageBox_")
									JuneLoot.HandleBG:Lookup(szImageName):Hide()
									itemBox:Hide()
									JuneLoot.AdjustAllPosAndSize()
									break
								end
							end
						end},
						{szOption = g_tStrings.STR_HOTKEY_CANCEL},
					}
					MessageBox(msg)
				else
					RecordGKP.show("JuneLoot")
					for i,v in pairs(JuneLoot.ItemsTable) do
						if v.dwItemID==dwItemID then
							table.remove(JuneLoot.ItemsTable,i)
							local szImageName = itemBox:GetName():gsub("ItemBox_", "ImageBox_")
							JuneLoot.HandleBG:Lookup(szImageName):Hide()
							itemBox:Hide()
							JuneLoot.AdjustAllPosAndSize()
							break
						end
					end
				end
			end
			local menu = {fnAction = fAction}
			table.sort(aPartyMember,function(a,b) return (a.dwForceID<b.dwForceID) end)
			for i, k in ipairs(aPartyMember) do
				local szPath, nFrame = GetForceImage(k.dwForceID)
				local r, g, b = JuneLoot.GetForceColor(k.dwForceID)
				if doodad then
					local bPartyMember = doodad.GetLooterList()
					local bOnlineFlag = false
					for j, v in ipairs(bPartyMember) do
						if v.dwID == k.dwID then
							bOnlineFlag = v.bOnlineFlag
							break
						end
					end
					table.insert(menu, {szOption = k.szName, UserData = k, bDisable = not(bOnlineFlag), r = r, g = g, b = b, szIcon = szPath; nFrame=nFrame;szLayer = "ICON_LEFT"})
				else
					table.insert(menu, {szOption = k.szName, UserData = k, bDisable = not(k.bIsOnLine), r = r, g = g, b = b, szIcon = szPath; nFrame=nFrame;szLayer = "ICON_LEFT"})
				end
			end
			PopupMenu(menu)
		end
		return
	end
end
function JuneLoot.CheckEmptyToClose()
	if #JuneLoot.ItemsTable<1 then
		JuneLoot.ClosePanel()
	end
end
RegisterEvent("OPEN_DOODAD", function()
	if not JuneGKP.GKP_YoN then
		return
	end
	JuneLoot.dwDoodadID = arg0
	local doodad = GetDoodad(arg0)
	local frame = Station.Lookup("Normal/LootList")
	if not frame then
		return
	end
	local nBoxWidth = 68
	local nBoxHeight = 68
	local handle = frame:Lookup("", "Handle_LootList")
	local nCount = handle:GetItemCount() - 1
	local bInsert = false
	for i = 0, nCount, 1 do
		local itemBox = handle:Lookup(i)
		if itemBox.bNeedDistribute then
			bInsert = true
			break
		end
	end
	if bInsert then
		if not JuneLoot.IsOpened() then
			JuneLoot.OpenPanel()
		end
		JuneLoot.ClearPanel()
		frame:Hide()
	else
		return
	end
	for i = 0, nCount, 1 do
		local itemBox = handle:Lookup(i)
		local item = GetItem(itemBox.dwID)
		if item and itemBox.bNeedDistribute then		-- ������߻�ȡ�ɹ�, �����ӵ����������
			local nQuality = item.nQuality
			local box = JuneLoot.handleBox:AppendItemFromIni(szIniFile, "Box_Bag1", "ItemBox_" .. i)
			box.dwDoodadID = arg0
			box.szNpcName = doodad.szName
			box.dwItemID = item.dwID
			box.dwItemTabType = item.dwTabType
			box.szItemName = item.szName
			box.nItemVersion = item.nVersion
			box.bNeedRoll = itemBox.bNeedRoll
			box.bNeedDistribute = itemBox.bNeedDistribute
			box.nLootIndex = itemBox.nLootIndex
			box.nItemUiId = item.nUiId
			box.nItemQuality = item.nQuality
			box:SetObject(UI_OBJECT_ITEM_ONLY_ID, item.nUiId, item.dwID, item.nVersion, item.dwTabType, item.dwIndex)
			box:SetObjectIcon(Table_GetItemIconID(item.nUiId))
			box:SetSize(nBoxWidth - 4, nBoxHeight - 4)
			box:SetOverTextPosition(0, ITEM_POSITION.RIGHT_BOTTOM)
			box:SetOverTextFontScheme(0, 15)
			if item.bCanStack and item.nStackNum > 1 then
				box:SetOverText(0, item.nStackNum)
				box.nItemNum = item.nStackNum
			else
				box:SetOverText(0, "")
				box.nItemNum = 0
			end
			box:Show()
			-- ���洦������
			local tQualityText = {"Image_White", "Image_Green", "Image_Blue", "Image_Purple", "Image_Orange"}
			tQualityText[0] = "Image_Red"
			local imageBox = JuneLoot.HandleBG:AppendItemFromIni(szIniFile, tQualityText[nQuality], "ImageBox_" .. i)
			imageBox:SetSize(nBoxWidth, nBoxHeight)
			imageBox:SetAlpha(200)
			imageBox:Show()
			if nQuality > 0 then
				imageBox:Show()
			else
				imageBox:Hide()
			end
			table.insert(JuneLoot.ItemsTable, box)
		end
	end
	Wnd.CloseWindow("LootList")
	JuneLoot.AdjustAllPosAndSize()
end)

function JuneLoot.AdjustAllPosAndSize()
	if not JuneLoot.IsOpened() then
		return
	end
	local frame = Station.Lookup("Normal/JuneLoot")
	local nBoxWidth = 68
	local nBoxHeight = 68
	local nMaxRow = 6  --ÿ�и���
	local nMaxCol = math.ceil(#JuneLoot.ItemsTable/nMaxRow)
	if #JuneLoot.ItemsTable < nMaxRow then
		nMaxRow = #JuneLoot.ItemsTable
	end
	--��������ʽ����
	local nWidthNeed = (nBoxWidth + 4) * nMaxRow + 4 * 2
	local nHeightNeed = (nBoxHeight + 4) * nMaxCol + 32 + 4 * 2
	local buttonClose = JuneLoot.frameSelf:Lookup("Btn_Close")
	buttonClose:SetRelPos(nWidthNeed - 28, 8)
	JuneLoot.frameSelf:SetSize(nWidthNeed, nHeightNeed)
	JuneLoot.HandleTotal:SetSize(nWidthNeed, nHeightNeed)
	JuneLoot.HandleTotal:Lookup("Image_Bg"):SetSize(nWidthNeed, nHeightNeed)
	JuneLoot.HandleTotal:Lookup("Image_Title"):SetSize(nWidthNeed, 32)
	JuneLoot.handleBox:SetSize(nWidthNeed, nHeightNeed)
	JuneLoot.HandleBG:SetSize(nWidthNeed, nHeightNeed)

	for nCol = 0, nMaxCol-1 do
		for nRow= 1, nMaxRow do
			local box = JuneLoot.ItemsTable[nMaxRow*nCol+nRow]
			if box then
				box:SetRelPos((nRow - 1) * (nBoxWidth + 4)+2 , 34 + nCol * (nBoxHeight + 4)+2)
				local szImageName = box:GetName():gsub("ItemBox_", "ImageBox_")
				local image = JuneLoot.HandleBG:Lookup(szImageName)
				if image then
					image:SetRelPos((nRow - 1) * (nBoxWidth + 4) , 34 + nCol * (nBoxHeight + 4))
				end
			end
		end
	end

	JuneLoot.HandleBG:FormatAllItemPos()
	JuneLoot.handleBox:FormatAllItemPos()
	JuneLoot.HandleTotal:FormatAllItemPos()
	JuneLoot.CheckEmptyToClose()
end
RegisterMsgMonitor(JuneLoot.MonitorSYS, {"MSG_SYS"})