RecordTrade={}
function RecordTrade.RecordSave()
	local frame = Station.Lookup("Normal/RecordTrade")
	RecordTrade.mName = JuneGKP.toName(frame:Lookup("Edit_mName"):GetText())
	RecordTrade.tName = JuneGKP.toName(frame:Lookup("Edit_tName"):GetText())
	RecordTrade.mMoney = tonumber(frame:Lookup("Edit_mMoney"):GetText())
	RecordTrade.tMoney = tonumber(frame:Lookup("Edit_tMoney"):GetText())
	if RecordTrade.mMoney==nil or RecordTrade.tMoney==nil or RecordTrade.mName=="" or RecordTrade.tName=="" then
		local msg =
		{
		szMessage = GetFormatText("��д�������ֲ���Ϊ�գ������ʹ��������д��", 16),
		bRichText = true,
		szName = "RecordMoneyBagSure",
		{szOption = g_tStrings.STR_HOTKEY_SURE, nFont = 16},
		nil
		}
		MessageBox(msg)
		return
	end
	if RecordTrade.message=="TradeEdit" then
		local mframe = Station.Lookup("Normal/JuneGKP")
		local mpage = mframe:Lookup("PageSet_Total/Page_Trade")
		local mhList = mpage:Lookup("", "Handle_TradeList")
		local nCount = mhList:GetItemCount() - 1
		for i=0, nCount, 1 do
		    local hI = mhList:Lookup(i)
		    if hI.bSel then
				JuneGKP.TradeList[hI.dwID]["tName"]=RecordTrade.tName
				JuneGKP.TradeList[hI.dwID]["mMoney"]=(RecordTrade.mMoney*10000)
				JuneGKP.TradeList[hI.dwID]["tMoney"]=(RecordTrade.tMoney*10000)
				break
			end
		end
	else
		table.insert(JuneGKP.TradeList,{tName=RecordTrade.tName,tMoney=(RecordTrade.tMoney*10000),mName=RecordTrade.mName,mMoney=(RecordTrade.mMoney*10000),gTime=GetCurrentTime(),tType="Record"})
	end
	Wnd.CloseWindow("RecordTrade")
	JuneGKP.SaveFile("TradeList",JuneGKP.TradeList)
	local pframe = Station.Lookup("Normal/JuneGKP")
	if pframe then JuneGKP.UpdateTrade() end
end
function RecordTrade.UpdateRecordPanel()
	local frame = Station.Lookup("Normal/RecordTrade")
	if not GetClientPlayer().IsInParty() then
		frame:Lookup("Btn_Players"):Hide()
	end
	local textmName = frame:Lookup("Edit_mName")
	textmName:SetText(GetClientPlayer().szName)
	textmName:Enable(false)
	if RecordTrade.message=="TradeEdit" then
		local mframe = Station.Lookup("Normal/JuneGKP")
		if not mframe then return Wnd.CloseWindow("RecordTrade") end
		local mpage = mframe:Lookup("PageSet_Total/Page_Trade")
		local mhList = mpage:Lookup("", "Handle_TradeList")
		local nCount = mhList:GetItemCount() - 1
		for i=0, nCount, 1 do
		    local hI = mhList:Lookup(i)
		    if hI.bSel then
				textmName:SetText(JuneGKP.TradeList[hI.dwID]["mName"])
				frame:Lookup("Edit_tName"):SetText(JuneGKP.TradeList[hI.dwID]["tName"])
				frame:Lookup("Edit_mMoney"):SetText(JuneGKP.TradeList[hI.dwID]["mMoney"]/10000)
				frame:Lookup("Edit_tMoney"):SetText(JuneGKP.TradeList[hI.dwID]["tMoney"]/10000)
				break
			end
		end
	else
		frame:Lookup("Edit_mMoney"):SetText("0")
		frame:Lookup("Edit_tMoney"):SetText("0")
	end
end
function RecordTrade.show(message)
	frame = Wnd.OpenWindow("interface/JuneGKP/RecordTrade.ini", "RecordTrade")
	frame:Show()
	RecordTrade.Anchor()
	RecordTrade.message=message
	RecordTrade.UpdateRecordPanel()
end
function RecordTrade.Anchor()
	local mframe = Station.Lookup("Normal/JuneGKP")
	local frame = Station.Lookup("Normal/RecordTrade")
	if frame and mframe then
		local mX,mY = mframe:GetRelPos()
		frame:SetRelPos(mX-380,mY)
	end
end
function RecordTrade.OnLButtonDown()
    RecordTrade.OnLButtonHold()
end
function RecordTrade.OnLButtonHold()
    local szName = this:GetName()
    if  szName == "Btn_Cancel" or szName == "Btn_Close" then
        Wnd.CloseWindow("RecordTrade")
    elseif szName == "Btn_Sure" then
        RecordTrade.RecordSave()
    end
end
function RecordTrade.OnLButtonClick()
    local szName = this:GetName()
	local frame = this:GetRoot()
	local menu = {}
	if szName == "Btn_Players" then
		local textName = frame:Lookup("Edit_tName")
		local xA, yA = textName:GetAbsPos()
		local w, h = textName:GetSize()
		local hTeam = GetClientTeam()
		local nGroupNum = hTeam.nGroupNum
		local PlayerNum = 1
		for nGroupID = 0, nGroupNum - 1 do
			local tGroupInfo = hTeam.GetGroupInfo(nGroupID)
			if #tGroupInfo.MemberList > 0 then
				for i, dwID in ipairs(tGroupInfo.MemberList) do
					local tMemberInfo = hTeam.GetMemberInfo(dwID)
					menu[PlayerNum] = {
						szOption = tMemberInfo.szName,
						fnAction = function()
							frame:Lookup("Edit_tName"):SetText(tMemberInfo.szName)
						end,
					}
					PlayerNum=PlayerNum+1
				end
			end
		end
		PopupMenu(menu)
	end
end
