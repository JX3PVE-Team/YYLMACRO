
DotMonitor = DotMonitor or {}

local tConfig = {
	szName = "YYL_DotMonitor",
	szTitle = "DOT���",
	szAuthor = "������",
	szVersion = "1.0.0",
	szKey = "test",
	dwIcon = 3406,
	szClass = "Combat",
	tWidget = {
		{
			name = "YYL_DotMonitor_bOn", type = "CheckBox", w = 100, x = 0, y = 0, text = "�������",
			default = function()
				return DotMonitor.GetFrame
			end,
			callback = function(enabled)
				if enabled then
					Wnd.OpenWindow("Interface/A_Dot_Monitor/UI/YYL_DotMonitor.ini", "YYL_DotMonitor")
				else
					Wnd.CloseWindow("YYL_DotMonitor")
				end
			end
		}
	},
}
RegisterEvent("LOADING_END", function()
BK:RegisterPanel(tConfig)
end)
