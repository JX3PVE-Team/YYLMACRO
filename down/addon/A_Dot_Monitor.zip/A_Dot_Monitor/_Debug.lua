--------------------------------------------------------------------------------------------
-- debugs	���йء� debug_szErroText ���Ķ��ᱻ��¼������
--------------------------------------------------------------------------------------------
--
local debug_szErroText="A_Dot_Monitor"
local debug_szFile="\\Interface\\A_Dot_Monitor\\_erros.lua"
local debug_tErroes=LoadLUAData(debug_szFile) or {}
RegisterEvent("CALL_LUA_ERROR", function()
	if not string.find(arg0,debug_szErroText) then return end
	for _,i in pairs(debug_tErroes) do if arg0==i then return end end
	debug_tErroes[GetLocalTimeText().."_"..Random(GetLogicFrameCount())]=arg0
	SaveLUAData(debug_szFile,debug_tErroes)
end)



