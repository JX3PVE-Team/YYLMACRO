local tFunc=YYLtFunc
local tTrans=YYLtTrans
local _c=tFunc.TableVaToIn
----------------------------
-- �û�����
----------------------------
YYL_DotMonitor={}

YYL_DotMonitor.bFrameOn=true
RegisterCustomData("YYL_DotMonitor.bFrameOn")

YYL_DotMonitor.tPos={400,300}
RegisterCustomData("YYL_DotMonitor.tPos")


YYL_DotMonitor.tDots={
	[10003]=_c({"��ɨ����","��ӽ�ɳ","���̽Կ�"}),--�׽��buff����ID�����߼������ƣ�


}

RegisterCustomData("YYL_DotMonitor.tDots")




----------------------------
-- �������
----------------------------
local DotMonitor={}
setmetatable(YYL_DotMonitor,{__metatable=true,__index=DotMonitor,__newindex=function()end})

DotMonitor.OnFrameDragEnd=function()
	this:CorrectPos()
	YYL_DotMonitor.tPos={this:GetAbsPos()}
end

DotMonitor.GetFrame=function()
	return Station.Lookup("Normal/YYL_DotMonitor")
end

DotMonitor.OnFrameCreate=function()
	this:RegisterEvent("UI_SCALED")
	this:RegisterEvent("ON_ENTER_CUSTOM_UI_MODE")
	this:RegisterEvent("ON_LEAVE_CUSTOM_UI_MODE")
----
	this:RegisterEvent("SKILL_MOUNT_KUNG_FU")
----
	DotMonitor.OnEvent("UI_SCALED")
	DotMonitor.ReInitAllBox()
end

DotMonitor.OnEvent=function(event)
	if event=="UI_SCALED" then
		this:SetAbsPos(unpack(YYL_DotMonitor.tPos))
		this:CorrectPos()

	elseif event=="ON_ENTER_CUSTOM_UI_MODE" or event=="ON_LEAVE_CUSTOM_UI_MODE" then
		UpdateCustomModeWindow(this,"YYLDot���")

	elseif event=="SKILL_MOUNT_KUNG_FU" then
		DotMonitor.ReInitAllBox()

	end
end


DotMonitor.ReInitAllBox=function()--��������box
	local handle=DotMonitor.GetFrame():Lookup("","")
	handle:Clear()
----
	local tList=YYL_DotMonitor.tDots[tTrans.nKongFu]
	if not tList then return end
----
	for buff,nIcon in pairs(tList)do
		local hI=handle:AppendItemFromIni("Interface/A_Dot_Monitor/UI/A_Handle_Box.ini", "Handle_Box")
		hI:SetRelPos(hI:GetIndex()*53,0)
		hI.buff=buff

		local box=hI:Lookup("Box")
		box:SetObject(UI_OBJECT_NOT_NEED_KNOWN,0)

	end
----
	handle:FormatAllItemPos()
	DotMonitor.OnFrameBreathe()
end

DotMonitor.OnFrameBreathe=function()--����������ʱ�䡢����
	local tList=YYL_DotMonitor.tDots[tTrans.nKongFu]
	if not tList or tFunc.TableIsEmpty(tList) then return end
----
	local tTemp={}
	for i,v in pairs(tTrans.taTar and tTrans.GetBuffListFromID(tTrans.nTarID) or {}) do
		if v.dwSkillSrcID==tTrans.PLAYERID then
			local n=v.nEndFrame-GetLogicFrameCount()
			if n>0 then
				local index
				if tList[v.dwID] then
					index=v.dwID
				else
					local szName=Table_GetBuffName(v.dwID,v.nLevel)
					if tList[szName] then
						index=szName
					end
				end
				----
				if index then
					local nIcon=Table_GetBuffIconID(v.dwID,v.nLevel)
					tList[index]=nIcon>=0 and nIcon or 13--����Icon

					tTemp[index]={
						n,--ʣ��ʱ��/��λ֡
						GetBuffTime(v.dwID,v.nLevel) or 1,--��ʱ��/��λ֡
						Table_GetBuffIconID(v.dwID,v.nLevel) or 13,--ͼ��ID
						v.nStackNum,--����
						}
				end
			end
		end
	end
----
	local handle=DotMonitor.GetFrame():Lookup("","")
	for i=0,handle:GetItemCount()-1 do
		local hI=handle:Lookup(i)
		local buff=hI.buff
		
		local imageTimeBarBG = hI:Lookup("Image_TimeBarBG")
		local imageTimeBar = hI:Lookup("Image_TimeBar")
		local box = hI:Lookup("Box")
		box:SetObjectIcon(tList[buff])
		
		local t=tTemp[buff]
		if t then
			imageTimeBarBG:Show()
			----
			imageTimeBar:Show()
			local per=t[1]/t[2]
			imageTimeBar:SetFrame((per>0.75 and 25) or (per>0.35 and 26) or 21)--�̡��ơ���
			imageTimeBar:SetPercentage(per)
			----
			box:EnableObject(1)
			
			box:SetOverTextPosition(0, ITEM_POSITION.RIGHT_BOTTOM)
			box:SetOverTextFontScheme(0, 15)
			box:SetOverText(0, t[4]==1 and "" or t[4])
			
			box:SetOverTextPosition(1, ITEM_POSITION.LEFT_TOP)
			box:SetOverTextFontScheme(1, 15)
			local nSec=t[1]/GLOBAL.GAME_FPS
			box:SetOverText( 1 ,(nSec>=10 and math.floor(nSec) or string.format("%.1f",nSec)).."'" )
			
		else
			imageTimeBarBG:Hide()
			----
			imageTimeBar:Hide()
			----
			box:EnableObject(0)
			
			box:SetOverText(0,"")
			
			box:SetOverText(1,"")
		end
	end
end








DotMonitor.GetTraceMenu=function()
	local nKf=tTrans.nKongFu
	YYL_DotMonitor.tDots[nKf]=YYL_DotMonitor.tDots[nKf] or {}
	local tList=YYL_DotMonitor.tDots[tTrans.nKongFu]
----
	local tMenu={
		szOption="[YYL]Dot�����",
		[1]={
			szOption="�������",
			bCheck=true,
			bChecked=DotMonitor.GetFrame,
			fnAction=function()
				Wnd.ToggleWindow("Interface/A_Dot_Monitor/UI/YYL_DotMonitor.ini", "YYL_DotMonitor")
			end,
			},
		[2]={szOption="��������Ŀ",
			fnMouseEnter=tFunc.GetMenuTipFunc("���ӵ�ǰ�ķ���Ҫ��ص�Dot\n�������ƻ���ID"),
			fnAction=function()
				GetUserInput("����Dot�����ƻ���ID��",function(sz)
					if sz=="" then return end
					sz=tonumber(sz) or sz
					local nIcon= type(sz)=="number" and Table_GetBuffIconID(sz,1) or 13
					if nIcon<0 then nIcon=13 end
					tList[sz]=nIcon
					DotMonitor.ReInitAllBox()
				end)
			end,
		
		},
		[3]={bDevide = true},
	}
----
	local fnMouseEnter=tFunc.GetMenuTipFunc("���ɾ������Ŀ")
	for buff,n in pairs(tList)do
		table.insert(tMenu,{
			szOption = type(buff)=="string" and buff or Table_GetBuffName(buff,1).."("..buff..")" ,
			fnMouseEnter=fnMouseEnter,
			fnAction=function()
				tList[buff]=nil
				DotMonitor.ReInitAllBox()
			end,
		})
	end
----
	return tMenu
end



TraceButton_AppendAddonMenu({function()return{DotMonitor.GetTraceMenu()}end})









tFunc.AddStatrFunc(function()
	_c=nil
	if YYL_DotMonitor.bFrameOn then
		Wnd.OpenWindow("Interface/A_Dot_Monitor/UI/YYL_DotMonitor.ini", "YYL_DotMonitor")
	end
----
	for _,t in pairs(YYL_DotMonitor.tDots)do--�ͼ��հ�
		for i,v in pairs(t)do
			if type(v)~="number" then
				t[i]=13
			end
		end
	end
	
	tFunc.print("YYL_Dot��ʱ�����سɹ� ! Enjoy !")
end)



