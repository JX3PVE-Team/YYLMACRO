RaidGrid = RaidGrid or {}
RaidGrid.nSteper = -1
RaidGrid.frameSelf = nil
RaidGrid.handleMain = nil
RaidGrid.handleBG = nil
RaidGrid.handleRoleDummy = nil
RaidGrid.handleRoles = nil
RaidGrid.imageBG = nil
RaidGrid.imageTitle = nil

RaidGrid.nColLength = 66
RaidGrid.nRowLength = 40
RaidGrid.nMarginTop = 4
RaidGrid.nMarginLeft = 14

RaidGrid.handleLastSelect = nil
RaidGrid.bDrag = false
RaidGrid.TeamGroupInfo = {}

RaidGrid.szTitleText = "�Ŷӿ��"
RaidGrid.tLastLoc = {nX = 0, nY = 0}					RegisterCustomData("RaidGrid.tLastLoc")

local szIniFile = "Interface/RaidGrid/RaidGrid.ini"

function RaidGrid.OnCustomDataLoaded()
	if arg0 ~= "Role" then
		return
	end
	RaidGrid.frameSelf = Wnd.OpenWindow("Interface\\RaidGrid\\RaidGrid.ini", "RaidGrid")

	RaidGrid.EnableRaidPanel(RaidGrid.bShowSystemRaidPanel)
	if RaidGrid.tLastLoc.nX == 0 and RaidGrid.tLastLoc.nY == 0 then
		RaidGrid.SetPanelPos()
	elseif RaidGrid.frameSelf then
		RaidGrid.SetPanelPos(RaidGrid.tLastLoc.nX, RaidGrid.tLastLoc.nY)
	end
end

-----------------------------------------------------------------------------------------------
--	ϵͳ�����¼�
-----------------------------------------------------------------------------------------------
function RaidGrid.OnFrameCreate()
	this:RegisterEvent("PARTY_SYNC_MEMBER_DATA")
	this:RegisterEvent("PARTY_ADD_MEMBER")
	this:RegisterEvent("PARTY_DISBAND")
	this:RegisterEvent("PARTY_DELETE_MEMBER")
	this:RegisterEvent("PARTY_UPDATE_MEMBER_INFO")
	this:RegisterEvent("PARTY_UPDATE_MEMBER_LMR")
	this:RegisterEvent("PARTY_SET_MEMBER_ONLINE_FLAG")
	this:RegisterEvent("PLAYER_STATE_UPDATE")
	this:RegisterEvent("PARTY_SET_MARK")
	this:RegisterEvent("BUFF_UPDATE")
	this:RegisterEvent("UPDATE_PLAYER_SCHOOL_ID")
	this:RegisterEvent("RIAD_READY_CONFIRM_RECEIVE_ANSWER")
	this:RegisterEvent("UI_SCALED")
	this:RegisterEvent("TEAM_AUTHORITY_CHANGED")
	this:RegisterEvent("PARTY_SET_FORMATION_LEADER")
	this:RegisterEvent("TEAM_CHANGE_MEMBER_GROUP")
	local frame = Station.Lookup("Normal/RaidGrid")
	RaidGrid.frameSelf = frame
end

function RaidGrid.OnEvent(szEvent)
	local player = GetClientPlayer()
	if not player then return end
	local frame = Station.Lookup("Normal/RaidGrid")
	if szEvent == "PARTY_SYNC_MEMBER_DATA" then
		RaidGrid.OnMemberJoinTeam(arg1, arg2)
		RaidGrid.ShowRoleHandle(nil, nil, RaidGrid.GetRoleHandleByID(arg1))
		RaidGrid.RedrawMemberHandleHPnMP(arg1)
		RaidGrid.RedrawMemberHandleState(arg1)
		RaidGrid.UpdateMemberSpecialState(arg1)
		--RaidGrid.AutoScalePanel()
	elseif szEvent == "PARTY_ADD_MEMBER" then
		RaidGrid.OnMemberJoinTeam(arg1, arg2)
		RaidGrid.ShowRoleHandle(nil, nil, RaidGrid.GetRoleHandleByID(arg1))
		RaidGrid.RedrawMemberHandleHPnMP(arg1)
		RaidGrid.RedrawMemberHandleState(arg1)
		RaidGrid.UpdateMemberSpecialState(arg1)
		--RaidGrid.AutoScalePanel()
		RaidGrid.ReloadEntireTeamInfo(true)
		if RaidGrid.bControlPartyInRaid then
			if RaidGrid.IsInRaid() then
				if RaidGrid.bShowPartyPanel then
					if not IsTeammateOpened() then
						OpenTeammate()
					end
				else
					if IsTeammateOpened() then
						CloseTeammate()
					end
				end
			end
		else
			if RaidGrid.bShowPartyPanel then
				if not IsTeammateOpened() then
					OpenTeammate()
				end
			else
				if IsTeammateOpened() then
					CloseTeammate()
				end
			end
		end
		if not RaidGrid.IsInRaid() then
			if RaidGrid.bShowInRaid then
				RaidGrid.ClosePanel()
			else
				RaidGrid.OpenPanel()
			end
		end
	elseif szEvent == "PARTY_DELETE_MEMBER" then
		if GetClientPlayer().dwID == arg1 then
			if RaidGrid.bShowInRaid then
				RaidGrid.ClosePanel()
			else
				RaidGrid.OnMemberChangeGroup()
			end
		else
			RaidGrid.OnMemberChangeGroup()
		end
	elseif szEvent == "PARTY_DISBAND" then
		if RaidGrid.bShowInRaid then
			RaidGrid.ClosePanel()
		else
			RaidGrid.OnMemberChangeGroup()
		end
	elseif szEvent == "PARTY_UPDATE_MEMBER_INFO" then
		RaidGrid.RedrawMemberHandleState(arg1)
		RaidGrid.UpdateMemberSpecialState(arg1)
	elseif szEvent == "UPDATE_PLAYER_SCHOOL_ID" then
		if player.IsPlayerInMyParty(arg0) then
			RaidGrid.RedrawMemberHandleState(arg1)
			RaidGrid.UpdateMemberSpecialState(arg0)
		end
	elseif szEvent == "PARTY_UPDATE_MEMBER_LMR" then
		RaidGrid.RedrawMemberHandleHPnMP(arg1)
	elseif szEvent == "PLAYER_STATE_UPDATE" then
		if player.IsPlayerInMyParty(arg0) then
			RaidGrid.RedrawMemberHandleState(arg0)
		end
	elseif szEvent == "PARTY_SET_MEMBER_ONLINE_FLAG" then
		RaidGrid.RedrawMemberHandleHPnMP(arg1)
		RaidGrid.RedrawMemberHandleState(arg1)
		RaidGrid.UpdateMemberSpecialState(arg1)
		RaidGrid.ReloadEntireTeamInfo(true)
	elseif szEvent == "PARTY_SET_MARK" then
		RaidGrid.ReloadEntireTeamInfo(true)
	elseif szEvent == "BUFF_UPDATE" then
		if player.IsPlayerInMyParty(arg0) then
			RaidGrid.OnUpdateBuffData(arg0, arg1, arg3, arg4, arg8)
		end
	elseif szEvent == "TEAM_AUTHORITY_CHANGED" then
		RaidGrid.RedrawMemberHandleState(arg2)
		RaidGrid.RedrawMemberHandleState(arg3)
	elseif szEvent == "PARTY_SET_FORMATION_LEADER" then
		RaidGrid.OnMemberChangeGroup()
	elseif szEvent == "RIAD_READY_CONFIRM_RECEIVE_ANSWER" then
		RaidGrid.ChangeReadyConfirm(arg0, arg1)
	elseif szEvent == "UI_SCALED" then
		if RaidGrid.tLastLoc.nX == 0 and RaidGrid.tLastLoc.nY == 0 then
			RaidGrid.SetPanelPos()
		else
			RaidGrid.SetPanelPos(RaidGrid.tLastLoc.nX, RaidGrid.tLastLoc.nY)
		end
	elseif szEvent == "TEAM_CHANGE_MEMBER_GROUP" then
		if not RaidGrid.IsOpened() and RaidGrid.bShowInRaid then
			frame:Show()
		end
	end
end

function RaidGrid.OnFrameBreathe()
	RaidGrid.nSteper = RaidGrid.nSteper + 1
	-- Ŀ����ʾ
	local player = GetClientPlayer()
	if player then
		if RaidGrid.handleLastSelect then
			local ani = RaidGrid.handleLastSelect:Lookup("Animate_SelectRole")
			if ani then
				ani:Hide()
				RaidGrid.handleLastSelect = nil
			end
		end

		local _, dwTargetID = player.GetTarget()
		if dwTargetID and dwTargetID > 0 then
			local target = nil
			if IsPlayer(dwTargetID) and player.IsPlayerInMyParty(dwTargetID) then
				target = GetPlayer(dwTargetID)
			else
				if IsPlayer(dwTargetID) then
					target = GetPlayer(dwTargetID)
				else
					target = GetNpc(dwTargetID)
				end
				if target then
					local _, dwTargetTargetID = target.GetTarget()
					if IsPlayer(dwTargetTargetID) and player.IsPlayerInMyParty(dwTargetTargetID) then
						target = GetPlayer(dwTargetTargetID)
					else
						target = nil
					end
				end
			end
			if target then
				RaidGrid.handleLastSelect = RaidGrid.GetRoleHandleByID(target.dwID)
				if RaidGrid.handleLastSelect then
					RaidGrid.handleLastSelect:Lookup("Animate_SelectRole"):Show()
				end
			end
		end
	end

	-- �ر���߮ģʽ
	if RaidGrid.bDrag and not IsKeyDown("LButton") then
		RaidGrid.bDrag = false
		RaidGrid.handleBG:Lookup("Image_DragBox"):Hide()
		RaidGrid.handleBG:Lookup("Image_DragBox_Disable"):Hide()
		nDragGroupID = nil
		dwDragMemberID = nil
		CloseRaidDragPanel()
	end

	-- ���¾�����ʾ
	if RaidGrid.nSteper % 12 == 0 then
		for dwMemberID, _ in pairs(RaidGrid.tRoleIDList) do
			RaidGrid.UpdateMemberSpecialState(dwMemberID)
		end
	end

	RaidGrid.tLastLoc.nX, RaidGrid.tLastLoc.nY = RaidGrid.frameSelf:GetRelPos()
end

-----------------------------------------------------------------------------------------------
--	�����Ӧ
-----------------------------------------------------------------------------------------------
-- ---------------------------------------------------------------
-- ����ֶ�, �϶���Ա���
-- ---------------------------------------------------------------
local nDragGroupID = nil			-- �϶���ԴС�����
local dwDragMemberID = nil			-- �϶��Ľ�ɫID
function RaidGrid.OnItemLButtonDrag()
	local szName = this:GetName()
	if not RaidGrid.IsLeader(GetClientPlayer().dwID) or not szName:match("Handle_Role_") then
		return
	end
	if not RaidGrid.bLockGroup or IsShiftKeyDown() then
		RaidGrid.bDrag = true

		nDragGroupID = this.nGroupIndex
		dwDragMemberID = RaidGrid.tGroupList[this.nGroupIndex][this.nSortIndex]
		OpenRaidDragPanel(dwDragMemberID)
	else
		RaidGrid.Message("����С�ӷ���������������Ҫ ���� �� ��סShift ���ܽ��з��飡")
	end
end

function RaidGrid.OnItemLButtonDragEnd()
	local szName = this:GetName()
	local team = GetClientTeam()
	if not RaidGrid.IsLeader(GetClientPlayer().dwID) or not szName:match("Handle_Role_") or not team then
		return
	end

	RaidGrid.bDrag = false
	local nTargetGroup = this.nGroupIndex
	local dwTargetMemberID = RaidGrid.tGroupList[this.nGroupIndex][this.nSortIndex] or 0

	if nTargetGroup and nTargetGroup >= 0 and nTargetGroup < 5 then
		if nDragGroupID and dwDragMemberID and dwTargetMemberID and (nTargetGroup ~= nDragGroupID) then
			team.ChangeMemberGroup(dwDragMemberID, nTargetGroup, dwTargetMemberID)
		end
	end

	RaidGrid.handleBG:Lookup("Image_DragBox"):Hide()
	RaidGrid.handleBG:Lookup("Image_DragBox_Disable"):Hide()

	nDragGroupID = nil
	dwDragMemberID = nil
	CloseRaidDragPanel()
end


function RaidGrid.OnLButtonClick()
	local szName = this:GetName()
	if szName == "Btn_Setting" then
		RaidGrid.PopOptions()
	end
end

function RaidGrid.OnItemLButtonClick()
	local szName = this:GetName()
	--Output(szName)
	if szName:match("Handle_Role_") and this:GetAlpha() == 255 then
		--Output("LeftClick")
		local dwMemberID = RaidGrid.tGroupList[this.nGroupIndex][this.nSortIndex]
		if dwMemberID and dwMemberID > 0 and IsPlayer(dwMemberID) then --
			local player = GetPlayer(dwMemberID)
			local tMemberInfo = RaidGrid.GetTeamMemberInfo(dwMemberID)
			if tMemberInfo then
				if RaidGrid.handleLastSelect then
					RaidGrid.handleLastSelect:Lookup("Animate_SelectRole"):Hide()
					RaidGrid.handleLastSelect = nil
				end
				if IsCtrlKeyDown() then
					if IsGMPanelReceivePlayer() then
						GMPanel_LinkPlayerID(tMemberInfo.dwID)
					else
						EditBox_AppendLinkPlayer(tMemberInfo.szName)
					end
				else
					if player then
						RaidGrid.SetTarget(dwMemberID)
					end
				end
			end
		end
	end
end

function RaidGrid.OnItemRButtonClick()
	local szName = this:GetName()
	--Output(szName)
	local team = GetClientTeam()
	if not team then
		return
	end
	if szName:match("Handle_Role_") and this:GetAlpha() == 255 then
		--Output("RightClick")
		local tMenu = {}
		local player = GetClientPlayer()
		local dwMemberID = RaidGrid.tGroupList[this.nGroupIndex][this.nSortIndex]

		if RaidGrid.IsLeader(player.dwID) then
			RaidPanel.InsertChangeGroupMenu(tMenu, dwMemberID)
		end

		if dwMemberID ~= player.dwID then
			InsertTeammateMenu(tMenu, dwMemberID)
		else
			InsertPlayerMenu(tMenu)
		end

		if tMenu and #tMenu > 0 then
			PopupMenu(tMenu)
		end
	end
end

function RaidGrid.OnItemMouseEnter()
	local szName = this:GetName()
	if szName:match("Handle_Role_") then
		RaidGrid.EnterRoleHandle(nil, nil, this)
		if RaidGrid.bDrag then
			local nGroupIndex = this.nGroupIndex
			local imageDragBox = nil
			if nGroupIndex == nDragGroupID then
				imageDragBox = RaidGrid.handleBG:Lookup("Image_DragBox_Disable")
				RaidGrid.handleBG:Lookup("Image_DragBox"):Hide()
			else
				imageDragBox = RaidGrid.handleBG:Lookup("Image_DragBox")
				RaidGrid.handleBG:Lookup("Image_DragBox_Disable"):Hide()
			end
			if imageDragBox then
				imageDragBox:Show()
				imageDragBox:SetRelPos(nGroupIndex * RaidGrid.nColLength + 5, 32)
				RaidGrid.handleBG:FormatAllItemPos()
			end
		end
	end
end

function RaidGrid.OnItemMouseLeave()
	local szName = this:GetName()
	if szName:match("Handle_Role_") then
		RaidGrid.LeaveRoleHandle(nil, nil, this)
	end
end

function RaidGrid.OnCheckBoxCheck()
	local szName = this:GetName()
	if szName == "CheckBox_Minimize" then
		RaidGrid.bShowHandle = false
		RaidGrid.imageBG:SetSize(350, 32)
		RaidGrid.handleBG:Hide()
		RaidGrid.handleRoles:Hide()
	end
end

function RaidGrid.OnCheckBoxUncheck()
	local szName = this:GetName()
	if szName == "CheckBox_Minimize" then
		RaidGrid.bShowHandle = true
		RaidGrid.ReloadEntireTeamInfo(true)
		RaidGrid.imageBG:SetSize(350, 246)
		RaidGrid.handleBG:Show()
		RaidGrid.handleRoles:Show()
	end
end



function RaidGrid.SetTarget(dwTargetID)
	--local nType = TARGET.NPC
	--if IsPlayer(dwTargetID) then
	--	nType = TARGET.PLAYER

	--end
	--SelectTarget(nType, dwTargetID)
	if IsPlayer(dwTargetID) then
		if dwTargetID == GetClientPlayer().dwID then
			SelectPlayer()
		else
			SelectTarget(TARGET.PLAYER, dwTargetID)
		end
	end
end

function RaidGrid.ClosePanel()
	local frame = Station.Lookup("Normal/RaidGrid")
	if frame then
		frame:Hide()
	end
end

function RaidGrid.IsOpened()
	local frame = Station.Lookup("Normal/RaidGrid")
	if frame then
		return frame:IsVisible()
	end
end

function RaidGrid.IsInRaid()
	local team = GetClientTeam()
	if not team or team.nGroupNum <=1 then
		return false
	end
	return true
end


function RaidGrid.OpenPanel(bForceShow)
	local player = GetClientPlayer()
	if not player then
		return
	end

	local frame = Station.Lookup("Normal/RaidGrid")
	if not frame then
		frame = Wnd.OpenWindow("Interface\\RaidGrid\\RaidGrid.ini", "RaidGrid")
	end

	RaidGrid.frameSelf = frame

	RaidGrid.handleMain = frame:Lookup("", "")
	RaidGrid.handleBG = frame:Lookup("", "Handle_BG")
	RaidGrid.imageBG = frame:Lookup("", "Image_BG")
	RaidGrid.imageTitle = frame:Lookup("", "Image_Title")
	RaidGrid.handleRoleDummy = frame:Lookup("", "Handle_RoleDummy")
	RaidGrid.handleRoles = frame:Lookup("", "Handle_Roles")

	--RaidGrid.frameSelf:Lookup("", "Text_Title")
	RaidGrid.frameSelf:Lookup("", "Text_Title"):SetText(RaidGrid.szTitleText)
	--RaidGrid.frameSelf:Lookup("", "Handle_Dummy"):Hide()
	RaidGrid.CreateAllRoleHandle()
	RaidGrid.ReloadEntireTeamInfo(true)
	RaidGrid.SetPanelPos(RaidGrid.tLastLoc.nX, RaidGrid.tLastLoc.nY)

	RaidGrid.handleMain:FormatAllItemPos()
	frame:Show()

	if not RaidGrid.IsInRaid() then
		if RaidGrid.bShowInRaid and not bForceShow then
			RaidGrid.ClosePanel()
		end
	end
	if RaidGrid.bControlPartyInRaid then
		if RaidGrid.IsInRaid() then
			if RaidGrid.bShowPartyPanel then
				if not IsTeammateOpened() then
					OpenTeammate()
				end
			else
				if IsTeammateOpened() then
					CloseTeammate()
				end
			end
		end
	else
		if RaidGrid.bShowPartyPanel then
			if not IsTeammateOpened() then
				OpenTeammate()
			end
		else
			if IsTeammateOpened() then
				CloseTeammate()
			end
		end
	end
end

function RaidGrid.NoticeChangeLootMode()
	local player = GetClientPlayer()
	local hTeam = GetClientTeam()
	local dwLooterID = hTeam.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.DISTRIBUTE)

	if player.IsInParty() then
		if player.dwID == dwLooterID then
			local msg=
			{
				szMessage = "�Ƿ�Ҫת������ģʽΪ�������߷��䡿��",
				szName = "LootModeChangeTip",
				{szOption = g_tStrings.STR_HOTKEY_SURE, fnAction = function() hTeam.SetTeamLootMode(PARTY_LOOT_MODE.DISTRIBUTE) end},
				{szOption = g_tStrings.STR_HOTKEY_CANCEL}
			}
			MessageBox(msg)
		else
			RaidGrid.Message("��û�з���Ȩ���޷��Զ����ķ���ģʽ�������ѵ�ǰ������ע����ķ���ģʽ��")
		end
	end
end

RegisterEvent("CUSTOM_DATA_LOADED", RaidGrid.OnCustomDataLoaded )
RegisterEvent("SYNC_ROLE_DATA_END", function() RaidGrid.OpenPanel() RaidGrid.EnableRaidPanel(RaidGrid.bShowSystemRaidPanel) end)
RegisterEvent("PARTY_UPDATE_BASE_INFO", function() RaidGrid.OpenPanel() RaidGrid.EnableRaidPanel(RaidGrid.bShowSystemRaidPanel) end)
RegisterEvent("PARTY_LEVEL_UP_RAID", function() RaidGrid.OpenPanel() RaidGrid.EnableRaidPanel(RaidGrid.bShowSystemRaidPanel) RaidGrid.NoticeChangeLootMode() end)
RegisterEvent("TEAM_CHANGE_MEMBER_GROUP", function() RaidGrid.OnMemberChangeGroup(arg0, arg1, arg3, arg2) end)
Hotkey.AddBinding("RaidGrid_Toggle", "��/�ر�", "�Ŷӿ��",
	function()
		if RaidGrid.IsOpened() then
			RaidGrid.ClosePanel()
		else
			RaidGrid.OpenPanel(true)
		end
	end,
nil)



