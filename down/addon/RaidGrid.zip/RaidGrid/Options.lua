RaidGrid = RaidGrid or {}

-- ����Ĭ����幦��
RaidGrid.RaidPanel_OpenRaidFrame_Org = RaidPanel.OpenRaidFrame
RaidPanel.OpenRaidFrame = function(nGroupID)
	RaidGrid.RaidPanel_OpenRaidFrame_Org(nGroupID)
	if not RaidGrid.bShowSystemRaidPanel and RaidGrid.IsOpened() then
		local frame = Station.Lookup("Normal/RaidPanel_" .. nGroupID)
		frame:Hide()
	end
end

RaidGrid.bLockPanel = false							RegisterCustomData("RaidGrid.bLockPanel")
RaidGrid.bShowSystemRaidPanel = false				RegisterCustomData("RaidGrid.bShowSystemRaidPanel")
RaidGrid.bControlPartyInRaid = true					RegisterCustomData("RaidGrid.bControlPartyInRaid")
RaidGrid.bShowInRaid = false						RegisterCustomData("RaidGrid.bShowInRaid")
RaidGrid.bAutoAlpha = true
RaidGrid.bShowAlert = true							RegisterCustomData("RaidGrid.bShowAlert")
RaidGrid.bLockGroup = false							--RegisterCustomData("RaidGrid.bLockGroup")
RaidGrid.bShowPartyPanel = false					RegisterCustomData("RaidGrid.bShowPartyPanel")
RaidGrid.szFontScheme = 3
RaidGrid.nAutoDistColor = 24						RegisterCustomData("RaidGrid.nAutoDistColor")
RaidGrid.nManaAlertPer = 0.3						RegisterCustomData("RaidGrid.nManaAlertPer")
RaidGrid.bManaAlert = true							RegisterCustomData("RaidGrid.bManaAlert")
RaidGrid.bBuffAlert = true							RegisterCustomData("RaidGrid.bBuffAlert")
RaidGrid.bDebuffAlert = true						RegisterCustomData("RaidGrid.bDebuffAlert")
RaidGrid.fScale = 1

-- ����ʵ�ʵĲ˵�
function RaidGrid.PopOptions()
	local menu = {}
	local m_lock = {
		szOption = "�����Ŷӽ���",
		bCheck = true,
		bChecked = RaidGrid.bLockPanel,
		fnAction = function()
			RaidGrid.bLockPanel = not RaidGrid.bLockPanel
			if RaidGrid.bLockPanel then
				RaidGrid.frameSelf:EnableDrag(false)
			else
				RaidGrid.frameSelf:EnableDrag(true)
			end
		end,
	}
	table.insert(menu, m_lock)
	local m_reload = {
		szOption = "�����Ŷӽ���",
		bCheck = true,
		bChecked = false,
		fnAction = function()
			GetPopupMenu():Hide()
			RaidGrid.OnMemberChangeGroup()
		end,
	}
	table.insert(menu, m_reload)
	table.insert(menu, {bDevide = true})
	local m_confirm = {
		szOption = "�ŶӾ�λȷ��",
		bCheck = true,
		bChecked = false,
		fnDisable = function()
			return not RaidGrid.IsLeader(GetClientPlayer().dwID) or not RaidGrid.IsInRaid()
		end,
		{
			szOption = "��ʼ��λȷ��", bCheck = false, bChecked = false, fnAction =
			function()
				local tMsg =
				{
					szMessage = g_tStrings.STR_RAID_MSG_START_READY_CONFIRM,
					szName = "StartReadyConfirm",
					{szOption = g_tStrings.STR_HOTKEY_SURE, fnAction = function() RaidPanel.StartReadyConfirm(); RaidGrid.ReadyCheck() end,},
					{szOption = g_tStrings.STR_HOTKEY_CANCEL, },
				}
				MessageBox(tMsg)
			end
		},
		{
			szOption = "����ȷ��״̬", bCheck = false, bChecked = false, fnAction =
			function(UserData, bCheck)
				GetPopupMenu():Hide(); RaidGrid.OnMemberChangeGroup()
			end,
		},
	}
	table.insert(menu, m_confirm)
	table.insert(menu, {bDevide = true})
	local m_spart = {
		szOption = "����ϵͳ�Ŷ����",
		bCheck = true,
		bChecked = RaidGrid.bShowSystemRaidPanel,
		fnAction = function()
			RaidGrid.bShowSystemRaidPanel = not RaidGrid.bShowSystemRaidPanel
			RaidGrid.EnableRaidPanel(RaidGrid.bShowSystemRaidPanel)
		end,
	}
	table.insert(menu, m_spart)
	local m_steam = {
		szOption = "����ϵͳС�����",
		bCheck = true,
		bChecked = RaidGrid.bShowPartyPanel ,
		fnAction = function()
			RaidGrid.bShowPartyPanel = not RaidGrid.bShowPartyPanel
			if RaidGrid.bControlPartyInRaid then
				if RaidGrid.IsInRaid() then
					if RaidGrid.bShowPartyPanel then
						if not IsTeammateOpened() then
							OpenTeammate()
						end
					else
						if IsTeammateOpened() then
							CloseTeammate()
						end
					end
				end
			else
				if RaidGrid.bShowPartyPanel then
					if not IsTeammateOpened() then
						OpenTeammate()
					end
				else
					if IsTeammateOpened() then
						CloseTeammate()
					end
				end
			end
		end,
		{
			szOption = "�����Ŷ��вſ���",
			bCheck = true,
			bChecked = RaidGrid.bControlPartyInRaid,
			fnAction = function()
				RaidGrid.bControlPartyInRaid = not RaidGrid.bControlPartyInRaid
			end
		},
	}
	table.insert(menu, m_steam)
	local m_inraid = {
		szOption = "ֻ���Ŷ�ʱ����ʾ",
		bCheck = true,
		bChecked = RaidGrid.bShowInRaid,
		fnAction = function()
			RaidGrid.bShowInRaid = not RaidGrid.bShowInRaid
			if not RaidGrid.IsInRaid() then
				if RaidGrid.bShowInRaid then
					RaidGrid.ClosePanel()
				else
					RaidGrid.OpenPanel()
				end
			end
		end,
	}
	table.insert(menu, m_inraid)
	local m_corner = {
		szOption = "״ָ̬ʾ��",
		bCheck = true,
		bChecked = RaidGrid.bShowAlert,
		fnAction = function()
			RaidGrid.bShowAlert = not RaidGrid.bShowAlert
		end,
		{
			szOption = "����",
			bCheck = true,
			bChecked = RaidGrid.bManaAlert,
			fnAction = function()
				RaidGrid.bManaAlert = not RaidGrid.bManaAlert
			end,
			fnDisable = function()
				return not RaidGrid.bShowAlert
			end,
			{
				szOption = "����"..(RaidGrid.nManaAlertPer * 100).."%", fnAction = function()
					GetUserInput("����ٷֱ�(0-1)��",  function(szText)  RaidGrid.nManaAlertPer = tonumber(szText) end, nil, nil, nil, nil, nil)
				end,
			},
		},
	}
	local m_buff = {
		szOption = "����",
		bCheck = true,
		bChecked = RaidGrid.bBuffAlert,
		fnAction = function()
			RaidGrid.bBuffAlert = not RaidGrid.bBuffAlert
		end,
		fnDisable = function()
			return not RaidGrid.bShowAlert
		end,
	}
	table.insert(m_corner, m_buff)
	local m_buff_corner_1 = {szOption = "�Ǳ�һ"}
	for k, v in pairs(RaidGrid.tMonitorTable["Buff"][1]) do
		local m_sbuff =
		{
			szOption = v,
			bCheck = true,
			bChecked = true,
			fnAction = function() RaidGrid.tMonitorTable["Buff"][1][k] = nil, RaidGrid.Message("["..v.."]��ɾ����") end,
		}
		table.insert(m_buff_corner_1, m_sbuff)
	end
	table.insert(m_buff_corner_1, {bDevide = true})
	table.insert(m_buff_corner_1, {szOption = "����", fnAction = function() GetUserInput("����BUFF���ƣ�",  function(szText)  RaidGrid.AddToList("Buff", 1, szText) end, nil, nil, nil, nil, nil) end,})
	table.insert(m_buff, m_buff_corner_1)

	local m_buff_corner_2 = {szOption = "�Ǳ��"}
	for k, v in pairs(RaidGrid.tMonitorTable["Buff"][2]) do
		local m_sbuff =
		{
			szOption = v,
			bCheck = true,
			bChecked = true,
			fnAction = function() RaidGrid.tMonitorTable["Buff"][2][k] = nil, RaidGrid.Message("["..v.."]��ɾ����") end,
		}
		table.insert(m_buff_corner_2, m_sbuff)
	end
	table.insert(m_buff_corner_2, {bDevide = true})
	table.insert(m_buff_corner_2, {szOption = "����", fnAction = function() GetUserInput("����BUFF���ƣ�",  function(szText)  RaidGrid.AddToList("Buff", 2, szText) end, nil, nil, nil, nil, nil) end,})
	table.insert(m_buff, m_buff_corner_2)

	local m_buff_corner_3 = {szOption = "�Ǳ���"}
	for k, v in pairs(RaidGrid.tMonitorTable["Buff"][3]) do
		local m_sbuff =
		{
			szOption = v,
			bCheck = true,
			bChecked = true,
			fnAction = function() RaidGrid.tMonitorTable["Buff"][3][k] = nil, RaidGrid.Message("["..v.."]��ɾ����") end,
		}
		table.insert(m_buff_corner_3, m_sbuff)
	end
	table.insert(m_buff_corner_3, {bDevide = true})
	table.insert(m_buff_corner_3, {szOption = "����", fnAction = function() GetUserInput("����BUFF���ƣ�",  function(szText)  RaidGrid.AddToList("Buff", 3, szText) end, nil, nil, nil, nil, nil) end,})
	table.insert(m_buff, m_buff_corner_3)

	local m_debuff = {
		szOption = "����",
		bCheck = true,
		bChecked = RaidGrid.bDebuffAlert,
		fnAction = function()
			RaidGrid.bbDebuffAlert = not RaidGrid.bDebuffAlert
		end,
		fnDisable = function()
			return not RaidGrid.bShowAlert
		end,
	}
	table.insert(m_corner, m_debuff)
	local m_debuff_corner_1 = {szOption = "�Ǳ�һ"}
	for k, v in pairs(RaidGrid.tMonitorTable["Debuff"][1]) do
		local m_sbuff =
		{
			szOption = v,
			bCheck = true,
			bChecked = true,
			fnAction = function() RaidGrid.tMonitorTable["Debuff"][1][k] = nil, RaidGrid.Message("["..v.."]��ɾ����") end,
		}
		table.insert(m_debuff_corner_1, m_sbuff)
	end
	table.insert(m_debuff_corner_1, {bDevide = true})
	table.insert(m_debuff_corner_1, {szOption = "����", fnAction = function() GetUserInput("����DEBUFF���ƣ�",  function(szText)  RaidGrid.AddToList("Debuff", 1, szText) end, nil, nil, nil, nil, nil) end,})
	table.insert(m_debuff, m_debuff_corner_1)

	local m_debuff_corner_2 = {szOption = "�Ǳ��"}
	for k, v in pairs(RaidGrid.tMonitorTable["Debuff"][2]) do
		local m_sbuff =
		{
			szOption = v,
			bCheck = true,
			bChecked = true,
			fnAction = function() RaidGrid.tMonitorTable["Debuff"][2][k] = nil, RaidGrid.Message("["..v.."]��ɾ����") end,
		}
		table.insert(m_debuff_corner_2, m_sbuff)
	end
	table.insert(m_debuff_corner_2, {bDevide = true})
	table.insert(m_debuff_corner_2, {szOption = "����", fnAction = function() GetUserInput("����DEBUFF���ƣ�",  function(szText)  RaidGrid.AddToList("Debuff", 2, szText) end, nil, nil, nil, nil, nil) end,})
	table.insert(m_debuff, m_debuff_corner_2)

	local m_debuff_corner_3 = {szOption = "�Ǳ���"}
	for k, v in pairs(RaidGrid.tMonitorTable["Debuff"][3]) do
		local m_sbuff =
		{
			szOption = v,
			bCheck = true,
			bChecked = true,
			fnAction = function() RaidGrid.tMonitorTable["Debuff"][3][k] = nil, RaidGrid.Message("["..v.."]��ɾ����") end,
		}
		table.insert(m_debuff_corner_3, m_sbuff)
	end
	table.insert(m_debuff_corner_3, {bDevide = true})
	table.insert(m_debuff_corner_3, {szOption = "����", fnAction = function() GetUserInput("����DEBUFF���ƣ�",  function(szText)  RaidGrid.AddToList("Debuff", 3, szText) end, nil, nil, nil, nil, nil) end,})
	table.insert(m_debuff, m_debuff_corner_3)
	table.insert(menu, m_corner)
	local m_distance = {
		szOption = "����",
		{
			szOption = RaidGrid.nAutoDistColor.."��",
			fnAction = function()
				GetUserInput("�����ɫ���룺",  function(szText)  RaidGrid.nAutoDistColor = tonumber(szText) end, nil, nil, nil, nil, nil)
			end,
		},
	}
	table.insert(m_corner, m_distance)

	if  RaidGrid.IsInRaid() then
		table.insert(menu, {bDevide = true})
		RaidPanel.InsertForceCountMenu(menu)
	end

	if menu and #menu > 0 then
		PopupMenu(menu)
	end
end

function RaidGrid.AddToList(szPos, nPos, szText)
	local szPos = tostring(szPos)
	local nPos = tonumber(nPos)
	local szText = tostring(szText)
	if next(RaidGrid.tMonitorTable[szPos][nPos]) == nil then
		table.insert(RaidGrid.tMonitorTable[szPos][nPos], szText)
		RaidGrid.Message("["..szText.."]�����ӣ�")
	else
		for k, v in pairs(RaidGrid.tMonitorTable[szPos][nPos]) do
			if szText ~= v then
				table.insert(RaidGrid.tMonitorTable[szPos][nPos], szText)
				RaidGrid.Message("["..szText.."]�����ӣ�")
				return
			end
		end
	end
end
