RaidGrid = RaidGrid or {}
RaidGrid.tGroupList = {}			-- ����ʵ��С�������򱣴浱ǰ�Ŷ�λ��
RaidGrid.tForceList = {}			-- �������ɷ��ౣ�������Ŷ�λ��
RaidGrid.tCustomList = {}			-- �Զ����Ŷ�λ��
RaidGrid.tRoleIDList = {}			-- ���Ŷ��еĽ�ɫID�ܱ�

RaidGrid.nMaxCol = 5
RaidGrid.nMaxRow = 5

RaidGrid.tMonitorTable = {
	["Buff"] = {
		--���Ͻ������Ǳ�BUFF�б���ͬ�Ǳ��ڼ��ܲ�����ͬʱ���ڳ���
		[1] = {},
		[2] = {},
		[3] = {},
	},
	["Debuff"] = {
		--���½������Ǳ�DEBUFF�б���ͬ�Ǳ��ڼ��ܲ�����ͬʱ���ڳ���
		[1] = {},
		[2] = {},
		[3] = {},
	}
}
RegisterCustomData("RaidGrid.tMonitorTable")

local szIniFile = "Interface/RaidGrid/RaidGrid.ini"

-- �������п��ܵĸ���, һ���ڳ�ʼ����ʱ�����
function RaidGrid.CreateAllRoleHandle()
	RaidGrid.handleRoles:Clear()
	for nCol = 0, RaidGrid.nMaxCol -1 do
		for nRow = 1, RaidGrid.nMaxRow  do
			local handleRole = RaidGrid.handleRoles:AppendItemFromIni(szIniFile, "Handle_RoleDummy", "Handle_Role_" .. nCol .. "_" .. nRow)
			handleRole:SetRelPos(nCol * RaidGrid.nColLength + RaidGrid.nMarginLeft, (nRow - 1) * RaidGrid.nRowLength + RaidGrid.nMarginTop)
			handleRole:Show()
			handleRole.nGroupIndex = nCol
			handleRole.nSortIndex = nRow
			handleRole.dwMemberID = nil
			RaidGrid.HideRoleHandle(nCol, nRow)
			--RaidGrid.ShowRoleHandle(nCol, nRow)
			--handleRole:Scale(RaidGrid.fScale, RaidGrid.fScale)
		end
	end
	RaidGrid.handleRoles:FormatAllItemPos()
end

-- ��ʾһ������
function RaidGrid.ShowRoleHandle(nCol, nRow, handleRole)
	local handleRole = handleRole or RaidGrid.handleRoles:Lookup("Handle_Role_" .. tostring(nCol) .. "_" .. tostring(nRow))
	if not handleRole then
		return
	end
	handleRole:Show()
	handleRole:SetAlpha(255)
	handleRole:Lookup("Text_Name"):SetText("")
	handleRole:Lookup("Image_LifeBG"):Show()
	handleRole:Lookup("Image_LifeBG"):SetAlpha(180)
	handleRole:Lookup("Image_Life"):Hide()

	handleRole:Lookup("Image_Life"):SetAlpha(255)
	handleRole:Lookup("Image_ManaAlert"):Hide()
	handleRole:Lookup("Image_ManaAlert"):SetAlpha(255)
	handleRole:Lookup("Image_Leader"):Hide()
	handleRole:Lookup("Image_Matrix"):Hide()
	handleRole:Lookup("Image_MarkImage"):Hide()
	handleRole:Lookup("Image_DeathFlag"):Hide()
end

-- ����һ������
function RaidGrid.HideRoleHandle(nCol, nRow, handleRole)
	local handleRole = handleRole or RaidGrid.handleRoles:Lookup("Handle_Role_" .. nCol .. "_" .. nRow)
	if not handleRole then
		return
	end
	handleRole:Show()
	handleRole:SetAlpha(32)
	handleRole:Lookup("Text_Name"):SetText("")
	handleRole:Lookup("Image_LifeBG"):Hide()
	handleRole:Lookup("Image_Life"):Hide()
	handleRole:Lookup("Image_ManaAlert"):Hide()
	handleRole:Lookup("Image_Leader"):Hide()
	handleRole:Lookup("Image_Matrix"):Hide()
	handleRole:Lookup("Image_MarkImage"):Hide()
	handleRole:Lookup("Image_DeathFlag"):Hide()
end

-- ����ƶ�������
function RaidGrid.EnterRoleHandle(nCol, nRow, handleRole)
	local handleRole = handleRole or RaidGrid.handleRoles:Lookup("Handle_Role_" .. nCol .. "_" .. nRow)
	if not handleRole then
		return
	end
	local nCol = nCol or handleRole.nGroupIndex
	local nRow = nRow or handleRole.nSortIndex
	if handleRole:GetAlpha() == 32 then
		handleRole:SetAlpha(128)
	elseif handleRole:GetAlpha() == 255 then
		handleRole:Lookup("Animate_SelectRole"):Show()
		local dwMemberID = RaidGrid.tGroupList[nCol]
		if dwMemberID then
			dwMemberID = RaidGrid.tGroupList[nCol][nRow]
		end
		if not dwMemberID then
			return
		end
		local tMemberInfo = RaidGrid.GetTeamMemberInfo(dwMemberID)
		if not tMemberInfo then
			return
		end
		local nX, nY = RaidGrid.frameSelf:GetAbsPos()
		local nW, nH = RaidGrid.frameSelf:GetSize()
		OutputTeamMemberTip(dwMemberID, {nX, nY, nW, nH})
	end
end

-- ����뿪����
function RaidGrid.LeaveRoleHandle(nCol, nRow, handleRole)
	local handleRole = handleRole or RaidGrid.handleRoles:Lookup("Handle_Role_" .. nCol .. "_" .. nRow)
	if not handleRole then
		return
	end
	local nCol = nCol or handleRole.nGroupIndex
	local nRow = nCol or handleRole.nSortIndex
	if handleRole:GetAlpha() == 128 then
		RaidGrid.HideRoleHandle(nCol, nRow, handleRole)
	elseif handleRole:GetAlpha() == 255 then
		if RaidGrid.handleLastSelect ~= handleRole then
			handleRole:Lookup("Animate_SelectRole"):Hide()
			RaidGrid.handleLastSelect = nil
		end
		HideTip()
	end
end

-- ͨ����ɫ ID ������ ID �Ľ�ɫ���Ŷ��е�λ��
function RaidGrid.GetHandlePosByID(dwMemberID)
	for nCol = 0, RaidGrid.nMaxCol -1 do
		for nRow = 1, RaidGrid.nMaxRow  do
			if RaidGrid.tGroupList and RaidGrid.tGroupList[nCol] and RaidGrid.tGroupList[nCol][nRow] == dwMemberID then
				return nCol, nRow
			end
		end
	end
end

-- ͨ����ɫ ID �������ж�Ӧ�ؼ�������
function RaidGrid.GetHandleNameByID(dwMemberID)
	local nCol, nRow = RaidGrid.GetHandlePosByID(dwMemberID)
	if nCol and nRow then
		return "Handle_Role_" .. nCol .. "_" .. nRow
	end
end

-- ͨ����ɫ ID �������ж�Ӧ�ؼ�
function RaidGrid.GetRoleHandleByID(dwMemberID)
	local szName = RaidGrid.GetHandleNameByID(dwMemberID)
	if szName then
		local handleRole = RaidGrid.handleRoles:Lookup(szName)
		return handleRole
	end
end

-- ���»����ض���ɫ��Ѫ��
function RaidGrid.RedrawMemberHandleHPnMP(dwMemberID)
	local handleRole = RaidGrid.GetRoleHandleByID(dwMemberID)
	local tMemberInfo = RaidGrid.GetTeamMemberInfo(dwMemberID)

	if not handleRole or not tMemberInfo then
		return
	end
	handleRole:Show()

	--Ѫ��
	handleRole:Lookup("Image_Life"):Hide()
	if tMemberInfo.bIsOnLine then
		local nLifePercentage = tMemberInfo.nCurrentLife / tMemberInfo.nMaxLife
		handleRole:Lookup("Image_Life"):Show()
		handleRole:Lookup("Image_Life"):SetPercentage(nLifePercentage)
		--������־
		if tMemberInfo.bDeathFlag then
			handleRole:Lookup("Image_DeathFlag"):Show()
		else
			if handleRole:Lookup("Image_DeathFlag"):IsVisible() then
				handleRole:Lookup("Image_DeathFlag"):Hide()
			end
		end
	else
		handleRole:Lookup("Image_Life"):SetFrame(0)
		handleRole:Lookup("Image_Life"):SetAlpha(100)
		handleRole:Lookup("Image_Life"):Show()
	end

	--����
	handleRole:Lookup("Image_ManaAlert"):Hide()
	if tMemberInfo.bIsOnLine then
		local nManaPercentage = tMemberInfo.nCurrentMana / tMemberInfo.nMaxMana
		if nManaPercentage <= RaidGrid.nManaAlertPer and not tMemberInfo.bDeathFlag then
			handleRole:Lookup("Image_ManaAlert"):Show()
			handleRole:Lookup("Image_ManaAlert"):SetAlpha(255 - 100 * nManaPercentage)
		else
			handleRole:Lookup("Image_ManaAlert"):Hide()
		end
	else
		handleRole:Lookup("Image_ManaAlert"):Hide()
	end
end

-- ���»��ƶ��ѱ��ͼ��
local tMarkerImageList = {66, 67, 73, 74, 75, 76, 77, 78, 81, 82}
function RaidGrid.UpdateMarkImage(dwMemberID)
	local team = GetClientTeam()
	local tPartyMark = team.GetTeamMark()
	if not tPartyMark then
		return
	end
	local handleRole = RaidGrid.GetRoleHandleByID(dwMemberID)
	if handleRole then
		local nMarkImageIndex = tPartyMark[dwMemberID]
		if nMarkImageIndex and tMarkerImageList[nMarkImageIndex] then
			local imageMark = handleRole:Lookup("Image_MarkImage")
			imageMark:SetFrame(tMarkerImageList[nMarkImageIndex])
			imageMark:Show()
			imageMark:SetAlpha(255)
			imageMark.nFlashDegSpeed = -1
		else
			local imageMark = handleRole:Lookup("Image_MarkImage")
			imageMark:Hide()
		end
	end
end

-- ���»����ض���ɫ��״̬ͼ��, ������, �ӳ���
function RaidGrid.RedrawMemberHandleState(dwMemberID)
	local handleRole = RaidGrid.GetRoleHandleByID(dwMemberID)
	local tMemberInfo = RaidGrid.GetTeamMemberInfo(dwMemberID)
	if not handleRole or not tMemberInfo then
		return
	end
	handleRole:Show()

	-- �ӳ�
	local imageLeader = handleRole:Lookup("Image_Leader")
	if RaidGrid.IsLeader(dwMemberID) then
		imageLeader:Show()
	else
		imageLeader:Hide()
	end

	-- ����
	local imageMatrix = handleRole:Lookup("Image_Matrix")
	if RaidGrid.IsMatrixcore(dwMemberID) then
		imageMatrix:Show()
	else
		imageMatrix:Hide()
	end

	-- ���ѱ��
	RaidGrid.UpdateMarkImage(dwMemberID)
end

-- �����������½�ɫ��һЩ������ʾ, �� ������ӵ�, ������ֵ�
function RaidGrid.UpdateMemberSpecialState(dwMemberID)
	local handleRole = RaidGrid.GetRoleHandleByID(dwMemberID)
	local tMemberInfo = RaidGrid.GetTeamMemberInfo(dwMemberID)
	if not handleRole or not tMemberInfo then
		return
	end
	handleRole:Show()
	local nFrame = RaidGrid.GetCharacterImageColor(dwMemberID, tMemberInfo.dwForceID)
	handleRole:Lookup("Image_Life"):SetFrame(nFrame)
	handleRole:Lookup("Image_Life"):Show()

	local textName = handleRole:Lookup("Text_Name")
	local szName = ""
	local NameLimit = 6 --((RaidGrid.fScale/0.2)-4)*2 + 4 --6

	textName:SetFontScheme(RaidGrid.szFontScheme)

	if tMemberInfo.bIsOnLine then
		szName = tMemberInfo.szName
	else
		szName = "����"
	end

	if NameLimit > 12 then
		NameLimit = 12
	end

	if #szName == 4 then
		textName:SetFontSpacing(10)
		textName:SetText(szName)
	elseif #szName == NameLimit then
		textName:SetFontSpacing(-2)
		textName:SetText(szName)
	else
		textName:SetFontSpacing(-3)
		textName:SetText(szName:sub(1, NameLimit - 2) .. "��")
	end

	local objPlayer = GetPlayer(dwMemberID)
	if RaidGrid.bAutoAlpha then
		if objPlayer then
			local player = GetClientPlayer()
			if player then
				local nDist2d = math.floor(((objPlayer.nX - player.nX) ^ 2 + (objPlayer.nY - player.nY) ^ 2) ^ 0.5)
				local nDistM = nDist2d / 64
				if nDistM <= RaidGrid.nAutoDistColor then
					handleRole:Lookup("Image_Life"):SetFrame(nFrame)
					handleRole:Lookup("Image_Life"):SetAlpha(255)
				else
					handleRole:Lookup("Image_Life"):SetFrame(1)
					handleRole:Lookup("Image_Life"):SetAlpha(255)
				end
			end
			RaidGrid.RedrawMemberHandleHPnMP(dwMemberID)
		else
			handleRole:Lookup("Image_Life"):SetFrame(0)
			handleRole:Lookup("Image_Life"):SetAlpha(200)
			RaidGrid.RedrawMemberHandleHPnMP(dwMemberID)
		end
	end
end

-- �������е�Ѫ����ɫ
function RaidGrid.HideAllLifeBar(handleRole)
	handleRole:Lookup("Image_Life"):Hide()
end


-- ����Ĭ���Ŷӽ���
function RaidGrid.EnableRaidPanel(bEnable)
	for nGroupID = -1, 6 do
		local frame = Station.Lookup("Normal/RaidPanel_" .. nGroupID)
		if frame then
			if not bEnable then
				frame:Hide()
			else
				frame:Show()
			end
		end
	end
end

-- ���¼��������Ŷ�����
function RaidGrid.ReloadEntireTeamInfo(bRedraw)
	local team = GetClientTeam()
	if not team then
		return
	end
	if bRedraw then
		RaidGrid.frameSelf:Lookup("", "Text_Title"):SetText(RaidGrid.szTitleText)
	end

	RaidGrid.tGroupList = {}
	RaidGrid.tForceList = {}
	--RaidGrid.tCustomList = {}
	RaidGrid.tRoleIDList = {}

	if GetClientPlayer().IsInParty() then
		for nGroupIndex = 0, math.min(4, team.nGroupNum - 1) do
			local tGroupInfo = team.GetGroupInfo(nGroupIndex)
			if tGroupInfo then
				RaidGrid.tGroupList[nGroupIndex] = RaidGrid.tGroupList[nGroupIndex] or {}
				for nSortIndex = 1, #tGroupInfo.MemberList do
					local dwMemberID = tGroupInfo.MemberList[nSortIndex]
					RaidGrid.OnMemberJoinTeam(dwMemberID, nGroupIndex)

					if bRedraw then
						RaidGrid.ShowRoleHandle(nGroupIndex, nSortIndex)
						RaidGrid.RedrawMemberHandleHPnMP(dwMemberID)
						RaidGrid.RedrawMemberHandleState(dwMemberID)
						RaidGrid.UpdateMemberSpecialState(dwMemberID)
					end
				end
			end
		end
	end
end

-- On PARTY_SYNC_MEMBER_DATA / PARTY_ADD_MEMBER [dwMemberID:arg1, nGroupIndex:arg2]
-- ���������¶�Ա�����ʱ�򴥷��¼�
function RaidGrid.OnMemberJoinTeam(dwMemberID, nGroupIndex)
	local team = GetClientTeam()
	if not team then
		return
	end

	local tMemberInfo = team.GetMemberInfo(dwMemberID)
	if tMemberInfo then
		RaidGrid.tForceList[tMemberInfo.dwForceID] = RaidGrid.tForceList[tMemberInfo.dwForceID] or {}
		table.insert(RaidGrid.tGroupList[nGroupIndex], dwMemberID)				-- ���浽С���б�����
		table.insert(RaidGrid.tForceList[tMemberInfo.dwForceID], dwMemberID)		-- ���浽�����б�����
		RaidGrid.tRoleIDList[dwMemberID] = dwMemberID								-- ���浽��ɫģʽ
	end
end

function RaidGrid.OnUpdateBuffData(dwMemberID, bIsRemoved, bCanCancel, dwBuffID, nLevel)
	if nLevel <= 0 then
		return
	end

	local member = GetPlayer(dwMemberID)
	if not member then
		return
	end

	local tBuffList = member.GetBuffList()
	if not tBuffList then
		return
	end

	local szBuffName = Table_GetBuffName(dwBuffID, nLevel)
	if not szBuffName or szBuffName == "" then
		return
	end

	local handleRole = RaidGrid.GetRoleHandleByID(dwMemberID)

	if bCanCancel then
		if RaidGrid.bBuffAlert then
			for i = 1, #RaidGrid.tMonitorTable["Buff"] do	--�����Ǳ�
				for k, v in pairs(RaidGrid.tMonitorTable["Buff"][i]) do	--�����Ǳ�BUFF
					if szBuffName == v then
						if bIsRemoved then
							handleRole:Lookup("Image_Buff_"..i):Hide()
						else
							handleRole:Lookup("Image_Buff_"..i):Show()
						end
						return
					end
				end
			end
		end
	else
		if RaidGrid.bDebuffAlert then
			for i = 1, #RaidGrid.tMonitorTable["Debuff"] do	--�����Ǳ�
				for k, v in pairs(RaidGrid.tMonitorTable["Debuff"][i]) do	--�����Ǳ�BUFF
					if szBuffName == v then
						if bIsRemoved then
							handleRole:Lookup("Image_Debuff_"..i):Hide()
						else
							handleRole:Lookup("Image_Debuff_"..i):Show()
						end
						return
					end
				end
			end
		end
	end
end

-- On TEAM_CHANGE_MEMBER_GROUP [dwSrcMember:arg0, nSrcGroup:arg1, dwDesMember:arg3, nDesGroup:arg2]
-- ������ʾ�˸ı�ǰ��Դ��Ŀ������, dwDesMember Ϊ 0 ��ʾ��Դ�ƶ������ǽ���
-- ���ӳ�����һ�����󴥷��¼�, ����Ĳ�����ʾ��λ���ǸĶ�ǰ��
function RaidGrid.OnMemberChangeGroup(dwSrcMember, nSrcGroup, dwDesMember, nDesGroup)
	RaidGrid.CreateAllRoleHandle()
	RaidGrid.ReloadEntireTeamInfo(true)
end

-- ----------------------------------------------------------------------------------------------------------
-- ���ػ������ݷ���:
-- ----------------------------------------------------------------------------------------------------------
-- ��ȡ�ų� ID
function RaidGrid.GetLeader()
	local team = GetClientTeam()
	if not team then
		return
	end
	return team.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.LEADER)
end

-- �ж�����Ƿ����ŶӶӳ�
function RaidGrid.IsLeader(dwMemberID)
	return dwMemberID == RaidGrid.GetLeader()
end

-- ��ȡ���� ID
function RaidGrid.GetMatrixcore(nGroupIndex)
	local team = GetClientTeam()
	if not team then
		return
	end
	if GetClientPlayer().IsInParty() then
		local tGroupInfo = team.GetGroupInfo(nGroupIndex)
		if tGroupInfo and tGroupInfo.MemberList and #tGroupInfo.MemberList > 0 then
			return tGroupInfo.dwFormationLeader
		end
	end
end

-- �ж�����Ƿ�������
function RaidGrid.IsMatrixcore(dwMemberID)
	local team = GetClientTeam()
	if not team then
		return
	end
	if GetClientPlayer().IsInParty() then
		for i = 0, math.min(4, team.nGroupNum - 1) do
			local tGroupInfo = team.GetGroupInfo(i)
			if tGroupInfo and tGroupInfo.MemberList and #tGroupInfo.MemberList > 0 and tGroupInfo.dwFormationLeader == dwMemberID then
				return true
			end
		end
	end
	return false
end

-- ��ȡʰȡ�� ID
function RaidGrid.GetLooter()
	local team = GetClientTeam()
	if not team then
		return
	end
	return team.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.DISTRIBUTE)
end

-- �ж�����Ƿ�ʰȡ��
function RaidGrid.IsLooter(dwMemberID)
	return dwMemberID == RaidGrid.GetLooter()
end

-- ��ȡ����� ID
function RaidGrid.GetMarker()
	local team = GetClientTeam()
	if not team then
		return
	end
	return team.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.MARK)
end

-- �ж�����Ƿ�����
function RaidGrid.IsMarker(dwMemberID)
	return dwMemberID == RaidGrid.GetMarker()
end

-- ��ȡʰȡģʽ��Ʒ��
function RaidGrid.GetLootModenQuality()
	local team = GetClientTeam()
	if not team then
		return
	end
	return team.nLootMode, team.nRollQuality
end

-- ͨ�� ID ��ȡһ������, �ⲻ��һ������, �����������ݵļ��ϱ�
function RaidGrid.GetTeamMemberInfo(dwMemberID)
	local player = GetClientPlayer()
	if not player then return end
	local team = GetClientTeam()
	if not team then return end
	local member = team.GetMemberInfo(dwMemberID)
	if not member then
		return
	end
	member.nX = member.nPosX
	member.nY = member.nPosY
	return member
end

-- ��ȡ��ɫ�ڱ��е��������: nSortIndex
-- nTypeIndex: �� tGroupMode �б�ʾС��ID, �� tForceMode �б�ʾ����(����)ID
function RaidGrid.GetSortIndex(tTeamInfoSubTable, nTypeIndex, dwMemberID)
	local tInfo = tTeamInfoSubTable[nTypeIndex]
	if not tInfo then
		return
	end
	for i = 1, #tInfo do
		if tInfo[i] and tInfo[i] == dwMemberID then
			return i
		end
	end
end

-- ȡ�ý�ɫ���ڵ�С�ӵ����
function RaidGrid.GetGroupIndex(dwMemberID)
	local team = GetClientTeam()
	return team.GetMemberGroupIndex(dwMemberID)
end

-- ��ȡ���λ�����ĸ�С�ӷ�Χ��
function RaidGrid.GetMouseGroupIndex()
	local nX = RaidGrid.frameSelf:GetAbsPos()
	local nMouseX = Cursor.GetPos()
	for i = 0, 4, 1 do
		if nMouseX <= nX + (i + 1) * RaidGrid.nColLength then
			return i
		end
	end
	return 4
end

-- ģ��ƥ��Buff����
function RaidGrid.SearchBuffNameInTable(szBuffName,tSplitTextTable)
	for k,v in pairs(tSplitTextTable) do
		if string.find(tostring(szBuffName),tostring(k)) then
			return tostring(k)
		end
	end
	return ""
end

-- ----------------------------------------------------------------------------------------------------------
-- ����:
-- ----------------------------------------------------------------------------------------------------------
function RaidGrid.Message(...)
	local a = {...}
	for i, v in ipairs(a) do
		a[i] = tostring(v)
	end
	OutputMessage("MSG_SYS", "[�Ŷӿ��] " .. table.concat(a, "\t").. "\n")
end

function RaidGrid.GetCharacterImageColor(dwCharacterID, dwForceID)
	local tImageFrame = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11}
	local player = GetClientPlayer()
	if not player then
		return tImageFrame[1]
	end
	if not IsPlayer(dwCharacterID) then
		return tImageFrame[1]
	end

	if not dwForceID then
		local target = GetPlayer(dwCharacterID)
		if not target then
			return tImageFrame[1]
		end

		dwForceID = target.dwForceID
		if not dwForceID then
			return tImageFrame[1]
		end
	end
	if dwForceID == 0 then		-- ��
		return tImageFrame[2]
	elseif dwForceID == 1 then	-- ����
		return tImageFrame[3]
	elseif dwForceID == 2 then	-- ��
		return tImageFrame[4]
	elseif dwForceID == 3 then	-- ���
		return tImageFrame[5]
	elseif dwForceID == 4 then	-- ����
		return tImageFrame[6]
	elseif dwForceID == 5 then	-- ����
		return tImageFrame[7]
	elseif dwForceID == 6 then	-- �嶾
		return tImageFrame[8]
	elseif dwForceID == 7 then	-- ����
		return tImageFrame[9]
	elseif dwForceID == 8 then	-- �ؽ�
		return tImageFrame[10]
	--elseif dwForceID == 9 then	-- ����
	--	return tImageFrame[11]
	--elseif dwForceID == 10 then	-- ؤ��
	--	return tImageFrame[12]
	end
	return tImageFrame[1]
end


function RaidGrid.SetPanelPos(nX, nY)
	local frame = Station.Lookup("Normal/RaidGrid")
	if not frame then
		frame = Wnd.OpenWindow("Interface\\RaidGrid\\RaidGrid.ini", "RaidGrid")
	end
	if not nX or not nY then
		frame:SetPoint("CENTER", 0, 0, "CENTER", 0, 0)
	else
		local nW, nH = Station.GetClientSize(true)
		if nX < 0 then nX = 0 end
		if nX > nW - 100 then nX = nW - 100 end
		if nY < 0 then nY = 0 end
		if nY > nH - 100 then nY = nH - 100 end
		frame:SetRelPos(nX, nY)
	end
	RaidGrid.tLastLoc.nX, RaidGrid.tLastLoc.nY = frame:GetRelPos()
end

function RaidGrid.ChangeReadyConfirm(dwMemberID, nReadyState)
	local handleRole = RaidGrid.GetRoleHandleByID(dwMemberID)
	local imgReadyCheck = handleRole:Lookup("Image_ReadyCheck")
	local imgReadyCheckNo = handleRole:Lookup("Image_ReadyCheck_No")
	if nReadyState == 1 then
		imgReadyCheck:Hide()
	elseif nReadyState == 2 then
		imgReadyCheckNo:Show()
	end
end

function RaidGrid.ReadyCheck()
	local team = GetClientTeam()
	if GetClientPlayer().IsInParty() then
		for nGroupIndex = 0, 4, 1 do
			local tGroupInfo = team.GetGroupInfo(nGroupIndex)
			if tGroupInfo then
				RaidGrid.tGroupList[nGroupIndex] = RaidGrid.tGroupList[nGroupIndex] or {}
				for nSortIndex = 1, #tGroupInfo.MemberList do
					local dwMemberID = tGroupInfo.MemberList[nSortIndex]
					if RaidGrid.GetLeader() ~= dwMemberID then
						local handleRole = RaidGrid.GetRoleHandleByID(dwMemberID)
						local imgReadyCheck = handleRole:Lookup("Image_ReadyCheck")
						imgReadyCheck:SetAlpha(255)
						imgReadyCheck:Show()
					end
				end
			end
		end
	end
end
