
if not HeadExSettings then
	HeadExSettings = {}
end
function HeadExSettings.PopOptions()
	HeadExSettings.tOptions = {
		{
			bDevide = true
		},
		{
			szOption = "��������Ѫ��", bCheck = true, bChecked = HeadEx.hMainFrame:IsVisible(),
			fnAction = function(UserData, bCheck)
				if bCheck then
					HeadEx.hMainFrame:Show()
					HeadEx.hHandleOuch:Show()
					HeadEx.hImageOuchTop:Hide()
					HeadEx.hImageOuchLeft:Hide()
					HeadEx.hImageOuchRight:Hide()
					HeadEx.hImageOuchBelow:Hide()  
				else
					HeadEx.hMainFrame:Hide()
					HeadEx.hHandleOuch:Hide()
					HeadEx.ShowSystemPlayerPanel()
					HeadEx.tLogic.bHideSystemPlayerPanle = false 
				end
				GetPopupMenu():Hide()
			end,
		},
		{
			szOption = "�ر�ϵͳͷ��", bCheck = true, bChecked = HeadEx.tLogic.bHideSystemPlayerPanle == true, 
			fnAction = function(UserData, bCheck)
				if bCheck then
					HeadEx.HideSystemPlayerPanel()
					HeadEx.tLogic.bHideSystemPlayerPanle = true 
				else
					HeadEx.ShowSystemPlayerPanel()
					HeadEx.tLogic.bHideSystemPlayerPanle = false 
				end
			end,
		},
--		{
--			szOption = "����ALTͷ��", bCheck = true, bChecked = HeadEx.tLogic.bALTShowPlayerPanle == true, 
--			fnAction = function(UserData, bCheck)
--				if bCheck then
--					HeadEx.tLogic.bALTShowPlayerPanle = true 
--				else
--					HeadEx.tLogic.bALTShowPlayerPanle = false 
--				end
--			end,
--		},
--	{
--				szOption = "������ս��״̬����", bCheck = true, bChecked = HeadEx.tLogic.bFightAlphaShow == true, 
--			fnAction = function(UserData, bCheck)
--				HeadEx.tLogic.bFightAlphaShow = bCheck
--					if bCheck then
--					HeadEx.tLogic.bFightAlphaShow = true
--						HeadEx.hMainFrame:Hide()
--			            HeadEx.hImageHPBG:Hide()
--	                     HeadEx.hImageMPBG:Hide()
--				else
--					HeadEx.tLogic.bFightAlphaShow = false
--				    HeadEx.hMainFrame:Show()
--			            HeadEx.hImageHPBG:Show()
--	                  HeadEx.hImageMPBG:Show()
--			end
--                     GetPopupMenu():Hide()					
--				end,
--			},
--		{
--			szOption = "����ְҵ����", bCheck = true, bChecked = HeadEx.tLogic.bHideMountKF == true,
--			fnAction = function(UserData, bCheck)
--			HeadEx.tLogic.bHideMountKF = bCheck
--			local player = GetClientPlayer()
--	        local skill = player.GetKungfuMount()
--					if bCheck then
--					    HeadEx.bHideMountKF = true
--						HeadEx.hHandleMain:Lookup("Handle_ChunYang"):Hide()
--		                HeadEx.hHandleMain:Lookup("Handle_ShaoLin"):Hide()
--		                HeadEx.hHandleMain:Lookup("Handle_CangJian"):Hide()
--		                HeadEx.hHandleMain:Lookup("Handle_TangMen"):Hide()
--		                HeadEx.hHandleMain:Lookup("Handle_QiXiu"):Hide()
--					else
--                       HeadEx.bHideMountKF = false
--					if skill.dwMountType == 3 then --�����ڹ�
--					HeadEx.hHandleMain:Lookup("Handle_ChunYang"):Show()
--					elseif skill.dwMountType == 5 then --�����ڹ�
--					HeadEx.hHandleMain:Lookup("Handle_ShaoLin"):Show()
--					elseif skill.dwMountType == 6 then --�ؽ��ڹ�
--					HeadEx.hHandleMain:Lookup("Handle_CangJian"):Show()
--					elseif skill.dwMountType == 10 then --�����ڹ�
--					HeadEx.hHandleMain:Lookup("Handle_TangMen"):Show()
--					elseif skill.dwMountType == 4 then  -- �����ڹ�
--					HeadEx.hHandleMain:Lookup("Handle_QiXiu"):Show()
--					end
--               end
--		end,
--	},
		{
			bDevide = true
		},
		{	szOption = "ս��״̬",
			{
				szOption = "����ս��״̬ͼ��", bCheck = true, bChecked = HeadEx.tLogic.bShowFightFlag == true, 
				fnAction = function(UserData, bCheck)
					HeadEx.tLogic.bShowFightFlag = bCheck
					if not bCheck then
						HeadEx.hImageFightFlag:Hide()
					end	
				end,
			},
--			{szOption = "����ս����͸��", 	bCheck = true, bChecked = HeadEx.tLogic.bFightAlpha == true,
--				fnAction = function(UserData, bCheck)
--					HeadEx.tLogic.bFightAlpha = bCheck
--					if not bCheck then
--						HeadEx.hMainFrame:SetAlpha(255)
--						HeadEx.hImageHPBG:SetAlpha(100)
--						HeadEx.hImageMPBG:SetAlpha(100)
--					end
--				end
--			},
			{
				szOption = "ս��״̬͸����",
				{szOption = "30%", 	bCheck = true, bChecked = HeadEx.tLogic.nFightAlpha == 77, 		fnAction = function(UserData, bCheck) HeadEx.tLogic.nFightAlpha = 77 ;GetPopupMenu():Hide();end},
				{szOption = "40%", 	bCheck = true, bChecked = HeadEx.tLogic.nFightAlpha == 102, 	fnAction = function(UserData, bCheck) HeadEx.tLogic.nFightAlpha = 102;GetPopupMenu():Hide();end},
				{szOption = "50%", 	bCheck = true, bChecked = HeadEx.tLogic.nFightAlpha == 128, 	fnAction = function(UserData, bCheck) HeadEx.tLogic.nFightAlpha = 128;GetPopupMenu():Hide();end},
				{szOption = "60%",  bCheck = true, bChecked = HeadEx.tLogic.nFightAlpha == 153, 	fnAction = function(UserData, bCheck) HeadEx.tLogic.nFightAlpha = 153;GetPopupMenu():Hide();end},
				{szOption = "70%",  bCheck = true, bChecked = HeadEx.tLogic.nFightAlpha == 179, 	fnAction = function(UserData, bCheck) HeadEx.tLogic.nFightAlpha = 179;GetPopupMenu():Hide();end},
			},
			
		},
		
		{
			bDevide = true
		},
--		{
--			szOption = "������λ��ʾ",
--			{szOption = "����������λ��ʾ", bCheck = true, bChecked = HeadEx.tLogic.bAttackOpen == true, fnAction = function(UserData, bCheck) HeadEx.tLogic.bAttackOpen = bCheck end},
--			{ 
--				szOption = "��˸����",
--				{szOption = "1", bCheck = true, bChecked = HeadEx.tLogic.nAttackFlash == 1, fnAction = function(UserData, bCheck) HeadEx.tLogic.nAttackFlash = 1;GetPopupMenu():Hide(); end},
--				{szOption = "2", bCheck = true, bChecked = HeadEx.tLogic.nAttackFlash == 2, fnAction = function(UserData, bCheck) HeadEx.tLogic.nAttackFlash = 2;GetPopupMenu():Hide(); end},
--				{szOption = "3", bCheck = true, bChecked = HeadEx.tLogic.nAttackFlash == 3, fnAction = function(UserData, bCheck) HeadEx.tLogic.nAttackFlash = 3;GetPopupMenu():Hide(); end},
--				{szOption = "4", bCheck = true, bChecked = HeadEx.tLogic.nAttackFlash == 4, fnAction = function(UserData, bCheck) HeadEx.tLogic.nAttackFlash = 4;GetPopupMenu():Hide(); end},
--			},
--			{ 
--				szOption = "��˸�ٶ�",
--				{szOption = "10", bCheck = true, bChecked = HeadEx.tLogic.nAttackFlashTime == 10, fnAction = function(UserData, bCheck) HeadEx.tLogic.nAttackFlashTime = 10;GetPopupMenu():Hide(); end},
--				{szOption = "20", bCheck = true, bChecked = HeadEx.tLogic.nAttackFlashTime == 20, fnAction = function(UserData, bCheck) HeadEx.tLogic.nAttackFlashTime = 20;GetPopupMenu():Hide(); end},
--				{szOption = "25", bCheck = true, bChecked = HeadEx.tLogic.nAttackFlashTime == 25, fnAction = function(UserData, bCheck) HeadEx.tLogic.nAttackFlashTime = 25;GetPopupMenu():Hide(); end},
--				{szOption = "30", bCheck = true, bChecked = HeadEx.tLogic.nAttackFlashTime == 30, fnAction = function(UserData, bCheck) HeadEx.tLogic.nAttackFlashTime = 30;GetPopupMenu():Hide(); end},
--				{szOption = "40", bCheck = true, bChecked = HeadEx.tLogic.nAttackFlashTime == 40, fnAction = function(UserData, bCheck) HeadEx.tLogic.nAttackFlashTime = 40;GetPopupMenu():Hide(); end},
--				{szOption = "50", bCheck = true, bChecked = HeadEx.tLogic.nAttackFlashTime == 50, fnAction = function(UserData, bCheck) HeadEx.tLogic.nAttackFlashTime = 50;GetPopupMenu():Hide(); end},
--			},
--		},
		
		{
			bDevide = true
		},
		{ 
			szOption = "��ֵ��ʾ��ʽ",
			{ 
				szOption = "Ѫ������ֵ��ʾ��ʽ",
				{szOption = "�ٷֱ�", 	bCheck = true, bChecked = HeadEx.tLogic.eNumberDisplayType1 == PLAYERINFOTYPE.PERCENT, 	fnAction = function(UserData, bCheck) HeadEx.tLogic.eNumberDisplayType1 = PLAYERINFOTYPE.PERCENT;	GetPopupMenu():Hide();HeadEx.UpdatePlayerState(); end},
				{szOption = "��ǰ��ֵ", bCheck = true, bChecked = HeadEx.tLogic.eNumberDisplayType1 == PLAYERINFOTYPE.CURRENT, 	fnAction = function(UserData, bCheck) HeadEx.tLogic.eNumberDisplayType1 = PLAYERINFOTYPE.CURRENT;	GetPopupMenu():Hide();HeadEx.UpdatePlayerState(); end},
				{szOption = "������ֵ", bCheck = true, bChecked = HeadEx.tLogic.eNumberDisplayType1 == PLAYERINFOTYPE.MAX, 		fnAction = function(UserData, bCheck) HeadEx.tLogic.eNumberDisplayType1 = PLAYERINFOTYPE.MAX;		GetPopupMenu():Hide();HeadEx.UpdatePlayerState(); end},
				{szOption = "X / X", 	bCheck = true, bChecked = HeadEx.tLogic.eNumberDisplayType1 == PLAYERINFOTYPE.ALLINFO, 	fnAction = function(UserData, bCheck) HeadEx.tLogic.eNumberDisplayType1 = PLAYERINFOTYPE.ALLINFO;	GetPopupMenu():Hide();HeadEx.UpdatePlayerState(); end},
			},
			{ 
				szOption = "Ѫ������ֵ��ʾ��ʽ",
				{szOption = "�ٷֱ�", 	bCheck = true, bChecked = HeadEx.tLogic.eNumberDisplayType2 == PLAYERINFOTYPE.PERCENT, 	fnAction = function(UserData, bCheck) HeadEx.tLogic.eNumberDisplayType2 = PLAYERINFOTYPE.PERCENT;	GetPopupMenu():Hide();HeadEx.UpdatePlayerState(); end},
				{szOption = "��ǰ��ֵ", bCheck = true, bChecked = HeadEx.tLogic.eNumberDisplayType2 == PLAYERINFOTYPE.CURRENT, 	fnAction = function(UserData, bCheck) HeadEx.tLogic.eNumberDisplayType2 = PLAYERINFOTYPE.CURRENT;	GetPopupMenu():Hide();HeadEx.UpdatePlayerState(); end},
				{szOption = "������ֵ", bCheck = true, bChecked = HeadEx.tLogic.eNumberDisplayType2 == PLAYERINFOTYPE.MAX, 		fnAction = function(UserData, bCheck) HeadEx.tLogic.eNumberDisplayType2 = PLAYERINFOTYPE.MAX;		GetPopupMenu():Hide();HeadEx.UpdatePlayerState(); end},
				{szOption = "X / X", 	bCheck = true, bChecked = HeadEx.tLogic.eNumberDisplayType2 == PLAYERINFOTYPE.ALLINFO, 	fnAction = function(UserData, bCheck) HeadEx.tLogic.eNumberDisplayType2 = PLAYERINFOTYPE.ALLINFO;	GetPopupMenu():Hide();HeadEx.UpdatePlayerState(); end},
			},
		},
		{
			bDevide = true
		},
		{ 
			szOption = "������",
			{
				szOption = "��������������", bCheck = true, bChecked = HeadEx.tLogic.bEnableOTBar == true,
					fnAction = function(UserData, bCheck)
						if bCheck then
							HeadEx.tLogic.bEnableOTBar = true
						else
--							OTActionBar = HeadEx.OldOTActionBar
							HeadEx.tLogic.bEnableOTBar = false
							HeadEx.tLogic.bHideSystemOTBar = false
						end
--						GetPopupMenu():Hide()
					end,
			},
			{
				szOption = "����ϵͳ������", bCheck = true, bChecked = HeadEx.tLogic.bHideSystemOTBar == true,
					fnAction = function(UserData, bCheck)
						if bCheck then
							HeadEx.tLogic.bHideSystemOTBar = true
							local frame = Station.Lookup("Topmost/OTActionBar")
							if frame then
								frame:Hide()
							end
						else
							HeadEx.tLogic.bHideSystemOTBar = false
						end
					end
			},
		},
		{
			bDevide = true
		},
		{szOption = "���ò��", bCheck = false, bChecked = false, fnAction = function(UserData, bCheck) HeadEx.RestInterface() end },
		
		--------------------------------------------------------
		fnAction = function(UserData, bCheck)
		end,
		fnChangeColor = function(UserData, r, g, b)
		end,
		fnCancelAction = function()
		end,
		fnAutoClose = function()
			return false
		end,
	}
	
	local nX, nY = Cursor.GetPos(true)
	HeadExSettings.tOptions.x, HeadExSettings.tOptions.y = nX + 15, nY + 15
	PopupMenu(HeadExSettings.tOptions)
end

function HeadExSettings.OnLButtonClick()
	local szName = this:GetName()
	if szName ~= "Btn_Settings" then
		return
	end
	HeadExSettings.PopOptions()
	HideTip()
end


function HeadExSettings.OnRButtonClick()
	local szName = this:GetName()
	if szName ~= "Btn_Settings" then
		return
	end
	local tMenu = {}
	InsertPlayerMenu(tMenu)
	PopupMenu(tMenu)
	HideTip()
end


function HeadExSettings.OnMouseEnter()
	local szName = this:GetName()
	if szName ~= "Btn_Settings" then
		return
	end
	local szTips = "<text>text="..EncodeComponentsString("��������\n") .. " font=80 r=255 g=255 b=0</text>"
		.. "<text>text="..EncodeComponentsString("    ���л���Ѫ�����ò˵�\n") .. " font=40 r=0 g=255 b=0</text>"
		.. "<text>text="..EncodeComponentsString("�Ҽ������\n") .. " font=80 r=255 g=255 b=0</text>"
		.. "<text>text="..EncodeComponentsString("    ��ϵͳ�������ò˵�\n") .. " font=40 r=0 g=255 b=0</text>"
		.. "<text>text="..EncodeComponentsString("����ALT��\n") .. " font=80 r=255 g=255 b=0</text>"
		.. "<text>text="..EncodeComponentsString("    ��ϵͳͷ�����λ��\n") .. " font=40 r=0 g=255 b=0</text>"
	OutputTip(szTips, 600, {0, 0, 15, 0})
end

function HeadExSettings.OnMouseLeave()
	local szName = this:GetName()
	if szName ~= "Btn_Settings" then
		return
	end
	HideTip()
end

