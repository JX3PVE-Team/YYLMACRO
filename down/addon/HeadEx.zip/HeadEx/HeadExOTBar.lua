--========================================================================================================
-- ���� : HeadEx
-- ���� : Constantine
-- ���� : ��������������
--========================================================================================================
if not HeadExOTBar then
	HeadExOTBar = {
		PROGRESS_TYPE_ADD = 1, -- const
		PROGRESS_TYPE_DEC = 2, -- const		
}
end
--========================================================================================================
-- ���� : HeadEx
-- ���� : Constantine
-- ���� : ϵͳ�ص�
--========================================================================================================

function HeadExOTBar.OnFrameRender()
	if not HeadExOTBar.bShow then
		return
	end
	
	if HeadExOTBar.bFadeOut then
		local nTime = GetTickCount()
		if not HeadExOTBar.nStartFadeTime then
			HeadExOTBar.nStartFadeTime = nTime
		end
		if nTime - HeadExOTBar.nStartFadeTime > 1000 then
			HeadExOTBar.HideProgress(this)
			HeadExOTBar.bFadeOut = false
			HeadExOTBar.nStartFadeTime = nil
		else
			HeadEx.hOTBar:SetAlpha(255 * (1 - (nTime - HeadExOTBar.nStartFadeTime) / 1000))
		end
		return
	end
	
	local nCurrentFrame = GetLogicFrameCount(); 
	if (nCurrentFrame >= HeadExOTBar.nEndFrame) then
	    HeadExOTBar.FlashProgressBar(true);
	    return;
	end
	
	local nCurrentTime = GetTickCount()
	local nPast = nCurrentTime - HeadExOTBar.nStartTime
	local nTotoal = HeadExOTBar.nEndTime - HeadExOTBar.nStartTime
	local fP = nPast / nTotoal;	
	if HeadExOTBar.nProgressType == HeadExOTBar.PROGRESS_TYPE_DEC then
		fP = 1 - fP
	end
	HeadExOTBar.SetProgressBarPercentage(HeadEx.hImageOT, fP)
end

function HeadExOTBar.OnEvent(event)
	if event == "UI_SCALED" then
		--HeadEx.UpdatePos()
	elseif event == "DO_SKILL_PREPARE_PROGRESS" then
	--	Output("DO_SKILL_PREPARE_PROGRESS",arg1)
		HeadExOTBar.OnSkillPrepareProgress(event)
	elseif event == "DO_SKILL_CHANNEL_PROGRESS" then
	--	Output("DO_SKILL_CHANNEL_PROGRESS",arg1)
		HeadExOTBar.OnSkillChannelProgress(event)
	elseif event == "OT_ACTION_PROGRESS_UPDATE" then
		HeadExOTBar.OnActionProgressUpdate(event)
	elseif event == "OT_ACTION_PROGRESS_BREAK" then
		if arg0 == GetClientPlayer().dwID then
			HeadExOTBar.OnActionProgressBreak(event)
		end
	elseif event == "DO_PICK_PREPARE_PROGRESS" then
		HeadExOTBar.OnPickPrepareProgress(event)
	elseif event == "DO_CUSTOM_OTACTION_PROGRESS" then
		HeadExOTBar.OnCustomOTActionProgress(event)
	elseif event == "DO_RECIPE_PREPARE_PROGRESS" then
		HeadExOTBar.OnRecipeOTActionProgress(event)
	end
end


function HeadExOTBar.OnFrameCreate()
	this:RegisterEvent("UI_SCALED")
	this:RegisterEvent("DO_SKILL_PREPARE_PROGRESS")
	this:RegisterEvent("DO_SKILL_CHANNEL_PROGRESS")
	this:RegisterEvent("OT_ACTION_PROGRESS_UPDATE")
	this:RegisterEvent("OT_ACTION_PROGRESS_BREAK")
	this:RegisterEvent("DO_PICK_PREPARE_PROGRESS")
	this:RegisterEvent("DO_CUSTOM_OTACTION_PROGRESS")
	this:RegisterEvent("DO_RECIPE_PREPARE_PROGRESS")
end
--========================================================================================================
-- ���� : HeadEx
-- ���� : Constantine
-- ���� : �Զ��庯��
--========================================================================================================
function HeadExOTBar.OnActionProgressBreak()
	HeadExOTBar.FlashProgressBar(false)	
end

function HeadExOTBar.OnActionProgressUpdate(event)
    local nFrame = arg0;
	HeadExOTBar.nEndFrame  = HeadExOTBar.nEndFrame + nFrame;
	HeadExOTBar.nEndTime = HeadExOTBar.nEndTime + nFrame * 1000 / GLOBAL.GAME_FPS
end
function HeadExOTBar.ShowProgress(frame)
	if not HeadEx.tLogic.bEnableOTBar then
		return
	end
	frame:Show()
	frame.bShow = true
	frame:SetAlpha(255)
end

function HeadExOTBar.HideProgress(frame)
	frame:Hide()
	frame.bShow = false
end

function HeadExOTBar.FlashProgressBar(bSuccess)
	HeadEx.hImageOT:Hide()
	
	if bSuccess then
		HeadEx.hImageOTOK:Show()
	else
		HeadEx.hImageOTBreak:Show()
	end
	HeadExOTBar.bFadeOut = true
end


function HeadExOTBar.OnRecipeOTActionProgress(event)
	local nTotalFrame = arg0;
	local nCraftID = arg1;
	local nRecipeID = arg2;
	
	if (nTotalFrame <= 0) then
	    return;
	end
	
 	local nCurrentFrame = GetLogicFrameCount(); 
	
	HeadExOTBar.nStartFrame 		= nCurrentFrame;
	HeadExOTBar.nEndFrame   		= nCurrentFrame + nTotalFrame;
	HeadExOTBar.nProgressType 		= HeadExOTBar.PROGRESS_TYPE_ADD;
	HeadExOTBar.UpdateTime()
	
	local szText = Table_GetRecipeName(arg1, arg2);
	HeadExOTBar.PrepaireProgressBar(0, szText);
end

function HeadExOTBar.OnCustomOTActionProgress(event)
	local nTotalFrame = arg0;
	if (nTotalFrame <= 0) then
	    return;
	end
	
    local nCurrentFrame 	= GetLogicFrameCount(); 
    HeadExOTBar.nStartFrame = nCurrentFrame;
    HeadExOTBar.nEndFrame 	= nCurrentFrame + nTotalFrame;
    HeadExOTBar.UpdateTime()

	if (arg2 == 0) then
		HeadExOTBar.nProgressType = HeadExOTBar.PROGRESS_TYPE_ADD;
	else
		HeadExOTBar.nProgressType = HeadExOTBar.PROGRESS_TYPE_DEC;
	end

	HeadExOTBar.PrepaireProgressBar(0, arg1);
end


function HeadExOTBar.OnPickPrepareProgress(event)
	local nTotalFrame = arg0;
	if (nTotalFrame <= 0) then
	    return;
	end
	
    local nCurrentFrame = GetLogicFrameCount(); 

	HeadExOTBar.nStartFrame 		= nCurrentFrame;
	HeadExOTBar.nEndFrame   		= nCurrentFrame + nTotalFrame;
	HeadExOTBar.nProgressType 		= HeadExOTBar.PROGRESS_TYPE_ADD;
	HeadExOTBar.UpdateTime()
	
	local doodad = GetDoodad(arg1);
	local szName = Table_GetDoodadName(doodad.dwTemplateID, doodad.dwNpcTemplateID)
	local doodadTemplate = GetDoodadTemplate(doodad.dwTemplateID);

	if doodadTemplate then
		local szBarText = Table_GetDoodadTemplateBarText(doodad.dwTemplateID)
		if szBarText ~= "" then
			szName = szBarText;
		end

		if  doodadTemplate.dwCraftID ~= 0 then
			local craft = GetCraft(doodadTemplate.dwCraftID);
			if craft then
				szName = Table_GetCraftName(doodadTemplate.dwCraftID)
			end
		end
	end	
	HeadExOTBar.PrepaireProgressBar(0, szName)
end

function HeadExOTBar.OnSkillPrepareProgress(event)
	local nTotalFrame = arg0;
	if (nTotalFrame <= 0) then
	    return
	end
	
    local nCurrentFrame = GetLogicFrameCount(); 

	HeadExOTBar.nStartFrame 		= nCurrentFrame;
	HeadExOTBar.nEndFrame   		= nCurrentFrame + nTotalFrame;
	HeadExOTBar.nProgressType 		= HeadExOTBar.PROGRESS_TYPE_ADD;
	HeadExOTBar.UpdateTime()
	
	local szText = Table_GetSkillName(arg1, arg2);	
	HeadExOTBar.PrepaireProgressBar(0, szText)
end

function HeadExOTBar.OnSkillChannelProgress(event)
	local nTotalFrame = arg0;
	if (nTotalFrame <= 0) then
	    return;
	end
	
    local nCurrentFrame = GetLogicFrameCount(); 

	HeadExOTBar.nStartFrame 		= nCurrentFrame;
	HeadExOTBar.nEndFrame   		= nCurrentFrame + nTotalFrame;
	HeadExOTBar.nProgressType 		= HeadExOTBar.PROGRESS_TYPE_DEC;

	HeadExOTBar.UpdateTime()
	
	local szText = Table_GetSkillName(arg1, arg2);
	HeadExOTBar.PrepaireProgressBar(0, szText)
end
function HeadExOTBar.PrepaireProgressBar(fPercentage, szName)
 	HeadExOTBar.ShowProgress(HeadEx.hOTBar)
 	HeadEx.hImageOTOK:Hide()
 	HeadEx.hImageOTBreak:Hide()
	HeadEx.hImageOT:Show()
	HeadEx.hImageOT:SetAlpha(255)
	HeadEx.hTextOT:Show()
	HeadEx.hTextOT:SetText(szName)
	HeadEx.hTextOT:SetAlpha(255)
	HeadEx.hImageOTBG:Show()
	HeadEx.hImageOTBG:SetAlpha(HeadEx.hImageHPBG:GetAlpha())
	if HeadEx.tLogic.bFightAlpha then
		if GetClientPlayer().bFightState then
			HeadEx.hOTBar:SetAlpha(HeadEx.tLogic.nFightAlpha)
			HeadEx.hImageOTBG:SetAlpha(HeadEx.tLogic.nFightAlpha * 0.4)
		else
			HeadEx.hOTBar:SetAlpha(255)
			HeadEx.hImageOTBG:SetAlpha(100)
		end
	end
	HeadExOTBar.bShow = true
	HeadExOTBar.bFadeOut = false
	HeadExOTBar.SetProgressBarPercentage(HeadEx.hImageOT, fPercentage)
end

function HeadExOTBar.SetProgressBarPercentage(handle, fPercentage)
	if fPercentage < 0 then
		fPercentage = 0
	end
	if fPercentage > 1 then
		fPercentage = 1
	end
	
	handle:SetPercentage(fPercentage)
end


function HeadExOTBar.UpdateTime()
	HeadExOTBar.nStartTime = GetTickCount()
	HeadExOTBar.nEndTime = HeadExOTBar.nStartTime + (HeadExOTBar.nEndFrame - HeadExOTBar.nStartFrame) * 1000 / GLOBAL.GAME_FPS
end

