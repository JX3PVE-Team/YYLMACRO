--========================================================================================================
-- ���� : HeadEx
-- ���� : Constantine
-- ���� : ������������ö�ٶ���
--========================================================================================================


PLAYERINFOKIND = {
	HP = 1,
	MP = 2,
}

PLAYERINFOTYPE = {
	MAX = 1,
	CURRENT = 2,
	PERCENT = 3,	
	ALLINFO = 4,
}

DIFFERENCEANGLE = {
	["TOP"]			= 1,
	["TOP_RIGHT"] 	= 2,
	["RIGHT"] 		= 3,
	["BELOW_RIGHT"] = 4,
	["BELOW"] 		= 5,
	["BELOW_LEFT"] 	= 6,
	["LEFT"] 		= 7,
	["TOP_LEFT"] 	= 8,
}


if not HeadEx then
	HeadEx = {
		fUnitAngle = 1/8,		-- const
		nAttackFlashCount = 0,
		tDefaultLogic = {
			nAttackFlashTime 					= 20,
			nAttackFlash 						= 1,
			nAttackAlpha 						= 100,
			bAttackOpen 						= false,  --������λ��ʾ
			bHideSystemPlayerPanle 	= false,  --�ر�ϵͳͷ��
			bShowFightFlag 				  = true,   --ս����־
			bFightAlphaShow         = false,   --������ս��״̬����
			eNumberDisplayType1			= PLAYERINFOTYPE.MAX,   --Ѫ���м����ʾģʽ
			eNumberDisplayType2		  = PLAYERINFOTYPE.CURRENT,--Ѫ���±ߵ���ʾģʽ 
			bFightAlpha							= false,          --ս����͸��
			nFightAlpha							= 153,            --ս��͸���ȵ�ֵ
			bEnableOTBar						= true,           --�������ζ���
			bHideSystemOTBar				= true,           --����ϵͳ����
			bALTShowPlayerPanle			= false,         --����ALTͷ��
			bHideMountKF            = false,         --����ϵͳ��ְҵ����
		},
		tSystemPlayerPanelPos = {0, 0},
		tPlayerAccumulate  = {
			aAccumulateShow =
			{
				{},
				{"10"},
				{"11"},
				{"11", "20"},
				{"11", "21"},
				{"11", "21", "30"},
				{"11", "21", "31"},
				{"11", "21", "31", "40"},
				{"11", "21", "31", "41"},
				{"11", "21", "31", "41", "50"},
				{"11", "21", "31", "41", "51"},
			},
			aAccumulateHide =
			{
				{"10", "11", "20", "21", "30", "31", "40", "41", "50", "51"},
				{"11", "20", "21", "30", "31", "40", "41", "50", "51"},
				{"10", "20", "21", "30", "31", "40", "41", "50", "51"},
				{"10", "21", "30", "31", "40", "41", "50", "51"},
				{"10", "20", "30", "31", "40", "41", "50", "51"},
				{"10", "20", "31", "40", "41", "50", "51"},
				{"10", "20", "30", "40", "41", "50", "51"},
				{"10", "20", "30", "41", "50", "51"},
				{"10", "20", "30", "40", "50", "51"},
				{"10", "20", "30", "40", "51"},
				{"10", "20", "30", "40", "50"},
			},
		},
	}
end

RegisterCustomData("HeadEx.tLogic")

function UpdataQiXiuImage(hImage)
	if hImage.bClickDown then
		hImage:SetFrame(89)
	elseif hImage.bInside then
		hImage:SetFrame(86)
	elseif hImage.bChecked then
		hImage:SetFrame(88)
	else
		hImage:SetFrame(85)
	end
end

--========================================================================================================
-- ���� : HeadEx
-- ���� : Constantine
-- ���� : ϵͳ�ص�
--========================================================================================================
function HeadEx.OnItemLButtonDown()
	Output("xx")
end



function HeadEx.OnFrameBreathe()
	if HeadEx.tLogic.bALTShowPlayerPanle then
		if IsAltKeyDown() then
			HeadEx.ShowSystemPlayerPanelOnCursor()
		else
			HeadEx.HideSystemPlayerPanelOnCursor()
		end
	end
	if HeadEx.nAttackFlashCount ~= 0 then
		local nAlpha = HeadEx.hHandleOuch:GetAlpha()
		if nAlpha ~= 0 then
			 HeadEx.hHandleOuch:SetAlpha(nAlpha - HeadEx.tLogic.nAttackFlashTime)
		else
			HeadEx.nAttackFlashCount = HeadEx.nAttackFlashCount - 1
			if HeadEx.nAttackFlashCount ~= 0 then
				HeadEx.hHandleOuch:SetAlpha(HeadEx.tLogic.nAttackAlpha)
			end
		end
	end
	if not this.bShow then
		return
	end
	
	local nCurrentTime = GetTickCount()
	local nPast = nCurrentTime - HeadEx.nStartTime
	local nTotoal = HeadEx.nEndTime - HeadEx.nStartTime
	local fP = nPast / nTotoal;	
	if HeadEx.nProgressType == HeadEx.PROGRESS_TYPE_DEC then
		fP = 1 - fP
	end
	HeadEx.SetProgressBarPercentage(HeadEx.hImageOT, fP)
end

function HeadEx.OnEvent(event)
	if event == "UI_SCALED" then
		HeadEx.UpdatePos()
		local nX, nY = Player_GetFrame():GetRelPos()
		HeadEx.tSystemPlayerPanelPos = {nX, nY} 
		if HeadEx.tLogic.bHideSystemPlayerPanle then
			HeadEx.HideSystemPlayerPanel()
		end
		HeadEx.OldOTActionBar = OTActionBar.PrepaireProgressBar
		OTActionBar.PrepaireProgressBar = function(fPercentage, szName)
			if HeadEx.tLogic.bHideSystemOTBar then
				return
			end
			HeadEx.OldOTActionBar(fPercentage, szName)
		end		
	elseif event == "PLAYER_STATE_UPDATE" then
		HeadEx.UpdatePlayerState()

	elseif event == "PLAYER_LEVEL_UPDATE" then
		HeadEx.UpdatePlayerState()

	elseif event == "SYNC_ROLE_DATA_END" then
		HeadEx.UpdatePlayerState()

	elseif event == "FIGHT_HINT" then
		HeadEx.OnFightHint()
	elseif event == "UI_UPDATE_ACCUMULATE" then
		HeadEx.OnUpdateAccumulateValue(this)
	elseif event == "SYS_MSG" then
			if HeadEx.tLogic.bAttackOpen then
				local DirectionnIndex = HeadEx.GetDirectionIndex(arg0, arg1, arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10)
				HeadEx.FlashAttack(DirectionnIndex)
			end
	elseif event == "CUSTOM_DATA_LOADED" then
		HeadEx.LoadData(arg0)
	end

end


function HeadEx.OnFrameCreate()
	this:RegisterEvent("UI_UPDATE_ACCUMULATE")
	this:RegisterEvent("UI_SCALED")
	this:RegisterEvent("PLAYER_STATE_UPDATE")
	this:RegisterEvent("PLAYER_LEVEL_UPDATE")
    this:RegisterEvent("SYNC_ROLE_DATA_END")
	this:RegisterEvent("FIGHT_HINT")
	this:RegisterEvent("SYS_MSG")
	this:RegisterEvent("CUSTOM_DATA_LOADED")
end
--========================================================================================================
-- ���� : HeadEx
-- ���� : Constantine
-- ���� : �Զ��庯��
--========================================================================================================
function HeadEx.RestInterface()
	HeadEx.tLogic = HeadEx.tDefaultLogic
	Wnd.CloseWindow(HeadEx.hMainFrame)
	HeadEx.CreateWindow()
end


function HeadEx.OnFightHint()
	if HeadEx.tLogic.bShowFightFlag then
		if arg0 then
			HeadEx.hImageFightFlag:Show()
		else
			HeadEx.hImageFightFlag:Hide()
		end
	end
	if HeadEx.tLogic.bFightAlpha then
		if arg0 then
			HeadEx.hMainFrame:SetAlpha(HeadEx.tLogic.nFightAlpha)
			HeadEx.hImageHPBG:SetAlpha(HeadEx.tLogic.nFightAlpha * 0.4)
			HeadEx.hImageMPBG:SetAlpha(HeadEx.tLogic.nFightAlpha * 0.4)
		else
			HeadEx.hMainFrame:SetAlpha(255)
			HeadEx.hImageHPBG:SetAlpha(100)
			HeadEx.hImageMPBG:SetAlpha(100)
		end
	end
	if HeadEx.tLogic.bFightAlphaShow then
		if arg0 then
			HeadEx.hMainFrame:Show()
			HeadEx.hImageHPBG:Show()
			HeadEx.hImageMPBG:Show()
		else
			HeadEx.hMainFrame:Hide()
			HeadEx.hImageHPBG:Hide()
			HeadEx.hImageMPBG:Hide()
		end
	end
end



function HeadEx.LoadData(szRole)
	if szRole ~= "Role" then
		return
	end
	HeadEx.tLogic = HeadEx.tLogic or HeadEx.tDefaultLogic
end

function HeadEx.UpdatePos()
	local nX, nY = Station.GetClientSize(true)
	HeadEx.hMainFrame:SetRelPos(nX / 2 - 165, nY / 2 - 100)
	nX, nY = HeadEx.hMainFrame:GetRelPos()
	HeadEx.hOTBar:SetRelPos(nX + 300, nY)
end


function HeadEx.FlashAttack(nDirection)
	if nDirection == DIFFERENCEANGLE.TOP then
		HeadEx.hImageOuchTop:Show()
		HeadEx.hImageOuchRight:Hide()
		HeadEx.hImageOuchBelow:Hide()
		HeadEx.hImageOuchLeft:Hide()
		HeadEx.hHandleOuch:SetRelPos(HeadEx.hMainFrame:GetRelPos())
		HeadEx.hHandleOuch:SetAlpha(HeadEx.tLogic.nAttackAlpha)
		HeadEx.nAttackFlashCount = HeadEx.tLogic.nAttackFlash
		return
	end
	if nDirection == DIFFERENCEANGLE.TOP_RIGHT then
		HeadEx.hImageOuchTop:Show()
		HeadEx.hImageOuchRight:Show()
		HeadEx.hImageOuchBelow:Hide()
		HeadEx.hImageOuchLeft:Hide()
		HeadEx.hHandleOuch:SetRelPos(HeadEx.hMainFrame:GetRelPos())
		HeadEx.hHandleOuch:SetAlpha(HeadEx.tLogic.nAttackAlpha)
		HeadEx.nAttackFlashCount = HeadEx.tLogic.nAttackFlash
		return
	end
	if nDirection == DIFFERENCEANGLE.RIGHT then
		HeadEx.hImageOuchTop:Hide()
		HeadEx.hImageOuchRight:Show()
		HeadEx.hImageOuchBelow:Hide()
		HeadEx.hImageOuchLeft:Hide()
		HeadEx.hHandleOuch:SetRelPos(HeadEx.hMainFrame:GetRelPos())
		HeadEx.hHandleOuch:SetAlpha(HeadEx.tLogic.nAttackAlpha)
		HeadEx.nAttackFlashCount = HeadEx.tLogic.nAttackFlash
		return
	end
	if nDirection == DIFFERENCEANGLE.BELOW_RIGHT then
		HeadEx.hImageOuchTop:Hide()
		HeadEx.hImageOuchRight:Show()
		HeadEx.hImageOuchBelow:Show()
		HeadEx.hImageOuchLeft:Hide()
		HeadEx.hHandleOuch:SetRelPos(HeadEx.hMainFrame:GetRelPos())
		HeadEx.hHandleOuch:SetAlpha(HeadEx.tLogic.nAttackAlpha)
		HeadEx.nAttackFlashCount = HeadEx.tLogic.nAttackFlash
		return
	end
	if nDirection == DIFFERENCEANGLE.BELOW then
		HeadEx.hImageOuchTop:Hide()
		HeadEx.hImageOuchRight:Hide()
		HeadEx.hImageOuchBelow:Show()
		HeadEx.hImageOuchLeft:Hide()
		HeadEx.hHandleOuch:SetRelPos(HeadEx.hMainFrame:GetRelPos())
		HeadEx.hHandleOuch:SetAlpha(HeadEx.tLogic.nAttackAlpha)
		HeadEx.nAttackFlashCount = HeadEx.tLogic.nAttackFlash
		return
	end
	if nDirection == DIFFERENCEANGLE.BELOW_LEFT then
		HeadEx.hImageOuchTop:Hide()
		HeadEx.hImageOuchRight:Hide()
		HeadEx.hImageOuchBelow:Show()
		HeadEx.hImageOuchLeft:Show()
		HeadEx.hHandleOuch:SetRelPos(HeadEx.hMainFrame:GetRelPos())
		HeadEx.hHandleOuch:SetAlpha(HeadEx.tLogic.nAttackAlpha)
		HeadEx.nAttackFlashCount = HeadEx.tLogic.nAttackFlash
		return
	end
	if nDirection == DIFFERENCEANGLE.LEFT then
		HeadEx.hImageOuchTop:Hide()
		HeadEx.hImageOuchRight:Hide()
		HeadEx.hImageOuchBelow:Hide()
		HeadEx.hImageOuchLeft:Show()
		HeadEx.hHandleOuch:SetRelPos(HeadEx.hMainFrame:GetRelPos())
		HeadEx.hHandleOuch:SetAlpha(HeadEx.tLogic.nAttackAlpha)
		HeadEx.nAttackFlashCount = HeadEx.tLogic.nAttackFlash
		return
	end
	if nDirection == DIFFERENCEANGLE.TOP_LEFT then
		HeadEx.hImageOuchTop:Show()
		HeadEx.hImageOuchRight:Hide()
		HeadEx.hImageOuchBelow:Hide()
		HeadEx.hImageOuchLeft:Show()
		HeadEx.hHandleOuch:SetRelPos(HeadEx.hMainFrame:GetRelPos())
		HeadEx.hHandleOuch:SetAlpha(HeadEx.tLogic.nAttackAlpha)
		HeadEx.nAttackFlashCount = HeadEx.tLogic.nAttackFlash
		return
	end
end

function HeadEx.GetEnemy(dwEnemyID)
	local targetEnemy = nil
	if IsPlayer(dwEnemyID) then
		targetEnemy = GetPlayer(dwEnemyID)
	else
		targetEnemy = GetNpc(dwEnemyID)
	end
	return targetEnemy
end

function HeadEx.UpdatePlayerState()
	local player = GetClientPlayer()
	if not player then
		return
	end
	HeadEx.hTextHP2:SetText(HeadEx.GetPlayerInfo(PLAYERINFOKIND.HP, HeadEx.tLogic.eNumberDisplayType1, player, true))
	HeadEx.hTextMP2:SetText(HeadEx.GetPlayerInfo(PLAYERINFOKIND.MP, HeadEx.tLogic.eNumberDisplayType1, player, true))
	HeadEx.hTextHP:SetText(HeadEx.GetPlayerInfo(PLAYERINFOKIND.HP, HeadEx.tLogic.eNumberDisplayType2, player, true))
	HeadEx.hTextMP:SetText(HeadEx.GetPlayerInfo(PLAYERINFOKIND.MP, HeadEx.tLogic.eNumberDisplayType2, player, true))
	HeadEx.hImageHP:SetPercentage(HeadEx.GetPlayerInfo(PLAYERINFOKIND.HP, PLAYERINFOTYPE.PERCENT, player, false))
	HeadEx.hImageMP:SetPercentage(HeadEx.GetPlayerInfo(PLAYERINFOKIND.MP, PLAYERINFOTYPE.PERCENT, player, false))
	HeadEx.OnMountKF(this)
	if player.bCanUseBigSword then
    	HeadEx.UpdateCangjianRage()
    end
   
end




function HeadEx.GetPlayerInfo(eKind, eType, player, bNeedText)
local player = GetClientPlayer()
local skill = player.GetKungfuMount()
	if eKind == PLAYERINFOKIND.HP then
		if eType == PLAYERINFOTYPE.MAX then
			return player.nMaxLife
		end
		if eType == PLAYERINFOTYPE.CURRENT then
			return player.nCurrentLife
		end
		if eType == PLAYERINFOTYPE.PERCENT then
			if bNeedText then
				return math.ceil(player.nCurrentLife / player.nMaxLife * 100) .. "%"
			else
				return player.nCurrentLife / player.nMaxLife
			end
		end
		if eType == PLAYERINFOTYPE.ALLINFO then
			return player.nCurrentLife .. " / " .. player.nMaxLife
		end
		return
	end
	if eKind == PLAYERINFOKIND.MP then
		if eType == PLAYERINFOTYPE.MAX then
			return player.nMaxMana
		end
		if eType == PLAYERINFOTYPE.CURRENT then
			return player.nCurrentMana
		end

		--if skill.dwMountType == 6 then --�ؽ��ڹ�
		--player.nMaxMana = player.nMaxRage
		--player.nCurrentMana = player.nCurrentRage
		--elseif skill.dwMountType == 10 then --�����ڹ�
		--player.nMaxMana = player.nMaxEnergy
		--player.nCurrentMana = player.nCurrentEnergy
		--end

		if eType == PLAYERINFOTYPE.PERCENT then
			if bNeedText then
				return math.ceil(player.nCurrentMana / player.nMaxMana * 100) .. "%"
			else
				return player.nCurrentMana / player.nMaxMana
			end
		end
		if eType == PLAYERINFOTYPE.ALLINFO then
			return player.nCurrentMana .. " / " .. player.nMaxMana
		end
		return
	end
end









function HeadEx.GetDirectionIndex(szEventName, dwCaster, dwTarget, bReact, nEffectType, dwID, dwLevel, bCriticalStrike, nDamageType, nValue)
	if szEventName ~= "UI_OME_SKILL_EFFECT_LOG" then
		return
	end
	if nDamageType == SKILL_RESULT_TYPE.THERAPY then
		return
	end
	local player = GetClientPlayer()
	if dwTarget ~= player.dwID then
		return
	end
	local target = HeadEx.GetEnemy(dwCaster)
	if not target then
		return
	end
	--Output(szEventName, dwCaster, dwTarget)
	local nAngle, nDist = HeadEx.GetTwoPointAngle(player.nX, player.nY, target.nX, target.nY)
	local fDifferenceAngle = (player.nFaceDirection / 128 + nAngle) % 2
		
	if (fDifferenceAngle >= 15 * HeadEx.fUnitAngle) or (fDifferenceAngle < HeadEx.fUnitAngle) then
		return DIFFERENCEANGLE.TOP
	elseif (fDifferenceAngle >= HeadEx.fUnitAngle) and (fDifferenceAngle < 3 * HeadEx.fUnitAngle) then
		return DIFFERENCEANGLE.TOP_RIGHT
	elseif (fDifferenceAngle >= 3 * HeadEx.fUnitAngle) and (fDifferenceAngle < 5 * HeadEx.fUnitAngle) then
		return DIFFERENCEANGLE.RIGHT
	elseif (fDifferenceAngle >= 5 * HeadEx.fUnitAngle) and (fDifferenceAngle < 7 * HeadEx.fUnitAngle) then
		return DIFFERENCEANGLE.BELOW_RIGHT
	elseif (fDifferenceAngle >= 7 * HeadEx.fUnitAngle) and (fDifferenceAngle < 9 * HeadEx.fUnitAngle) then
		return DIFFERENCEANGLE.BELOW
	elseif (fDifferenceAngle >= 9 * HeadEx.fUnitAngle) and (fDifferenceAngle < 11 * HeadEx.fUnitAngle) then
		return DIFFERENCEANGLE.BELOW_LEFT
	elseif (fDifferenceAngle >= 11 * HeadEx.fUnitAngle) and (fDifferenceAngle < 13 * HeadEx.fUnitAngle) then
		return DIFFERENCEANGLE.LEFT
	elseif (fDifferenceAngle >= 13 * HeadEx.fUnitAngle) and (fDifferenceAngle < 15 * HeadEx.fUnitAngle) then
		return DIFFERENCEANGLE.TOP_LEFT
	end
	
end

function HeadEx.UpdateSettings()
end

function HeadEx.GetTwoPointAngle(nOX, nOY, nX, nY)
	local fPI = math.pi
	local fTwoPi = math.pi * 2
	
	local nDist = ((nX - nOX) ^ 2 + (nY - nOY) ^ 2) ^ 0.5
	if nDist == 0 then
		return -1
	end
	local nAngle = math.asin((nY - nOY) / nDist)
	if nX < nOX then
		nAngle = fPI + nAngle
	else
		nAngle = fTwoPi - nAngle
	end
	
	return (nAngle % fTwoPi) / fPI, nDist
end


function HeadEx.GetHandles()
	HeadEx.hHandleMain 		= HeadEx.hMainFrame:Lookup("","")
	HeadEx.hDragBG 			= HeadEx.hHandleMain:Lookup("Drag_BG")
	HeadEx.hImageOuchTop 	= HeadEx.hHandleOuch:Lookup("",""):Lookup("Image_Top")
	HeadEx.hImageOuchLeft 	= HeadEx.hHandleOuch:Lookup("",""):Lookup("Image_Left")
	HeadEx.hImageOuchRight 	= HeadEx.hHandleOuch:Lookup("",""):Lookup("Image_Right")
	HeadEx.hImageOuchBelow 	= HeadEx.hHandleOuch:Lookup("",""):Lookup("Image_Below")
	HeadEx.hImageFightFlag 	= HeadEx.hHandleMain:Lookup("FightFlag")
	HeadEx.hImageHP 		= HeadEx.hHandleMain:Lookup("HP")
--	HeadEx.hImageHP2 		= HeadEx.hHandleMain:Lookup("HP2")
	HeadEx.hImageMP 		= HeadEx.hHandleMain:Lookup("MP")
	HeadEx.hTextHP 			= HeadEx.hHandleMain:Lookup("Text_HP")
	HeadEx.hTextHP2 		= HeadEx.hHandleMain:Lookup("Text_HP_2")
	HeadEx.hTextMP 			= HeadEx.hHandleMain:Lookup("Text_MP")
	HeadEx.hTextMP2 		= HeadEx.hHandleMain:Lookup("Text_MP_2")
	HeadEx.hImageHPBG 		= HeadEx.hHandleMain:Lookup("HP_BG")
--	HeadEx.hImageHP2BG 		= HeadEx.hHandleMain:Lookup("HP2_BG")
	HeadEx.hImageMPBG 		= HeadEx.hHandleMain:Lookup("MP_BG")
	HeadEx.hImageOTBG 		= HeadEx.hOTBar:Lookup("",""):Lookup("OT_BG")
	HeadEx.hImageOT 		= HeadEx.hOTBar:Lookup("",""):Lookup("OT")
	HeadEx.hImageOTOK 		= HeadEx.hOTBar:Lookup("",""):Lookup("OT_OK")
	HeadEx.hImageOTBreak 	= HeadEx.hOTBar:Lookup("",""):Lookup("OT_BREAK")
	HeadEx.hTextOT 	= HeadEx.hOTBar:Lookup("",""):Lookup("Text")
end


function HeadEx.ShowSystemPlayerPanel()
	local hSystemPlayerPanel = Player_GetFrame()
	if not hSystemPlayerPanel:IsVisible() then
		hSystemPlayerPanel:Show()
	end
end

function HeadEx.HideSystemPlayerPanel()
	local hSystemPlayerPanel = Player_GetFrame()
	if hSystemPlayerPanel:IsVisible() then
		hSystemPlayerPanel:Hide()
	end
end

function HeadEx.ShowSystemPlayerPanelOnCursor()
	local hSystemPlayerPanel = Player_GetFrame()
	hSystemPlayerPanel:Show()
	local nX, nY = Cursor.GetPos()
	hSystemPlayerPanel:SetRelPos(nX - 40, nY - 40)
end


function HeadEx.HideSystemPlayerPanelOnCursor()
	if HeadEx.tLogic.bHideSystemPlayerPanle then
		Player_GetFrame():SetRelPos(HeadEx.tSystemPlayerPanelPos[1], HeadEx.tSystemPlayerPanelPos[2])
		Player_GetFrame():Hide()
		return
	else
		Player_GetFrame():SetRelPos(HeadEx.tSystemPlayerPanelPos[1], HeadEx.tSystemPlayerPanelPos[2])
	end
end



function HeadEx.OnMountKF(frame)
	local player = GetClientPlayer()
	local skill = player.GetKungfuMount()
	local szShow = ""
	local szShowSub = ""
	if skill then
		if skill.dwMountType == 3 then --�����ڹ�
			szShow = "Handle_ChunYang"
			szShowSub = "CY_"
		elseif skill.dwMountType == 5 then --�����ڹ�
			szShow = "Handle_ShaoLin"
			szShowSub = "SL_"
		elseif skill.dwMountType == 6 then --�ؽ��ڹ�
			szShow = "Handle_CangJian"
			szShowSub = ""
		elseif skill.dwMountType == 10 then --�����ڹ�
			szShow = "Handle_TangMen"
			szShowSub = "TM_"
		elseif skill.dwMountType == 4 then  -- �����ڹ�
			szShow = "Handle_QiXiu"
			szShowSub = "QX_"
		elseif skill.dwMountType== 8 then--����
		 
		  szShow = "Handle_Mingjiao"
			szShowSub = "MJ_"
		  HeadEx.CreateMingjiaoEng()
		
		end
	end
	local handle = frame:Lookup("", "")
	if szShow == "" or HeadEx.bHideMountKF then
		handle:Lookup("Handle_ChunYang"):Hide()
		handle:Lookup("Handle_ShaoLin"):Hide()
		handle:Lookup("Handle_CangJian"):Hide()
		handle:Lookup("Handle_TangMen"):Hide()
		handle:Lookup("Handle_QiXiu"):Hide()
	else
		local aShow =
		{
			"Handle_ChunYang",
			"Handle_ShaoLin",
			"Handle_CangJian",
			"Handle_TangMen",
			"Handle_QiXiu",
			"Handle_Mingjiao"
		
		}
		for k, v in pairs(aShow) do
			if szShow == v then
				handle:Lookup(v):Show()
			else
				handle:Lookup(v):Hide()
			end
		end
	end
	this.szShow = szShow
	this.szShowSub = szShowSub
	
	if szShow == "Handle_ChunYang" or szShow == "Handle_ShaoLin" or szShow == "Handle_QiXiu"then
		HeadEx.OnUpdateAccumulateValue(this)
	elseif szShow == "Handle_CangJian" then
		HeadEx.UpdateCangjianRage()
	elseif szShow == "Handle_TangMen" then
		HeadEx.OnUpdateTangmenEnergy(this)
	end
	
	
	
end

function HeadEx.OnUpdateAccumulateValue(frame)
	if not frame.szShow or frame.szShow == "" then
		return
	end
	local handle = frame:Lookup("", frame.szShow)
	if handle then
		local nValue = GetClientPlayer().nAccumulateValue
		if nValue < 0 then
			nValue = 0
		end
		if frame.szShow == "Handle_ShaoLin" then
			if nValue > 3 then
				nValue = 3
			end
			local szSub = frame.szShowSub
			for i = 1, nValue, 1 do
				handle:Lookup(szSub..i):Show()
			end
			for i = nValue + 1, 3, 1 do
				handle:Lookup(szSub..i):Hide()
			end
		elseif frame.szShow == "Handle_ChunYang" then
			if nValue > 10 then
				nValue = 10
			end
			nValue = nValue + 1
			local szSub = frame.szShowSub
			local aShow = HeadEx.tPlayerAccumulate.aAccumulateShow[nValue]
			local aHide = HeadEx.tPlayerAccumulate.aAccumulateHide[nValue]
			for k, v in pairs(aShow) do
				handle:Lookup(szSub..v):Show()
			end
			for k, v in pairs(aHide) do
				handle:Lookup(szSub..v):Hide()
			end
		elseif frame.szShow == "Handle_QiXiu" then
			local hText = handle:Lookup("Text_Layer")
			local hImage = handle:Lookup("Image_QX_Btn")
			if nValue > 10 then
				nValue = 10
			end
			if nValue > 0 then 
				hText:SetText(nValue)
				hText:Show()
				hImage.bChecked = true
			else
				hText:Hide()
				hImage.bChecked = false
			end
			UpdataQiXiuImage(hImage)
			
			local szSub = frame.szShowSub
			for i = 1, nValue, 1 do
				handle:Lookup(szSub..i):Show()
			end
			for i = nValue + 1, 10, 1 do
				handle:Lookup(szSub..i):Hide()
			end
		end
	end
end

function HeadEx.OnUpdateTangmenEnergy(frame)
    local hTangmen = HeadEx.hHandleMain:Lookup("Handle_TangMen")
	if not frame.szShow or frame.szShow ~= "Handle_TangMen" then
		return
	end
	
	local hList = frame:Lookup("", "Handle_TangMen")
	local textNumber = hList:Lookup("Text_Energy")
	local imgEnergy = hList:Lookup("Image_Strip")
	local imgFrame = hList:Lookup("Image_Frame")
	--nMaxEnergy
	--nCurrentEnergy
	--nEnergyReplenish
	local player = GetClientPlayer();
	if player.nMaxEnergy > 0 then
		local fPer = player.nCurrentEnergy / player.nMaxEnergy
		imgEnergy:SetPercentage(fPer)
--		if IsShowStateValueByPercentage() then
--	    	textNumber:SetText(string.format("%d%%", 100 * fPer))
--	    else
	    	textNumber:SetText(player.nCurrentEnergy .. "/" .. player.nMaxEnergy)
--	    end
	else
		imgEnergy:SetPercentage(0)
	    textNumber:SetText("")
	end
end
   
   
function HeadEx.UpdateCangjianRage()
	local hCangjian = HeadEx.hHandleMain:Lookup("Handle_CangJian")
	if not hCangjian then
		return
	end
	local hPlayer = GetClientPlayer()
    local hImageShort = hCangjian:Lookup("Image_Short")
    local hTextShort = hCangjian:Lookup("Text_Short")
    local hAniShort = hCangjian:Lookup("Animate_Short")
    local hImageLong = hCangjian:Lookup("Image_Long")
    local hTextLong = hCangjian:Lookup("Text_Long")
    local hAniLong = hCangjian:Lookup("Animate_Long")
    local szShow = nil

    if hPlayer.nMaxRage > 100 then
	    hImageShort:Hide()
	    hTextShort:Hide()
   		hAniShort:Hide()

	    hImageLong:Show()
	    hTextLong:Show()
   		hAniLong:Show()
   		
   		szShow = "Long"
    else	    
	    hImageShort:Show()
	    hTextShort:Show()
	    hAniShort:Show()
	    
	    hImageLong:Hide()
	    hTextLong:Hide()
   		hAniLong:Hide()
   		
   		szShow = "Short"
    end
    
    if hPlayer.nMaxRage > 0 then
    	local fRage = hPlayer.nCurrentRage / hPlayer.nMaxRage
    	
    	hCangjian:Lookup("Image_"..szShow):SetPercentage(fRage)
    	
--	    if IsShowStateValueByPercentage() then
--	    	hCangjian:Lookup("Text_"..szShow):SetText(string.format("%d%%", 100 * fRage))
--	    else
	    	hCangjian:Lookup("Text_"..szShow):SetText(hPlayer.nCurrentRage .. "/" .. hPlayer.nMaxRage)
--	    end
--    else
--	    hCangjian:Lookup("Image_"..szShow):SetPercentage(0)
--	    hCangjian:Lookup("Text_"..szShow):SetText("")
    end
end

function HeadEx.OnItemMouseEnter()
	local szName = this:GetName()
	if szName == "Image_QX_Btn" then
		this.bInside = true
		UpdataQiXiuImage(this)
	end
end

function HeadEx.OnItemMouseLeave()
--	HideTip()
	local szName = this:GetName()
	if szName == "Image_QX_Btn" then
		local nAccumulateValue = GetClientPlayer().nAccumulateValue
		this.bInside = false
		UpdataQiXiuImage(this)
	end
end

function HeadEx.OnLButtonClick()
	local szName = this:GetName()
	
	if szName == "Btn_RoleChange" then
		HeadEx.OnItemRButtonDown()
	end
end

function HeadEx.OnItemLButtonUp()
	if this:GetName() == "Image_QX_Btn" then
		local nAccumulateValue = GetClientPlayer().nAccumulateValue
		if nAccumulateValue == 0 then 
--			OnUseSkill(537, 0)
            OnAddOnUseSkill(537, 0)
		else
			local buffList = GetClientPlayer().GetBuffList()
			local dwIndex
			for _,v in pairs(buffList) do
				if v.dwID == 409 then 
					dwIndex = v.nIndex
					break
				end
			end
			if dwIndex then 
				GetClientPlayer().CancelBuff(dwIndex)
			end
		end
		this.bClickDown = false
		UpdataQiXiuImage(this)
		return 
	end
end

function HeadEx.OnItemLButtonDown()
	if this:GetName() == "Image_QX_Btn" then
		this.bClickDown = true
		UpdataQiXiuImage(this)
		return 
	end

--	SelectSelf()
end

function HeadEx.Init()	
	HeadEx.GetHandles()
	HeadEx.hImageHPBG:SetAlpha(100)
	HeadEx.hImageMPBG:SetAlpha(100)
	HeadEx.hImageOTBG:SetAlpha(100)
	--HeadEx.hHandleMain:Lookup("Text_HP_2"):SetAlpha(180)
	--HeadEx.hHandleMain:Lookup("Text_MP_2"):SetAlpha(180)	
	HeadEx.hDragBG:Hide()
	HeadEx.hImageOuchTop:Hide()
	HeadEx.hImageOuchLeft:Hide()
	HeadEx.hImageOuchRight:Hide()
	HeadEx.hImageOuchBelow:Hide()  	
	HeadEx.hImageFightFlag:Hide()
	HeadEx.hOTBar:Hide()
	HeadEx.hMainFrame:SetMousePenetrable(true)
	HeadEx.hOTBar:SetMousePenetrable(true)
	HeadEx.UpdatePos()
	HeadEx.UpdatePlayerState()
end

--function HeadEx.HideMountKF()
--if HeadEx.bHideMountKF() then
 --                       HeadEx.hHandleMain:Lookup("Handle_ChunYang"):Hide()
--		                HeadEx.hHandleMain:Lookup("Handle_ShaoLin"):Hide()
--		                HeadEx.hHandleMain:Lookup("Handle_CangJian"):Hide()
--		                HeadEx.hHandleMain:Lookup("Handle_TangMen"):Hide()
--		                HeadEx.hHandleMain:Lookup("Handle_QiXiu"):Hide()
--						end
--end


function HeadEx.CreateWindow()
	if IsOptionOrOptionChildPanelOpened() then
		return
	end
	HeadEx.hHandleOuch = Station.Lookup("Normal/HeadExOuch")
	if not HeadEx.hHandleOuch then
		HeadEx.hHandleOuch = Wnd.OpenWindow("Interface\\HeadEx\\LEOConst_HeadExOuch.ini", "HeadExOuch")
		HeadEx.hHandleOuch:SetAlpha(0)
	end
	HeadEx.hBtnSettings = Station.Lookup("Normal/HeadExSettings")
	if not HeadEx.hBtnSettings then
		HeadEx.hBtnSettings = Wnd.OpenWindow("Interface\\HeadEx\\LEOConst_HeadExSettings.ini", "HeadExSettings")
	end
	HeadEx.hOTBar = Station.Lookup("Normal/HeadExOTBar")
	if not HeadEx.hOTBar then
		HeadEx.hOTBar = Wnd.OpenWindow("Interface\\HeadEx\\LEOConst_HeadExOT.ini", "HeadExOTBar")
	end	
	HeadEx.hMainFrame = Station.Lookup("Normal/HeadEx")
	if not HeadEx.hMainFrame then
		HeadEx.hMainFrame = Wnd.OpenWindow("Interface\\HeadEx\\LEOConst_HeadEx.ini", "HeadEx")
	end
	
	HeadEx.Init()
end


function HeadEx.CreateMingjiaoEng()


SunMoonBar = SunMoonBar or {} SunMoonBar.tAnchor = { s = "LEFT", r = "LEFT", x = 500, y = 600 } RegisterCustomData("SunMoonBar.tAnchor") function SunMoonBar.OnFrameCreate() this:RegisterEvent("UI_SCALED") this:RegisterEvent("CUSTOM_DATA_LOADED") this:RegisterEvent("ON_ENTER_CUSTOM_UI_MODE") this:RegisterEvent("ON_LEAVE_CUSTOM_UI_MODE") end function SunMoonBar.OnEvent(SunMoonBar_d0708241b607c9a9dd1953c812fadfb7) if SunMoonBar_d0708241b607c9a9dd1953c812fadfb7=="UI_SCALED" or (SunMoonBar_d0708241b607c9a9dd1953c812fadfb7 == "CUSTOM_DATA_LOADED" and arg0 == "Role") then SunMoonBar.UpdateAnchor(this) elseif SunMoonBar_d0708241b607c9a9dd1953c812fadfb7 == "ON_ENTER_CUSTOM_UI_MODE" or SunMoonBar_d0708241b607c9a9dd1953c812fadfb7 == "ON_LEAVE_CUSTOM_UI_MODE" then UpdateCustomModeWindow(this, "By����-������") end end function SunMoonBar.OnFrameDragEnd() this:CorrectPos() SunMoonBar.tAnchor = GetFrameAnchor(this) end function SunMoonBar.UpdateAnchor(SunMoonBar_411b8aa6d5954c6020f0b9c9e80e847a) local SunMoonBar_14bd3b46801c67a61cdc231d79a52920 = SunMoonBar.tAnchor SunMoonBar_411b8aa6d5954c6020f0b9c9e80e847a:SetPoint(SunMoonBar_14bd3b46801c67a61cdc231d79a52920.s, 0, 0, SunMoonBar_14bd3b46801c67a61cdc231d79a52920.r, SunMoonBar_14bd3b46801c67a61cdc231d79a52920.x, SunMoonBar_14bd3b46801c67a61cdc231d79a52920.y) SunMoonBar_411b8aa6d5954c6020f0b9c9e80e847a:CorrectPos() end function SunMoonBar.OnFrameBreathe() local SunMoonBar_9079f2d9a7f2ed42e963268a5fe794de = Player_GetFrame() local SunMoonBar_f8dfb471cc5fc0cb3ef47a4f1021cbad = SunMoonBar_9079f2d9a7f2ed42e963268a5fe794de:Lookup("", "") local SunMoonBar_af80f8086fe03c9bb7eb4367176c2d92 = SunMoonBar_f8dfb471cc5fc0cb3ef47a4f1021cbad:Lookup("Handle_MingJiao") local SunMoonBar_8871e6d2e6da5db055f2d5aab3c441f0 = SunMoonBar_af80f8086fe03c9bb7eb4367176c2d92:Lookup("Image_MingJiaoBG1") if not SunMoonBar_8871e6d2e6da5db055f2d5aab3c441f0:IsVisible() then return end local SunMoonBar_f5c83829ece2b55ceb31a1fc1f1a9e9b = SunMoonBar_af80f8086fe03c9bb7eb4367176c2d92:Lookup("Image_SunCao") local SunMoonBar_cacd84fb5e38aa04ae16dc290dccffc9 = SunMoonBar_af80f8086fe03c9bb7eb4367176c2d92:Lookup("Image_MoonCao") local SunMoonBar_5ad5adfd9e8fdf8fcf6365730b9d4c21 = SunMoonBar_af80f8086fe03c9bb7eb4367176c2d92:Lookup("Image_MingJiaoBG2") local SunMoonBar_058504b6b3b4b7693a0465d8642c352b = SunMoonBar_af80f8086fe03c9bb7eb4367176c2d92:Lookup("Image_SunEnergy") local SunMoonBar_4fceeabf3ca20b532aef97fa099cdbcb = SunMoonBar_af80f8086fe03c9bb7eb4367176c2d92:Lookup("Image_MoonEnergy") local SunMoonBar_413b0d3ca9dce4ba4e7d00a1383048d5 = SunMoonBar_af80f8086fe03c9bb7eb4367176c2d92:Lookup("Image_SunBG") local SunMoonBar_5d5a5a41cfabd957f3754ba46322f013 = SunMoonBar_af80f8086fe03c9bb7eb4367176c2d92:Lookup("Image_MoonBG") local SunMoonBar_d32881fdf2d03ee3687dedf672540a9b = SunMoonBar_af80f8086fe03c9bb7eb4367176c2d92:Lookup("Animate_SunValue") local SunMoonBar_f073ea0c502492fea8eaa34c0c0eb9fb = SunMoonBar_af80f8086fe03c9bb7eb4367176c2d92:Lookup("Animate_MoonValue") local SunMoonBar_6cca4d253093d36b7439e73fbfc95185 = this:Lookup("", "") local SunMoonBar_79ef840f70eb175338a37c1b48aaa8d3 = SunMoonBar_6cca4d253093d36b7439e73fbfc95185:Lookup("Handle_MingJiao") local SunMoonBar_f78966a9e0a9c83602c32b2ce0a21687 = SunMoonBar_79ef840f70eb175338a37c1b48aaa8d3:Lookup("Image_SunCao") local SunMoonBar_2647e7eea5c52dfa9339acfd223e58ac = SunMoonBar_79ef840f70eb175338a37c1b48aaa8d3:Lookup("Image_MoonCao") local SunMoonBar_a5a899ce277fc62adc7f1bada27092c2 = SunMoonBar_79ef840f70eb175338a37c1b48aaa8d3:Lookup("Image_MingJiaoBG2") local SunMoonBar_4cf3f008bb76daf70b2139c894a9b9e5 = SunMoonBar_79ef840f70eb175338a37c1b48aaa8d3:Lookup("Image_SunEnergy") local SunMoonBar_685bb4ac44f964019b424c232cf87f8b = SunMoonBar_79ef840f70eb175338a37c1b48aaa8d3:Lookup("Image_MoonEnergy") local SunMoonBar_3efe01cdb29694618cd1f1fe0a6c206b = SunMoonBar_79ef840f70eb175338a37c1b48aaa8d3:Lookup("Image_SunBG") local SunMoonBar_70badab8f2a003487613306633d218f3 = SunMoonBar_79ef840f70eb175338a37c1b48aaa8d3:Lookup("Image_MoonBG") local SunMoonBar_b2c90dd8b35ab3c59bf27d2fe5b57165 = SunMoonBar_79ef840f70eb175338a37c1b48aaa8d3:Lookup("Animate_SunValue") local SunMoonBar_0927a4d3f36bd01250cf186a619b2f3b = SunMoonBar_79ef840f70eb175338a37c1b48aaa8d3:Lookup("Animate_MoonValue") if SunMoonBar_f5c83829ece2b55ceb31a1fc1f1a9e9b:IsVisible() then SunMoonBar_f78966a9e0a9c83602c32b2ce0a21687:Show() else SunMoonBar_f78966a9e0a9c83602c32b2ce0a21687:Hide() end if SunMoonBar_cacd84fb5e38aa04ae16dc290dccffc9:IsVisible() then SunMoonBar_2647e7eea5c52dfa9339acfd223e58ac:Show() else SunMoonBar_2647e7eea5c52dfa9339acfd223e58ac:Hide() end if SunMoonBar_058504b6b3b4b7693a0465d8642c352b:IsVisible() then SunMoonBar_4cf3f008bb76daf70b2139c894a9b9e5:Show() local SunMoonBar_5963e04a46e0a7bacc76fdf58e73d643 = SunMoonBar_058504b6b3b4b7693a0465d8642c352b:GetPercentage() SunMoonBar_4cf3f008bb76daf70b2139c894a9b9e5:SetPercentage(SunMoonBar_5963e04a46e0a7bacc76fdf58e73d643) else SunMoonBar_4cf3f008bb76daf70b2139c894a9b9e5:Hide() SunMoonBar_4cf3f008bb76daf70b2139c894a9b9e5:SetPercentage(0) end if SunMoonBar_4fceeabf3ca20b532aef97fa099cdbcb:IsVisible() then SunMoonBar_685bb4ac44f964019b424c232cf87f8b:Show() local SunMoonBar_5963e04a46e0a7bacc76fdf58e73d643 = SunMoonBar_4fceeabf3ca20b532aef97fa099cdbcb:GetPercentage() SunMoonBar_685bb4ac44f964019b424c232cf87f8b:SetPercentage(SunMoonBar_5963e04a46e0a7bacc76fdf58e73d643) else SunMoonBar_685bb4ac44f964019b424c232cf87f8b:Hide() SunMoonBar_685bb4ac44f964019b424c232cf87f8b:SetPercentage(0) end if SunMoonBar_5ad5adfd9e8fdf8fcf6365730b9d4c21:IsVisible() then SunMoonBar_a5a899ce277fc62adc7f1bada27092c2:Show() else SunMoonBar_a5a899ce277fc62adc7f1bada27092c2:Hide() end if SunMoonBar_413b0d3ca9dce4ba4e7d00a1383048d5:IsVisible() then SunMoonBar_3efe01cdb29694618cd1f1fe0a6c206b:Show() else SunMoonBar_3efe01cdb29694618cd1f1fe0a6c206b:Hide() end if SunMoonBar_5d5a5a41cfabd957f3754ba46322f013:IsVisible() then SunMoonBar_70badab8f2a003487613306633d218f3:Show() else SunMoonBar_70badab8f2a003487613306633d218f3:Hide() end if SunMoonBar_d32881fdf2d03ee3687dedf672540a9b:IsVisible() then SunMoonBar_b2c90dd8b35ab3c59bf27d2fe5b57165:Show() else SunMoonBar_b2c90dd8b35ab3c59bf27d2fe5b57165:Hide() end if SunMoonBar_f073ea0c502492fea8eaa34c0c0eb9fb:IsVisible() then SunMoonBar_0927a4d3f36bd01250cf186a619b2f3b:Show() else SunMoonBar_0927a4d3f36bd01250cf186a619b2f3b:Hide() end end 

Wnd.OpenWindow("Interface\\HeadEx\\SunMoonBar.ini", "SunMoonBar") 


end








HeadEx.CreateWindow()

