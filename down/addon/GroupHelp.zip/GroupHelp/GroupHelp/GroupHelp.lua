GroupHelp={}
GroupHelp.tHeadSet={}
GroupHelp.tNowHave={}
GroupHelp.tNowNeed={}
GroupHelp.tAnyCreateInfo={}
GroupHelp.nBreatheFrame=0
GroupHelp.tDelayCall={}
GroupHelp.nAlpha=0
--����Text
--����˵����Ҫ����Text��Handle,��Text�ؼ��������ϣ�������(���)������ID���ı�]]--
function GroupHelp.AddText(tHandle,NewTextName,tX,tY,tW,tH,tFontID,tText)
	local NewText=tHandle:AppendItemFromIni("interface\\GroupHelp\\GroupHelp_Stencil.ini","Text_Stencil","Txt_"..NewTextName)
	NewText:SetRelPos(tX,tY)
	NewText:SetSize(tW,tH)
	NewText:SetFontScheme(tFontID)
	NewText:SetText(tText)
	tHandle:FormatAllItemPos()
end
--����Image
--����˵����Ҫ����Image��Handle����Image�ؼ��������ϣ�������(���),IconID(int) �� Uitex·��(string),���� �� ֡��,͸����,]]--
function GroupHelp.AddImage(tHandle,NewImgName,tX,tY,tW,tH,tImgPath,tFrameNum,tAlpha)
	local NewImg=tHandle:AppendItemFromIni("interface\\GroupHelp\\GroupHelp_Stencil.ini","Image_Stencil","Img_"..NewImgName)
	NewImg:SetRelPos(tX,tY)
	NewImg:SetSize(tW,tH)
	if type(tImgPath)=="string" then
		NewImg:FromUITex(tImgPath,tFrameNum)
	else
		NewImg:FromIconID(tImgPath)
	end
	NewImg:SetAlpha(tAlpha)
	tHandle:FormatAllItemPos()
end
--����WndEdit
--����˵����Ҫ����WndEdit��Wnd�ؼ�,ģ��ini�ļ�·����ģ��ĸ�����(��Frame)��ģ��WndEdit�ؼ���,��WndEdit�ؼ���,���ϣ�������(���),������볤��,�����ı�����(int)]]--
function GroupHelp.AddEditBox(tWnd,tEditName,tX,tY,tW,tH,tLimit,tType)
	local TempFrame = Wnd.OpenWindow("interface\\GroupHelp\\GroupHelp_Stencil.ini","GroupHelp_Stencil")
	local NewEdit = TempFrame:Lookup("Edit_Stencil")
	NewEdit:ChangeRelation(tWnd,true,true)
	Wnd.CloseWindow(TempFrame)
	NewEdit:SetName("Edt_"..tEditName)
	NewEdit:SetRelPos(tX,tY)
	NewEdit:SetSize(tW,tH)
	NewEdit:SetLimit(tLimit)
	NewEdit:SetType(tType)
	if tLimit>30 then
		NewEdit:SetMultiLine(true)
	end
end
--����WndButton  ע��·��˫\\sIni,sFrame,sBtnName,="interface\\GroupHelp\\GroupHelp_Stencil.ini","GroupHelp_Stencil","Btn_Stencil",
--����˵����Ҫ����Button��Wnd�ؼ�,��Button�ؼ���,���ϣ�������(���),��ť����]]--
function GroupHelp.AddBtnBox(tWnd,tBtnName,tX,tY,tW,tH,tBtnText)
	local TempFrame = Wnd.OpenWindow("interface\\GroupHelp\\GroupHelp_Stencil.ini","GroupHelp_Stencil")
	local NewBtn = TempFrame:Lookup("Btn_Stencil")
	NewBtn:ChangeRelation(tWnd,true,true)
	Wnd.CloseWindow(TempFrame)
	NewBtn:SetName("Btn_"..tBtnName)
	NewBtn:SetRelPos(tX,tY)
	NewBtn:SetSize(tW,tH)
	local BtnHandle = NewBtn:Lookup("","")
	local BtnText = BtnHandle:Lookup("Text_Btn")
	BtnHandle:SetSize(tW,tH)
	BtnText:SetSize(tW,tH)
	BtnText:SetText(tBtnText)
end
function GroupHelp.Alert(sAlert)
	GroupHelp.nAlpha=240
	Station.Lookup("Topmost2/GroupHelp"):SetAlpha(GroupHelp.nAlpha)
	Station.Lookup("Topmost2/GroupHelp"):Lookup("",""):Lookup("Text_Alert"):SetText(sAlert)
end
function GroupHelp.UISwitch()
	if Station.Lookup("Normal/GroupHelp_Create")~=nil then
		Wnd.CloseWindow("GroupHelp_Create")
		return
	elseif Station.Lookup("Normal/GroupHelp_Search")~=nil then
		Wnd.CloseWindow("GroupHelp_Search")
		return
	elseif Station.Lookup("Normal/GroupHelp_Show")~=nil then
		Wnd.CloseWindow("GroupHelp_Show")
		return
	end
	if GetClientPlayer().IsInParty() then
		if GetClientPlayer().IsPartyLeader() then
			Wnd.OpenWindow("Interface/GroupHelp/GroupHelp_Create.ini", "GroupHelp_Create")
		else
			GroupHelp.Alert("�������Ŷ���,��Ա��������������")
		end
	else
		local nClientW, nClientH = Station.GetClientSize()
		local tMsg = {
			x = nClientW / 2,
			y = nClientH / 2-200,
			szMessage = "                   �������",
			szName = "GroupHelp_Choose",
			{
				szOption = "����",
				fnAction = function() Wnd.OpenWindow("Interface/GroupHelp/GroupHelp_Create.ini", "GroupHelp_Create") end,
			},
			{
				szOption = "����",
				fnAction = function() Wnd.OpenWindow("Interface/GroupHelp/GroupHelp_Search.ini", "GroupHelp_Search") end,
			},
		}
		MessageBox(tMsg)
	end
end
function GroupHelp.TalkMonitor()
	local tTalkData=GetClientPlayer().GetTalkData()
	local bUsTalk,sCode,sMsgMain=GroupHelp.MsgFilt(tTalkData,arg3)
	if not bUsTalk then return end
	local sChannel=GroupHelp.GetChannel(arg1)
	if arg3==GetClientPlayer().szName then
		if sChannel=="WORLD" then GroupHelp_Talk.bHadTalkInWorld=true end
		if sMsgMain=="������" then
				GroupHelp.tHeadSet={}
				GroupHelp.tNowHave={}
				GroupHelp.tNowNeed={}
				Wnd.CloseWindow("GroupHelp_Talk")
				GetClientPlayer().Talk(PLAYER_TALK_CHANNEL.RAID,"",{{type="text",text = "�������,ȫ������"}})
				GroupHelp.Alert("����������,ҡ�ڰ�ɧ�����")
		else
			local nMinTalkDelay=-1
			for i,j in pairs(GroupHelp.tHeadSet.Channel) do
				if i==sChannel then
					GroupHelp.tHeadSet.Channel[i]=GroupHelp.nBreatheFrame+2*60*16
				end
				if nMinTalkDelay==-1 then
					nMinTalkDelay=GroupHelp.tHeadSet.Channel[i]
				elseif GroupHelp.tHeadSet.Channel[i] < nMinTalkDelay then
					nMinTalkDelay=GroupHelp.tHeadSet.Channel[i]
				end
			end
			if nMinTalkDelay > GroupHelp.nBreatheFrame then
				GroupHelp_Talk.SetBtnTalk_UN()
				local nDelayFrame=nMinTalkDelay-GroupHelp.nBreatheFrame
				GroupHelp.DelayCall(nDelayFrame,GroupHelp_Talk.SetBtnTalk_EN)
			end
		end
		return
	end
	if sCode==" " then
		if sChannel then
			if sMsgMain=="������" then
				GroupHelp.tAnyCreateInfo[arg3]=nil
			else
				GroupHelp.WriteCreateTalkInfo(arg3,sChannel,sMsgMain)
			end
		end
	elseif sCode=="1" then
		if arg1 == PLAYER_TALK_CHANNEL.WHISPER
		 and GroupHelp.SubDwString(sMsgMain,2,"��")=="�������" then
			GroupHelp.UpdateNowNeed()
			local sHisKungfuAcronym = GroupHelp.SubDwString(sMsgMain,1,"��")
			local sHisKungfuType = GroupHelp.GetKungfuType(sHisKungfuAcronym)
			for i=1,21 do
				if GroupHelp.tNowNeed[i][1]==sHisKungfuAcronym
				 or GroupHelp.tNowNeed[i][1]==sHisKungfuType then
					if GroupHelp.tNowNeed[i][2]>0 then
						local InviteTeam
						local tMenu = {}
						InsertInviteTeamMenu(tMenu,arg3)
						for _,v in pairs(tMenu) do
							if v.szOption=="���" then
								InviteTeam=v.fnAction
							end
						end
						InviteTeam()
						return
					end
				end
			end
		end
	end
end
function GroupHelp.OnFrameCreate()
	this:RegisterEvent("PLAYER_TALK")
	this:RegisterEvent("SYNC_ROLE_DATA_END")
end
function GroupHelp.OnFrameBreathe()
	GroupHelp.nBreatheFrame = GroupHelp.nBreatheFrame + 1
	if GroupHelp.nBreatheFrame % 3 == 0 then
		for i, v in pairs(GroupHelp.tDelayCall) do
			if GroupHelp.nBreatheFrame > v[1] then
				pcall(v[2])
				table.remove(GroupHelp.tDelayCall,i)
			end
		end
		if GroupHelp.nAlpha >= 0 then
			GroupHelp.UpdateAlpha()
		end
	end
end
function GroupHelp.OnEvent(event)
	if event=="PLAYER_TALK" then
		GroupHelp.TalkMonitor()
	elseif event=="SYNC_ROLE_DATA_END" then
		Station.Lookup("Topmost2/GroupHelp"):SetPoint("CENTER", 0, 0, "CENTER", 0, -200)
	end
end
function GroupHelp.MsgFilt(tTalkData,sTalkerName)
	for i,v in pairs(tTalkData) do
		if v.type == "text" then
			if string.sub(v.text,1,3)=="*v*" then
				local a,b = string.find(v.text,sTalkerName,5)
				if a==5 then
					local sTalkCode=string.sub(v.text,4,4)
					local sMsgMain = string.sub(v.text,b+2)
					return true,sTalkCode,sMsgMain
				end
			end
		end
	end
	return false
end
function GroupHelp.GetChannel(n)
	for i,v in pairs(GroupHelp_Talk.tTalkChannelHeader) do
		if PLAYER_TALK_CHANNEL[i] == n then
			return i
		end
	end
end
function GroupHelp.WriteCreateTalkInfo(sTalkerName,sChannel,sMsg)
	local tTime=GroupHelp.GetTime()
	if GroupHelp.tAnyCreateInfo[sTalkerName]==nil then
		GroupHelp.tAnyCreateInfo[sTalkerName]={["Channel"]={sChannel},["Time"]=tTime,["MainMsg"]=sMsg,}
	else
		if not GroupHelp.HadThisChannel(sTalkerName,sChannel) then
			table.insert(GroupHelp.tAnyCreateInfo[sTalkerName]["Channel"],sChannel)
		end
		GroupHelp.tAnyCreateInfo[sTalkerName]["MainMsg"]=sMsg
		GroupHelp.tAnyCreateInfo[sTalkerName]["Time"]=tTime
	end
end
function GroupHelp.HadThisChannel(sTalkerName,sChannel)
	for _,s in pairs(GroupHelp.tAnyCreateInfo[sTalkerName]["Channel"]) do
		if s==sChannel then
			return true
		end
	end
	return false
end
function GroupHelp.GetTime()
	local nTime=GetCurrentTime()
	local tTime=TimeToDate(nTime)
	return {tTime.hour, tTime.minute, tTime.second}
end
function GroupHelp.GetKungfuType(sMyKungfu)
	local sTail = string.sub(sMyKungfu,3)
	if sTail=="t" then
		return "TPS"
	elseif sTail=="n" then
		return "HPS"
	else
		return "DPS"
	end
end
function GroupHelp.SubDwString(sSource,nDW,sPartern)
	local nParternLen=string.len(sPartern)
	if nDW==1 then
		nBreakPoint = string.find(sSource,sPartern)
		return string.sub(sSource,0,nBreakPoint-1)
	end
	local nBreakPoint = -2
	for i=1,nDW-1 do
		nBreakPoint = string.find(sSource,sPartern,nBreakPoint+nParternLen)
	end
	local sNew=string.sub(sSource,nBreakPoint+nParternLen)
	nBreakPoint = string.find(sNew,sPartern)
	if nBreakPoint then
		sNew=string.sub(sNew,0,nBreakPoint-1)
	end
	return sNew
end
function GroupHelp.UpdateNowHave()
	GroupHelp.tNowHave={}
	local Team = GetClientTeam()
	local tMemberList=Team.GetTeamMemberList()
	for i,v in pairs(tMemberList) do
		local tMemberInfo=Team.GetMemberInfo(v)
		local nMemberKungfuID = tMemberInfo.dwMountKungfuID
		local sMemberKungfuName=Table_GetSkillName(nMemberKungfuID,0)
		local sMemberKungfuAcronym = GroupHelp.GetMyKungfuAcronym(sMemberKungfuName)
		table.insert(GroupHelp.tNowHave,v,sMemberKungfuAcronym)
	end
end
function GroupHelp.UpdateNowNeed()
	GroupHelp.UpdateNowHave()
	GroupHelp.tNowNeed=clone(GroupHelp.tHeadSet["School"])
	for i,v in pairs(GroupHelp.tNowHave) do
		if v~=""then
			local sKungfuAcronym=v
			for m,n in pairs(GroupHelp.tNowNeed) do
				if n[1]==sKungfuAcronym then
					if n[2]>0 then
						GroupHelp.tNowNeed[m][2]=GroupHelp.tNowNeed[m][2]-1
					else
						local sKungfuType=GroupHelp.GetKungfuType(sKungfuAcronym)
						for p,q in pairs(GroupHelp.tNowNeed) do
							if q[1]==sKungfuType then
								if q[2]>0 then
									GroupHelp.tNowNeed[p][2]=GroupHelp.tNowNeed[p][2]-1
								else
									GroupHelp.Alert("��ӹ����ж�Ա�л��ڹ����³�Ա���ɳ���")
								end
							end
						end
					end
				end
			end
		end
	end
end
function GroupHelp.GetMemberKungfuName(nPlayerID)
	local Team = GetClientTeam()
	local tMemberInfo=Team.GetMemberInfo(nPlayerID)
	local nMemberKungfuID = tMemberInfo.dwMountKungfuID
	local sMemberKungfuName=Table_GetSkillName(nMemberKungfuID,0)
	return sMemberKungfuName
end
function GroupHelp.GetMyKungfuAcronym(sKungfuName)
	local sAcronym=""
	for i,v in pairs(GroupHelp_Create.EdtInfo["School"]) do
		if v[8]==sKungfuName then
			sAcronym=v[1]
			break
		end
	end
	if sKungfuName=="��ˮ��" then sAcronym="CJ" end
	return sAcronym
end

function GroupHelp.DelayCall(nFrame, fun)
	local nCallFrame = GroupHelp.nBreatheFrame + nFrame
	local tDelayInfo = {nCallFrame, fun}
	table.insert(GroupHelp.tDelayCall, tDelayInfo)
end
function GroupHelp.UpdateAlpha()
	Station.Lookup("Topmost2/GroupHelp"):SetAlpha(GroupHelp.nAlpha)
	GroupHelp.nAlpha=GroupHelp.nAlpha-20
end
Hotkey.AddBinding("GroupHelpUISwitch","�������","�������",GroupHelp.UISwitch,nil)
Wnd.OpenWindow("Interface/GroupHelp/GroupHelp.ini", "GroupHelp")
