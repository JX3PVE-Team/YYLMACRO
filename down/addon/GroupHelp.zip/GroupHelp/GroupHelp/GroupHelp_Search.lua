GroupHelp_Search={
	["ACL_H"]="���л",
	["ACL_X"]="����Ƶ��",
}
GroupHelp_Search.tTrans={
	["����Ƶ��"]="FRIENDS",
	["���Ƶ��"]="TONG",
	["ͬ��Ƶ��"]="TONG_ALLIANCE",
	["��ӪƵ��"]="CAMP",
	["����Ƶ��"]="WORLD",
}
GroupHelp_Search.nHICount=0
GroupHelp_Search.tIApply={}
GroupHelp_Search.Menu_ACL_HDLX={
	{szOption="���л",fnAction=function() GroupHelp_Search.Menu_ACL_HDLXClick(this) end},
	{szOption="PVP",
		{szOption="10���ƺ�",fnAction=function() GroupHelp_Search.Menu_ACL_HDLXClick(this) end},
		{szOption="15����ũ",fnAction=function() GroupHelp_Search.Menu_ACL_HDLXClick(this) end},
		{szOption="25�˾Ź�",fnAction=function() GroupHelp_Search.Menu_ACL_HDLXClick(this) end},
		{szOption="25��˿·",fnAction=function() GroupHelp_Search.Menu_ACL_HDLXClick(this) end},
	},
	{szOption="����",fnAction=function() GroupHelp_Search.Menu_ACL_HDLXClick(this) end},
}
GroupHelp_Search.Menu_ACL_XXLY={
	{szOption="����Ƶ��",fnAction=function() GroupHelp_Search.Menu_ACL_XXLYClick(this) end},
	{szOption="����Ƶ��",fnAction=function() GroupHelp_Search.Menu_ACL_XXLYClick(this) end},
	{szOption="���Ƶ��",fnAction=function() GroupHelp_Search.Menu_ACL_XXLYClick(this) end},
	{szOption="ͬ��Ƶ��",fnAction=function() GroupHelp_Search.Menu_ACL_XXLYClick(this) end},
	{szOption="��ӪƵ��",fnAction=function() GroupHelp_Search.Menu_ACL_XXLYClick(this) end},
	{szOption="����Ƶ��",fnAction=function() GroupHelp_Search.Menu_ACL_XXLYClick(this) end},
}
function GroupHelp_Search.OnFrameCreate()
	this:RegisterEvent("PARTY_INVITE_REQUEST")
	Station.Lookup("Normal/GroupHelp_Search"):SetPoint("CENTER", 0, 0, "CENTER", 0, -200)
	GroupHelp_Search.UpdateMainUI()
	GroupHelp_Search.UpdateHandleItem()
end
function GroupHelp_Search.OnEvent(event)
	if event=="PARTY_INVITE_REQUEST" then
		for _,s in pairs(GroupHelp_Search.tIApply) do
			if arg0==s then
				GroupHelp.DelayCall(16,GroupHelp_Search.EnterTeam(arg0))
			end
		end
	end
end
function GroupHelp_Search.OnItemRButtonClick()
	local szName = this:GetName()
	if string.sub(szName,0,3)=="HI_" then
		local sHeaderName = this:Lookup("Txt_Header"):GetText()
		local tMenu = {
			{szOption="�������",fnAction=function()
					GroupHelp_Search.TalkInviteTeam(sHeaderName)
					table.insert(GroupHelp_Search.tIApply,sHeaderName)
				end
			},
		}
		PopupMenu(tMenu)
	end
end
function GroupHelp_Search.OnLButtonClick()
	local szName=this:GetName()
	if szName=="Btn_ACL_HDLX" then
		PopupMenu(GroupHelp_Search.Menu_ACL_HDLX)
	elseif szName=="Btn_ACL_XXLY" then
		PopupMenu(GroupHelp_Search.Menu_ACL_XXLY)
	elseif szName=="Btn_Refresh"then
		GroupHelp_Search.UpdateHandleItem()
	end
end
function GroupHelp_Search.OnLButtonDown()
	GroupHelp_Search.OnLButtonHold()
end
function GroupHelp_Search.OnLButtonHold()
    local szName = this:GetName()
	if szName == "Btn_Up" then
		this:GetRoot():Lookup("Scroll_List"):ScrollPrev(1)
	elseif szName == "Btn_Down" then
		this:GetRoot():Lookup("Scroll_List"):ScrollNext(1)
    end
end
function GroupHelp_Search.OnScrollBarPosChanged()
	local nPos = this:GetScrollPos()
	local Frame = this:GetRoot()
	if nPos == 0 then
		Frame:Lookup("Btn_Up"):Enable(false)
	else
		Frame:Lookup("Btn_Up"):Enable(true)
	end
	if nPos == this:GetStepCount() then
		Frame:Lookup("Btn_Down"):Enable(false)
	else
		Frame:Lookup("Btn_Down"):Enable(true)
	end
    local HandleList = Frame:Lookup("",""):Lookup("Handle_List")
    HandleList:SetItemStartRelPos(0, - nPos * 32)
	HandleList:FormatAllItemPos()
end
function GroupHelp_Search.UpdateMainUI()
	local Frame=Station.Lookup("Normal/GroupHelp_Search")
	local HandleAll=Frame:Lookup("","")
	GroupHelp.AddBtnBox(Frame,"ACL_HDLX",160,450,130,32,"�����")
	GroupHelp.AddBtnBox(Frame,"ACL_XXLY",300,450,130,32,"��Ϣ��Դ")
	GroupHelp.AddBtnBox(Frame,"Refresh",460,442,60,34,"ˢ��")
	GroupHelp.AddText(HandleAll,"Title",280,20,210,30,200,"������֡�������")
	GroupHelp.AddText(HandleAll,"SXTJ",130,422,100,20,23,"ɸѡ����:")
	Frame:Lookup("Btn_ACL_HDLX"):Lookup("",""):Lookup("Text_Btn"):SetText(GroupHelp_Search.ACL_H)
	Frame:Lookup("Btn_ACL_XXLY"):Lookup("",""):Lookup("Text_Btn"):SetText(GroupHelp_Search.ACL_X)
end
function GroupHelp_Search.UpdateScrollInfo()
	local Frame=Station.Lookup("Normal/GroupHelp_Search")
	local HandleList = Frame:Lookup("",""):Lookup("Handle_List")
	local Scroll=Frame:Lookup("Scroll_List")
	local _,nAllItem_H=HandleList:GetAllItemSize()
	local nBtnList_H=280*280/nAllItem_H
	local nItemCount=HandleList:GetItemCount()
	local nStep = (nAllItem_H-280)/32
	if nAllItem_H>280 then
		Frame:Lookup("Scroll_List"):Show()
		Frame:Lookup("Btn_Up"):Show()
		Frame:Lookup("Btn_Down"):Show()
	else
		Frame:Lookup("Scroll_List"):Hide()
		Frame:Lookup("Btn_Up"):Hide()
		Frame:Lookup("Btn_Down"):Hide()
	end
	Frame:Lookup("Scroll_List"):Lookup("Btn_List"):SetSize(18,nBtnList_H)
	Frame:Lookup("Scroll_List"):SetStepCount(nStep)
end
function GroupHelp_Search.UpdateHandleItem()
	local sMyKungfuName=GetClientPlayer().GetKungfuMount().szSkillName
	local sMyKungfuAcronym=GroupHelp.GetMyKungfuAcronym(sMyKungfuName)
	local tUsefulCreateInfo=GroupHelp_Search.Filt(GroupHelp.tAnyCreateInfo,sMyKungfuAcronym)
	GroupHelp_Search.SortItemAndAddToHandle(tUsefulCreateInfo)
end

function GroupHelp_Search.Filt(tA,sMyKungfu)
	local tB=clone(tA)
	local sMyKungfuType=GroupHelp.GetKungfuType(sMyKungfu)
	for i,v in pairs(tB) do
		local sNeedKungfu=GroupHelp.SubDwString(v["MainMsg"],5,"��")
		local bNeedMe=false
		for sKind in string.gfind(sNeedKungfu, "%d+(%a+)") do
			if sKind==sMyKungfu or sKind==sMyKungfuType then
				bNeedMe=true
			end
		end
		if not bNeedMe then
			tB[i]=nil
		end
	end
	if GroupHelp_Search.ACL_X ~= "����Ƶ��" then
		local sChannel=GroupHelp_Search.tTrans[GroupHelp_Search.ACL_X]
		for i,v in pairs(tB) do
			local Has=false
			for m,n in pairs(v.Channel) do
				if n==sChannel then
					Has=true
					break
				end
			end
			if not Has then
				tB[i]=nil
			end
		end
	end
	if GroupHelp_Search.ACL_H ~= "���л" then
		if GroupHelp_Search.ACL_H == "����" then
			for i,v in pairs(tB) do
				if string.sub(v["MainMsg"],0,1) ~= "-" then
					tB[i]=nil
				end
			end
		else
			for i,v in pairs(tB) do
				if GroupHelp.SubDwString(v["MainMsg"],1,"��") ~= GroupHelp_Search.ACL_H then
					tB[i]=nil
				end
			end
		end
	end
	return tB
end
function GroupHelp_Search.SortItemAndAddToHandle(tUCI)
	local HandleList=Station.Lookup("Normal/GroupHelp_Search"):Lookup("",""):Lookup("Handle_List")
	HandleList:Clear()
	GroupHelp_Search.nHICount=0
	GroupHelp_Search.FiltItemToAdd(tUCI,"FRIENDS","TONG")
	GroupHelp_Search.FiltItemToAdd(tUCI,"FRIENDS","TONG_ALLIANCE")
	GroupHelp_Search.FiltItemToAdd(tUCI,"FRIENDS")
	GroupHelp_Search.FiltItemToAdd(tUCI,"TONG")
	GroupHelp_Search.FiltItemToAdd(tUCI,"TONG_ALLIANCE")
	GroupHelp_Search.FiltItemToAdd(tUCI,"CAMP")
	GroupHelp_Search.FiltItemToAdd(tUCI,"WORLD")
	GroupHelp_Search.UpdateScrollInfo()
end
function GroupHelp_Search.FiltItemToAdd(tUCI,sChannel1,sChannel2)
	for i,v in pairs(tUCI) do
		local Have1=false
		local Have2=false
		for _,n in pairs(v["Channel"]) do
			if n==sChannel1 then Have1=true end
			if n==sChannel2 then Have2=true end
		end
		if Have1 then
			if (not sChannel2) or Have2 then
					GroupHelp_Search.AddToHandle(i,v)
					tUCI[i]=nil
			end
		end
	end
end
function GroupHelp_Search.AddToHandle(sHeadName,tInfo)
	local sMainMsg=tInfo["MainMsg"]
	local sHDLX=GroupHelp.SubDwString(sMainMsg,1,"��")
	local sYY=GroupHelp.SubDwString(sMainMsg,2,"��")
	local sBZ=GroupHelp.SubDwString(sMainMsg,3,"��")
	local sWaiting=GroupHelp.SubDwString(sMainMsg,4,"��")
	local Frame=Station.Lookup("Normal/GroupHelp_Search")
	Frame:SetPoint("CENTER", 0, 0, "CENTER", 0, -200)
	local HandleList=Frame:Lookup("",""):Lookup("Handle_List")
	HandleList:AppendItemFromIni("interface\\GroupHelp\\GroupHelp_Search.ini","Handle_Item","HI_"..GroupHelp_Search.nHICount)
	local HI = HandleList:Lookup("HI_"..GroupHelp_Search.nHICount)
	HI:SetRelPos(0,GroupHelp_Search.nHICount*32)
	GroupHelp.AddText(HI,"Header",   6,0,106,28,0,sHeadName)
	GroupHelp.AddText(HI,"HDLX",   112,0,132,28,0,sHDLX)
	GroupHelp.AddText(HI,"Waiting",244,0, 64,28,0,sWaiting)
	GroupHelp.AddText(HI,"YY",     308,0,134,28,0,sYY)
	GroupHelp.AddText(HI,"BZ",     442,0,238,28,0,sBZ)
	HandleList:FormatAllItemPos()
	GroupHelp_Search.nHICount=GroupHelp_Search.nHICount+1
end
function GroupHelp_Search.SetMenu_ACL_HDLX()
	local menu_1={}
	for i1,j1 in pairs(GroupHelp_Create.FBinfo) do
		local menu_2={}
		menu_2.szOption=i1
		for i2,j2 in pairs(j1) do
			local menu_3={}
			menu_3.szOption=i2
			for i3,j3 in pairs(j2) do
				local menu_4={}
				menu_4.szOption=i3
				for _,j4 in pairs(j3) do
					local menu_5={}
					menu_5.szOption=j4
					menu_5.fnAction=function() GroupHelp_Search.Menu_ACL_HDLXClick(this) end
					table.insert(menu_4,menu_5)
				end
				table.insert(menu_3,menu_4)
			end
			table.insert(menu_2,menu_3)
		end
		table.insert(menu_1,menu_2)
	end
	menu_1.szOption="PVE"
	table.insert(GroupHelp_Search.Menu_ACL_HDLX,menu_1)
end
function GroupHelp_Search.Menu_ACL_HDLXClick(this)
	GroupHelp_Search.ACL_H=this["tData"].szOption
	Station.Lookup("Normal/GroupHelp_Search"):Lookup("Btn_ACL_HDLX"):Lookup("",""):Lookup("Text_Btn"):SetText(GroupHelp_Search.ACL_H)
	GroupHelp_Search.UpdateHandleItem()
end
function GroupHelp_Search.Menu_ACL_XXLYClick(this)
	GroupHelp_Search.ACL_X=this["tData"].szOption
	Station.Lookup("Normal/GroupHelp_Search"):Lookup("Btn_ACL_XXLY"):Lookup("",""):Lookup("Text_Btn"):SetText(GroupHelp_Search.ACL_X)
	GroupHelp_Search.UpdateHandleItem()
end
function GroupHelp_Search.TalkInviteTeam(sPlayerName)
	local Me=GetClientPlayer()
	local sMyKungfuName=Me.GetKungfuMount().szSkillName
	local sMyKungfuAcronym=GroupHelp.GetMyKungfuAcronym(sMyKungfuName)
	local sTalkMsg="*v*1"..Me.szName.." "..sMyKungfuAcronym.."���������"
	Me.Talk(PLAYER_TALK_CHANNEL.WHISPER,sPlayerName,{{type = "text", text = "BG_CHANNEL_MSG"},{type="text",text =sTalkMsg}})
end
function GroupHelp_Search.GetTimeInterval(tTime1,tTime2)
	local Interval=(tTime1[1]-tTime2[1])*60*60+(tTime1[2]-tTime2[2])*60+(tTime1[3]-tTime2[3])
	if Interval<0 then
		Interval=Interval+24*60*60
	end
	return Interval
end
function GroupHelp_Search.EnterTeam(sPlayerName)
	local Frame = Station.Lookup("Topmost/MB_IMTP_"..sPlayerName)
	if Frame then
		local Btn = Frame:Lookup("Wnd_All/Btn_Option1")
		Btn.fnAction(1)
		GroupHelp.Alert("���ѽ���,����ر�")
		GroupHelp_Search.tIApply={}
		Wnd.CloseWindow("GroupHelp_Search")
		Wnd.CloseWindow("MB_IMTP_"..sPlayerName)
	end
end
GroupHelp_Search.SetMenu_ACL_HDLX()
