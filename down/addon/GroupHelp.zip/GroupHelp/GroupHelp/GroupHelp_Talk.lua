GroupHelp_Talk={}
GroupHelp_Talk.x=600
GroupHelp_Talk.y=300
GroupHelp_Talk.bStop=false
GroupHelp_Talk.bHadTalkInWorld=false
GroupHelp_Talk.tTalkChannelHeader = {
	["TONG"] = "",
	["TONG_ALLIANCE"] = "",
	["FRIENDS"] = "/o ",
	["CAMP"] = "/c ",
	["WORLD"] = "/h ",
}
GroupHelp_Talk.tTalkChannel={}
RegisterCustomData("GroupHelp_Talk.x")
RegisterCustomData("GroupHelp_Talk.y")
function GroupHelp_Talk.OnFrameCreate()
	Station.Lookup("Normal/GroupHelp_Talk"):SetAbsPos(GroupHelp_Talk.x,GroupHelp_Talk.y)
	GroupHelp_Talk.bStop=false
	GroupHelp_Talk.bHadTalkInWorld=false
	local nMinTalkDelay=-1
	for i,j in pairs(GroupHelp.tHeadSet.Channel) do
		if nMinTalkDelay==-1 then
			nMinTalkDelay=GroupHelp.tHeadSet.Channel[i]
		elseif GroupHelp.tHeadSet.Channel[i] < nMinTalkDelay then
			nMinTalkDelay=GroupHelp.tHeadSet.Channel[i]
		end
	end
	if nMinTalkDelay > GroupHelp.nBreatheFrame then
		GroupHelp_Talk.SetBtnTalk_UN()
		local nDelayFrame=nMinTalkDelay-GroupHelp.nBreatheFrame
		GroupHelp.DelayCall(nDelayFrame,GroupHelp_Talk.SetBtnTalk_EN)
	end
end
function GroupHelp_Talk.OnFrameDragEnd()
	GroupHelp_Talk.x,GroupHelp_Talk.y=Station.Lookup("Normal/GroupHelp_Talk"):GetAbsPos()
end
function GroupHelp_Talk.OnLButtonClick()
	GroupHelp_Talk.tTalkChannel=GroupHelp_Talk.GetTalkChannel(GroupHelp.nBreatheFrame)
	if this:GetName()=="Btn_Talk" then
		local sTalkStr=GroupHelp_Talk.SetTalkStr()
		for i=1,#GroupHelp_Talk.tTalkChannel do
			GroupHelp_Talk.Talk(GroupHelp_Talk.tTalkChannel[i],"",sTalkStr)
		end
	elseif this:GetName()=="Btn_Stop" then
		GroupHelp_Talk.bStop=true
		GroupHelp_Talk.tTalkChannel={}
		if GroupHelp.tHeadSet.Channel["WORLD"]==nil
		  or GroupHelp.tHeadSet.Channel["WORLD"] < GroupHelp.nBreatheFrame
		  or not GroupHelp_Talk.bHadTalkInWorld then
			local Str="*v* "..GetClientPlayer().szName.." ������"
			GroupHelp_Talk.Talk("WORLD","",Str)
		end
	end
end
function GroupHelp_Talk.GetTalkChannel(nBreathe)
	local tTalkChannel={}
	if GroupHelp_Talk.bStop then
		if GroupHelp.tHeadSet.Channel["WORLD"]==nil
		  or GroupHelp.tHeadSet.Channel["WORLD"] < nBreathe then
			if not GroupHelp_Talk.bHadTalkInWorld then
				table.insert(tTalkChannel,"WORLD")
			else
				local Str="*v* "..GetClientPlayer().szName.." ������"
				GroupHelp_Talk.Talk("WORLD","",Str)
			end
		end
	else
		for i,j in pairs(GroupHelp.tHeadSet.Channel) do
			if j < nBreathe then
				table.insert(tTalkChannel,i)
			end
		end
	end
	return tTalkChannel
end
function GroupHelp_Talk.SetTalkStr()
	local Str="*v* "..GetClientPlayer().szName.." "
	if GroupHelp_Talk.bStop then
		Str=Str.."������"
		return Str
	end
	local nNowRS=GetClientTeam().GetTeamSize()
	if nNowRS==0 then nNowRS=1 end
	local nMBRS=GroupHelp.tHeadSet["Other"]["MBRS"]
	if nNowRS > 1 and GetClientTeam().nGroupNum==1 and nMBRS>5 then
		GroupHelp.DelayCall(52,function() GroupHelp.Alert("���ٶ�-->ת��Ϊ�Ŷ�") end)
	end
	if nNowRS>=nMBRS then
		Str=Str.."������"
		GroupHelp_Talk.bStop=true
		return Str
	else
		Str=Str..GroupHelp.tHeadSet["HDLX"]
		if GroupHelp.tHeadSet["Other"]["YY"]~="" then
			Str=Str.."��"..GroupHelp.tHeadSet["Other"]["YY"]
		else
			Str=Str.."��"
		end
		Str=Str.."��"..GroupHelp.tHeadSet["Other"]["BZ"].."��"..nNowRS.."="..(nMBRS-nNowRS).."����"
	end
	GroupHelp.UpdateNowNeed()
	for i=1,21 do
		if GroupHelp.tNowNeed[i][2]~=0 then
			Str=Str..GroupHelp.tNowNeed[i][2]..GroupHelp.tNowNeed[i][1]
		end
	end
	return Str
end
function GroupHelp_Talk.Talk(nChannel,TargetPlayer,sTalkStr)
	if GroupHelp_Talk.tTalkChannelHeader[nChannel]=="" then
		GetClientPlayer().Talk(PLAYER_TALK_CHANNEL[nChannel],TargetPlayer,{{type="text",text = sTalkStr}})
	else
		local Edit_TalkInput = Station.Lookup("Lowest2/EditBox/Edit_Input")
		Edit_TalkInput:ClearText()
		Edit_TalkInput:InsertText(sTalkStr)
		local sHeader = GroupHelp_Talk.tTalkChannelHeader[nChannel]
		if sHeader and sHeader~="" then
			SwitchChatChannel(sHeader)
		end
		GroupHelp.Alert("������Ϣ�����������,�밴Enter����")
	end
end
function GroupHelp_Talk.SetBtnTalk_EN()
	local t=GroupHelp_Talk.GetTalkChannel(GroupHelp.nBreatheFrame)
	if next(t)==nil then return end
	Station.Lookup("Normal/GroupHelp_Talk"):Lookup("Btn_Talk"):Enable(true)
	GroupHelp.Alert("���Ժ�����")
end
function GroupHelp_Talk.SetBtnTalk_UN()
	Station.Lookup("Normal/GroupHelp_Talk"):Lookup("Btn_Talk"):Enable(false)
	GroupHelp.Alert("�����ݸ�һ����")
end
