WoW_LifeBarSettings = WoW_LifeBarSettings or {}
WoW_LifeBarSettings.Anchor= { s = "LEFTCENTER", r = "LEFTCENTER", x = 394, y =-161}
RegisterCustomData("WoW_LifeBarSettings.Anchor")

function WoW_LifeBarSettings.OnLButtonClick()
	local szName = this:GetName()
	local nStep = -1
	if IsCtrlKeyDown() then
		nStep = -5
	end
	if szName:match("Right") then
		nStep = nStep * -1
	end
	
	if szName == "Btn_RangeZone_Left" or szName == "Btn_RangeZone_Right" then
		WoW_LifeBar.nRange = WoW_LifeBar.nRange + nStep
		if WoW_LifeBar.nRange <= 0 then
			WoW_LifeBar.nRange = 0
		elseif WoW_LifeBar.nRange >= WoW_LifeBar.nRangeMax then
			WoW_LifeBar.nRange = WoW_LifeBar.nRangeMax
		end
	elseif szName == "Btn_Close" then
		WoW_LifeBarSettings.ClosePanel()
		return
	end
	
	WoW_LifeBarSettings.UpdateSettingPanelData()
end

function WoW_LifeBarSettings.OnCheckBoxCheck(event)
	WoW_LifeBarSettings.CheckBoxEvent(this:GetName(), true)
end

function WoW_LifeBarSettings.OnCheckBoxUncheck(event)
	WoW_LifeBarSettings.CheckBoxEvent(this:GetName(), false)
end

function WoW_LifeBarSettings.CheckBoxEvent(szName, bFlag)
	if WoW_LifeBarSettings.bIgnoreCheckboxEvent then
		return
	end
	if szName == "CheckBox_ShowNpc" then
		WoW_LifeBar.bShowNpc = bFlag
	elseif szName == "CheckBox_ShowPlayer" then
		WoW_LifeBar.bShowPlayer = bFlag
	elseif szName == "CheckBox_OnlyParty" then
		WoW_LifeBar.bOnlyParty = bFlag
	elseif szName == "CheckBox_FixedX" then
		WoW_LifeBar.bFixedX = bFlag
	elseif szName == "CheckBox_ShowDistance" then
		WoW_LifeBar.bShowDistance = bFlag
	elseif szName == "CheckBox_ShowSelf" then
		WoW_LifeBar.bShowSelf = bFlag
		if bFlag then
			WoW_LifeBar.CreateLifeBar(GetClientPlayer().dwID)
		else
			WoW_LifeBar.RemoveLifeBar(GetClientPlayer().dwID)
		end
		WoW_LifeBar.ReplaceTopHeadEx(GetClientPlayer().dwID, false)
	elseif szName == "CheckBox_ShowCastingBar" then
		WoW_LifeBar.bShowCastingBar = bFlag
	elseif szName=="CheckBox_ShowCastingName" then 
		WoW_LifeBar.bShowCastingName=bFlag
	elseif szName == "CheckBox_ShowLifeBar" then
		WoW_LifeBar.bShowLifeBar = bFlag
	elseif szName == "CheckBox_ShowManaBar" then
		WoW_LifeBar.bShowManaBar = bFlag
	elseif szName == "CheckBox_ShowName" then
		WoW_LifeBar.bShowName = bFlag
	elseif szName == "CheckBox_ShowTarget" then
		WoW_LifeBar.bShowTarget = bFlag
	elseif szName == "CheckBox_AutoSort" then
		WoW_LifeBar.bAutoSort = bFlag
	elseif szName=="CheckBox_ShowForce" then 
		WoW_LifeBar.bShowForce=bFlag	
	end
	
	WoW_LifeBarSettings.UpdateSettingPanelData()
end

function WoW_LifeBarSettings.UpdateSettingPanelData()
	WoW_LifeBarSettings.bIgnoreCheckboxEvent = true
	WoW_LifeBarSettings.handleRangeZone:Lookup("Text_RangeZone_Value"):SetText(WoW_LifeBar.nRange)

	WoW_LifeBarSettings.frameSelf:Lookup("CheckBox_ShowNpc"):Check(WoW_LifeBar.bShowNpc)
	WoW_LifeBarSettings.frameSelf:Lookup("CheckBox_ShowPlayer"):Check(WoW_LifeBar.bShowPlayer)
	WoW_LifeBarSettings.frameSelf:Lookup("CheckBox_OnlyParty"):Check(WoW_LifeBar.bOnlyParty)
	WoW_LifeBarSettings.frameSelf:Lookup("CheckBox_FixedX"):Check(WoW_LifeBar.bFixedX)
	WoW_LifeBarSettings.frameSelf:Lookup("CheckBox_ShowDistance"):Check(WoW_LifeBar.bShowDistance)
	
	WoW_LifeBarSettings.frameSelf:Lookup("CheckBox_ShowSelf"):Check(WoW_LifeBar.bShowSelf)
	WoW_LifeBarSettings.frameSelf:Lookup("CheckBox_ShowCastingBar"):Check(WoW_LifeBar.bShowCastingBar)
	WoW_LifeBarSettings.frameSelf:Lookup("CheckBox_ShowCastingName"):Check(WoW_LifeBar.bShowCastingName)
	WoW_LifeBarSettings.frameSelf:Lookup("CheckBox_ShowLifeBar"):Check(WoW_LifeBar.bShowLifeBar)
	WoW_LifeBarSettings.frameSelf:Lookup("CheckBox_ShowManaBar"):Check(WoW_LifeBar.bShowManaBar)
	WoW_LifeBarSettings.frameSelf:Lookup("CheckBox_ShowName"):Check(WoW_LifeBar.bShowName)
	WoW_LifeBarSettings.frameSelf:Lookup("CheckBox_ShowForce"):Check(WoW_LifeBar.bShowForce)
	WoW_LifeBarSettings.frameSelf:Lookup("CheckBox_ShowTarget"):Check(WoW_LifeBar.bShowTarget)
	WoW_LifeBarSettings.frameSelf:Lookup("CheckBox_AutoSort"):Check(WoW_LifeBar.bAutoSort)
	
	WoW_LifeBarSettings.bIgnoreCheckboxEvent = false
end

function WoW_LifeBarSettings.OpenPanel()
	local frame = Station.Lookup("Normal/WoW_LifeBarSettings")
	if not frame then
		frame = Wnd.OpenWindow("Interface\\WoW_LifeBar\\WoW_LifeBarSettings.ini", "WoW_LifeBarSettings")
	end
	frame:Show()
	
	WoW_LifeBarSettings.frameSelf = frame
	WoW_LifeBarSettings.handleMain = frame:Lookup("", "")
	
	WoW_LifeBarSettings.handleRangeZone = frame:Lookup("", "Handle_RangeZone")

	WoW_LifeBarSettings.UpdateAnchor(frame)
	WoW_LifeBarSettings.UpdateSettingPanelData()
end

function WoW_LifeBarSettings.OnFrameDragEnd()
	this:CorrectPos()
	WoW_LifeBarSettings.Anchor = GetFrameAnchor(this)
end

function WoW_LifeBarSettings.UpdateAnchor(frame)
	frame:SetPoint(WoW_LifeBarSettings.Anchor.s, 0, 0, WoW_LifeBarSettings.Anchor.r, WoW_LifeBarSettings.Anchor.x, WoW_LifeBarSettings.Anchor.y)
	frame:CorrectPos()
end

function WoW_LifeBarSettings.ClosePanel()
	local frame = Station.Lookup("Normal/WoW_LifeBarSettings")
	if not frame then
		return
	end
	frame:Hide()
end

function WoW_LifeBarSettings.IsOpend()
	local frame = Station.Lookup("Normal/WoW_LifeBarSettings")
	if frame and frame:IsVisible() then
		return true
	end
	return false
end

function WoW_LifeBarSettings.Message(szMessage)
	OutputMessage("MSG_SYS", "[WoW_LifeBar] " .. tostring(szMessage) .. "\n")
end

Hotkey.AddBinding("WoW_LifeBar_Settings", "�������", "WOW���ͷ��Ѫ��",function()
	if WoW_LifeBarSettings.IsOpend() then
		WoW_LifeBarSettings.ClosePanel()
	else
		WoW_LifeBarSettings.OpenPanel()
	end
end,nil)
	
Hotkey.AddBinding("WoW_LifeBar_ShowEnemy", "�ж�Ѫ��", "",function()
	WoW_LifeBar.bShowEnemy = not WoW_LifeBar.bShowEnemy
	if WoW_LifeBar.bShowEnemy then 
		WoW_LifeBarSettings.Message("[����]�ж�Ѫ����ʾ")
	else
		WoW_LifeBarSettings.Message("[�ر�]�ж�Ѫ����ʾ")
	end
end,nil)
	
Hotkey.AddBinding("WoW_LifeBar_ShowAlly", "�Ѻ�Ѫ��", "",function()
	WoW_LifeBar.bShowAlly = not WoW_LifeBar.bShowAlly
	if WoW_LifeBar.bShowAlly then 
		WoW_LifeBarSettings.Message("[����]�Ѻ�Ѫ����ʾ")
	else
		WoW_LifeBarSettings.Message("[�ر�]�Ѻ�Ѫ����ʾ")
	end
end,nil)