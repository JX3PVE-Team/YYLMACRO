WoW_LifeBar = {}
WoW_LifeBar.nSteper = -1
WoW_LifeBar.tLifeBarList = {}					-- ���е� Frame ����
WoW_LifeBar.tSortedVisibleLifeBarList = {}		-- �Ѿ�������Ŀ���ʾ Frame ����

WoW_LifeBar.bShowSelf = true;			RegisterCustomData("WoW_LifeBar.bShowSelf")
WoW_LifeBar.bShowEnemy = true;			RegisterCustomData("WoW_LifeBar.bShowEnemy")
WoW_LifeBar.bShowAlly = true;			RegisterCustomData("WoW_LifeBar.bShowAlly")
WoW_LifeBar.bShowNpc = false;			RegisterCustomData("WoW_LifeBar.bShowNpc")
WoW_LifeBar.bShowPlayer = true;			RegisterCustomData("WoW_LifeBar.bShowPlayer")
WoW_LifeBar.bOnlyParty = false;			RegisterCustomData("WoW_LifeBar.bOnlyParty")

WoW_LifeBar.bFixedX = false;			RegisterCustomData("WoW_LifeBar.bFixedX")
WoW_LifeBar.bShowDistance = false;		RegisterCustomData("WoW_LifeBar.bShowDistance")
WoW_LifeBar.bShowLifeBar = true;		RegisterCustomData("WoW_LifeBar.bShowLifeBar")
WoW_LifeBar.bShowCastingName=false 		RegisterCustomData("WoW_LifeBar.bShowCastingName")
WoW_LifeBar.bShowManaBar = false;		RegisterCustomData("WoW_LifeBar.bShowManaBar")
WoW_LifeBar.bShowCastingBar = true;		RegisterCustomData("WoW_LifeBar.bShowCastingBar")
WoW_LifeBar.bShowTarget = true;			RegisterCustomData("WoW_LifeBar.bShowTarget")
WoW_LifeBar.bShowName = true;			RegisterCustomData("WoW_LifeBar.bShowName")
WoW_LifeBar.bShowForce = false;			RegisterCustomData("WoW_LifeBar.bShowForce")
WoW_LifeBar.bAutoSort = true;			RegisterCustomData("WoW_LifeBar.bAutoSort")

WoW_LifeBar.nRange = 20;				RegisterCustomData("WoW_LifeBar.nRange")
WoW_LifeBar.nRangeMax = 40;
WoW_LifeBar.nAllowMember = 30;		
WoW_LifeBar.bLastMouseVisibleState = nil




WoW_LifeBar.Scene_GetCharacterTopScreenPos = function(fnAction,dwID)
	PostThreadCall(WoW_LifeBar.ApplyPointCallback,fnAction,"Scene_GetCharacterTopScreenPos", dwID)
end

WoW_LifeBar.ApplyPointCallback = function(fnAction, nX, nY)
	if not nX or (nX > 0 and nX < 0.00001 and nY > 0 and nY < 0.00001) then
		nX, nY = nil, nil
	else
		nX, nY = Station.AdjustToOriginalPos(nX, nY)
	end
	local res, err = pcall(fnAction, nX, nY)
	if not res then
		Output("ApplyScreenPoint ERROR: " .. err)
	end
end


-------------------------------------------------------------------------------------------
-- 2013-7-1 Scene_ScenePointToScreenPoint
-------------------------------------------------------------------------------------------
function WoW_LifeBar.Scene_ScenePointToScreenPoint(nX,nY,nZ)
	local x,y
	x,y = Scene_ScenePointToScreenPoint(nX,nY,nZ)
	if not x or not y then
		return 0,0,false
	else
		return x,y,true
	end
end

function WoW_LifeBar.OnFrameCreate()
	this:RegisterEvent("RENDER_FRAME_UPDATE")
	this:RegisterEvent("NPC_ENTER_SCENE")
	this:RegisterEvent("PLAYER_ENTER_SCENE")
	this:RegisterEvent("NPC_LEAVE_SCENE")
	this:RegisterEvent("PLAYER_LEAVE_SCENE")
end

function WoW_LifeBar.OnEvent(szEvent)
	if szEvent == "RENDER_FRAME_UPDATE" then
		WoW_LifeBar.CheckMouseVisibleState()
		WoW_LifeBar.RefreshLifeBarDisplay()
	elseif szEvent == "NPC_ENTER_SCENE" or szEvent == "PLAYER_ENTER_SCENE" then
		WoW_LifeBar.CreateLifeBar(arg0)
	elseif szEvent == "NPC_LEAVE_SCENE" or szEvent == "PLAYER_LEAVE_SCENE" then
		WoW_LifeBar.RemoveLifeBar(arg0)
	end
end

function WoW_LifeBar.OnFrameBreathe()
	WoW_LifeBar.nSteper = WoW_LifeBar.nSteper + 1
	local player = GetClientPlayer()
	if not player then
		return
	end
	WoW_LifeBar.SortVisibleFrameByDistance()
end

---------------------------------------------------------------------------------------------------
local frameLastDown = nil
local nLastSteper = nil
local nLastMousePos = {nX = 0, nY = 0}
function WoW_LifeBar.CheckMouseVisibleState()
	local bMouseVisibleState = Cursor.IsVisible()
	if bMouseVisibleState then
		nLastMousePos.nX, nLastMousePos.nY = Cursor.GetPos()
	end
	if WoW_LifeBar.bLastMouseVisibleState == bMouseVisibleState then
		return
	end
	WoW_LifeBar.bLastMouseVisibleState = bMouseVisibleState
	
	if bMouseVisibleState then			-- ����ǵ���
		local frameLastUp = WoW_LifeBar.GetRectFrameOnMouse()
		if frameLastUp and frameLastUp == frameLastDown and WoW_LifeBar.nSteper - nLastSteper <= 16 and frameLastUp:IsVisible() then
			local nType = TARGET.NPC
			if IsPlayer(frameLastUp.dwID) then
				nType = TARGET.PLAYER
			end
			--if GetClientPlayer().dwID == frameLastUp.dwID then
				--Player.OnItemLButtonDown()
			--else
				SetTarget(nType, frameLastUp.dwID)
				
				--if IsCtrlKeyDown() then
					--InteractTarget(nType, frameLastUp.dwID)
				--end
			--end
		end
	else								-- ����ǰ���
		frameLastDown = WoW_LifeBar.GetRectFrameOnMouse()
		nLastSteper = WoW_LifeBar.nSteper
	end
end

function WoW_LifeBar.GetRectFrameOnMouse()
	for i = 1, WoW_LifeBar.nAllowMember do
		local frame = WoW_LifeBar.tSortedVisibleLifeBarList[i]
		if frame and frame:IsVisible() then
			local target = WoW_LifeBar.GetCharacter(frame.dwID)
			if target then
				local nFX, nFY = frame:GetRelPos()
				local nX, nY = nLastMousePos.nX, nLastMousePos.nY
				if (nX > nFX and nX < nFX + 115) and (nY > nFY and nY < nFY + 28) then
					return frame
				end
			end
		end
	end
end

function WoW_LifeBar.RefreshLifeBarDisplay()
	local player = GetClientPlayer()
	if not player then
		return
	end
	
	local tPlacedRectsZone = {}
	local nRecursionCount = 0
	local function GetShortestPathLoc(nX, nY, nMode)
		nRecursionCount = nRecursionCount + 1
		if nRecursionCount >= 40 then
			return nX, nY
		end
		local nW = 120
		for i = 1, #tPlacedRectsZone do
			local nPlacedX = tPlacedRectsZone[i].nX
			local nPlacedY = tPlacedRectsZone[i].nY
			local nH = tPlacedRectsZone[i].nH
			local bIntersection = (nX + nW > nPlacedX and nX < nPlacedX + nW) and (nY + nH > nPlacedY and nY < nPlacedY + nH)
			if bIntersection then
				if nMode == 8 then
					return GetShortestPathLoc(nX, nPlacedY - nH - 1, nMode)
				elseif nMode == 2 then
					return GetShortestPathLoc(nX, nPlacedY + nH + 1, nMode)
				elseif nMode == 4 then
					return GetShortestPathLoc(nPlacedX - nW - 1, nY, nMode)
				elseif nMode == 6 then
					return GetShortestPathLoc(nPlacedX + nW + 1, nY, nMode)
				elseif nMode == 7 then
					return GetShortestPathLoc(nPlacedX - nW - 1, nPlacedY - nH - 1, nMode)
				elseif nMode == 3 then
					return GetShortestPathLoc(nPlacedX + nW + 1, nPlacedY + nH + 1, nMode)
				elseif nMode == 9 then
					return GetShortestPathLoc(nPlacedX + nW + 1, nPlacedY - nH - 1, nMode)
				elseif nMode == 1 then
					return GetShortestPathLoc(nPlacedX - nW - 1, nPlacedY + nH + 1, nMode)
				else
					return nX, nY
				end
			end
		end
		return nX, nY
	end
	
	for dwID, frame in pairs(WoW_LifeBar.tLifeBarList) do
		if frame then
			--����
			--WoW_LifeBar.ReplaceTopHeadEx(dwID, frame.bVisible)
			if frame.bVisible then
				frame:Show()
				local target = WoW_LifeBar.GetCharacter(dwID)
				if target then
					-- local nTopX, nTopY, nTopZ = Scene_GetCharacterTop(dwID)
					-- local nScreenX, nScreenY, bSuccess = 0, 0, false
					-- if nTopX and nTopY and nTopZ then
						-- nScreenX, nScreenY, bSuccess = WoW_LifeBar.Scene_ScenePointToScreenPoint(nTopX, nTopY, nTopZ)
					-- end
					-- if bSuccess then
						-- nScreenX, nScreenY = Station.AdjustToOriginalPos(nScreenX, nScreenY)
					-- else
						-- nScreenX, nScreenY = -4096, -4096
					-- end
					local nScreenX, nScreenY
					local fnAction = function()
						local nShiftMax = 14
						--local handleCastingBar = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Handle_CastingBar")
						local nAlpha = 255--handleCastingBar:GetAlpha()
						local nHShift = 32 + (nAlpha / 255) * nShiftMax
						local nNewX, nNewY = nScreenX - (115 / 2), nScreenY - nHShift
						
						local tDifLevel = {8, 2, 4, 6, 7, 9, 3, 1}
						local tClostLoc = {nX = nNewX, nY = nNewY, nDist = 99999999}
						if WoW_LifeBar.bShowLifeBar and WoW_LifeBar.bAutoSort then
							local nLoopEnd = #tDifLevel
							if WoW_LifeBar.bFixedX then
								nLoopEnd = math.min(2, nLoopEnd)
							end
							for i = 1, nLoopEnd do
								local nMode = tDifLevel[i]
								local nDifX, nDifY = GetShortestPathLoc(nNewX, nNewY, nMode)
								nRecursionCount = 0
								local nDist = math.floor(((nNewX - nDifX) ^ 2 + (nNewY - nDifY) ^ 2) ^ 0.5)
								if (nDist + 2) < tClostLoc.nDist then
									tClostLoc.nX = nDifX
									tClostLoc.nY = nDifY
									tClostLoc.nDist = nDist
								end
							end
						end

						local nRectH = 36
						if not WoW_LifeBar.bShowName and not WoW_LifeBar.bShowDistance then
							nRectH = 26
						end
						table.insert(tPlacedRectsZone, {nX = tClostLoc.nX, nY = tClostLoc.nY, nH = nRectH})
						frame:SetRelPos(tClostLoc.nX, tClostLoc.nY)

						local nX, nY = Cursor.GetPos()
						local handleLifeBar = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Handle_LifeBar")
						if (nX > tClostLoc.nX and nX < tClostLoc.nX + 120) and (nY > tClostLoc.nY and nY < tClostLoc.nY + 28) and Cursor.IsVisible() then
							handleLifeBar:Lookup("Image_LifeBar_L_Cover"):Show()
							handleLifeBar:Lookup("Image_LifeBar_M_Cover"):Show()
							handleLifeBar:Lookup("Image_LifeBar_R_Cover"):Show()
						else
							handleLifeBar:Lookup("Image_LifeBar_L_Cover"):Hide()
							handleLifeBar:Lookup("Image_LifeBar_M_Cover"):Hide()
							handleLifeBar:Lookup("Image_LifeBar_R_Cover"):Hide()
						end
					end
					WoW_LifeBar.Scene_GetCharacterTopScreenPos(function(x,y)
						if not x or not y then
							nScreenX, nScreenY = -4096 , -4096
						else
							nScreenX, nScreenY = x, y
						end
						fnAction()
					end,dwID)
				else
					WoW_LifeBar.RemoveLifeBar(dwID)
				end				
			else
				local handleLifeBar = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Handle_LifeBar")
				handleLifeBar:SetAlpha(0)
				frame:Hide()
			end
		else
			WoW_LifeBar.RemoveLifeBar(dwID)
		end
	end
end

function WoW_LifeBar.GetFrameVisibleDistance(frame)
	local player = GetClientPlayer()
	if not player then
		return
	end
	if not frame then
		return
	end
	frame.nDist3D = 99999999
	
	local dwID = frame.dwID
	local target = WoW_LifeBar.GetCharacter(dwID)
	if not target then
		WoW_LifeBar.RemoveLifeBar(dwID)
		return
	end
	
	if IsEnemy(player.dwID, dwID) then
		if not WoW_LifeBar.bShowEnemy then
			return
		end
	elseif not WoW_LifeBar.bShowAlly then
		return
	end

	if IsPlayer(dwID) then
		if not WoW_LifeBar.bShowPlayer then
			return
		end
		if WoW_LifeBar.bOnlyParty and not player.IsPlayerInMyParty(dwID) then
			return
		end	
	elseif not WoW_LifeBar.bShowNpc then
		return
	end
	
	local nDist3D = math.floor(((player.nX - target.nX) ^ 2 + (player.nY - target.nY) ^ 2 + (player.nZ / 8 - target.nZ / 8) ^ 2) ^ 0.5)
	frame.nDist3D = nDist3D
	local nCampDist = math.min(WoW_LifeBar.nRange * 64, WoW_LifeBar.nRangeMax * 64)
	if not WoW_LifeBar.bShowLifeBar then
		nCampDist = WoW_LifeBar.nRangeMax * 64
	end
	if nDist3D > nCampDist then
		return false, nDist3D
	end
	
	return true, nDist3D
end

function WoW_LifeBar.SortVisibleFrameByDistance()
	local player = GetClientPlayer()
	if not player then
		return
	end
	local _, dwSelectedTargetID = player.GetTarget()
	WoW_LifeBar.tSortedVisibleLifeBarList = {}
	if WoW_LifeBar.bShowTarget then
		if dwSelectedTargetID and dwSelectedTargetID > 0 and WoW_LifeBar.tLifeBarList[dwSelectedTargetID] then
			table.insert(WoW_LifeBar.tSortedVisibleLifeBarList, WoW_LifeBar.tLifeBarList[dwSelectedTargetID])
		end
	end
	
	for dwID, frame in pairs(WoW_LifeBar.tLifeBarList) do
		if frame then
			frame.bVisible = false
			if WoW_LifeBar.GetFrameVisibleDistance(frame) and (not WoW_LifeBar.bShowTarget or frame.dwID ~= dwSelectedTargetID) then
				if #WoW_LifeBar.tSortedVisibleLifeBarList == 0 then
					table.insert(WoW_LifeBar.tSortedVisibleLifeBarList, frame)
				else
					local nCurrentLen = math.min(#WoW_LifeBar.tSortedVisibleLifeBarList, WoW_LifeBar.nAllowMember)
					WoW_LifeBar.tSortedVisibleLifeBarList[nCurrentLen + 1] = frame
					for i = nCurrentLen, 1, -1 do
						local nCampDist = WoW_LifeBar.tSortedVisibleLifeBarList[i + 1].nDist3D
						local nSelfDist = WoW_LifeBar.tSortedVisibleLifeBarList[i].nDist3D
						if nCampDist < nSelfDist and (not WoW_LifeBar.bShowTarget or WoW_LifeBar.tSortedVisibleLifeBarList[i].dwID ~= dwSelectedTargetID) then
							WoW_LifeBar.tSortedVisibleLifeBarList[i + 1], WoW_LifeBar.tSortedVisibleLifeBarList[i] = WoW_LifeBar.tSortedVisibleLifeBarList[i], WoW_LifeBar.tSortedVisibleLifeBarList[i + 1]
						else
							break
						end
					end
				end
			end
		else
			WoW_LifeBar.RemoveLifeBar(dwID)
		end
	end
	WoW_LifeBar.tSortedVisibleLifeBarList[WoW_LifeBar.nAllowMember + 1] = nil

	for i = 1, #WoW_LifeBar.tSortedVisibleLifeBarList do
		WoW_LifeBar.tSortedVisibleLifeBarList[i].bVisible = true
		WoW_LifeBar.UpdateVisibleLifeBarData(WoW_LifeBar.tSortedVisibleLifeBarList[i])
	end
	return WoW_LifeBar.tSortedVisibleLifeBarList
end

local SchoolList={
	[0]="����",
	[1]="���",
	[2]="����",
	[3]="����", 
	[4]="��", 
	[5]="����",
	[6]="�ؽ�", 
	[7]="�ؽ�",
	[8]="�嶾"
}

local MANA_TYPE =
{
	MANA = 0,
	RAGE = 1,
	ENERGY = 2,
}

function WoW_LifeBar.UpdateVisibleLifeBarData(frame)
	if not frame then
		return
	end
	local player = GetClientPlayer()
	if not player then
		return
	end
	local dwID = frame.dwID
	local _, dwSelectedTargetID = player.GetTarget()
	local target = WoW_LifeBar.GetCharacter(dwID)
	if not target then
		WoW_LifeBar.RemoveLifeBar(dwID)
		return
	end
	
	local handleCastingBar = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Handle_CastingBar")
	local nCastingBarAlpha = handleCastingBar:GetAlpha()
	local imageCastingBarIcon = handleCastingBar:Lookup("Image_SkillIcon")
	local imageCastingBar = handleCastingBar:Lookup("Image_CastingBar")
	
	local handleLifeBar = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Handle_LifeBar")
	local imageLifeBar = handleLifeBar:Lookup("Image_LifeBar")
	local imageManaBar = handleLifeBar:Lookup("Image_ManaBar")
	local aniSelected = handleLifeBar:Lookup("Animate_Selected")
	
	if not imageManaBar.nManaType then
		imageManaBar.nManaType = MANA_TYPE.MANA
	end
	
	aniSelected:Hide()
	if dwSelectedTargetID == target.dwID then
		aniSelected:Show()
		frame.nFrameAlpha = 255
	elseif frame.nDist3D <= 640 then
		frame.nFrameAlpha = 175
	else
		if WoW_LifeBar.bShowLifeBar then
			local nCurrentRange = math.min(WoW_LifeBar.nRange * 64, WoW_LifeBar.nRangeMax * 64)
			frame.nFrameAlpha = 75 + math.max(100 * (1 - (frame.nDist3D - 640) / (nCurrentRange - 640)), 0)
		else
			frame.nFrameAlpha=175
		end
	end

	--������ʾ
	if WoW_LifeBar.nSteper % 4 == 0 then
		WoW_LifeBar.UpdateLifeBarColor(imageLifeBar, target)
		
		local textName = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Text_TargetName")
		local szName = target.szName
		if not WoW_LifeBar.bShowName or not WoW_LifeBar.bShowLifeBar then
			szName = ""
		end
		if WoW_LifeBar.bShowLifeBar and WoW_LifeBar.bShowDistance and dwID ~= player.dwID then
			local nDistTarget = frame.nDist3D
			if not frame.nDist3D or frame.nDist3D > 99999 then
				local target = WoW_LifeBar.GetCharacter(dwID)
				if target then
					nDistTarget = math.floor(((player.nX - target.nX) ^ 2 + (player.nY - target.nY) ^ 2 + (player.nZ / 8 - target.nZ / 8) ^ 2) ^ 0.5)
				else
					nDistTarget = 0
				end
			end
			szName = szName .. " " .. ("%.1f"):format(nDistTarget / 64) .. ""
		end
		
		if WoW_LifeBar.bShowLifeBar and WoW_LifeBar.bShowForce and IsPlayer(target.dwID) and target.dwSchoolID and SchoolList[target.dwSchoolID] then
			local szForeTitle=GetForceTitle(target.dwForceID)
			if SchoolList[target.dwSchoolID]=="����" then
				if szForeTitle=="�嶾" then
					szName="(�嶾)"..szName
				elseif szForeTitle=="����" then 
					szName="(����)"..szName
				elseif szForeTitle=="����" then 
					szName="(����)"..szName
				elseif szForeTitle=="ؤ��" then 
					szName="(ؤ��)"..szName
				else
					szName="("..SchoolList[target.dwSchoolID]..")"..szName
				end
			else
				szName="("..SchoolList[target.dwSchoolID]..")"..szName
			end
		end
		local r, g, b = WoW_LifeBar.GetCharacterColor(dwID)
		textName:SetFontColor(r, g, b)		
		textName:SetText(szName)
	end
	
	--Ѫ���ٷֱ�
	local nPercentage = target.nCurrentLife / target.nMaxLife
	imageLifeBar:SetPercentage(nPercentage)
	
	--����
	if WoW_LifeBar.bShowManaBar and target.nMoveState~=MOVE_STATE.ON_DEATH and IsPlayer(dwID) then
		local kungfu = target.GetKungfuMount()
		if kungfu and kungfu.dwMountType == 6 then
			if imageManaBar.nManaType ~= MANA_TYPE.RAGE then
				imageManaBar:FromUITex("ui\\Image\\TargetPanel\\Target.UITex", 86)
				imageManaBar.nManaType = MANA_TYPE.RAGE
			end
			imageManaBar:Show()
			local nRagePercentage = target.nCurrentRage / target.nMaxRage
			imageManaBar:SetPercentage(nRagePercentage)
		elseif kungfu and kungfu.dwMountType == 10 then
			if imageManaBar.nManaType ~= MANA_TYPE.ENERGY then
				imageManaBar:FromUITex("ui\\Image\\TargetPanel\\Target.UITex", 87)
				imageManaBar.nManaType = MANA_TYPE.ENERGY
			end
			imageManaBar:Show()
			local nEnergyPercentage = target.nCurrentEnergy / target.nMaxEnergy
			imageManaBar:SetPercentage(nEnergyPercentage)
		else
			if imageManaBar.nManaType ~= MANA_TYPE.MANA then
				imageManaBar:FromUITex("ui\\Image\\TargetPanel\\Target.UITex", 84)
				imageManaBar.nManaType = MANA_TYPE.MANA
			end
			imageManaBar:Show()
			local nManaPercentage = target.nCurrentMana / target.nMaxMana
			imageManaBar:SetPercentage(nManaPercentage)
		end
	else
		imageManaBar:Hide()
	end

	--����
	if WoW_LifeBar.bShowCastingBar then
		handleCastingBar:Show()
		local bPrePare, dwSkillID, dwSkillLevel, fCastPercent = target.GetSkillPrepareState()
		local textSkillName = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Text_SkillName")
		if bPrePare then
			local nSkillIconID = Table_GetSkillIconID(dwSkillID, dwSkillLevel)
			if not nSkillIconID or nSkillIconID == -1 then
				nSkillIconID = 13
			end
			imageCastingBarIcon:FromIconID(nSkillIconID)
			imageCastingBar:SetPercentage(fCastPercent)
			nCastingBarAlpha = nCastingBarAlpha + 45 * (frame.nFrameAlpha / 255)
			
			if (WoW_LifeBar.bShowName and not WoW_LifeBar.bShowLifeBar) or WoW_LifeBar.bShowCastingName and dwID ~= player.dwID then
				local szSkillName = Table_GetSkillName(dwSkillID, dwSkillLevel) or ""
				textSkillName:SetText(szSkillName)
				textSkillName:Show()
			else
				textSkillName:Hide()
			end
		elseif IsPlayer(dwID) and target.GetOTActionState() == 1 then
			local selectedtarget = WoW_LifeBar.GetCharacter(dwSelectedTargetID)
			local dwSelectedTargetTargetID = 0
			if selectedtarget then
				 _, dwSelectedTargetTargetID = selectedtarget.GetTarget()
			end				
			if target.dwID == dwSelectedTargetID then
				local target_frame = Station.Lookup("Normal/Target")
				local target_handle = target_frame:Lookup("", "Handle_Bar")
				local fCastPercent = target_handle:Lookup("Image_Progress"):GetPercentage()
				local szSkillName = target_handle:Lookup("Text_Name"):GetText()
				imageCastingBarIcon:FromIconID(13)
				imageCastingBar:SetPercentage(fCastPercent)
				nCastingBarAlpha = nCastingBarAlpha + 45 * (frame.nFrameAlpha / 255)
			
				if (WoW_LifeBar.bShowName and not WoW_LifeBar.bShowLifeBar) or WoW_LifeBar.bShowCastingName and dwID ~= player.dwID then
					textSkillName:SetText(szSkillName)
					textSkillName:Show()
				else
					textSkillName:Hide()
				end				
			elseif target.dwID == dwSelectedTargetTargetID and IsPlayer(dwSelectedTargetTargetID) then
				local targettarget_frame = Station.Lookup("Normal/TargetTarget")
				local targettarget_handle = targettarget_frame:Lookup("", "Handle_Bar")
				local fCastPercent = targettarget_handle:Lookup("Image_Progress"):GetPercentage()
				local szSkillName = targettarget_handle:Lookup("Text_Name"):GetText()
				imageCastingBarIcon:FromIconID(13)
				imageCastingBar:SetPercentage(fCastPercent)
				nCastingBarAlpha = nCastingBarAlpha + 45 * (frame.nFrameAlpha / 255)
			
				if (WoW_LifeBar.bShowName and not WoW_LifeBar.bShowLifeBar) or WoW_LifeBar.bShowCastingName and dwID ~= player.dwID then
					textSkillName:SetText(szSkillName)
					textSkillName:Show()
				else
					textSkillName:Hide()
				end		
			else
				imageCastingBarIcon:FromIconID(13)
				imageCastingBar:SetPercentage(1)
				nCastingBarAlpha = nCastingBarAlpha + 45 * (frame.nFrameAlpha / 255)
			
				if (WoW_LifeBar.bShowName and not WoW_LifeBar.bShowLifeBar) or WoW_LifeBar.bShowCastingName and dwID ~= player.dwID then
					textSkillName:SetText("������")
					textSkillName:Show()
				else
					textSkillName:Hide()
				end
			end
		elseif IsPlayer(dwID) and target.GetOTActionState() == 2 then
			if TargetEx and TargetEx.tChannelList[dwID] then
				local szSkillName, fP, nChannel = TargetEx.GetSkillChannelState(dwID)
				if nChannel then
					local dwSkillID = TargetEx.tChannelList[dwID][4]
					local nSkillIconID = Table_GetSkillIconID(dwSkillID, dwSkillLevel) or 13
					if dwSkillID == 3034 then
						nSkillIconID = 308
					elseif dwSkillID == 3035 then
						nSkillIconID = 796
					elseif dwSkillID == 4113 then
						nSkillIconID = 2891
					elseif arg1 == 3398 then
						nSkillIconID = 3193
					end
					imageCastingBarIcon:FromIconID(nSkillIconID)
					imageCastingBar:SetPercentage(fP)
			
					nCastingBarAlpha = nCastingBarAlpha + 45 * (frame.nFrameAlpha / 255)
			
					if (WoW_LifeBar.bShowName and not WoW_LifeBar.bShowLifeBar) or WoW_LifeBar.bShowCastingName and dwID ~= player.dwID then
						textSkillName:SetText(szSkillName)
						textSkillName:Show()
					else
						textSkillName:Hide()
					end	
				else
					imageCastingBarIcon:FromIconID(13)
					imageCastingBar:SetPercentage(1)
			
					nCastingBarAlpha = nCastingBarAlpha + 45 * (frame.nFrameAlpha / 255)
			
					if (WoW_LifeBar.bShowName and not WoW_LifeBar.bShowLifeBar) or WoW_LifeBar.bShowCastingName and dwID ~= player.dwID then
						textSkillName:SetText("������")
						textSkillName:Show()
					else
						textSkillName:Hide()
					end
				end
			else
				imageCastingBarIcon:FromIconID(13)
				imageCastingBar:SetPercentage(1)
			
				nCastingBarAlpha = nCastingBarAlpha + 45 * (frame.nFrameAlpha / 255)
			
				if (WoW_LifeBar.bShowName and not WoW_LifeBar.bShowLifeBar) or WoW_LifeBar.bShowCastingName and dwID ~= player.dwID then
					textSkillName:SetText("������")
					textSkillName:Show()
				else
					textSkillName:Hide()
				end
			end
		else
			textSkillName:Hide()
			nCastingBarAlpha = nCastingBarAlpha - 45 * (frame.nFrameAlpha / 255)
		end
		
		imageCastingBarIcon:SetSize(16, 16)
		if nCastingBarAlpha <= 0 then
			handleCastingBar:SetAlpha(0)
		elseif nCastingBarAlpha >= frame.nFrameAlpha then
			handleCastingBar:SetAlpha(frame.nFrameAlpha)
		else
			handleCastingBar:SetAlpha(nCastingBarAlpha)
			if bPrePare then
				local nSize = 16
				local nSizeMax = 116
				local nScale = math.min((fCastPercent * 8 * (frame.nFrameAlpha / 255)), 1)
				nSize = nSizeMax - nScale * (nSizeMax - nSize)
				imageCastingBarIcon:SetSize(nSize, nSize)
			end
		end
	else
		handleCastingBar:Hide()
	end
	
	local nLifeBarAlpha = handleLifeBar:GetAlpha()
	nLifeBarAlpha = math.min(nLifeBarAlpha + 30, frame.nFrameAlpha)
	if not WoW_LifeBar.bShowLifeBar then
		nLifeBarAlpha = 0
	end
	handleLifeBar:SetAlpha(nLifeBarAlpha)
	aniSelected:SetAlpha(nLifeBarAlpha * 0.5)
end

function WoW_LifeBar.ReplaceTopHeadEx(dwCharacterID, bHideTHE)
	if not WoW_LifeBar.bShowLifeBar then
		bHideTHE = false
	end
	
	if TopHeadDisplayEx then
		local handle = TopHeadDisplayEx.handleTotal
		if not handle then
			return
		end
		
		local handleLabel_Hp = handle:Lookup("Hp_" .. dwCharacterID)
		if handleLabel_Hp then
			if bHideTHE then
				handleLabel_Hp:SetAlpha(0)
			else
				handleLabel_Hp:SetAlpha(255)
			end
		end
		
		local handleLabel_Mp = handle:Lookup("Mp_" .. dwCharacterID)
		if handleLabel_Mp then
			if bHideTHE then
				handleLabel_Mp:SetAlpha(0)
			else
				handleLabel_Mp:SetAlpha(255)
			end
		end
		
		local handleLabel_Name = handle:Lookup("Name_" .. dwCharacterID)
		if handleLabel_Name then
			if bHideTHE then
				handleLabel_Name:Hide()
			else
				handleLabel_Name:Show()
			end
		end
	end
	if Head then
		local frame = Station.Lookup("Lowest/Head")
		if frame then
			local handle = frame:Lookup("","")
			if handle then
				local item = handle:Lookup(tostring(dwCharacterID))
				if item then
					if bHideTHE then
						item:Hide()
						if item.hwndmp then 
							item.hwndmp:Hide()
						end
						item.hwndbg:Hide()
						item.hwndhp:Hide()
					else
						item:Show()
					end
				end
			end
		end
	end
	if XuHead then
		local handle = XuHead.handleTotal
		if not handle then
			return
		end
		
		local handleLabel_Name = handle:Lookup("Name_xNPC_" .. dwCharacterID)
		if handleLabel_Name then
			if bHideTHE then
				handleLabel_Name:Hide()
			else
				handleLabel_Name:Show()
			end
		end
	end
end

function WoW_LifeBar.GetCharacterColor(dwCharacterID)
	local player = GetClientPlayer()
	if not player then
		return 128, 128, 128
	end
	
	if not IsPlayer(dwCharacterID) then
		local nRed, nGreen, nBlue=GetHeadTextForceFontColor(dwCharacterID,player.dwID)
		return nRed, nGreen, nBlue
	end

	local target = WoW_LifeBar.GetCharacter(dwCharacterID)
	if not target then
		return 128, 128, 128
	end
	
	local nForceID = target.dwForceID
	if not nForceID then
		return 250, 250, 250
	end
	
	if nForceID == 0 then		-- ��
		return 255, 255, 255
	elseif nForceID == 1 then	-- ����
		return 255, 178, 95
	elseif nForceID == 2 then	-- ��
		return 196, 152, 255
	elseif nForceID == 3 then	-- ���
		return 255, 68, 72
	elseif nForceID == 4 then	-- ����
		return 89, 224, 232
	elseif nForceID == 5 then	-- ����
		return 255, 129, 176
	elseif nForceID == 6 then	-- �嶾
		return 55, 147, 255
	elseif nForceID == 7 then	-- ����
		return 121, 183, 54
	elseif nForceID == 8 then	-- �ؽ�
		return 214, 249, 93
	elseif nForceID == 9 then	-- ؤ��
		return 240, 210, 174
	elseif nForceID == 10 then	-- ����
		return 247, 101, 13
	end
	return 250, 250, 250
end

function WoW_LifeBar.UpdateLifeBarColor(imageBar, target)
	if not imageBar or not target then
		return
	end
	local player = GetClientPlayer()
	if not player then
		return
	end
	local nImageFrame = 79
	if IsNeutrality(player.dwID, target.dwID) then
		nImageFrame = 38
	elseif IsAlly(player.dwID, target.dwID) then
		if IsPlayer(target.dwID) then
			if player.IsPlayerInMyParty(target.dwID) then
				nImageFrame = 37
			else
				nImageFrame = 87
			end
		else
			nImageFrame = 73
		end
	elseif IsEnemy(player.dwID, target.dwID) then
		nImageFrame = 40
	end
	if imageBar.nImageFrame ~= nImageFrame then
		imageBar:SetFrame(nImageFrame)
		imageBar.nImageFrame = nImageFrame
	end
end

function WoW_LifeBar.GetCharacter(dwID)
	local target = nil
	if IsPlayer(dwID) then
		target = GetPlayer(dwID)
	else
		target = GetNpc(dwID)
		if target and not target.CanSeeName() then
			return
		end
	end
	return target
end

function WoW_LifeBar.CreateLifeBar(dwTargetID)
	if not dwTargetID then
		return
	end
	if not WoW_LifeBar.bShowSelf then
		if dwTargetID == GetClientPlayer().dwID then
			return
		end
	end
	
	local target = WoW_LifeBar.GetCharacter(dwTargetID)
	if not target then
		return
	end
	
	local frame = Station.Lookup("Lowest1/WoW_LifeBar_" .. dwTargetID)
	if frame then
		return
	end
	
	frame = Wnd.OpenWindow("Interface\\WoW_LifeBar\\WoW_LifeBar.ini", "WoW_LifeBar_" .. dwTargetID)
	if not frame then
		return
	end
	frame:Show()
	frame.dwID = dwTargetID
	WoW_LifeBar.tLifeBarList[dwTargetID] = frame

	local textName = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Text_TargetName")
	if WoW_LifeBar.bShowName and WoW_LifeBar.bShowLifeBar then
		textName:SetText(target.szName)
	else
		textName:SetText("")
	end
		
	
	local handleLifeBar = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Handle_LifeBar")
	local imageBar = handleLifeBar:Lookup("Image_LifeBar")
	WoW_LifeBar.UpdateLifeBarColor(imageBar, target)
	handleLifeBar:SetAlpha(0)
	
	local handleCastingBar = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Handle_CastingBar")
	handleCastingBar:SetAlpha(0)
end

function WoW_LifeBar.RemoveLifeBar(dwTargetID)
	local frame = Station.Lookup("Lowest1/WoW_LifeBar_" .. dwTargetID)
	if frame then
		WoW_LifeBar.tLifeBarList[dwTargetID] = nil
		Wnd.CloseWindow(frame:GetName())
	end
end

function WoW_LifeBar.OpenPanel()
	local frame = Station.Lookup("Lowest1/WoW_LifeBar")
	if not frame then
		frame = Wnd.OpenWindow("Interface\\WoW_LifeBar\\WoW_LifeBar.ini", "WoW_LifeBar")
	end
	frame:Show()
	frame:SetSize(0, 0)
	frame:Lookup("", ""):Hide()
end

WoW_LifeBar.OpenPanel()