JunePrepare={
bSwitch=true,
nSteper=0,
pList={},
m_1=false,
m_2=1,
m_3=true,
nDist=40,
tChannel = {},
}
RegisterCustomData("JunePrepare.bSwitch")
RegisterCustomData("JunePrepare.m_1")
RegisterCustomData("JunePrepare.m_2")
RegisterCustomData("JunePrepare.m_3")
RegisterCustomData("JunePrepare.nDist")
if not June_AllNear then
	June_AllNear = {}
end
if not June_ChannelSkill then
	June_ChannelSkill = {
	[570] = 80,		[7319] = 96,	[2724] = 40,	[3100] = 48,	[1645] = 84,
	[7320] = 128,	[2674] = 8,		[2707] = 48,	[2589] = 96,	[7317] = 48,
	[3093] = 40,	[7318] = 64,	[565] = 48,		[567] = 160,	[2233] = 80,
	[2235] = 128,	[368] = 80,		[300] = 80,		[2636] = 80,	[7314] = 32,
	[368] = 80,
	}
end
if not June_GetTarget then
	June_GetTarget = function(dwType, dwID)
	if not dwID then
		dwID, dwType = dwType, TARGET.NPC
		if IsPlayer(dwID) then
			dwType = TARGET.PLAYER
		end
	end
	if dwID <= 0 or dwType == TARGET.NO_TARGET then
		return nil, TARGET.NO_TARGET
	elseif dwType == TARGET.PLAYER then
		return GetPlayer(dwID), TARGET.PLAYER
	else
		return GetNpc(dwID), TARGET.NPC
	end
	end
end
if not June_doSkillCast then
	June_doSkillCast = function(dwCaster, dwID, dwLevel,szEvent)
	local player = GetClientPlayer()
	local nCurrentFrame = GetLogicFrameCount()
	local SkillName = Table_GetSkillName(dwID, dwLevel)
	if June_ChannelSkill[dwID] and (SkillName and SkillName~= nil) then
		for k, v in pairs(JunePrepare.tChannel) do
			local bDel = (nCurrentFrame - v[2]) > v[3]
			if not bDel then
				local tar,tType=June_GetTarget(k)
				bDel = tar ~= nil and tar.GetOTActionState() ~= 2
			end
			if bDel then
				JunePrepare.tChannel[k] = nil
			end
		end
		if not JunePrepare.tChannel[dwCaster] then
			--OutputMessage("MSG_SYS",tar.szName.."("..SkillName..") \n")
			JunePrepare.tChannel[dwCaster] = { SkillName, nCurrentFrame, June_ChannelSkill[dwID], dwID }
		end
	end
	end
end
if not June_GetSkillChannelState then
	June_GetSkillChannelState = function(dwID)
	local rec = JunePrepare.tChannel[dwID]
	if rec then
		local nFrame = GetLogicFrameCount() - rec[2]
		if nFrame < rec[3] then
			local fP = 1 - nFrame / rec[3]
			return rec[1], fP, rec[2]
		end
	end
	end
end
if not June_GetNearList then
	June_GetNearList = function()
	local player = GetClientPlayer()
	local NearList = {}
	for i,v in pairs(June_AllNear) do
		local tar,tType=June_GetTarget(v)
		if tar then
			table.insert(NearList,tar)
		end
	end
	return NearList
	end
end
function JunePrepare.OnFrameCreate()
	this:RegisterEvent("CUSTOM_DATA_LOADED")
	this:RegisterEvent("UI_SCALED")
	this:RegisterEvent("NPC_ENTER_SCENE")
	this:RegisterEvent("NPC_LEAVE_SCENE")
	this:RegisterEvent("PLAYER_ENTER_SCENE")
	this:RegisterEvent("PLAYER_LEAVE_SCENE")
	this:RegisterEvent("RENDER_FRAME_UPDATE")
	this:RegisterEvent("DO_SKILL_CAST")
	this:RegisterEvent("SYS_MSG")
	this:RegisterEvent("OT_ACTION_PROGRESS_BREAK")

end
function JunePrepare.OnEvent(event)
	if event == "RENDER_FRAME_UPDATE" then
		JunePrepare.UpdateAll()
	elseif event == "NPC_ENTER_SCENE" or event == "PLAYER_ENTER_SCENE" then
		table.insert(June_AllNear,arg0)
	elseif event == "NPC_LEAVE_SCENE" or event == "PLAYER_LEAVE_SCENE" then
		local tID = arg0
		for i,v in pairs(June_AllNear) do
			if v == tID then
				table.remove(June_AllNear,i)
			end
		end
	elseif event == "DO_SKILL_CAST" then
			June_doSkillCast(arg0, arg1, arg2, event)
	elseif event == "SYS_MSG" then
		if arg0 == "UI_OME_SKILL_CAST_LOG" then
			June_doSkillCast(arg1, arg2, arg3, arg0)
		elseif arg0 == "UI_OME_SKILL_EFFECT_LOG" then
			June_doSkillCast(arg1, arg5, arg6, arg0)
		elseif arg0 == "UI_OME_SKILL_MISS_LOG" then
			June_doSkillCast(arg1, arg4, arg5, arg0)
		elseif	arg0 == "UI_OME_SKILL_HIT_LOG" then
			June_doSkillCast(arg1, arg4, arg5, arg0)
		elseif arg0 == "UI_OME_SKILL_DODGE_LOG" then
			June_doSkillCast(arg1, arg4, arg5, arg0)
		elseif arg0 == "UI_OME_SKILL_SHIELD" then
			June_doSkillCast(arg1, arg4, arg5, arg0)
		elseif arg0 == "UI_OME_SKILL_BLOCK_LOG" then
			June_doSkillCast(arg1, arg4, arg5, arg0)
		end
	elseif event == "OT_ACTION_PROGRESS_BREAK" then
		JunePrepare.tChannel[arg0] = nil
	end
end

function JunePrepare.OnFrameBreathe()
	if not JunePrepare.bSwitch then return end
	JunePrepare.nSteper = JunePrepare.nSteper + 1
	if JunePrepare.nSteper>16 then
		JunePrepare.getList()
		JunePrepare.nSteper=0
	end
end

function JunePrepare.OnRespondCharacterTopScreenPos(handleLabel, nScreenX, nScreenY)
	if handleLabel and nScreenX and nScreenY then
		nScreenX, nScreenY = Station.AdjustToOriginalPos(nScreenX, nScreenY)
		local nWidth, nHeight = handleLabel:GetSize()
		local nX, nY = math.floor(nScreenX - nWidth / 2), math.floor(nScreenY - 4)
		handleLabel:SetAbsPos(nX, nY-4)
		handleLabel:Show()
	end
end
function JunePrepare.GetTopScreenPos(hPlayer)
	local nTopX, nTopY, nTopZ = Scene_GetCharacterTop(hPlayer.dwID)
	local nScreenX, nScreenY
	if nTopX and nTopY and nTopZ then
		nScreenX, nScreenY = Scene_ScenePointToScreenPoint(nTopX, nTopY, nTopZ)
	end
	if nScreenX and nScreenY then
		nScreenX, nScreenY = Station.AdjustToOriginalPos(nScreenX, nScreenY)
	end
	return nScreenX, nScreenY, true
end
function JunePrepare.UpdateAll()
	if not JunePrepare.bSwitch then return end
	local handle = JunePrepare.handleTotal
	handle:Clear()
	for _,hPlayer in ipairs(JunePrepare.pList) do
		local szHandleLabelName = "Name_" .. tostring(hPlayer.dwID)
		local handleLabel = handle:Lookup(szHandleLabelName)
		local bPrePare, dwID, dwLevel, fP = hPlayer.GetSkillPrepareState()
		local szSkill
		if bPrePare then
			szSkill = Table_GetSkillName(dwID, dwLevel)
			JunePrepare.tChannel[hPlayer.dwID] = nil
		elseif (not bPrePare) and JunePrepare.tChannel[hPlayer.dwID] then
			szSkill, fP, _ = June_GetSkillChannelState(hPlayer.dwID)
		end
		if not handleLabel and szSkill then
			handle:AppendItemFromIni("Interface/JunePrepare/JunePrepare.ini", "Handle_Label", szHandleLabelName)
			handleLabel = handle:Lookup(handle:GetItemCount() - 1)
			handleLabel.dwID = hPlayer.dwID
			handleLabel:Hide()
			local imgProgress = handleLabel:Lookup("Image_Progress")
			local textProgress = handleLabel:Lookup("Text_Progress")
			textProgress:SetText(szSkill)
			imgProgress:SetPercentage(fP)
			PostThreadCall(JunePrepare.OnRespondCharacterTopScreenPos, handleLabel, "Scene_GetCharacterTopScreenPos", hPlayer.dwID)
		end
	end
end
function JunePrepare.getList()
		JunePrepare.pList={}
		for k,v in pairs(June_GetNearList()) do
			local player=GetClientPlayer()
			local bInsert=true
			if bInsert and JunePrepare.m_1 then
				bInsert=IsEnemy(player.dwID,v.dwID)
			end
			if bInsert and JunePrepare.m_2 == 5 then
				bInsert=(IsPlayer(v.dwID))
			end
			if bInsert and JunePrepare.m_2 == 4 then
				bInsert=(GetNpcIntensity(v) == 4)
			end
			if bInsert and JunePrepare.m_2 == 3 then
				bInsert=(not IsPlayer(v.dwID))
			end
			if bInsert and JunePrepare.m_3 then
				bInsert=(math.floor(GetCharacterDistance(player.dwID,v.dwID)/64)<JunePrepare.nDist)
			end
			if bInsert then
				table.insert(JunePrepare.pList,v)
			end
		end
end
function JunePrepare.OpenPanel()
	local frame = Station.Lookup("Lowest/JunePrepare")
	if not frame then
		frame = Wnd.OpenWindow("Interface/JunePrepare/JunePrepare.ini", "JunePrepare")
	end
	frame:Show()
	JunePrepare.handleTotal = frame:Lookup("", "")
end
JunePrepare.OpenPanel()
JunePrepare.Menu = function()
	local menu = {
	szOption = " Juneͷ������",
	bCheck = true,
	bChecked = JunePrepare.bSwitch==true,
	fnAction = function()
		if JunePrepare.bSwitch then
			JunePrepare.bSwitch=false
			JunePrepare.handleTotal:Clear()
			OutputMessage("MSG_SYS","Juneͷ��������ʾ�رգ�by �޻�@�㻪��\n")
		else
			JunePrepare.bSwitch=true
			JunePrepare.getList()
			JunePrepare.UpdateAll()
			OutputMessage("MSG_SYS","Juneͷ��������ʾ������by �޻�@�㻪��\n")
		end
	end,
	}
	local m_1 = {
			szOption = "����ʾ�жԶ���",
			bCheck = true,
			bChecked = JunePrepare.m_1==true,
			fnAction = function()
				JunePrepare.m_1 = not JunePrepare.m_1
				if JunePrepare.m_1 then
					JunePrepare.getList()
					OutputMessage("MSG_SYS","Juneͷ������������ʾ�жԶ�������\n")
				end
			end,
		}
	local m_2 = {
			szOption = "����ʾNPC����",
			bMCheck = true,
			bChecked = JunePrepare.m_2==3,
			fnAction = function()
				JunePrepare.m_2 = 3
					JunePrepare.getList()
				OutputMessage("MSG_SYS","Juneͷ������������ʾNPC��������\n")
			end,
		}
	local m_5 = {
			szOption = "����ʾBOSS����",
			bMCheck = true,
			bChecked = JunePrepare.m_2==4,
			fnAction = function()
				JunePrepare.m_2 = 4
				JunePrepare.getList()
				OutputMessage("MSG_SYS","Juneͷ������������ʾBOSS��������\n")
			end,
		}
	local m_4 = {
			szOption = "����ʾ��Ҷ���",
			bMCheck = true,
			bChecked = JunePrepare.m_2==5,
			fnAction = function()
				JunePrepare.m_2 = 5
				JunePrepare.getList()
				OutputMessage("MSG_SYS","Juneͷ������������ʾ��Ҷ�������\n")
			end,
		}
	local m_3 = {
			szOption = "������������",
			bCheck = true,
			bChecked = JunePrepare.m_3==true,
			fnAction = function()
				JunePrepare.m_3 = not JunePrepare.m_3
				if JunePrepare.m_3 then
					JunePrepare.getList()
					OutputMessage("MSG_SYS","Juneͷ���������������ơ��ѿ�����ֻ��ʾ"..JunePrepare.nDist.."�����ڶ�����\n")
				end
			end,
		}
	local m_3_1 = {
			szOption = "20",
			bMCheck = true,
			bChecked = JunePrepare.nDist==20,
			fnAction = function()
				JunePrepare.nDist=20
				if not JunePrepare.m_3 then
					OutputMessage("MSG_SYS","�����������������ơ������Ϲ�Ϊ������\n")
				end
			end,
		}
	local m_3_2 = {
			szOption = "40",
			bMCheck = true,
			bChecked = JunePrepare.nDist==40,
			fnAction = function()
				JunePrepare.nDist=40
				if not JunePrepare.m_3 then
					OutputMessage("MSG_SYS","�����������������ơ������Ϲ�Ϊ������\n")
				end
			end,
		}
	local m_3_3 = {
			szOption = "80",
			bMCheck = true,
			bChecked = JunePrepare.nDist==80,
			fnAction = function()
				JunePrepare.nDist=80
				if not JunePrepare.m_3 then
					OutputMessage("MSG_SYS","�����������������ơ������Ϲ�Ϊ������\n")
				end
			end,
		}
	table.insert(menu, m_1)
	table.insert(menu, m_4)
	table.insert(menu, m_2)
	table.insert(menu, m_5)
	table.insert(menu, m_3)
	table.insert(m_3, m_3_1)
	table.insert(m_3, m_3_2)
	table.insert(m_3, m_3_3)
	return menu
end

Player_AppendAddonMenu({function() return {JunePrepare.Menu()} end})

OutputMessage("MSG_SYS","Juneͷ������ v2.24 ����Ѽ��أ� by �޻�@�㻪��\n")