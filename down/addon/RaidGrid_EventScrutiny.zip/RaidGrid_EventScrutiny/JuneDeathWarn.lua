JuneDeathWarn = {
	bSwitch = true,
	szIniFile = "interface\\\RaidGrid_EventScrutiny\\JuneDeathWarn.ini",
	nChannel = "MSG_SYS",
	tDeath = {},
	tDamage = {},
	bDeathWarn = true,
	tNoFight = 0,
	bFightDel = false,
	bSelfDeath = false,
}
RegisterCustomData("JuneDeathWarn.bSwitch")
-- RegisterCustomData("JuneDeathWarn.bDeathWarn")
RegisterCustomData("JuneDeathWarn.bFightDel")
-- RegisterCustomData("JuneDeathWarn.nChannel")
RegisterCustomData("JuneDeathWarn.tDeath")

function JuneDeathWarn.OnFrameCreate()
	this:RegisterEvent("SYS_MSG")
	this:RegisterEvent("FIGHT_HINT")
end
function JuneDeathWarn.OnEvent(event)
	local player = GetClientPlayer()
	if not player or not JuneDeathWarn.bSwitch then return end
	if event == "SYS_MSG" then
		if arg0 == "UI_OME_DEATH_NOTIFY" then
			JuneDeathWarn.OnDeath(arg1, arg3)
		elseif arg0 == "UI_OME_SKILL_EFFECT_LOG" then
			JuneDeathWarn.OnSkillEffectLog(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9)
		elseif arg0 == "UI_OME_COMMON_HEALTH_LOG" then
			JuneDeathWarn.OnCommonHealthLog(arg1, arg2)
		end
	elseif event == "FIGHT_HINT" and JuneDeathWarn.bFightDel then
		local tLogicFrame = GetLogicFrameCount()
		if not arg0 and player.nMoveState ~= MOVE_STATE.ON_DEATH then
			JuneDeathWarn.tNoFight = tLogicFrame
		elseif arg0 then
			if tLogicFrame - JuneDeathWarn.tNoFight > 3 * 16 then
				JuneDeathWarn.tDeath = {}
			end
		end
	end
end
function JuneDeathWarn.OnSkillEffectLog(dwCaster, dwTarget, bReact, nEffectType, dwID, dwLevel, bCriticalStrike, nCount, tResult)
	local Caster = nil;
	local Target = nil;
	local szSkillName = nil;
	if nCount <= 2 then
		return
	end
	if IsPlayer(dwCaster) then
		Caster = GetPlayer(dwCaster)
	else
		Caster = GetNpc(dwCaster)
	end
	if not Caster then
		return
	end
	if IsPlayer(dwTarget) then
		Target = GetPlayer(dwTarget)
	else
		Target = GetNpc(dwTarget)
	end
	if not Target then
		return
	end
	if nEffectType == SKILL_EFFECT_TYPE.SKILL then
		szSkillName = Table_GetSkillName(dwID, dwLevel);
	elseif nEffectType == SKILL_EFFECT_TYPE.BUFF then
		szSkillName = Table_GetBuffName(dwID, dwLevel);
	end
	if not szSkillName then
		return
	end
	local player = GetClientPlayer()
	local hTeam = GetClientTeam()
	if IsPlayer(dwTarget) then
		if player.IsPlayerInMyParty(dwTarget) or hTeam.IsPlayerInTeam(dwTarget) or dwTarget==player.dwID then
			if not JuneDeathWarn.tDamage[dwTarget] then
				JuneDeathWarn.tDamage[dwTarget] = {}
			end
			local szDamage = ""
			local nValue = tResult[SKILL_RESULT_TYPE.PHYSICS_DAMAGE]
			if nValue and nValue > 0 then
				if szDamage ~= "" then
					szDamage = szDamage..g_tStrings.STR_COMMA
				end	
				szDamage = szDamage..FormatString(g_tStrings.SKILL_DAMAGE, nValue, g_tStrings.STR_SKILL_PHYSICS_DAMAGE)
			end
			nValue = tResult[SKILL_RESULT_TYPE.SOLAR_MAGIC_DAMAGE]
			if nValue and nValue > 0 then
				if szDamage ~= "" then
					szDamage = szDamage..g_tStrings.STR_COMMA
				end
				szDamage = szDamage..FormatString(g_tStrings.SKILL_DAMAGE, nValue, g_tStrings.STR_SKILL_SOLAR_MAGIC_DAMAGE)
			end
			nValue = tResult[SKILL_RESULT_TYPE.NEUTRAL_MAGIC_DAMAGE]
			if nValue and nValue > 0 then
				if szDamage ~= "" then
					szDamage = szDamage..g_tStrings.STR_COMMA
				end
				szDamage = szDamage..FormatString(g_tStrings.SKILL_DAMAGE, nValue, g_tStrings.STR_SKILL_NEUTRAL_MAGIC_DAMAGE)
			end
			nValue = tResult[SKILL_RESULT_TYPE.LUNAR_MAGIC_DAMAGE]
			if nValue and nValue > 0 then
				if szDamage ~= "" then
					szDamage = szDamage..g_tStrings.STR_COMMA
				end
				szDamage = szDamage..FormatString(g_tStrings.SKILL_DAMAGE, nValue, g_tStrings.STR_SKILL_LUNAR_MAGIC_DAMAGE)
			end
			nValue = tResult[SKILL_RESULT_TYPE.POISON_DAMAGE]
			if nValue and nValue > 0 then
				if szDamage ~= "" then
					szDamage = szDamage..g_tStrings.STR_COMMA
				end
				szDamage = szDamage..FormatString(g_tStrings.SKILL_DAMAGE, nValue, g_tStrings.STR_SKILL_POISON_DAMAGE)
			end
			if szDamage ~= "" then
				table.insert(JuneDeathWarn.tDamage[dwTarget],{
					szCaster = Caster.szName,
					szTarget = Target.szName,
					szSkillName = szSkillName,
					szValue = szDamage,
				})
			end
		end
	end
	if IsPlayer(dwCaster) and (player.IsPlayerInMyParty(dwCaster) or hTeam.IsPlayerInTeam(dwCaster) or dwCaster==player.dwID) then
		if not JuneDeathWarn.tDamage[dwCaster] then
			JuneDeathWarn.tDamage[dwCaster] = {}
		end
		local szDamage = ""
		local nValue = tResult[SKILL_RESULT_TYPE.REFLECTIED_DAMAGE]
		if nValue and nValue > 0 then
			if szDamage ~= "" then
				szDamage = szDamage..g_tStrings.STR_COMMA
			end
			szDamage = szDamage..nValue.."���˺�"
		end
		if szDamage ~= "" then
			table.insert(JuneDeathWarn.tDamage[dwCaster],{
				szCaster = Target.szName,
				szTarget = Caster.szName,
				szSkillName = "����("..szSkillName..")",
				szValue = szDamage,
			})
		end
	end
end
function JuneDeathWarn.OnCommonHealthLog(dwTarget, nDeltaLife)
	local Target = nil;
	if IsPlayer(dwTarget) then
		Target = GetPlayer(dwTarget)
	else
		Target = GetNpc(dwTarget)
	end
	if not Target then
		return
	end
	if nDeltaLife < 0 then
		nDeltaLife = -nDeltaLife
	end
	local player = GetClientPlayer()
	local hTeam = GetClientTeam() 
	if IsPlayer(dwTarget) then
		if player.IsPlayerInMyParty(dwTarget) or hTeam.IsPlayerInTeam(dwTarget) or dwTarget==player.dwID then
			if not JuneDeathWarn.tDamage[dwTarget] then
				JuneDeathWarn.tDamage[dwTarget] = {}
			end
			table.insert(JuneDeathWarn.tDamage[dwTarget],{
				szCaster = "δ֪Ŀ��",
				szTarget = Target.szName,
				szSkillName = "��������",
				szValue = nDeltaLife.."���˺�",
			})
		end
	end
end
function JuneDeathWarn.OnDeath(dwTarget, szKiller)
	local player = GetClientPlayer()
	if JuneDeathWarn.bSelfDeath and dwTarget~=player.dwID then return end
	local hTeam = GetClientTeam()
	local tRecordList = JuneDeathWarn.tDamage[dwTarget]
	if IsPlayer(dwTarget) and tRecordList then
		if player.IsPlayerInMyParty(dwTarget) or hTeam.IsPlayerInTeam(dwTarget) or dwTarget==player.dwID then
			local nCurrent = GetCurrentTime()
			local tInfo = tRecordList[#tRecordList]
			if tInfo then
				tInfo.time = nCurrent
				if JuneDeathWarn.bDeathWarn then
					if JuneDeathWarn.nChannel == "MSG_SYS" then
						JuneDeathWarn.ColorMessage({tInfo.szTarget,{30,154,225}},{" �� ",{255,128,128}},{tInfo.szCaster,{30,154,225}},{" >> ",{255,255,128}},{tInfo.szSkillName.." ("..tInfo.szValue..")",{255,255,255}})
					else
						player.Talk(JuneDeathWarn.nChannel,"",{{type="text",text="["..tInfo.szTarget.."]��["..tInfo.szCaster.."]��<"..tInfo.szSkillName..">�����"..tInfo.szValue.."���������ˣ�\n"}})
					end
				end
				table.insert(JuneDeathWarn.tDeath,tInfo)
				JuneDeathWarn.tDamage[dwTarget] = nil
			end
		end
	end
end

function JuneDeathWarn.ColorMessage(...)
	local aTabel = { ... }
	local szText = ""
	for _, v in ipairs(aTabel) do
		local szMessage = v[1]
		local r,g,b = unpack(v[2])
		szText = szText .. "<text>text=\"".. tostring(szMessage) .."\" font=10 r="..r.." g="..g.." b="..b.." </text>"
	end
	OutputMessage("MSG_SYS",szText.."<text>text=\"\n\"</text>",true)
end
function JuneDeathWarn.Menu()
    menu = {
    szOption = "������ʾ",
    bCheck = true,
    bChecked = JuneDeathWarn.bSwitch == true,
    fnAction = function()
		JuneDeathWarn.bSwitch = not JuneDeathWarn.bSwitch
		if JuneDeathWarn.bSwitch then
			OutputMessage("MSG_SYS","June������ʾ �ѿ����� by �޻�@�㻪��\n")
		else
			OutputMessage("MSG_SYS","June������ʾ �ѹرգ� by �޻�@�㻪��\n")
		end
	end,
    }
	local m_1 = {
			szOption = "�������˼�¼",
            bCheck = true,
            fnAction = function()
				local player = GetClientPlayer()
				for i,tInfo in ipairs(JuneDeathWarn.tDeath) do
					local t = TimeToDate(tInfo.time)
					local szTime = string.format("%02d:%02d:%02d", t.hour, t.minute, t.second)
					player.Talk(PLAYER_TALK_CHANNEL.RAID,"",{{type="text",text=szTime.."��["..tInfo.szTarget.."]��["..tInfo.szCaster.."]��<"..tInfo.szSkillName..">�����"..tInfo.szValue.."���������ˣ�\n"}})
				end
            end,
			}
			table.insert(m_1,{szOption = "===��ʾ���50����¼===",bCheck = true,bDisable = true,})
			table.insert(m_1, {bDevide = true})
			for i=#JuneDeathWarn.tDeath,#JuneDeathWarn.tDeath-50,-1 do
				local tInfo = JuneDeathWarn.tDeath[i]
				if tInfo then
					local t = TimeToDate(tInfo.time)
					local szTime = string.format("%02d:%02d:%02d", t.hour, t.minute, t.second)
					table.insert(m_1,{szOption = szTime.."��["..tInfo.szTarget.."]��["..tInfo.szCaster.."]��<"..tInfo.szSkillName..">���ˣ�",})
				end
			end
	local m_2 = {
			szOption = "������˼�¼",
            fnAction = function()
				JuneDeathWarn.tDeath = {}
            end,
			}
	local m_3 = {
			szOption = "������ʾ����",
            bCheck = true,
            bChecked = JuneDeathWarn.bDeathWarn == true,
            fnAction = function()
				JuneDeathWarn.bDeathWarn = not JuneDeathWarn.bDeathWarn
            end,
			}
	local m_4 = {
			szOption = "��ʾƵ������",
			}
	local tChannel={
			["MSG_SYS"]="ϵͳƵ��",
			[PLAYER_TALK_CHANNEL.NEARBY]="����Ƶ��",
			[PLAYER_TALK_CHANNEL.RAID]="�Ŷ�Ƶ��",
			[PLAYER_TALK_CHANNEL.TONG]="���Ƶ��",
			}
		for nChannel,szChannel in pairs(tChannel) do
			table.insert(m_4,{
			szOption = szChannel,
            bMCheck = true,
            bChecked = JuneDeathWarn.nChannel == nChannel,
            fnAction = function()
				JuneDeathWarn.nChannel = nChannel
            end,
			})
		end
	local m_5 = {
			szOption = "��ս�����¼",
            bCheck = true,
            bChecked = JuneDeathWarn.bFightDel == true,
            fnAction = function()
				JuneDeathWarn.bFightDel = not JuneDeathWarn.bFightDel
            end,
			}
	local m_6 = {
			szOption = "ֻ��¼��������",
            bCheck = true,
            bChecked = JuneDeathWarn.bSelfDeath == true,
            fnAction = function()
				JuneDeathWarn.bSelfDeath = not JuneDeathWarn.bSelfDeath
            end,
			}
		-- table.insert(menu,m_4)
		-- table.insert(menu,m_3)
		table.insert(menu,m_5)
		table.insert(menu,m_6)
		table.insert(menu, {bDevide = true})
		table.insert(menu,m_1)
		table.insert(menu,m_2)
	return menu
end
Player_AppendAddonMenu({function() return {JuneDeathWarn.Menu()} end})
-- �󶨿�ݼ�
Hotkey.AddBinding("JuneDeathWarn", "�л�����״̬","June������ʾ",
	function()
		JuneDeathWarn.bSwitch = not JuneDeathWarn.bSwitch
		if JuneDeathWarn.bSwitch then
			OutputMessage("MSG_SYS","June������ʾ �ѿ����� by �޻�@�㻪��\n")
		else
			OutputMessage("MSG_SYS","June������ʾ �ѹرգ� by �޻�@�㻪��\n")
		end
	end,nil)
-- Hotkey.AddBinding("JuneDeathWarn_Output", "�������˼�¼","",
	-- function()
		-- local player = GetClientPlayer()
		-- for i,tInfo in ipairs(JuneDeathWarn.tDeath) do
			-- local t = TimeToDate(tInfo.time)
			-- local szTime = string.format("%02d:%02d:%02d", t.hour, t.minute, t.second)
			-- if JuneDeathWarn.nChannel == "MSG_SYS" then
				-- JuneDeathWarn.ColorMessage({szTime,{255,128,128}},{tInfo.szTarget,{75,200,80}},{" �� ",{255,128,128}},{tInfo.szCaster,{75,200,80}},{" >> ",{255,128,128}},{tInfo.szSkillName.." ("..tInfo.szValue..")",{225,128,255}})
			-- else
				-- player.Talk(JuneDeathWarn.nChannel,"",{{type="text",text=szTime.."��["..tInfo.szTarget.."]��["..tInfo.szCaster.."]��<"..tInfo.szSkillName..">�����"..tInfo.szValue.."���������ˣ�\n"}})
			-- end
		-- end
	-- end,nil)
Hotkey.AddBinding("JuneDeathWarn_Del", "������˼�¼","",
	function()
		JuneDeathWarn.tDeath = {}
	end,nil)

Wnd.OpenWindow(JuneDeathWarn.szIniFile, "JuneDeathWarn"):Hide()
--OutputMessage("MSG_SYS","June������ʾ ������Ѽ��أ� by �޻�@�㻪��\n")