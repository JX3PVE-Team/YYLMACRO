Snow_OTBarSkinOpt = {}

function Snow_OTBarSkinOpt.OnFrameCreate()
	this:SetPoint("CENTER", 0, 0, "CENTER", -15, -180)
	this:Lookup("",""):Lookup("Image_Preview"):FromTextureFile("Interface\\Snow_OTBar\\Skins\\"..Snow_OTBar.UserData.SkinFolderName.."\\Snow_OTBar_Sample.tga")
	local text = string.gsub(Snow_OTBar.SkinList[Snow_OTBar.UserData.nSkinNum],"Skin%d_","")
	this:Lookup("",""):Lookup("Text_Skin"):SetText(text)
	this:Lookup("",""):Lookup("Text_SkinNum"):SetText("Ƥ��"..tostring(Snow_OTBar.UserData.nSkinNum))
	if Snow_OTBar.UserData.nSkinNum == 1 then
		this:Lookup("Button_Prev"):Enable(false)
	elseif Snow_OTBar.UserData.nSkinNum == #Snow_OTBar.SkinList then
		this:Lookup("Button_Next"):Enable(false)
	end
end

function Snow_OTBarSkinOpt.OnLButtonClick()
	local frame = Station.Lookup("Topmost/Snow_OTBarSkinOpt")
	if this:GetName() == "Button_Prev" then
		if Snow_OTBar.UserData.nSkinNum == #Snow_OTBar.SkinList then
			frame:Lookup("Button_Next"):Enable(true)
		end
		Snow_OTBar.UserData.nSkinNum = Snow_OTBar.UserData.nSkinNum - 1
		Snow_OTBar.UserData.SkinFolderName = Snow_OTBar.SkinList[Snow_OTBar.UserData.nSkinNum]
		if Snow_OTBar.UserData.nSkinNum == 1 then
			this:Enable(false)
		end
		frame:Lookup("",""):Lookup("Image_Preview"):FromTextureFile("Interface\\Snow_OTBar\\Skins\\"..Snow_OTBar.UserData.SkinFolderName.."\\Snow_OTBar_Sample.tga")
		local text = string.gsub(Snow_OTBar.SkinList[Snow_OTBar.UserData.nSkinNum],"Skin%d_","")
		frame:Lookup("",""):Lookup("Text_Skin"):SetText(text)
		frame:Lookup("",""):Lookup("Text_SkinNum"):SetText("Ƥ��"..tostring(Snow_OTBar.UserData.nSkinNum))
	elseif this:GetName() == "Button_Next" then
		if Snow_OTBar.UserData.nSkinNum == 1 then
			frame:Lookup("Button_Prev"):Enable(true)
		end
		Snow_OTBar.UserData.nSkinNum = Snow_OTBar.UserData.nSkinNum + 1
		Snow_OTBar.UserData.SkinFolderName = Snow_OTBar.SkinList[Snow_OTBar.UserData.nSkinNum]
		if Snow_OTBar.UserData.nSkinNum == #Snow_OTBar.SkinList then
			this:Enable(false)
		end
		frame:Lookup("",""):Lookup("Image_Preview"):FromTextureFile("Interface\\Snow_OTBar\\Skins\\"..Snow_OTBar.UserData.SkinFolderName.."\\Snow_OTBar_Sample.tga")
		local text = string.gsub(Snow_OTBar.SkinList[Snow_OTBar.UserData.nSkinNum],"Skin%d_","")
		frame:Lookup("",""):Lookup("Text_Skin"):SetText(text)
		frame:Lookup("",""):Lookup("Text_SkinNum"):SetText("Ƥ��"..tostring(Snow_OTBar.UserData.nSkinNum))
	end


end

function Snow_OTBarSkinOpt.PanelSwitch()
	local frame = Station.Lookup("Topmost/Snow_OTBarSkinOpt")
	if not frame then
		frame = Wnd.OpenWindow("Interface\\Snow_OTBar\\Snow_OTBarSkinOpt.ini","Snow_OTBarSkinOpt")
	else
		Wnd.CloseWindow("Snow_OTBarSkinOpt")
		local OTBarframe = Station.Lookup("Topmost/Snow_OTBar")
		Snow_OTBar.ChangeSkin(OTBarframe)
	end
end
