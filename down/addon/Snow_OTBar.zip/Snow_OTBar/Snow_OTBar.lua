Snow_OTBar =
{
Break = false,
bAdjustUIPos = false,
bCraftAll = false,
bFade = false,
bSaveCurrentTime = false,
FadeAlpha = 255,
IconSize = 35,
nCraftNum = 0,
nDiverderNum = 0,
nTimeMakeOne = 0,
nStartTickCount = 0,
nStartTickCountSave = 0,
nEndTickCount = 0,
nEndTickCountSave = 0,
SkillName = "",
ProgressType = 0, -- 1Ϊadd,2Ϊdec
Sav_CraftManagePanel = nil,
DefaultAnchor = {s = "BOTTOMCENTER", r = "BOTTOMCENTER",  x = 0, y = -255},
SkinList =
{
[1] = "Skin1_Org",
[2] = "Skin2_UncleX����",
[3] = "Skin3_Flower",
[4] = "Skin4_Dragon"
},
}

Snow_OTBar.UserData =
{
	Anchor = {s = "BOTTOMCENTER", r = "BOTTOMCENTER",  x = 0, y = -255},
	AlphaFrame = 255,
	AlphaBG = 255,
	AlphaProgress = 255,
	AlphaResult = 255,
	AlphaDelay = 255,
	bCloseSystemBar = true,
	bShowDivider = true,
	nSkinNum = 1,
	SkinFolderName = "",
	Results_S = "Interface\\Snow_OTBar\\Skins\\Skin0_Org\\Snow_OTBar_Success.uitex",
	Results_F = "Interface\\Snow_OTBar\\Skins\\Skin0_Org\\Snow_OTBar_Interrupt.uitex",
	Divider = "Interface\\Snow_OTBar\\Skins\\Skin0_Org\\Snow_OTBar_Divider.uitex",

}

RegisterCustomData("Snow_OTBar.UserData")

function Snow_OTBar.OnFrameCreate()

	this:RegisterEvent("DO_SKILL_PREPARE_PROGRESS")
	this:RegisterEvent("DO_SKILL_CHANNEL_PROGRESS")
	this:RegisterEvent("OT_ACTION_PROGRESS_UPDATE")
	this:RegisterEvent("OT_ACTION_PROGRESS_BREAK")
	this:RegisterEvent("DO_PICK_PREPARE_PROGRESS")
	this:RegisterEvent("DO_CUSTOM_OTACTION_PROGRESS")
	this:RegisterEvent("DO_RECIPE_PREPARE_PROGRESS")

	this:RegisterEvent("UI_SCALED")
	this:RegisterEvent("OTACTION_BAR_ANCHOR_CHANGED")
	this:RegisterEvent("CUSTOM_DATA_LOADED")
	this:RegisterEvent("ON_ENTER_CUSTOM_UI_MODE")
	this:RegisterEvent("ON_LEAVE_CUSTOM_UI_MODE")

	this:EnableDrag(false)
	Snow_OTBar.UpdateAnchor(this)
	Snow_OTBar.ChangeSkin(this)

end

function Snow_OTBar.ChangeSkin(frame)
	if Snow_OTBar.UserData.nSkinNum == 1 then
		Snow_OTBar.UserData.SkinFolderName = Snow_OTBar.SkinList[Snow_OTBar.UserData.nSkinNum]
	elseif Snow_OTBar.UserData.nSkinNum == 2 then
		Snow_OTBar.UserData.SkinFolderName = Snow_OTBar.SkinList[Snow_OTBar.UserData.nSkinNum]
		Snow_OTBar.UserData.AlphaDelay = 180
		Snow_OTBar.UserData.AlphaBG = 180
	elseif Snow_OTBar.UserData.nSkinNum == 3 then
		Snow_OTBar.UserData.SkinFolderName = Snow_OTBar.SkinList[Snow_OTBar.UserData.nSkinNum]
		Snow_OTBar.UserData.AlphaDelay = 180
		Snow_OTBar.UserData.AlphaBG = 180
	end

	frame:Lookup("",""):Lookup("Image_BG"):FromUITex("Interface\\Snow_OTBar\\Skins\\"..Snow_OTBar.UserData.SkinFolderName.."\\Snow_OTBar_BG.uitex",0)
	frame:Lookup("",""):Lookup("Image_Progress"):FromUITex("Interface\\Snow_OTBar\\Skins\\"..Snow_OTBar.UserData.SkinFolderName.."\\Snow_OTBar_Progress.uitex",0)
	frame:Lookup("",""):Lookup("Image_Delay_B"):FromUITex("Interface\\Snow_OTBar\\Skins\\"..Snow_OTBar.UserData.SkinFolderName.."\\Snow_OTBar_Delay.uitex",0)
	frame:Lookup("",""):Lookup("Image_Delay_F"):FromUITex("Interface\\Snow_OTBar\\Skins\\"..Snow_OTBar.UserData.SkinFolderName.."\\Snow_OTBar_Delay.uitex",0)
	frame:Lookup("",""):Lookup("Handle_Divider"):Lookup("Image_Divider"):FromUITex("Interface\\Snow_OTBar\\Skins\\"..Snow_OTBar.UserData.SkinFolderName.."\\Snow_OTBar_Divider.uitex",0)
	Snow_OTBar.UserData.Results_S = "Interface\\Snow_OTBar\\Skins\\"..Snow_OTBar.UserData.SkinFolderName.."\\Snow_OTBar_Success.uitex"
	Snow_OTBar.UserData.Results_F = "Interface\\Snow_OTBar\\Skins\\"..Snow_OTBar.UserData.SkinFolderName.."\\Snow_OTBar_Interrupt.uitex"
	Snow_OTBar.UserData.Divider = "Interface\\Snow_OTBar\\Skins\\"..Snow_OTBar.UserData.SkinFolderName.."\\Snow_OTBar_Divider.uitex"
end

function Snow_OTBar.OnFrameDragEnd()
	this:CorrectPos()
	Snow_OTBar.UserData.Anchor = GetFrameAnchor(this)
end

function Snow_OTBar.UpdateAnchor(frame)
	frame:SetPoint(Snow_OTBar.UserData.Anchor.s, 0, 0, Snow_OTBar.UserData.Anchor.r, Snow_OTBar.UserData.Anchor.x, Snow_OTBar.UserData.Anchor.y)
	frame:CorrectPos()
end

function Snow_OTBar.OnEvent(szEvent)
	if szEvent == "DO_SKILL_PREPARE_PROGRESS" and not Snow_OTBar.bAdjustUIPos then
		Snow_OTBar.OnSkillPrepareProgress(szEvent)
	elseif szEvent == "DO_SKILL_CHANNEL_PROGRESS" and not Snow_OTBar.bAdjustUIPos then
		Snow_OTBar.OnSkillChannelProgress(szEvent)
	elseif szEvent == "OT_ACTION_PROGRESS_UPDATE" and not Snow_OTBar.bAdjustUIPos then
		Snow_OTBar.OnActionProgressUpdate(szEvent)
	elseif szEvent == "OT_ACTION_PROGRESS_BREAK" and not Snow_OTBar.bAdjustUIPos then
		if arg0 == GetClientPlayer().dwID then
			Snow_OTBar.OnActionProgressBreak(szEvent)
		end
	elseif szEvent == "DO_PICK_PREPARE_PROGRESS" and not Snow_OTBar.bAdjustUIPos then
		Snow_OTBar.OnPickPrepareProgress(szEvent)
	elseif szEvent == "DO_CUSTOM_OTACTION_PROGRESS" and not Snow_OTBar.bAdjustUIPos then
		Snow_OTBar.OnCustomOTActionProgress(szEvent)
	elseif szEvent == "DO_RECIPE_PREPARE_PROGRESS" and not Snow_OTBar.bAdjustUIPos then
		Snow_OTBar.OnRecipeOTActionProgress(szEvent)
	elseif szEvent == "CUSTOM_DATA_LOADED" then
		Snow_OTBar.UpdateAnchor(this)
		Snow_OTBar.ChangeSkin(this)
		if Snow_OTBar.UserData.bCloseSystemBar then
			Wnd.CloseWindow("OTActionBar")
		end
	elseif szEvent == "UI_SCALED" then
		Snow_OTBar.UpdateAnchor(this)
	end
end

function Snow_OTBar.OnFrameRender()

	local frame = Station.Lookup("Topmost/Snow_OTBar")
	local handle = frame:Lookup("","")

	if Snow_OTBar.bAdjustUIPos then
		frame:Show()
		frame:SetAlpha(255)
		frame:EnableDrag(true)
		handle:Lookup("Image_Icon"):FromIconID(13)
		handle:Lookup("Image_Results"):Hide()
		handle:Lookup("Image_Progress"):Show()
		handle:Lookup("Image_Progress"):SetPercentage(0.5)
		handle:Lookup("Text_SkillName"):SetText("�϶��Ե���λ��")
		handle:Lookup("Text_Time"):SetText("--/--")
		handle:Lookup("Image_Delay_B"):Hide()
		handle:Lookup("Image_Delay_F"):Hide()
		handle:Lookup("Handle_Divider"):Hide()
		return
	end

	frame:EnableDrag(false)

	if GetTickCount() < Snow_OTBar.nEndTickCount and not Snow_OTBar.bCraftAll and not Snow_OTBar.Break then
		Snow_OTBar.bFade = false
	end

	-----����-----
	if Snow_OTBar.bFade then
		frame:SetAlpha(Snow_OTBar.FadeAlpha)
		Snow_OTBar.FadeAlpha = Snow_OTBar.FadeAlpha - 42.5
		if Snow_OTBar.FadeAlpha <= 0 then
			frame:Hide()
			Snow_OTBar.FadeAlpha = 0
			Snow_OTBar.bFade = false
		end
	end

	-----��С-----
	Snow_OTBar.IconSize = Snow_OTBar.IconSize - 4.5

	if Snow_OTBar.IconSize < 35 then
		Snow_OTBar.IconSize = 35
	end

	handle:Lookup("Image_Icon"):SetSize(Snow_OTBar.IconSize,Snow_OTBar.IconSize)
	handle:Lookup("Image_Icon"):SetRelPos(17.5 - Snow_OTBar.IconSize/2,17.5 - Snow_OTBar.IconSize/2)
	handle:FormatAllItemPos()

	if GetTickCount() > Snow_OTBar.nEndTickCount and Snow_OTBar.FadeAlpha > 0 and not Snow_OTBar.bCraftAll then
		Snow_OTBar.FlashProgressBar(true)
	end

	Snow_OTBar.UpdateProgressBar()
end

--���༼��������
--����
function Snow_OTBar.OnSkillPrepareProgress(szEvent)
	local nTotalFrame = arg0

	if (nTotalFrame <= 0) then
	    return
	end

	local nTotalTime = tonumber(("%.2f"):format(nTotalFrame / GLOBAL.GAME_FPS))
	Snow_OTBar.nStartTickCount = GetTickCount()
	Snow_OTBar.nEndTickCount = GetTickCount() + nTotalFrame * 1000 / GLOBAL.GAME_FPS

	Snow_OTBar.ProgressType = 1
	Snow_OTBar.Break = false

	local szName = Table_GetSkillName(arg1,arg2)
	local dwIconID = Table_GetSkillIconID(arg1,arg2)
	if arg1 == 53 then
		dwIconID = Table_GetSkillIconID(605,1) --����
	elseif arg1 == 3691 then
		dwIconID = Table_GetSkillIconID(81,1)
	end

	if dwIconID == 13 then
		local nCount = g_tTable.Item:GetRowCount()
		for i = 1, nCount do
			local tLine = g_tTable.Item:GetRow(i)
			if tLine.szName == szName then
				dwIconID = tLine.dwIconID
				break
			end
		end
	end

	Snow_OTBar.SkillName = szName
	Snow_OTBar.PrepareProgressBar(dwIconID,szName)
end

--����
function Snow_OTBar.OnSkillChannelProgress(szEvent)

	local nTotalFrame = arg0

	if (nTotalFrame <= 0) then
	    return
	end

	Snow_OTBar.nStartTickCount = GetTickCount()
	Snow_OTBar.nEndTickCount = GetTickCount() + nTotalFrame * 1000 / GLOBAL.GAME_FPS
	Snow_OTBar.nEndTickCountSave = Snow_OTBar.nEndTickCount

	Snow_OTBar.ProgressType = 2
	Snow_OTBar.Break = false

	local szName = Table_GetSkillName(arg1,arg2)
	local dwIconID = Table_GetSkillIconID(arg1,arg2)
	if arg1 == 3034 then
		dwIconID = 308
		szName = "ѩ�������"
	elseif arg1 == 3035 then
		dwIconID = 796
		szName = "ѪӰ�����輧"
	elseif arg1 == 4113 then
		dwIconID = 2891
		szName = "Ы������"
	elseif arg1 == 3398 then
		dwIconID = 3193
	end
	Snow_OTBar.SkillName = szName

	if arg1 == 300 then --�������
		Snow_OTBar.PrepareCombineProgressBar(dwIconID,szName,10)
	elseif
	arg1 == 368 or --���϶���
	arg1 == 567 or --������ת
	arg1 == 570 or --�»���к
	arg1 == 2233 or	--�������
	arg1 == 2636 or --��ѩʱ��
	arg1 == 2724 or --��������
	arg1 == 3093 then --�����滨��
		Snow_OTBar.PrepareCombineProgressBar(dwIconID,szName,5)
	elseif
	arg1 == 3034 then --ѩ�������
		Snow_OTBar.PrepareCombineProgressBar(dwIconID,szName,6)
	elseif
	arg1 == 565 or --��ѩƮҡ
	arg1 == 2707 or --���Ҽ���
	arg1 == 3100 or --������
	arg1 == 4113 then --Ы������
		Snow_OTBar.PrepareCombineProgressBar(dwIconID,szName,3)
	elseif arg1 == 1645 then --��ɽ����
		if GetClientPlayer().GetSkillLevel(2756) == 1 then --���ɼ��
			Snow_OTBar.PrepareCombineProgressBar(dwIconID,szName,10)
		elseif GetClientPlayer().GetSkillLevel(2756) == 2 then
			Snow_OTBar.PrepareCombineProgressBar(dwIconID,szName,12)
		else
			Snow_OTBar.PrepareCombineProgressBar(dwIconID,szName,8)
		end
	elseif arg1 == 2235 then --ǧ������
		Snow_OTBar.PrepareCombineProgressBar(dwIconID,szName,16)
	elseif arg1 == 3539 then --���䱩���滨��
		Snow_OTBar.PrepareCombineProgressBar(dwIconID,szName,15)
	else
		Snow_OTBar.PrepareProgressBar(dwIconID,szName)
	end

end

--�ɼ�
function Snow_OTBar.OnPickPrepareProgress(szEvent)

	local nTotalFrame = arg0

	if (nTotalFrame <= 0) then
	    return
	end

	local doodad = GetDoodad(arg1);
	local szName = doodad.szName --Table_GetDoodadName(doodad.dwTemplateID, doodad.dwNpcTemplateID)
	local dwIconID = nil
	local doodadTemplate = GetDoodadTemplate(doodad.dwTemplateID);

	if doodadTemplate then
		local szBarText = ""
		local tDoodad = g_tTable.DoodadTemplate:Search(dwTemplateID)
		if tDoodad then
			szBarText = tDoodad.szBarText
		end
		if szBarText ~= "" then
			szName = szBarText;
		end

		if doodadTemplate.dwCraftID ~= 0 then
			--local craft = GetCraft(doodadTemplate.dwCraftID);
			--if craft then
				local tCraft = g_tTable.UICraft:Search(dwCraftID)
				if tCraft then
					szName = tCraft.szName
				end
				local nCount = g_tTable.Craft:GetRowCount()
				for i = 1, nCount do
					local tLine = g_tTable.Craft:GetRow(i)
					if doodadTemplate.dwCraftID == tLine.dwProfessionID then
						dwIconID = tLine.dwIconID
						break
					end
				end
			--end
		end
	end

	Snow_OTBar.nStartTickCount = GetTickCount()
	Snow_OTBar.nEndTickCount = GetTickCount() + nTotalFrame * 1000 / GLOBAL.GAME_FPS

	Snow_OTBar.ProgressType = 1
	Snow_OTBar.Break = false
	Snow_OTBar.SkillName = szName

	Snow_OTBar.PrepareProgressBar(dwIconID,szName)

end

--�䷽
function Snow_OTBar.OnRecipeOTActionProgress(event)

	local nTotalFrame = arg0

	if (nTotalFrame <= 0) then
	    return
	end

	Snow_OTBar.nStartTickCount = GetTickCount()
	Snow_OTBar.nEndTickCount = GetTickCount() + nTotalFrame * 1000 / GLOBAL.GAME_FPS

	Snow_OTBar.ProgressType = 1
	Snow_OTBar.Break = false

	local szName = Table_GetRecipeName(arg1, arg2)
	local dwIconID = nil

	if arg1 == 12 then
		dwIconID = 26 --ë��ͼ��
	else
		local recipe = GetRecipe(arg1,arg2)
		local nType = recipe.dwCreateItemType1
		local nID	= recipe.dwCreateItemIndex1
		dwIconID = Table_GetItemIconID(GetItemInfo(nType,nID).nUiId)
	end

	Snow_OTBar.SkillName = szName

	if Snow_OTBar.bSaveCurrentTime then
		Snow_OTBar.nStartTickCountSave = Snow_OTBar.nStartTickCount
		Snow_OTBar.nEndTickCountSave = Snow_OTBar.nEndTickCount
		Snow_OTBar.nTimeMakeOne = (Snow_OTBar.nEndTickCount - Snow_OTBar.nStartTickCount) / 1000
		Snow_OTBar.bSaveCurrentTime = false
		Snow_OTBar.PrepareCombineProgressBar(dwIconID,szName,CraftManagePanel.nMakeCount)
	else
		Snow_OTBar.PrepareProgressBar(dwIconID,szName)
	end
end

--�Զ���
function Snow_OTBar.OnCustomOTActionProgress(event)

	local nTotalFrame = arg0

	if (nTotalFrame <= 0) then
	    return
	end

	Snow_OTBar.nStartTickCount = GetTickCount()
	Snow_OTBar.nEndTickCount = GetTickCount() + nTotalFrame * 1000 / GLOBAL.GAME_FPS

	if arg2 == 0 then
		Snow_OTBar.ProgressType = 1
		Snow_OTBar.Break = false
	else
		Snow_OTBar.ProgressType = 2
		Snow_OTBar.Break = false
	end
	Snow_OTBar.SkillName = arg1
	Snow_OTBar.PrepareProgressBar(nil,arg1)

end

function Snow_OTBar.OnActionProgressBreak(szEvent)
	Snow_OTBar.FlashProgressBar(false)
end

function Snow_OTBar.OnActionProgressUpdate(event)
    local nFrame = arg0
	Snow_OTBar.nEndTickCount = Snow_OTBar.nEndTickCount + nFrame * 1000 / GLOBAL.GAME_FPS
end
--------------׼��������--------------
function Snow_OTBar.PrepareProgressBar(dwIconID,szName)
	local frame = Station.Lookup("Topmost/Snow_OTBar")
	local handle = Station.Lookup("Topmost/Snow_OTBar"):Lookup("","")
	local hI = handle:Lookup("Handle_Divider_List")
	hI:Clear()

	frame:Show()
	frame:SetAlpha(Snow_OTBar.UserData.AlphaFrame)

	if dwIconID == nil then
		handle:Lookup("Image_Icon"):FromIconID(13) --��ɫ̫��ͼ
	else
		handle:Lookup("Image_Icon"):FromIconID(dwIconID)
	end

	local ping = GetPingValue() / 2

	if Snow_OTBar.ProgressType == 1 then
		handle:Lookup("Image_Delay_B"):Hide()
		handle:Lookup("Image_Delay_F"):Show()
		handle:Lookup("Image_Delay_F"):SetAlpha(Snow_OTBar.UserData.AlphaDelay)
		handle:Lookup("Image_Delay_F"):SetPercentage(ping / (Snow_OTBar.nEndTickCount - Snow_OTBar.nStartTickCount))
	else
		handle:Lookup("Image_Delay_B"):Show()
		handle:Lookup("Image_Delay_F"):Hide()
		handle:Lookup("Image_Delay_B"):SetAlpha(Snow_OTBar.UserData.AlphaDelay)
		handle:Lookup("Image_Delay_B"):SetPercentage(ping / (Snow_OTBar.nEndTickCount - Snow_OTBar.nStartTickCount))
	end

	handle:Lookup("Handle_Divider"):Hide()
	handle:Lookup("Image_Results"):Hide()
	handle:Lookup("Image_Progress"):Show()
	handle:Lookup("Image_BG"):Show()

	handle:Lookup("Text_SkillName"):SetText(szName)

	if Snow_OTBar.bCraftAll then
		handle:Lookup("Text_SkillName"):SetText(szName.."    "..(Snow_OTBar.nCraftNum - CraftManagePanel.nMakeCount + 1).."/"..Snow_OTBar.nCraftNum)
	end


	handle:Lookup("Image_Results"):SetAlpha(Snow_OTBar.UserData.AlphaResult)
	handle:Lookup("Image_Progress"):SetAlpha(Snow_OTBar.UserData.AlphaProgress)
	handle:Lookup("Image_BG"):SetAlpha(Snow_OTBar.UserData.AlphaBG)
	Snow_OTBar.FadeAlpha = Snow_OTBar.UserData.AlphaFrame
	Snow_OTBar.IconSize = 75

	hI:FormatAllItemPos()

end

function Snow_OTBar.PrepareCombineProgressBar(dwIconID,szName,nNum)
	local frame = Station.Lookup("Topmost/Snow_OTBar")
	local handle = Station.Lookup("Topmost/Snow_OTBar"):Lookup("","")
	local hI = handle:Lookup("Handle_Divider_List")
	hI:Clear()

	frame:Show()
	frame:SetAlpha(Snow_OTBar.UserData.AlphaFrame)

	if dwIconID == nil then
		handle:Lookup("Image_Icon"):FromIconID(13) --��ɫ̫��ͼ
	else
		handle:Lookup("Image_Icon"):FromIconID(dwIconID)
	end

	local ping = GetPingValue() / 2
	handle:Lookup("Image_Delay_B"):Show()
	handle:Lookup("Image_Delay_B"):SetAlpha(Snow_OTBar.UserData.AlphaDelay)
	handle:Lookup("Image_Delay_B"):SetPercentage(ping / (Snow_OTBar.nEndTickCount - Snow_OTBar.nStartTickCount))
	handle:Lookup("Image_Delay_F"):Hide()
	handle:Lookup("Handle_Divider"):Hide()
	--handle:Lookup("Handle_Divider"):SetRelPos(35,0)
	--handle:Lookup("Handle_Divider"):SetAlpha(180)
	handle:Lookup("Image_Results"):Hide()
	handle:Lookup("Image_Progress"):Show()
	handle:Lookup("Image_BG"):Show()

	if Snow_OTBar.bCraftAll then
		handle:Lookup("Image_Delay_B"):Hide()
		handle:Lookup("Text_SkillName"):SetText(szName.."    "..(Snow_OTBar.nCraftNum - CraftManagePanel.nMakeCount + 1).."/"..Snow_OTBar.nCraftNum)
	else
		handle:Lookup("Text_SkillName"):SetText(szName)
		if nNum > 1 then
			Snow_OTBar.nDiverderNum = nNum - 1
			for i = 1,nNum - 1 do
				local divider = hI:AppendItemFromIni("interface\\Snow_OTBar\\Snow_OTBar.ini", "Handle_Divider","Handle_Divider_"..i)
				divider:SetRelPos(40 + 340 / nNum * i,0)
				divider:Lookup("Image_Divider"):FromUITex(Snow_OTBar.UserData.Divider,0)
			end
			hI:FormatAllItemPos()
		end
	end

	handle:Lookup("Image_Results"):SetAlpha(Snow_OTBar.UserData.AlphaResult)
	handle:Lookup("Image_Progress"):SetAlpha(Snow_OTBar.UserData.AlphaProgress)
	handle:Lookup("Image_BG"):SetAlpha(Snow_OTBar.UserData.AlphaBG)

	Snow_OTBar.FadeAlpha = Snow_OTBar.UserData.AlphaFrame
	Snow_OTBar.IconSize = 75

	if not Snow_OTBar.UserData.bShowDivider then
		hI:Clear()
	end

	handle:FormatAllItemPos()
end
--���¼�����
function Snow_OTBar.UpdateProgressBar()

	if Snow_OTBar.Break then
		return
	end

	if CraftManagePanel.nMakeCount == 0 then
		Snow_OTBar.bCraftAll = false
	end

	if GetTickCount() > Snow_OTBar.nEndTickCount then
		return
	end

	local frame = Station.Lookup("Topmost/Snow_OTBar")
	local handle = Station.Lookup("Topmost/Snow_OTBar"):Lookup("","")
	local currenttime = 0
	local totaltime = 0

	if Snow_OTBar.ProgressType == 2 then
		currenttime = tonumber(("%.2f"):format((Snow_OTBar.nEndTickCount - GetTickCount())/1000))
		totaltime = tonumber(("%.2f"):format((Snow_OTBar.nEndTickCountSave - Snow_OTBar.nStartTickCount)/1000))
	else
		currenttime = tonumber(("%.2f"):format((GetTickCount() - Snow_OTBar.nStartTickCount)/1000))
		totaltime = tonumber(("%.2f"):format((Snow_OTBar.nEndTickCount - Snow_OTBar.nStartTickCount)/1000))
	end

	local frameprogress = currenttime/totaltime

	if Snow_OTBar.bCraftAll then
		if totaltime > 0 then
			handle:Lookup("Handle_Divider"):Show()
			if 40 + frameprogress * 340 > 383 then
				handle:Lookup("Handle_Divider"):SetRelPos(383,0)
			else
				handle:Lookup("Handle_Divider"):SetRelPos(40 + frameprogress * 340,0)
			end
			handle:FormatAllItemPos()
			currenttime = tonumber(("%.2f"):format(currenttime + Snow_OTBar.nTimeMakeOne * (Snow_OTBar.nCraftNum - CraftManagePanel.nMakeCount)))
			totaltime = tonumber(("%.2f"):format(Snow_OTBar.nTimeMakeOne * Snow_OTBar.nCraftNum))
			frameprogress = currenttime / totaltime
		end
		if not Snow_OTBar.UserData.bShowDivider then
			handle:Lookup("Handle_Divider"):Hide()
		end
	end

	if frameprogress > 1 then
		frameprogress = 1
	elseif frameprogress < 0 then
		frameprogress = 0
	end

	if currenttime > totaltime then
		currenttime = totaltime
	elseif currenttime < 0 then
		currenttime = 0
	end

	handle:Lookup("Image_Progress"):SetPercentage(frameprogress)

	if currenttime > 10 and totaltime > 10 then
		handle:Lookup("Text_Time"):SetText(tostring(("%.0f"):format(currenttime)).." / "..tostring(("%.0f"):format(totaltime)))
	elseif totaltime > 10 then
		handle:Lookup("Text_Time"):SetText(tostring(("%.2f"):format(currenttime)).."/ "..tostring(("%.0f"):format(totaltime)))
	elseif currenttime > 10 then
		handle:Lookup("Text_Time"):SetText(tostring(("%.0f"):format(currenttime)).." /"..tostring(("%.2f"):format(totaltime)))
	else
		handle:Lookup("Text_Time"):SetText(tostring(("%.2f"):format(currenttime)).."/"..tostring(("%.2f"):format(totaltime)))
	end
end

--��˸
function Snow_OTBar.FlashProgressBar(bSuccess)

	local handle = Station.Lookup("Topmost/Snow_OTBar"):Lookup("","")
	local image = handle:Lookup("Image_Progress")
	image:Hide()

	if bSuccess then
		image = handle:Lookup("Image_Results")
		image:Show()
		image:FromUITex(Snow_OTBar.UserData.Results_S,0)
	else
		image = handle:Lookup("Image_Results")
		image:Show()
		image:FromUITex(Snow_OTBar.UserData.Results_F,0)
		handle:Lookup("Text_SkillName"):SetText(Snow_OTBar.SkillName.."    �Ѵ��")
		Snow_OTBar.Break = true
	end

	Snow_OTBar.bFade = true
end

--hook
Snow_OTBar.Sav_CraftManagePanel = CraftManagePanel.OnLButtonClick

function CraftManagePanel.OnLButtonClick()
	local frame  = this:GetRoot()
	local szName = this:GetName()

	if szName == "Btn_Close" then
		CloseCraftManagePanel()
	elseif szName == "Btn_Add" then
		CraftManagePanel.UpdateMakeCount(frame, 1)
	elseif szName == "Btn_Del" then
		CraftManagePanel.UpdateMakeCount(frame, -1)
	elseif szName == "Btn_Make" then
		local nProID = CraftManagePanel.nProfessionID
		local nCraftID = CraftManagePanel.tSelected[nProID].nCraftID
		local nRecipeID = CraftManagePanel.tSelected[nProID].nRecipeID
		local recipe = GetRecipe(nCraftID, nRecipeID)

		if recipe.nCraftType == ALL_CRAFT_TYPE.PRODUCE then
			CraftManagePanel.SetMakeInfo(frame)
			CraftManagePanel.OnMakeRecipe(frame)
		elseif  recipe.nCraftType == ALL_CRAFT_TYPE.ENCHANT then
			CraftManagePanel.nMakeCraftID  = nCraftID
			CraftManagePanel.nMakeRecipeID = nRecipeID
			CraftManagePanel.nMakeCount = 1
			CraftManagePanel.OnEnchantItem()
		end

		if CraftManagePanel.nMakeCount == 1 then
			Snow_OTBar.bCraftAll = false
		else
			Snow_OTBar.bCraftAll = true
			Snow_OTBar.bSaveCurrentTime = true
			Snow_OTBar.nCraftNum = CraftManagePanel.nMakeCount
		end
	elseif szName == "Btn_MakeAll" then
		CraftManagePanel.SetMakeInfo(frame, true)
		CraftManagePanel.OnMakeRecipe(frame)
		Snow_OTBar.bCraftAll = true
		Snow_OTBar.bSaveCurrentTime = true
		Snow_OTBar.nCraftNum = CraftManagePanel.nMakeCount
	end
end

Wnd.OpenWindow("Interface\\Snow_OTBar\\Snow_OTBar.ini","Snow_OTBar")
