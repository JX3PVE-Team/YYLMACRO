Snow_OTBarOpt = {}

function Snow_OTBarOpt.OnFrameCreate()

	this:SetPoint("CENTER", 0, 0, "CENTER", 0, 0)

end

function Snow_OTBarOpt.OnItemLButtonClick()
	local frame = Station.Lookup("Topmost/Snow_OTBarOpt")
	local text = frame:Lookup("",""):Lookup("Text_Centre")
	if this:GetName() == "Animate_TopLeft" then --����
		this:SetAlpha(100)
		DelayCall(0.1,function() frame:Lookup("",""):Lookup("Animate_TopLeft"):SetAlpha(255) end)
	elseif this:GetName() == "Animate_TopRight" then --��ʾ
		Snow_OTBar.UserData.bShowDivider = not Snow_OTBar.UserData.bShowDivider
		if Snow_OTBar.UserData.bShowDivider then
			OutputMessage("MSG_SYS","��ʾ�ָ���\n")
		else
			OutputMessage("MSG_SYS","���طָ���\n")
		end
		this:SetAlpha(100)
		DelayCall(0.1,function() frame:Lookup("",""):Lookup("Animate_TopRight"):SetAlpha(255) end)
	elseif this:GetName() == "Animate_BottomRight" then --͸��
		local x, y = frame:GetAbsPos()
		GetUserInputNumber(Snow_OTBar.UserData.AlphaFrame, 255, {x+450,y+120},function(nNum) Snow_OTBar.UserData.AlphaFrame = nNum end, nil, nil)
		this:SetAlpha(100)
		DelayCall(0.1,function() frame:Lookup("",""):Lookup("Animate_BottomRight"):SetAlpha(255) end)
	elseif this:GetName() == "Animate_BottomLeft" then --�ƶ�
		Snow_OTBar.bAdjustUIPos = not Snow_OTBar.bAdjustUIPos
		if Snow_OTBar.bAdjustUIPos then
			Station.Lookup("Topmost/Snow_OTBar"):Show()
			Station.Lookup("Topmost/Snow_OTBar"):SetAlpha(255)
			Station.Lookup("Topmost/Snow_OTBar"):Lookup("",""):Lookup("Handle_Divider_List"):Clear()
			OutputMessage("MSG_SYS","�뿪ʼ����λ��\n")
		else
			OutputMessage("MSG_SYS","��������\n")
			Station.Lookup("Topmost/Snow_OTBar"):Hide()
		end
		this:SetAlpha(100)
		DelayCall(0.1,function() frame:Lookup("",""):Lookup("Animate_BottomLeft"):SetAlpha(255) end)
	elseif this:GetName() == "Animate_Centre" then --Ƥ��
		Snow_OTBarSkinOpt.PanelSwitch()
		this:SetAlpha(100)
		DelayCall(0.1,function() frame:Lookup("",""):Lookup("Animate_Centre"):SetAlpha(255) end)
	end
end

function Snow_OTBarOpt.OnItemMouseEnter()
	local frame = Station.Lookup("Topmost/Snow_OTBarOpt")
	local text = frame:Lookup("",""):Lookup("Text_Centre")
	if this:GetName() == "Animate_TopLeft" then
		text:Show()
		text:SetText("����")
		this:SetAlpha(255)
	elseif this:GetName() == "Animate_TopRight" then
		text:Show()
		text:SetText("��ʾ")
		this:SetAlpha(255)
	elseif this:GetName() == "Animate_BottomRight" then
		text:Show()
		text:SetText("͸��")
		this:SetAlpha(255)
	elseif this:GetName() == "Animate_BottomLeft" then
		text:Show()
		text:SetText("�ƶ�")
		this:SetAlpha(255)
	elseif this:GetName() == "Animate_Centre" then
		text:Show()
		text:SetText("Ƥ��")
		this:SetAlpha(255)
	end
end

function Snow_OTBarOpt.OnItemMouseLeave()
	local frame = Station.Lookup("Topmost/Snow_OTBarOpt")
	local text = frame:Lookup("",""):Lookup("Text_Centre")
	if this:GetName() == "Animate_TopLeft" then
		text:Hide()
		this:SetAlpha(100)
	elseif this:GetName() == "Animate_TopRight" then
		text:Hide()
		this:SetAlpha(100)
	elseif this:GetName() == "Animate_BottomRight" then
		text:Hide()
		this:SetAlpha(100)
	elseif this:GetName() == "Animate_BottomLeft" then
		text:Hide()
		this:SetAlpha(100)
	elseif this:GetName() == "Animate_Centre" then
		text:Hide()
		this:SetAlpha(100)
	end
end


function Snow_OTBarOpt.PanelSwitch()
	local frame = Station.Lookup("Topmost/Snow_OTBarOpt")
	if not frame then
		frame = Wnd.OpenWindow("Interface\\Snow_OTBar\\Snow_OTBarOpt.ini","Snow_OTBarOpt")
	else
		Wnd.CloseWindow("Snow_OTBarOpt")

		local skinframe = Station.Lookup("Topmost/Snow_OTBarSkinOpt")
		if skinframe then
			Wnd.CloseWindow("Snow_OTBarSkinOpt")
			local OTBarframe = Station.Lookup("Topmost/Snow_OTBar")
			Snow_OTBar.ChangeSkin(OTBarframe)
		end

		if Snow_OTBar.bAdjustUIPos then
			Snow_OTBar.bAdjustUIPos = not Snow_OTBar.bAdjustUIPos
			OutputMessage("MSG_SYS","��������\n")
			Station.Lookup("Topmost/Snow_OTBar"):Hide()
		end
	end
end


function OpenOptionPanel(bDisableSound)
	if IsOptionPanelOpened() then
		return
	end

	CorrectAutoPosFrameEscClose(true)

	local wndOptionPanel = Wnd.OpenWindow("OptionPanel")

	if not bDisableSound then
		PlaySound(SOUND.UI_SOUND,g_sound.OpenFrame)
	end

	local _,_,_,szVersionEx = GetVersion()
	if szVersionEx == "snda" then
		wndOptionPanel:Lookup("Btn_ReturnChoose"):Enable(false)
	end

	local frame = Station.Lookup("Topmost/Snow_OTBarOpt")
	if frame then
		Snow_OTBarOpt.PanelSwitch()
	end
end

Hotkey.AddBinding("Snow_OTBarOpt","���ý���","Сѩ��������",
	function()
		Snow_OTBarOpt.PanelSwitch()
	end,
	nil
)
