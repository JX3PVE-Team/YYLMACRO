ZzLifeBar = {}
ZzLifeBar.nSteper = -1
ZzLifeBar.nCheckSteper = 0
ZzLifeBar.Scale = 1.2       --����Ѫ���Ŵ���
ZzLifeBar.nGlobalHeight = 4
ZzLifeBar.nGlobalTop = 4
ZzLifeBar.nGlobalLeft = 4
ZzLifeBar.tLifeBarList = {}					-- ���е� Frame ����
ZzLifeBar.TopLevelFrame = nil
ZzLifeBar.MidLevelFrame = nil
ZzLifeBar.LowLevelFrame = nil
ZzLifeBar.HighOffset = 5  -- �߶�����ƫ����

ZzLifeBar.const = {}
ZzLifeBar.const.PARTY_COLOR = {126, 126, 255}
ZzLifeBar.const.POSITIVE_NPC_COLOR = {255, 0, 0}  --��������NPC����ͷ����ɫ
ZzLifeBar.const.POSSIVE_NPC_COLOR = {255, 255, 0}  --��������NPC����ͷ����ɫ

ZzLifeBar.const.TEXT_FACE_DIRECTION = 1   --��ʾ����/����
ZzLifeBar.const.ANGLE_FACE_DIRECTION = 2    -- ��ʾ����

ZzLifeBar.bShowSelf = true
ZzLifeBar.bShowNeutralityNPC = false
ZzLifeBar.bShowAllyNPC = false
ZzLifeBar.bShowEnemyNPC = false
ZzLifeBar.bShowAllyPlayer = false
ZzLifeBar.bShowEnemyPlayer = false
ZzLifeBar.bShowPartyPlayer = false
ZzLifeBar.bShowNeutralityPlayer = false
ZzLifeBar.bShowCastingBar = false
ZzLifeBar.bShowLifeText = false
ZzLifeBar.bShowManaBar = false
ZzLifeBar.bShowFight = false
ZzLifeBar.bShowSpecialNPC = false
ZzLifeBar.bCanNotSeeName = false
ZzLifeBar.bCanNotSeeLifeBar = false
ZzLifeBar.bIsNotSelectable = false

ZzLifeBar.bShowLifeBar = true
ZzLifeBar.bShowSelfLifeText = false
ZzLifeBar.bShowNeutralityNPCLifeText = false
ZzLifeBar.bShowAllyNPCLifeText = false
ZzLifeBar.bShowEnemyNPCLifeText = false
ZzLifeBar.bShowAllyPlayerLifeText = false
ZzLifeBar.bShowEnemyPlayerLifeText = false
ZzLifeBar.bShowPartyPlayerLifeText = false
ZzLifeBar.bShowNeutralityPlayerLifeText = false

ZzLifeBar.SelfColor = {255, 128, 128}
ZzLifeBar.NeutralityColor = {190, 190, 16}
ZzLifeBar.MyPartyColor = {23, 132, 193}

ZzLifeBar.AllyColor = {28, 166, 34}
ZzLifeBar.EnemyColor = {203, 53, 9}
ZzLifeBar.DeathColor = {133, 133, 133}   -- �ݲ��ṩ�Զ������ã�����ʱ��ʾ����ɫ
ZzLifeBar.DeathAllyColor = {160, 109, 160}   -- �ݲ��ṩ�Զ������ã��ѷ�����ʱ��ʾ����ɫ

ZzLifeBar.LifeTextSelfColor = {255, 128, 128}
ZzLifeBar.LifeTextNeutralityColor = {190, 190, 16}
ZzLifeBar.LifeTextMyPartyColor = {23, 132, 193}
ZzLifeBar.LifeTextAllyColor = {28, 166, 34}
ZzLifeBar.LifeTextEnemyColor = {203, 53, 9}

ZzLifeBar.bColorTarget = false
ZzLifeBar.LifeTextTargetColor = {255, 255, 255}

ZzLifeBar.nShowRange = 30
ZzLifeBar.bShowLifePercent = true
ZzLifeBar.bShowLifePoint = true

ZzLifeBar.bShowHeadInfo = false

ZzLifeBar.bShowSelfName = false     -- �Լ�����
ZzLifeBar.bShowSelfTongName = false  -- �Լ��������
ZzLifeBar.bShowSelfTitle = false   -- �Լ��ƺ�

ZzLifeBar.bShowNPCName = false     -- NPC����
ZzLifeBar.bShowNPCTitle = false   -- NPC�ƺ�

ZzLifeBar.bShowPlayerName = false     -- �������
ZzLifeBar.bShowPlayerTongName = false  -- ��Ұ������
ZzLifeBar.bShowPlayerTitle = false   -- ��ҳƺ�

ZzLifeBar.bShowDistance = false  -- ��ʾ����
ZzLifeBar.bOnlyShowTargetDistance = false  -- ֻ��ʾĿ��ľ���

ZzLifeBar.nShowFaceDirectionType = ZzLifeBar.const.TEXT_FACE_DIRECTION
ZzLifeBar.bShowOtherFaceDirection = false  -- ��ʾ���˶��Լ�������
ZzLifeBar.bShowOnlyTargetFaceDirection = false   --����ʾĿ����Լ�������
ZzLifeBar.bShowSelfFaceDirection = false  -- ��ʾ�Լ���Ŀ�������

RegisterCustomData("ZzLifeBar.bShowSelf")
RegisterCustomData("ZzLifeBar.bShowNeutralityNPC")
RegisterCustomData("ZzLifeBar.bShowAllyNPC")
RegisterCustomData("ZzLifeBar.bShowEnemyNPC")
RegisterCustomData("ZzLifeBar.bShowAllyPlayer")
RegisterCustomData("ZzLifeBar.bShowEnemyPlayer")
RegisterCustomData("ZzLifeBar.bShowPartyPlayer")
RegisterCustomData("ZzLifeBar.bShowNeutralityPlayer")

RegisterCustomData("ZzLifeBar.bShowCastingBar")
RegisterCustomData("ZzLifeBar.bShowLifeText")
RegisterCustomData("ZzLifeBar.bShowManaBar")
RegisterCustomData("ZzLifeBar.bShowFight")
RegisterCustomData("ZzLifeBar.bShowSpecialNPC")
RegisterCustomData("ZzLifeBar.bCanNotSeeName")
RegisterCustomData("ZzLifeBar.bCanNotSeeLifeBar")
RegisterCustomData("ZzLifeBar.bIsNotSelectable")

RegisterCustomData("ZzLifeBar.bShowSelfLifeText")
RegisterCustomData("ZzLifeBar.bShowNeutralityNPCLifeText")
RegisterCustomData("ZzLifeBar.bShowAllyNPCLifeText")
RegisterCustomData("ZzLifeBar.bShowEnemyNPCLifeText")
RegisterCustomData("ZzLifeBar.bShowAllyPlayerLifeText")
RegisterCustomData("ZzLifeBar.bShowEnemyPlayerLifeText")
RegisterCustomData("ZzLifeBar.bShowPartyPlayerLifeText")
RegisterCustomData("ZzLifeBar.bShowNeutralityPlayerLifeText")

RegisterCustomData("ZzLifeBar.bColorTarget")
RegisterCustomData("ZzLifeBar.LifeTextTargetColor")

RegisterCustomData("ZzLifeBar.nShowRange")

RegisterCustomData("ZzLifeBar.bShowLifePercent")
RegisterCustomData("ZzLifeBar.bShowLifePoint")

RegisterCustomData("ZzLifeBar.bShowHeadInfo")
RegisterCustomData("ZzLifeBar.bShowSelfName")
RegisterCustomData("ZzLifeBar.bShowSelfTongName")
RegisterCustomData("ZzLifeBar.bShowSelfTitle")
RegisterCustomData("ZzLifeBar.bShowNPCName")
RegisterCustomData("ZzLifeBar.bShowNPCTitle")
RegisterCustomData("ZzLifeBar.bShowPlayerName")
RegisterCustomData("ZzLifeBar.bShowPlayerTongName")
RegisterCustomData("ZzLifeBar.bShowPlayerTitle")

RegisterCustomData("ZzLifeBar.bShowDistance")
RegisterCustomData("ZzLifeBar.bOnlyShowTargetDistance")

RegisterCustomData("ZzLifeBar.nShowFaceDirectionType")
RegisterCustomData("ZzLifeBar.bShowOtherFaceDirection")
RegisterCustomData("ZzLifeBar.bShowOnlyTargetFaceDirection")
RegisterCustomData("ZzLifeBar.bShowSelfFaceDirection")

RegisterCustomData("ZzLifeBar.SelfColor")
RegisterCustomData("ZzLifeBar.NeutralityColor")
RegisterCustomData("ZzLifeBar.MyPartyColor")
RegisterCustomData("ZzLifeBar.AllyColor")
RegisterCustomData("ZzLifeBar.EnemyColor")

RegisterCustomData("ZzLifeBar.LifeTextSelfColor")
RegisterCustomData("ZzLifeBar.LifeTextNeutralityColor")
RegisterCustomData("ZzLifeBar.LifeTextMyPartyColor")
RegisterCustomData("ZzLifeBar.LifeTextAllyColor")
RegisterCustomData("ZzLifeBar.LifeTextEnemyColor")

function ZzLifeBar.RefreshHP (dwID)
  local eType = TARGET.NPC
  if IsPlayer(dwID) then
    eType = TARGET.PLAYER
  end

  local player = GetClientPlayer()
  local eTargetType, dwTargetID = player.GetTarget()
  SetTarget(eType, dwID)
  SetTarget(eTargetType, dwTargetID)
end

function ZzLifeBar.RefreshHPExtra (target)
  local nRepeatCount = 0
  repeat
    ZzLifeBar.RefreshHP(target.dwID)
    nRepeatCount = nRepeatCount + 1
    if nRepeatCount >= 3 then
      break
    end
  until target.nMaxLife ~= 255
end


-----------------------------------------------
-- ���߳� PostThreadCall
-----------------------------------------------
ZzLifeBar.Scene_GetCharacterTopScreenPos = function(fnAction,dwID)
	PostThreadCall(ZzLifeBar.ApplyPointCallback,fnAction,"Scene_GetCharacterTopScreenPos", dwID)
end

ZzLifeBar.ApplyPointCallback = function(fnAction, nX, nY)
	if not nX or (nX > 0 and nX < 0.00001 and nY > 0 and nY < 0.00001) then
		nX, nY = nil, nil
	else
		nX, nY = Station.AdjustToOriginalPos(nX, nY)
	end
	local res, err = pcall(fnAction, nX, nY)
	if not res then
		Output("ApplyScreenPoint ERROR: " .. err)
	end
end



function ZzLifeBar.Scene_ScenePointToScreenPoint(nX,nY,nZ)
	local x,y
	x,y = Scene_ScenePointToScreenPoint(nX,nY,nZ)
	if not x or not y then
		return 0,0,false
	else
		return x,y,true
	end
end

function ZzLifeBar.BringToTop(frame)
  if not frame then
    return
  end

  frame:ChangeRelation("Lowest/ZzLifeBar_TOP_LEVEL", false)
end

function ZzLifeBar.BringToMiddle(frame)
  if not frame then
    return
  end

  frame:ChangeRelation("Lowest/ZzLifeBar_MIDDLE_LEVEL", false)
end

function ZzLifeBar.BringToBack(frame)
  if not frame then
    return
  end

  frame:ChangeRelation("Lowest/ZzLifeBar_LOW_LEVEL", false)
end

function ZzLifeBar.IsNeutralityHeadFontColor(dwSrcID, dwTargetID)
  local nColorR, nColorG, nColorB = GetHeadTextForceFontColor(dwTargetID, dwSrcID)
  return (ZzLifeBar.const.POSSIVE_NPC_COLOR[1] == nColorR and ZzLifeBar.const.POSSIVE_NPC_COLOR[2] == nColorG and ZzLifeBar.const.POSSIVE_NPC_COLOR[3] == nColorB)
end

function ZzLifeBar.OnFrameCreate()
	this:RegisterEvent("RENDER_FRAME_UPDATE")
	this:RegisterEvent("PLAYER_ENTER_SCENE")
	this:RegisterEvent("PLAYER_LEAVE_SCENE")
	this:RegisterEvent("NPC_ENTER_SCENE")
	this:RegisterEvent("NPC_LEAVE_SCENE")

	ZzLifeBar.TopLevelFrame = Wnd.OpenWindow("Interface\\ZzLifeBar\\ZzLifeBar.ini", "ZzLifeBar_TOP_LEVEL")
	ZzLifeBar.TopLevelFrame:ChangeRelation("Lowest/Scene")
	ZzLifeBar.TopLevelFrame:Show()

	ZzLifeBar.MidLevelFrame = Wnd.OpenWindow("Interface\\ZzLifeBar\\ZzLifeBar.ini", "ZzLifeBar_MIDDLE_LEVEL")
	ZzLifeBar.MidLevelFrame:ChangeRelation(ZzLifeBar.TopLevelFrame, false)
	ZzLifeBar.MidLevelFrame:Show()

	ZzLifeBar.LowLevelFrame = Wnd.OpenWindow("Interface\\ZzLifeBar\\ZzLifeBar.ini", "ZzLifeBar_LOW_LEVEL")
	ZzLifeBar.LowLevelFrame:ChangeRelation(ZzLifeBar.MidLevelFrame, false)
	ZzLifeBar.LowLevelFrame:Show()
end

function ZzLifeBar.OnEvent(szEvent)
	if szEvent == "RENDER_FRAME_UPDATE" then
		ZzLifeBar.RefreshLifeBarDisplay()
	elseif szEvent == "PLAYER_ENTER_SCENE" then
		ZzLifeBar.CreateLifeBar(arg0)
	elseif szEvent == "PLAYER_LEAVE_SCENE" then
		ZzLifeBar.RemoveLifeBar(arg0)
	elseif szEvent == "NPC_ENTER_SCENE" then
		ZzLifeBar.CreateLifeBar(arg0)
	elseif szEvent == "NPC_LEAVE_SCENE" then
		ZzLifeBar.RemoveLifeBar(arg0)
	end
end

function ZzLifeBar.OnFrameBreathe()
  ZzLifeBar.nCheckSteper = ZzLifeBar.nCheckSteper + 1
  if ZzLifeBar.nCheckSteper <= 160 then
    local headFrame = Station.Lookup("Lowest/Head")
    if headFrame then
      ZzLifeBar.LowLevelFrame:ChangeRelation(headFrame, true)
      ZzLifeBar.MidLevelFrame:ChangeRelation(ZzLifeBar.LowLevelFrame, true)
      ZzLifeBar.TopLevelFrame:ChangeRelation(ZzLifeBar.MidLevelFrame, true)
      ZzLifeBar.nCheckSteper = 160  -- ֻ��ִ��һ��
    end
  end

	ZzLifeBar.nSteper = ZzLifeBar.nSteper + 1
	local player = GetClientPlayer()
	if not player then
		return
	end
	if ZzLifeBar.nSteper % 2 == 0 then
		for dwID, frame in pairs(ZzLifeBar.tLifeBarList) do
      repeat
        frame.bVisible = true
        local hBarTemplate = frame:Lookup("", ""):Lookup("Handle_BarTemplate")
        hBarTemplate:Show()

        -- ��Χ�ⲻ��ʾ
        local distance = GetCharacterDistance(player.dwID, dwID)
        if distance > ZzLifeBar.nShowRange * 64 then
          frame.bVisible = false
          break
        end

        local npc = GetNpc(dwID)
        if npc then
          if not npc.CanSeeName() or not npc.CanSeeLifeBar() or not npc.IsSelectable() then
            frame.bVisible = false
          end
        end

        -- �Ƿ���ʾ����NPC
        if ZzLifeBar.bShowSpecialNPC then
          if npc then
            local specialCount = 0
            if not npc.CanSeeName() then
              specialCount = specialCount + 1
            end
--            if not npc.CanSeeLifeBar() then
--              specialCount = specialCount + 1
--            end
            if not npc.IsSelectable() then
              specialCount = specialCount + 1
            end
            if ZzLifeBar.bCanNotSeeName and not npc.CanSeeName() then
              specialCount = specialCount - 1
            end
--            if ZzLifeBar.bCanNotSeeLifeBar and not npc.CanSeeLifeBar() then
--              specialCount = specialCount - 1
--            end
            if ZzLifeBar.bIsNotSelectable and not npc.IsSelectable() then
              specialCount = specialCount - 1
            end
            if specialCount <= 0 then
              frame.bVisible = true
            end
          end
        end

        local bShowHeadInfo = true
        if ZzLifeBar.bShowHeadInfo then
          if not ZzLifeBar.bShowSelfName
             and not ZzLifeBar.bShowSelfTongName
             and not ZzLifeBar.bShowSelfTitle
             and not ZzLifeBar.bShowNPCName
             and not ZzLifeBar.bShowNPCTitle
             and not ZzLifeBar.bShowPlayerName
             and not ZzLifeBar.bShowPlayerTongName
             and not ZzLifeBar.bShowPlayerTitle
          then
            bShowHeadInfo = false
          end
        end

        -- ����ֻ��ʾ��ս��Ŀ�꿪�أ���ս���еĲ���ʾ
        if not bShowHeadInfo then
          if ZzLifeBar.bShowFight then
            local target = ZzLifeBar.GetCharacter(dwID)
            if not target.bFightState then
              frame.bVisible = false
              break
            end
          end
        else
          if ZzLifeBar.bShowFight then
            local target = ZzLifeBar.GetCharacter(dwID)
            if not target.bFightState then
              hBarTemplate:Hide()
              break
            end
          end
        end

        if not bShowHeadInfo then
          if not ZzLifeBar.bShowLifeBar then
            frame.bVisible = false
            break
          end

          if not ZzLifeBar.bShowSelf and dwID == player.dwID then
            frame.bVisible = false
            break
          end
          if not IsPlayer(dwID) then
            if not ZzLifeBar.bShowAllyNPC and IsAlly(player.dwID, dwID) then
              frame.bVisible = false
              break
            end
            if IsEnemy(player.dwID, dwID) then
              if not ZzLifeBar.bShowNeutralityNPC and ZzLifeBar.IsNeutralityHeadFontColor(player.dwID, dwID) then
                frame.bVisible = false
                break
              elseif not ZzLifeBar.bShowEnemyNPC and not ZzLifeBar.IsNeutralityHeadFontColor(player.dwID, dwID) then
                frame.bVisible = false
                break
              end
            end
            if not ZzLifeBar.bShowNeutralityNPC and IsNeutrality(player.dwID, dwID) then
              frame.bVisible = false
              break
            end
          else
            if not ZzLifeBar.bShowAllyPlayer and IsAlly(player.dwID, dwID) and dwID ~= player.dwID and not IsParty(player.dwID, dwID) then
              frame.bVisible = false
              break
            end
            if not ZzLifeBar.bShowPartyPlayer and dwID ~= player.dwID and IsParty(player.dwID, dwID) then
              frame.bVisible = false
              break
            end
            if not ZzLifeBar.bShowEnemyPlayer and IsEnemy(player.dwID, dwID) then
              frame.bVisible = false
              break
            end
            if not ZzLifeBar.bShowNeutralityPlayer and IsNeutrality(player.dwID, dwID) then
              frame.bVisible = false
              break
            end
          end
        else
          if not ZzLifeBar.bShowLifeBar then
            hBarTemplate:Hide()
            break
          end

          if npc and not npc.CanSeeLifeBar() then
            hBarTemplate:Hide()
            break
          end

          if not ZzLifeBar.bShowSelf and dwID == player.dwID then
            hBarTemplate:Hide()
            break
          end
          if not IsPlayer(dwID) then
            if not ZzLifeBar.bShowAllyNPC and IsAlly(player.dwID, dwID) then
              hBarTemplate:Hide()
              break
            end
            if IsEnemy(player.dwID, dwID) then
              if not ZzLifeBar.bShowNeutralityNPC and ZzLifeBar.IsNeutralityHeadFontColor(player.dwID, dwID) then
                hBarTemplate:Hide()
                break
              elseif not ZzLifeBar.bShowEnemyNPC and not ZzLifeBar.IsNeutralityHeadFontColor(player.dwID, dwID) then
                hBarTemplate:Hide()
                break
              end
            end
            if not ZzLifeBar.bShowNeutralityNPC and IsNeutrality(player.dwID, dwID) then
              hBarTemplate:Hide()
              break
            end
          else
            if not ZzLifeBar.bShowAllyPlayer and IsAlly(player.dwID, dwID) and dwID ~= player.dwID and not IsParty(player.dwID, dwID) then
              hBarTemplate:Hide()
              bIsHidden = true
            end
            if not ZzLifeBar.bShowPartyPlayer and dwID ~= player.dwID and IsParty(player.dwID, dwID) then
              hBarTemplate:Hide()
              break
            end
            if not ZzLifeBar.bShowEnemyPlayer and IsEnemy(player.dwID, dwID) then
              hBarTemplate:Hide()
              break
            end
            if not ZzLifeBar.bShowNeutralityPlayer and IsNeutrality(player.dwID, dwID) then
              hBarTemplate:Hide()
              break
            end
          end
        end
			until true

			ZzLifeBar.UpdateVisibleLifeBarData(dwID, frame)
		end
	end
end

function ZzLifeBar.RefreshLifeBarDisplay()
	local player = GetClientPlayer()
	if not player then
		return
	end
	for dwID, frame in pairs(ZzLifeBar.tLifeBarList) do
		if frame then
			if frame.bVisible then
				frame:Show()
				local target = ZzLifeBar.GetCharacter(dwID)
				if target then
					local nScreenX, nScreenY
					local fnAction = function()
					-- local nTopX, nTopY, nTopZ = Scene_GetCharacterTop(dwID)
					-- local nScreenX, nScreenY, bSuccess = 0, 0, false
					-- if nTopX and nTopY and nTopZ then
						-- nScreenX, nScreenY, bSuccess = ZzLifeBar.Scene_ScenePointToScreenPoint(nTopX, nTopY, nTopZ)
					-- end
					-- if bSuccess then
						-- nScreenX, nScreenY = Station.AdjustToOriginalPos(nScreenX, nScreenY)
					-- else
						-- nScreenX, nScreenY = -4096, -4096
					-- end
						nH = 0                                                     --������Ѫ������ͷ���߶�
						if dwID == player.dwID then
							nH = 3                                                   --����Ѫ������ͷ���߶�
						end
						frame:SetRelPos(nScreenX, nScreenY - nH - ZzLifeBar.HighOffset)
					end
					
					ZzLifeBar.Scene_GetCharacterTopScreenPos(function(x,y)
						if not x or not y then
							nScreenX, nScreenY = -4096 , -4096
						else
							nScreenX, nScreenY = x, y
						end
						fnAction()
					end,dwID)
					
				else
					ZzLifeBar.RemoveLifeBar(dwID)
				end
				
				
			else
				frame:Hide()
			end
		else
			ZzLifeBar.RemoveLifeBar(dwID)
		end
	end
end

function ZzLifeBar.UpdateVisibleLifeBarData(dwID, frame)
	if not frame or not frame.bVisible then
		return
	end
	local player = GetClientPlayer()
	if not player then
		return
	end
	local target = ZzLifeBar.GetCharacter(dwID)
	if not target then
		ZzLifeBar.RemoveLifeBar(dwID)
		return
	end

  local target_nCurrentLife = target.nCurrentLife
  local target_nMaxLife = target.nMaxLife

  ZzLifeBar.BringToBack(frame)

  --��ʾͷ��������Ϣ
  local handleHeadText = frame:Lookup("", ""):Lookup("Head_Text")
  if ZzLifeBar.bShowHeadInfo then
    local szHeadInfo = ""
    local szFixedName = ""
    local szFixedTitle = ""
    local szFixedTongName = ""
    local szFixedDistance = ""
    if dwID == player.dwID then
      if ZzLifeBar.bShowSelfName then
        szFixedName = player.szName .. "\n"
      end
      if ZzLifeBar.bShowSelfTitle and not (player.szTitle == "") then
        szFixedTitle = "<" .. player.szTitle .. ">" .. "\n"
      end
      if ZzLifeBar.bShowSelfTongName and not (player.dwTongID == 0) then
        local szTongName = GetTongClient().ApplyGetTongName(player.dwTongID)
        szFixedTongName = "[" .. szTongName .. "]" .. "\n"
      end
    elseif IsPlayer(dwID) then
      local handlePlayer = GetPlayer(dwID)

      if ZzLifeBar.bShowPlayerName then
        szFixedName = handlePlayer.szName .. "\n"
      end
      if ZzLifeBar.bShowPlayerTitle and not (handlePlayer.szTitle == "") then
        szFixedTitle = "<" .. handlePlayer.szTitle .. ">" .. "\n"
      end
      if ZzLifeBar.bShowPlayerTongName and not (handlePlayer.dwTongID == 0) then
        local szTongName = GetTongClient().ApplyGetTongName(handlePlayer.dwTongID)
        szFixedTongName = "[" .. szTongName .. "]" .. "\n"
      end
    else
      local hNPC = GetNpc(dwID)
--      if hNPC and hNPC.CanSeeName() then
      if hNPC then
        local szNpcName = ""
        if ZzLifeBar.bShowNPCName then
          if not (hNPC.dwEmployer == 0) then
            local hEmployer = GetPlayer(hNPC.dwEmployer)
            if hEmployer then
              szNpcName = szNpcName .. hEmployer.szName .. "��"
            end
          end

          szNpcName = szNpcName .. hNPC.szName
          szFixedName = szNpcName .. "\n"
        end
        if ZzLifeBar.bShowNPCTitle and not (hNPC.szTitle == "") then
          szFixedTitle = "<" .. hNPC.szTitle .. ">" .. "\n"
        end
      end
    end

    repeat
      local _, dwTargetID = player.GetTarget()
      if ZzLifeBar.bOnlyShowTargetDistance and dwID ~= dwTargetID then
        break  -- ��������ʾĿ����룬���Ҫ����Ķ�����Ŀ�꣬��������������߼�
      end

      if ZzLifeBar.bShowDistance and not (dwID == player.dwID) and not (szFixedName == "") then
        local distance = GetCharacterDistance(player.dwID, dwID)
        local szFixedLen = string.len(szFixedName)
        szFixedDistance = KeepTwoByteFloat(distance / 64) .. "��" .. "\n"
      end
    until true

    if ZzLifeBar.bShowOtherFaceDirection and not (dwID == player.dwID) and not (szFixedName == "") then
      local bShow = true
      if ZzLifeBar.bShowOnlyTargetFaceDirection then
        local _, dwTargetID = player.GetTarget()
        if not (dwTargetID == dwID) then
          bShow = false
        end
      end

      if bShow then
        local nTargetAngle = ZzLifeBar.GetAngleBetween(target.nX, target.nY, player.nX, player.nY)
        local nTargetFaceDirectionAngle = ZzLifeBar.FaceDirectionToAngle(target.nFaceDirection)
        local nRDeg = math.abs(nTargetAngle - nTargetFaceDirectionAngle)   -- ���ʵ��Ŀ�����Լ��ĽǶ�(360����),�ӵ���nFaceDirection��һ��1-255֮���һ��ֵ����Ҫת����ʵ�ʵ�360�ȵ���ֵ������ǶȽ��м��㡣��

        local nFixDeg = math.floor(nRDeg)
        if nFixDeg > 180 then
           nFixDeg = 360 - nFixDeg
        end

        local szFaceDescription = ""
        if ZzLifeBar.nShowFaceDirectionType == ZzLifeBar.const.TEXT_FACE_DIRECTION then
          local bFaceToFace = (nFixDeg <= 90)
          if bFaceToFace then
            szFaceDescription = "(��)"
          else
            szFaceDescription = "(��)"
          end
        else
          szFaceDescription = "(" .. tostring(nFixDeg) .. ")"
        end

        if not (szFaceDescription == "") then
          if not (szFixedDistance == "") then
            local nLen = string.len(szFixedDistance)
            szFixedDistance = string.sub(szFixedDistance, 1, nLen - 1)
          end

          szFixedDistance = szFixedDistance .. szFaceDescription .. "\n"
        end
      end
    end

    if ZzLifeBar.bShowSelfFaceDirection and dwID == player.dwID and not (szFixedName == "") then
      local _, dwTargetID = player.GetTarget()
      if not (dwTargetID == 0) then
        local hCurrTarget = ZzLifeBar.GetCharacter(dwTargetID)
        local nSelfAngle = ZzLifeBar.GetAngleBetween(player.nX, player.nY, hCurrTarget.nX, hCurrTarget.nY)
        local nSelfFaceDirectionAngle = ZzLifeBar.FaceDirectionToAngle(player.nFaceDirection)
        local nRDeg = math.abs(nSelfAngle - nSelfFaceDirectionAngle)

        local nFixDeg = math.floor(nRDeg)
        if nFixDeg > 180 then
           nFixDeg = 360 - nFixDeg
        end

        local szFaceDescription = ""
        if ZzLifeBar.nShowFaceDirectionType == ZzLifeBar.const.TEXT_FACE_DIRECTION then
          local bFaceToFace = (nFixDeg <= 90)
          if bFaceToFace then
            szFaceDescription = "(��)"
          else
            szFaceDescription = "(��)"
          end
        else
          szFaceDescription = "(" .. tostring(nFixDeg) .. ")"
        end

        if not (szFaceDescription == "") then
          if not (szFixedDistance == "") then
            local nLen = string.len(szFixedDistance)
            szFixedDistance = string.sub(szFixedDistance, 1, nLen - 1)
          end

          szFixedDistance = szFixedDistance .. szFaceDescription .. "\n"
        end
      end
    end

    szHeadInfo = szFixedDistance .. szFixedName .. szFixedTitle .. szFixedTongName

    if not szHeadInfo == "" then
      local nLen = string.len(szHeadInfo)
      szHeadInfo = string.sub(szHeadInfo, 1, nLen - 1)
    end
    handleHeadText:SetText(szHeadInfo)
  else
    handleHeadText:SetText("")
  end



  local handleLifeText = frame:Lookup("", ""):Lookup("Life_Text")

  local szLifeTextKey = ""
  local szHeadTextKey = ""
  local szBShowKey = ""



	if  dwID == player.dwID then						--	�Լ�
		ZzLifeBar.BringToMiddle(frame)
		szLifeTextKey = "LifeTextSelfColor"
		szHeadTextKey = "SelfColor"
		szBShowKey = "bShowSelfLifeText"

	elseif IsAlly(player.dwID, dwID) then
		if IsPlayer(dwID) then							--	���
		--	if IsParty(player.dwID, dwID) then  -- ͬһ����
		--	   szLifeTextKey = "LifeTextMyPartyColor"
		--	   szHeadTextKey = "MyPartyColor"
        --     szBShowKey = "bShowPartyPlayerLifeText"

			if not IsParty(player.dwID, dwID) then		-- ����ͬһ���� ��Ϊ�Ѻ�
			   szLifeTextKey = "LifeTextAllyColor"
               szHeadTextKey = "AllyColor"
               szBShowKey = "bShowAllyPlayerLifeText"


	        else										-- ͬ�����
            --   szLifeTextKey = "LifeTextAllyColor"
            --   szHeadTextKey = "AllyColor"
            --   szBShowKey = "bShowAllyPlayerLifeText"
			   szLifeTextKey = "LifeTextMyPartyColor"
			   szHeadTextKey = "MyPartyColor"
               szBShowKey = "bShowPartyPlayerLifeText"

	        end
		else	--	�Ѻ�NPC
			   szLifeTextKey = "LifeTextAllyColor"
               szHeadTextKey = "AllyColor"
               szBShowKey = "bShowAllyNPCLifeText"

		end
	elseif IsEnemy(player.dwID, dwID) then		--	�ж�
		if  IsPlayer(target.dwID) then 	--	�ж����
			szLifeTextKey = "LifeTextEnemyColor"
			szHeadTextKey = "EnemyColor"
			szBShowKey = "bShowEnemyPlayerLifeText"

		else						--	�ж�NPC
			if ZzLifeBar.IsNeutralityHeadFontColor(player.dwID, dwID) then    --	����������
			   szLifeTextKey = "LifeTextNeutralityColor"
               szHeadTextKey = "NeutralityColor"
               szBShowKey = "bShowNeutralityNPCLifeText"
			else
			   szLifeTextKey = "LifeTextEnemyColor"
			   szHeadTextKey = "EnemyColor"
			   szBShowKey = "bShowEnemyNPCLifeText"
			end
		end
	elseif IsNeutrality(player.dwID, dwID) then  --	����
		if  IsPlayer(dwID) then		--	��������
			   szLifeTextKey = "LifeTextNeutralityColor"
               szHeadTextKey = "NeutralityColor"
               szBShowKey = "bShowNeutralityPlayerLifeText"

		else						--	�����NPC
									--	����NPC
			   szLifeTextKey = "LifeTextNeutralityColor"
               szHeadTextKey = "NeutralityColor"
			   szBShowKey = "bShowNeutralityNPCLifeText"


		end
    end



  -- ֻ��ʾͷ����Ϣ
  if not frame:Lookup("", ""):Lookup("Handle_BarTemplate"):IsVisible() then

    local handleLifeBar = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Handle_LifeBar")
    local nLifeBarScale = 1
    if dwID == player.dwID then
        nLifeBarScale = ZzLifeBar.Scale
    end

    repeat

      if not IsPlayer(dwID) then
        local hNpc = GetNpc(dwID)
        if not hNpc.CanSeeLifeBar() then
          break
        end
      end

     if ZzLifeBar.bShowLifeText and ZzLifeBar[szBShowKey] then
        handleLifeText:Show()
        local fAbsX, fAbsY = handleLifeBar:GetAbsPos()  -- �����������Ǹ�����ֵ������������1.2������ô�������Ļ�׼ֵӦ����fAbsX/1.2, fAbsY/1.2
        handleHeadText:SetAbsPos(nLifeBarScale*(fAbsX/nLifeBarScale - 93.5), nLifeBarScale*(fAbsY/nLifeBarScale - 60))
      else
        handleLifeText:Hide()
        local fAbsX, fAbsY = handleLifeBar:GetAbsPos()
        handleHeadText:SetAbsPos(nLifeBarScale*(fAbsX/nLifeBarScale - 93.5), nLifeBarScale*(fAbsY/nLifeBarScale - 45))
      end

      if ZzLifeBar.bShowLifeText and ZzLifeBar[szBShowKey] and target_nCurrentLife >= 0 and target_nCurrentLife <= target_nMaxLife then
        local sLifePercent = ""
        if ZzLifeBar.bShowLifePercent then
          local percent = math.min(target_nCurrentLife / target_nMaxLife, 1)
          sLifePercent = "("..KeepTwoByteFloat(percent * 100).."%)"
        end

        local sLife = ""
        if ZzLifeBar.bShowLifePoint then
          sLife = target_nCurrentLife
          if target_nMaxLife == 255 then
            ZzLifeBar.RefreshHPExtra(target)
          end

          if target_nCurrentLife >= 10000 and target_nCurrentLife < 100000000 then
            local nLife = target_nCurrentLife / 10000
            local sPreLife = tostring(math.floor(nLife * 10))
            local ssLife = string.sub(sPreLife, 1, -2).."."..string.sub(sPreLife, -1)
            sLife = ssLife.."��"
          elseif target_nCurrentLife >= 100000000 then
            local nLife = target_nCurrentLife / 100000000
            local sPreLife = tostring(math.floor(nLife * 10))
            local ssLife = string.sub(sPreLife, 1, -2).."."..string.sub(sPreLife, -1)
            sLife = ssLife.."��"
          end
        end

        local sLifeText = sLife .. sLifePercent
        handleLifeText:SetText(sLifeText)
      elseif ZzLifeBar.bShowLifeText and ZzLifeBar[szBShowKey] then
        ZzLifeBar.RefreshHPExtra(target)
      end
    until true

	handleLifeText:SetFontColor(ZzLifeBar[szLifeTextKey][1], ZzLifeBar[szLifeTextKey][2], ZzLifeBar[szLifeTextKey][3])
	handleHeadText:SetFontColor(ZzLifeBar[szHeadTextKey][1], ZzLifeBar[szHeadTextKey][2], ZzLifeBar[szHeadTextKey][3])

    --�����������ʾ�Ķ�����ɫ
    if target.nMoveState==MOVE_STATE.ON_DEATH then
      if IsAlly(player.dwID, dwID) then
        handleHeadText:SetFontColor(ZzLifeBar.DeathAllyColor[1], ZzLifeBar.DeathAllyColor[2], ZzLifeBar.DeathAllyColor[3])
      else
        handleHeadText:SetFontColor(ZzLifeBar.DeathColor[1], ZzLifeBar.DeathColor[2], ZzLifeBar.DeathColor[3])
      end
    end

    --��ѡ��Ŀ�������ɫ
    local _, dwSelectedTargetID = player.GetTarget()
    if dwSelectedTargetID == dwID then
      if ZzLifeBar.bColorTarget then
        ZzLifeBar.BringToTop(frame)
        handleHeadText:SetFontColor(ZzLifeBar.LifeTextTargetColor[1], ZzLifeBar.LifeTextTargetColor[2], ZzLifeBar.LifeTextTargetColor[3])
        handleLifeText:SetFontColor(ZzLifeBar.LifeTextTargetColor[1], ZzLifeBar.LifeTextTargetColor[2], ZzLifeBar.LifeTextTargetColor[3])

      end
    end
  --���ж���ʾ
  else
    --����ͼ����ж�״̬��ʾ
    local AnimateMove = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Animate_Move")
    local imageType = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Image_Type")
      if IsPlayer(dwID) then
        if target.nMoveState==MOVE_STATE.ON_KNOCKED_DOWN then --������
          imageType:FromIconID(2027)
          AnimateMove:Show()
        elseif target.nMoveState==MOVE_STATE.ON_RISE then --����
          imageType:FromIconID(2027)
          AnimateMove:Show()
        elseif target.nMoveState==MOVE_STATE.ON_HALT then --ѣ��
          imageType:FromIconID(2019)
          AnimateMove:Show()
        elseif target.nMoveState==MOVE_STATE.ON_FREEZE then --����
          imageType:FromIconID(2036)
          AnimateMove:Show()
        elseif target.nMoveState==MOVE_STATE.ON_ENTRAP then --����
          imageType:FromIconID(2020)
          AnimateMove:Show()
        elseif target.nMoveState==MOVE_STATE.ON_DASH then --���
          imageType:FromIconID(2030)
          AnimateMove:Show()
        elseif target.nMoveState==MOVE_STATE.ON_REPULSED then --����
          imageType:FromIconID(2030)
          AnimateMove:Show()
        elseif target.nMoveState==MOVE_STATE.ON_SKID then --����
          imageType:FromIconID(2030)
          AnimateMove:Show()
        elseif target.nMoveState==MOVE_STATE.ON_PULL then --��ץ
          imageType:FromIconID(2030)
          AnimateMove:Show()
        elseif target.nMoveState==MOVE_STATE.ON_KNOCKED_BACK then --������
          imageType:FromIconID(2030)
          AnimateMove:Show()
        elseif target.nMoveState==MOVE_STATE.ON_KNOCKED_OFF then --������
          imageType:FromIconID(2030)
          AnimateMove:Show()
        else
          imageType:FromUITex(GetForceImage(target.dwForceID))
          AnimateMove:Hide()
        end
      else
        imageType:FromUITex(GetNpcHeadImage(target.dwID))
        AnimateMove:Hide()
      end

    --��ʾѪ��
    local handleLifeBar = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Handle_LifeBar")
    local nLifeBarScale = 1
    if dwID == player.dwID then
        nLifeBarScale = ZzLifeBar.Scale
    end

    repeat

      if not IsPlayer(dwID) then
        local hNpc = GetNpc(dwID)
        if not hNpc.CanSeeLifeBar() then
          break
        end
      end

      if ZzLifeBar.bShowLifeText and ZzLifeBar[szBShowKey] then
         handleLifeText:Show()
         local fAbsX, fAbsY = handleLifeBar:GetAbsPos()  -- �����������Ǹ�����ֵ������������1.2������ô�������Ļ�׼ֵӦ����fAbsX/1.2, fAbsY/1.2
		 handleHeadText:SetAbsPos(nLifeBarScale*(fAbsX/nLifeBarScale - 93.5), nLifeBarScale*(fAbsY/nLifeBarScale - 60))
      else
        handleLifeText:Hide()
        local fAbsX, fAbsY = handleLifeBar:GetAbsPos()
        handleHeadText:SetAbsPos(nLifeBarScale*(fAbsX/nLifeBarScale - 93.5), nLifeBarScale*(fAbsY/nLifeBarScale - 45))
      end




      if ZzLifeBar.bShowLifeText and ZzLifeBar[szBShowKey] and target_nCurrentLife >= 0 and target_nCurrentLife <= target_nMaxLife then
        local sLifePercent = ""
        if ZzLifeBar.bShowLifePercent then
          local percent = math.min(target_nCurrentLife / target_nMaxLife, 1)
          sLifePercent = "("..KeepTwoByteFloat(percent * 100).."%)"
        end

        local sLife = ""
        if ZzLifeBar.bShowLifePoint then
          sLife = target_nCurrentLife
          if target_nMaxLife == 255 then
            ZzLifeBar.RefreshHPExtra(target)
          end

          if target_nCurrentLife >= 10000 and target_nCurrentLife < 100000000 then
            local nLife = target_nCurrentLife / 10000
            local sPreLife = tostring(math.floor(nLife * 10))
            local ssLife = string.sub(sPreLife, 1, -2).."."..string.sub(sPreLife, -1)
            sLife = ssLife.."��"
          elseif target_nCurrentLife >= 100000000 then
            local nLife = target_nCurrentLife / 100000000
            local sPreLife = tostring(math.floor(nLife * 10))
            local ssLife = string.sub(sPreLife, 1, -2).."."..string.sub(sPreLife, -1)
            sLife = ssLife.."��"
          end
        end

        local sLifeText = sLife .. sLifePercent
        handleLifeText:SetText(sLifeText)
      elseif ZzLifeBar.bShowLifeText and ZzLifeBar[szBShowKey] then
        ZzLifeBar.RefreshHPExtra(target)
      end
    until true





    --����ʱ��Ѫ��
    local ShadowLifeBar = handleLifeBar:Lookup("Shadow_LifeBar")
    local ShadowManaBar = handleLifeBar:Lookup("Shadow_ManaBar")
    local AnimateDevide = handleLifeBar:Lookup("Animate_Devide")
    local AnimateSelected = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Animate_Selected")
    AnimateSelected:Hide()
    if target.nMoveState==MOVE_STATE.ON_DEATH then
      handleLifeBar:SetAlpha(120)
      ShadowLifeBar:Hide()
      ShadowManaBar:Hide()
      AnimateDevide:Hide()

      if IsAlly(player.dwID, dwID) then
        handleLifeText:SetFontColor(ZzLifeBar.DeathAllyColor[1], ZzLifeBar.DeathAllyColor[2], ZzLifeBar.DeathAllyColor[3])
        handleHeadText:SetFontColor(ZzLifeBar.DeathAllyColor[1], ZzLifeBar.DeathAllyColor[2], ZzLifeBar.DeathAllyColor[3])
      else
        handleLifeText:SetFontColor(ZzLifeBar.DeathColor[1], ZzLifeBar.DeathColor[2], ZzLifeBar.DeathColor[3])
        handleHeadText:SetFontColor(ZzLifeBar.DeathColor[1], ZzLifeBar.DeathColor[2], ZzLifeBar.DeathColor[3])
      end

      --��ѡ��Ŀ�����
      local _, dwSelectedTargetID = player.GetTarget()
      if dwSelectedTargetID == dwID then
        ZzLifeBar.BringToTop(frame)
        if ZzLifeBar.bColorTarget then
          ShadowLifeBar:SetColorRGB(ZzLifeBar.LifeTextTargetColor[1], ZzLifeBar.LifeTextTargetColor[2], ZzLifeBar.LifeTextTargetColor[3])
          handleHeadText:SetFontColor(ZzLifeBar.LifeTextTargetColor[1], ZzLifeBar.LifeTextTargetColor[2], ZzLifeBar.LifeTextTargetColor[3])
          handleLifeText:SetFontColor(ZzLifeBar.LifeTextTargetColor[1], ZzLifeBar.LifeTextTargetColor[2], ZzLifeBar.LifeTextTargetColor[3])
        end
      end
      return
    end

    --����Ѫ����ʾ
    handleLifeBar:SetAlpha(250)
    ShadowLifeBar:Show()

    handleLifeText:SetFontColor(ZzLifeBar[szLifeTextKey][1], ZzLifeBar[szLifeTextKey][2], ZzLifeBar[szLifeTextKey][3])
    handleHeadText:SetFontColor(ZzLifeBar[szHeadTextKey][1], ZzLifeBar[szHeadTextKey][2], ZzLifeBar[szHeadTextKey][3])
    ShadowLifeBar:SetColorRGB(ZzLifeBar[szHeadTextKey][1], ZzLifeBar[szHeadTextKey][2], ZzLifeBar[szHeadTextKey][3])



    -- ����ǰѪ�������Ѫ��Сʱ��ִ�У�����Ѫ����������⣩
    if target_nCurrentLife >= 0 and target_nCurrentLife <= target_nMaxLife then
      local nPercentage = math.min(target_nCurrentLife / target_nMaxLife, 1)
      if dwID == player.dwID then
        LifeBarScale = ZzLifeBar.Scale
      else
        LifeBarScale = 1
      end
      if ZzLifeBar.bShowManaBar and IsPlayer(dwID)  then
        LifeBarW = 68  --��ʾ����ʱ���Ѫ������
        ShadowLifeBar:SetRelPos(LifeBarScale*(ZzLifeBar.nGlobalLeft + LifeBarW*(1 - nPercentage)), LifeBarScale*ZzLifeBar.nGlobalTop)
      else
        LifeBarW = 105  --��������ʱ���Ѫ�����ȣ��Լ�NPCѪ������
        ShadowLifeBar:SetRelPos(LifeBarScale*ZzLifeBar.nGlobalLeft, LifeBarScale*ZzLifeBar.nGlobalTop)

      end
      --����Ѫ����С����3����Ѫ���߶�

--      if nPercentage <= 0.3 then
--        ShadowLifeBar:SetAlpha(math.min(55 + 40 * (ZzLifeBar.nSteper % 10), 255))
--      end
		ShadowLifeBar:SetSize(LifeBarScale*LifeBarW*nPercentage, LifeBarScale*ZzLifeBar.nGlobalHeight)
    else
      ZzLifeBar.RefreshHPExtra(target)
    end
    handleLifeBar:FormatAllItemPos()


	      --����������ʾ���ؽ����������������ֵ����
  if IsPlayer(dwID)  and  ZzLifeBar.bShowManaBar  then
	   ShadowManaBar:Show()
	   AnimateDevide:Show()
	if  dwID == player.dwID  then

					if player.dwForceID == 7 then		--TM
						nManaPercentage = math.min(player.nCurrentEnergy / player.nMaxEnergy, ZzLifeBar.Scale)
						ShadowManaBar:SetColorRGB(150, 255, 0)  --�������ֵ����ɫ
						if player.nCurrentEnergy > 0 then
						ShadowManaBar:SetSize(LifeBarScale*35*nManaPercentage, 	LifeBarScale*ZzLifeBar.nGlobalHeight)
						end
					elseif player.dwForceID == 8 then	-- CJ


						if player.nCurrentRage > 100 then

							nManaPercentage = math.min((player.nCurrentRage / player.nMaxRage)*100, ZzLifeBar.Scale)
							ShadowManaBar:SetColorRGB(255, 150, 0)  --�ؽ���������ɫ
							ShadowManaBar:SetSize(LifeBarScale*35*nManaPercentage, 	LifeBarScale*ZzLifeBar.nGlobalHeight)
						else
							nManaPercentage = math.min(player.nCurrentRage / player.nMaxRage, ZzLifeBar.Scale)
							ShadowManaBar:SetColorRGB(255, 150, 0)  --�ؽ���������ɫ
							ShadowManaBar:SetSize(LifeBarScale*35*nManaPercentage, 	LifeBarScale*ZzLifeBar.nGlobalHeight)
						end


					elseif player.dwForceID == 10 then -- MJ

						nManaPercentage = math.min(0, 1)
						if player.nSunPowerValue == 1 then
							nManaPercentage = math.min(100, 1)
							ShadowManaBar:SetColorRGB(255, 255, 160)  --������ϵ��������ɫ
							ShadowManaBar:SetSize(LifeBarScale*35*nManaPercentage, 	LifeBarScale*ZzLifeBar.nGlobalHeight)
						elseif player.nMoonPowerValue == 1 then
							nManaPercentage = math.min(100, 1)
							ShadowManaBar:SetColorRGB(0, 255, 255)  --������ϵ��������ɫ
							ShadowManaBar:SetSize(LifeBarScale*35*nManaPercentage, 	LifeBarScale*ZzLifeBar.nGlobalHeight)
						else

							if player.nCurrentSunEnergy > player.nCurrentMoonEnergy then
								nManaPercentage = math.min(player.nCurrentSunEnergy / player.nMaxSunEnergy, ZzLifeBar.Scale)
								ShadowManaBar:SetColorRGB(255, 255, 160)  --������ϵ��������ɫ
								ShadowManaBar:SetSize(LifeBarScale*35*nManaPercentage, 	LifeBarScale*ZzLifeBar.nGlobalHeight)
							elseif player.nCurrentMoonEnergy > player.nCurrentSunEnergy then
								nManaPercentage = math.min(player.nCurrentMoonEnergy / player.nMaxMoonEnergy, ZzLifeBar.Scale)
								ShadowManaBar:SetColorRGB(0, 255, 255)  --������ϵ��������ɫ
								ShadowManaBar:SetSize(LifeBarScale*35*nManaPercentage, 	LifeBarScale*ZzLifeBar.nGlobalHeight)
							else
								nManaPercentage = math.min(0, 1)
								--������ʱ û����ɫ
								ShadowManaBar:SetSize(LifeBarScale*35*nManaPercentage, LifeBarScale*ZzLifeBar.nGlobalHeight)
							end
						end

					else					--����

						nManaPercentage = math.min(player.nCurrentMana / player.nMaxMana, ZzLifeBar.Scale)
						ShadowManaBar:SetColorRGB(0, 255, 255)  --����ְҵ������ɫ
						ShadowManaBar:SetSize(LifeBarScale*35*nManaPercentage, 	LifeBarScale*ZzLifeBar.nGlobalHeight)
					end

					if nManaPercentage <= 0.5 then
						ShadowManaBar:SetAlpha(math.min(55 + 40 * (ZzLifeBar.nSteper % 10), 255))
					end
	elseif dwID == target.dwID then   --�������ң�����ʾ����

		if target.dwForceID == 7 then	-- TM
			nManaPercentage = math.min(target.nCurrentEnergy / target.nMaxEnergy, 1)
			ShadowManaBar:SetColorRGB(150, 255, 0)  --�������ֵ����ɫ

			if nManaPercentage > 0 then
			   ShadowManaBar:SetSize(LifeBarScale*35*nManaPercentage, LifeBarScale*ZzLifeBar.nGlobalHeight)

			end
		elseif target.dwForceID == 8 then	-- CJ
			ShadowManaBar:SetColorRGB(255, 150, 0)  --�ؽ���������ɫ

			if target.nMaxRage > 100 then
			   nManaPercentage = math.min((target.nCurrentRage / target.nMaxRage)*100, 1)
			   ShadowManaBar:SetSize(LifeBarScale*35*nManaPercentage, LifeBarScale*ZzLifeBar.nGlobalHeight)
			else
			   nManaPercentage = math.min(target.nCurrentRage / target.nMaxRage, 1)
			   ShadowManaBar:SetSize(LifeBarScale*35*nManaPercentage, LifeBarScale*ZzLifeBar.nGlobalHeight)
			end

		elseif 	target.dwForceID == 10 then -- MJ

			nManaPercentage = math.min(0, 1)
			if target.nSunPowerValue ~= 1 then
				if target.nCurrentSunEnergy > target.nCurrentMoonEnergy then
				   nManaPercentage = math.min(target.nCurrentSunEnergy / target.nMaxSunEnergy, 1)
			       ShadowManaBar:SetColorRGB(255, 255, 160)
			       ShadowManaBar:SetSize(LifeBarScale*35*nManaPercentage, LifeBarScale*ZzLifeBar.nGlobalHeight)
				elseif target.nCurrentMoonEnergy > target.nCurrentSunEnergy then
				   nManaPercentage = math.min(target.nCurrentMoonEnergy / target.nMaxMoonEnergy, 1)
			       ShadowManaBar:SetColorRGB(0, 255, 255)
			       ShadowManaBar:SetSize(LifeBarScale*35*nManaPercentage, LifeBarScale*ZzLifeBar.nGlobalHeight)
				else
				   nManaPercentage = math.min(0, 1)
				   ShadowManaBar:SetSize(LifeBarScale*35*nManaPercentage, LifeBarScale*ZzLifeBar.nGlobalHeight)
			   end
			elseif target.nMoonPowerValue ~= 1 then
			   if target.nCurrentSunEnergy > target.nCurrentMoonEnergy then
				   nManaPercentage = math.min(target.nCurrentSunEnergy / target.nMaxSunEnergy, 1)
			       ShadowManaBar:SetColorRGB(255, 255, 160)
			       ShadowManaBar:SetSize(LifeBarScale*35*nManaPercentage, LifeBarScale*ZzLifeBar.nGlobalHeight)
				elseif target.nCurrentMoonEnergy > target.nCurrentSunEnergy then
				   nManaPercentage = math.min(target.nCurrentMoonEnergy / target.nMaxMoonEnergy, 1)
			       ShadowManaBar:SetColorRGB(0, 255, 255)
			       ShadowManaBar:SetSize(LifeBarScale*35*nManaPercentage, LifeBarScale*ZzLifeBar.nGlobalHeight)
				else
				   nManaPercentage = math.min(0, 1)
				   ShadowManaBar:SetSize(LifeBarScale*35*nManaPercentage, LifeBarScale*ZzLifeBar.nGlobalHeight)
			   end
			end

			if target.nSunPowerValue == 1 then
			   nManaPercentage = math.min(100, 1)
			   ShadowManaBar:SetColorRGB(255, 255, 160)
			   ShadowManaBar:SetSize(LifeBarScale*35*nManaPercentage, LifeBarScale*ZzLifeBar.nGlobalHeight)

			elseif target.nMoonPowerValue == 1 then
			   nManaPercentage = math.min(100, 1)
			   ShadowManaBar:SetColorRGB(0, 255, 255)
			   ShadowManaBar:SetSize(LifeBarScale*35*nManaPercentage, LifeBarScale*ZzLifeBar.nGlobalHeight)

			end

		else
			nManaPercentage = math.min(target.nCurrentMana / target.nMaxMana, 1)
			ShadowManaBar:SetColorRGB(0, 255, 255)  --����ְҵ������ɫ
			ShadowManaBar:SetSize(LifeBarScale*35*nManaPercentage, LifeBarScale*ZzLifeBar.nGlobalHeight)
		end


	--ShadowManaBar:SetSize(LifeBarScale*35*nManaPercentage, LifeBarScale*ZzLifeBar.nGlobalHeight)
		if nManaPercentage <= 0.5 then
			ShadowManaBar:SetAlpha(math.min(55 + 40 * (ZzLifeBar.nSteper % 10), 255))
		end
	end
 else
		ShadowManaBar:Hide()
		AnimateDevide:Hide()
 end

    --��ѡ��Ŀ����ʾ����
    local _, dwSelectedTargetID = player.GetTarget()
    if dwSelectedTargetID == dwID then
      ZzLifeBar.BringToTop(frame)
      AnimateSelected:Show()

      if ZzLifeBar.bColorTarget then
        ShadowLifeBar:SetColorRGB(ZzLifeBar.LifeTextTargetColor[1], ZzLifeBar.LifeTextTargetColor[2], ZzLifeBar.LifeTextTargetColor[3])
        handleHeadText:SetFontColor(ZzLifeBar.LifeTextTargetColor[1], ZzLifeBar.LifeTextTargetColor[2], ZzLifeBar.LifeTextTargetColor[3])
        handleLifeText:SetFontColor(ZzLifeBar.LifeTextTargetColor[1], ZzLifeBar.LifeTextTargetColor[2], ZzLifeBar.LifeTextTargetColor[3])
      end
    end

    --�����˹�����
    local handleCastingBar = frame:Lookup("", ""):Lookup("Handle_BarTemplate"):Lookup("Handle_CastingBar")
    if ZzLifeBar.bShowCastingBar then
      local imageCastingBar = handleCastingBar:Lookup("Image_CastingBar")
      local textSkillName = handleCastingBar:Lookup("Text_SkillName")
      local nCastingBarAlpha = handleCastingBar:GetAlpha()
      local bPrePare, dwSkillID, dwSkillLevel, fCastPercent = target.GetSkillPrepareState()
      if bPrePare then
        imageCastingBar:SetPercentage(fCastPercent)
        local szSkillName = Table_GetSkillName(dwSkillID, dwSkillLevel) or ""
        textSkillName:SetText(szSkillName)
        nCastingBarAlpha = nCastingBarAlpha + 50
      else
        nCastingBarAlpha = nCastingBarAlpha - 50
      end
      if nCastingBarAlpha <= 0 then
        handleCastingBar:SetAlpha(0)
        imageType:SetAlpha(250)
      else
        handleCastingBar:SetAlpha(math.min(nCastingBarAlpha, 250))
        imageType:SetAlpha(250 - math.min(nCastingBarAlpha, 250))
      end
      handleCastingBar:Show()
    else
      handleCastingBar:Hide()
    end
  end
end

function ZzLifeBar.GetCharacter(dwID)
	local target = nil
	if IsPlayer(dwID) then
		target = GetPlayer(dwID)
	else
		target = GetNpc(dwID)
	end
	return target
end

----------------------------------------------------------------------------------------------------------------------------------------------
function ZzLifeBar.CreateLifeBar(dwTargetID)
	if not dwTargetID then
		return
	end
	local player = GetClientPlayer()
	if not player then
		return
	end
		local target = ZzLifeBar.GetCharacter(dwTargetID)
		if not target then
			return
		end
		local frame = Station.Lookup("Lowest/ZzLifeBar_" .. dwTargetID)
		if frame then
			return
		end
		frame = Wnd.OpenWindow("Interface\\ZzLifeBar\\ZzLifeBar.ini", "ZzLifeBar_" .. dwTargetID)
		if not frame then
			return
		end

		ZzLifeBar.BringToBack(frame)

		ZzLifeBar.tLifeBarList[dwTargetID] = frame
		if dwTargetID == player.dwID then
			frame:Scale(ZzLifeBar.Scale, ZzLifeBar.Scale)
		end
		frame:Hide()
end

function ZzLifeBar.RemoveLifeBar(dwTargetID)
	local frame = Station.Lookup("Lowest/ZzLifeBar_" .. dwTargetID)
	if frame then
		ZzLifeBar.tLifeBarList[dwTargetID] = nil
		Wnd.CloseWindow(frame:GetName())
	end
end
----------------------------------------------------------------------------------------------------------------------------------------------

function ZzLifeBar.OpenPanel()
	local frame = Station.Lookup("Lowest/ZzLifeBar")
	if not frame then
		frame = Wnd.OpenWindow("Interface\\ZzLifeBar\\ZzLifeBar.ini", "ZzLifeBar")
	end
	frame:Show()
	frame:SetSize(0, 0)
	frame:Lookup("", ""):Hide()
end

ZzLifeBar.OpenPanel()

--����Ϊ�˵�����
function ZzLifeBar.GetMenu()
	local menu = {szOption = "ͷ��Ѫ������",}
	local m_scope = {szOption = "��ʾ��Χ", bCheck = false}
		table.insert(m_scope, {szOption = "30", bMCheck = true, bChecked = ZzLifeBar.nShowRange == 30, fnAction = function() ZzLifeBar.nShowRange = 30; end, })
		table.insert(m_scope, {szOption = "40", bMCheck = true, bChecked = ZzLifeBar.nShowRange == 40, fnAction = function() ZzLifeBar.nShowRange = 40; end, })
		table.insert(m_scope, {szOption = "50", bMCheck = true, bChecked = ZzLifeBar.nShowRange == 50, fnAction = function() ZzLifeBar.nShowRange = 50; end, })
		table.insert(m_scope, {szOption = "60", bMCheck = true, bChecked = ZzLifeBar.nShowRange == 60, fnAction = function() ZzLifeBar.nShowRange = 60; end, })
		table.insert(m_scope, {szOption = "70", bMCheck = true, bChecked = ZzLifeBar.nShowRange == 70, fnAction = function() ZzLifeBar.nShowRange = 70; end, })
		table.insert(m_scope, {szOption = "80", bMCheck = true, bChecked = ZzLifeBar.nShowRange == 80, fnAction = function() ZzLifeBar.nShowRange = 80; end, })
		table.insert(m_scope, {szOption = "90", bMCheck = true, bChecked = ZzLifeBar.nShowRange == 90, fnAction = function() ZzLifeBar.nShowRange = 90; end, })
		table.insert(m_scope, {szOption = "100", bMCheck = true, bChecked = ZzLifeBar.nShowRange == 100, fnAction = function() ZzLifeBar.nShowRange = 100; end, })

	table.insert(menu, m_scope)
	local m_head = {szOption = "��ʾ����ͷ����Ϣ", bCheck = true, bChecked = ZzLifeBar.bShowHeadInfo == true, fnAction = function() ZzLifeBar.bShowHeadInfo = not ZzLifeBar.bShowHeadInfo end}
	table.insert(m_head, {szOption = "��ʾ�Լ�����", bCheck = true, bChecked = ZzLifeBar.bShowSelfName == true, fnAction = function() ZzLifeBar.bShowSelfName = not ZzLifeBar.bShowSelfName; end, fnDisable = function() return not ZzLifeBar.bShowHeadInfo end})
	table.insert(m_head, {szOption = "��ʾ�Լ��ƺ�", bCheck = true, bChecked = ZzLifeBar.bShowSelfTitle == true, fnAction = function() ZzLifeBar.bShowSelfTitle = not ZzLifeBar.bShowSelfTitle; end, fnDisable = function() return not ZzLifeBar.bShowHeadInfo end})
	table.insert(m_head, {szOption = "��ʾ�Լ��İ������", bCheck = true, bChecked = ZzLifeBar.bShowSelfTongName == true, fnAction = function() ZzLifeBar.bShowSelfTongName = not ZzLifeBar.bShowSelfTongName; end, fnDisable = function() return not ZzLifeBar.bShowHeadInfo end})
	table.insert(m_head, {szOption = "��ʾ�������", bCheck = true, bChecked = ZzLifeBar.bShowPlayerName == true, fnAction = function() ZzLifeBar.bShowPlayerName = not ZzLifeBar.bShowPlayerName; end, fnDisable = function() return not ZzLifeBar.bShowHeadInfo end})
	table.insert(m_head, {szOption = "��ʾ��ҳƺ�", bCheck = true, bChecked = ZzLifeBar.bShowPlayerTitle == true, fnAction = function() ZzLifeBar.bShowPlayerTitle = not ZzLifeBar.bShowPlayerTitle; end, fnDisable = function() return not ZzLifeBar.bShowHeadInfo end})
	table.insert(m_head, {szOption = "��ʾ��ҵİ������", bCheck = true, bChecked = ZzLifeBar.bShowPlayerTongName == true, fnAction = function() ZzLifeBar.bShowPlayerTongName = not ZzLifeBar.bShowPlayerTongName; end, fnDisable = function() return not ZzLifeBar.bShowHeadInfo end})
	table.insert(m_head, {szOption = "��ʾNPC����", bCheck = true, bChecked = ZzLifeBar.bShowNPCName == true, fnAction = function() ZzLifeBar.bShowNPCName = not ZzLifeBar.bShowNPCName; end, fnDisable = function() return not ZzLifeBar.bShowHeadInfo end})
	table.insert(m_head, {szOption = "��ʾNPC�ƺ�", bCheck = true, bChecked = ZzLifeBar.bShowNPCTitle == true, fnAction = function() ZzLifeBar.bShowNPCTitle = not ZzLifeBar.bShowNPCTitle; end, fnDisable = function() return not ZzLifeBar.bShowHeadInfo end})

	local m_distance = {szOption = "��ʾ����", bCheck = true, bChecked = ZzLifeBar.bShowDistance == true, fnAction = function() ZzLifeBar.bShowDistance = not ZzLifeBar.bShowDistance; end, fnDisable = function() return not ZzLifeBar.bShowHeadInfo end}
	table.insert(m_distance, {szOption = "����ʾĿ��ľ���", bCheck = true, bChecked = ZzLifeBar.bOnlyShowTargetDistance == true, fnAction = function() ZzLifeBar.bOnlyShowTargetDistance = not ZzLifeBar.bOnlyShowTargetDistance; end, })
	table.insert(m_head, m_distance)
	local m_angle = {szOption = "��ʾ����", fnDisable = function() return not ZzLifeBar.bShowHeadInfo end}
	local m_angle_type = {szOption = "��ʾ��ʽ"}
	table.insert(m_angle_type, {szOption = "�Ƕ�", bMCheck = true, bChecked = ZzLifeBar.nShowFaceDirectionType == ZzLifeBar.const.ANGLE_FACE_DIRECTION, fnAction = function() ZzLifeBar.nShowFaceDirectionType = ZzLifeBar.const.ANGLE_FACE_DIRECTION; end, })
	table.insert(m_angle_type, {szOption = "����(��/��)", bMCheck = true, bChecked = ZzLifeBar.nShowFaceDirectionType == ZzLifeBar.const.TEXT_FACE_DIRECTION, fnAction = function() ZzLifeBar.nShowFaceDirectionType = ZzLifeBar.const.TEXT_FACE_DIRECTION; end, })
	table.insert(m_angle, m_angle_type)
  local m_angle_other = {szOption = "��ʾ���˶��Լ�������", bCheck = true, bChecked = ZzLifeBar.bShowOtherFaceDirection == true, fnAction = function() ZzLifeBar.bShowOtherFaceDirection = not ZzLifeBar.bShowOtherFaceDirection; end, }
  table.insert(m_angle_other, {szOption = "����ʾĿ��", bCheck = true, bChecked = ZzLifeBar.bShowOnlyTargetFaceDirection == true, fnAction = function() ZzLifeBar.bShowOnlyTargetFaceDirection = not ZzLifeBar.bShowOnlyTargetFaceDirection; end, })
	table.insert(m_angle, m_angle_other)
	table.insert(m_angle, {szOption = "��ʾ�Լ���Ŀ�������", bCheck = true, bChecked = ZzLifeBar.bShowSelfFaceDirection == true, fnAction = function() ZzLifeBar.bShowSelfFaceDirection = not ZzLifeBar.bShowSelfFaceDirection; end, })
	table.insert(m_head, m_angle)

	table.insert(menu, m_head)
	table.insert(menu, {bDevide = true})
	local m_bHeadcolor = {szOption = "��ʾ��ѡ��Ŀ�������ɫ", bCheck = true, bChecked = ZzLifeBar.bColorTarget == true, fnAction = function() ZzLifeBar.bColorTarget = not ZzLifeBar.bColorTarget end}
	local m_headcolor = {szOption = "ѡ��Ŀ���ͷ����Ѫ����ɫ",
												bColorTable = true, rgb = ZzLifeBar.LifeTextTargetColor,
												fnChangeColor = function(UserData, r, g, b) ZzLifeBar.LifeTextTargetColor={r,g,b} end,
												fnAutoClose = function() return true end,
												fnAction = function()
                            GetUserInput("����RGBֵ����ʽΪxxx,xxx,xxx�����磺\n255,0,0��", function(szText)
                              local tRGB = ZzLifeBar.StringToRGB(szText)
                              if tRGB then
                                ZzLifeBar.LifeTextTargetColor = tRGB
                              end
                            end, nil, nil, nil, nil)
                        end,
                        fnDisable = function() return not ZzLifeBar.bColorTarget end}
	table.insert(m_bHeadcolor, m_headcolor)
	table.insert(menu, m_bHeadcolor)
	table.insert(menu, {bDevide = true})
	local m_lifebar = {szOption = "��ʾ��Ѫ��", bCheck = true, bChecked = ZzLifeBar.bShowLifeBar, fnAction = function() ZzLifeBar.bShowLifeBar = not ZzLifeBar.bShowLifeBar end,}
	local m_self = {szOption = "����", bCheck = true, bChecked = ZzLifeBar.bShowSelf, fnAction = function() ZzLifeBar.bShowSelf = not ZzLifeBar.bShowSelf end,fnDisable = function() return not ZzLifeBar.bShowLifeBar end}
		table.insert(m_self, {szOption = "1.0 ��", bMCheck = true, bChecked = ZzLifeBar.Scale == 1, fnAction = function() ZzLifeBar.Scale = 1; ZzLifeBar.RemoveLifeBar(GetClientPlayer().dwID); ZzLifeBar.CreateLifeBar(GetClientPlayer().dwID) end, fnDisable = function() return not ZzLifeBar.bShowSelf end})
		table.insert(m_self, {szOption = "1.1 ��", bMCheck = true, bChecked = ZzLifeBar.Scale == 1.1, fnAction = function() ZzLifeBar.Scale = 1.1; ZzLifeBar.RemoveLifeBar(GetClientPlayer().dwID); ZzLifeBar.CreateLifeBar(GetClientPlayer().dwID) end, fnDisable = function() return not ZzLifeBar.bShowSelf end})
		table.insert(m_self, {szOption = "1.2 ��", bMCheck = true, bChecked = ZzLifeBar.Scale == 1.2, fnAction = function() ZzLifeBar.Scale = 1.2; ZzLifeBar.RemoveLifeBar(GetClientPlayer().dwID); ZzLifeBar.CreateLifeBar(GetClientPlayer().dwID) end, fnDisable = function() return not ZzLifeBar.bShowSelf end})
		table.insert(m_self, {szOption = "1.3 ��", bMCheck = true, bChecked = ZzLifeBar.Scale == 1.3, fnAction = function() ZzLifeBar.Scale = 1.3; ZzLifeBar.RemoveLifeBar(GetClientPlayer().dwID); ZzLifeBar.CreateLifeBar(GetClientPlayer().dwID) end, fnDisable = function() return not ZzLifeBar.bShowSelf end})
		table.insert(m_self, {szOption = "1.4 ��", bMCheck = true, bChecked = ZzLifeBar.Scale == 1.4, fnAction = function() ZzLifeBar.Scale = 1.4; ZzLifeBar.RemoveLifeBar(GetClientPlayer().dwID); ZzLifeBar.CreateLifeBar(GetClientPlayer().dwID) end, fnDisable = function() return not ZzLifeBar.bShowSelf end})
		table.insert(m_self, {szOption = "1.5 ��", bMCheck = true, bChecked = ZzLifeBar.Scale == 1.5, fnAction = function() ZzLifeBar.Scale = 1.5; ZzLifeBar.RemoveLifeBar(GetClientPlayer().dwID); ZzLifeBar.CreateLifeBar(GetClientPlayer().dwID) end, fnDisable = function() return not ZzLifeBar.bShowSelf end})
	table.insert(m_lifebar, m_self)

	table.insert(m_lifebar, {szOption = "�ж�NPC", bCheck = true, bChecked = ZzLifeBar.bShowEnemyNPC, fnAction = function() ZzLifeBar.bShowEnemyNPC = not ZzLifeBar.bShowEnemyNPC end,fnDisable = function() return not ZzLifeBar.bShowLifeBar end})
	table.insert(m_lifebar, {szOption = "����NPC", bCheck = true, bChecked = ZzLifeBar.bShowNeutralityNPC, fnAction = function() ZzLifeBar.bShowNeutralityNPC = not ZzLifeBar.bShowNeutralityNPC end,fnDisable = function() return not ZzLifeBar.bShowLifeBar end})
	table.insert(m_lifebar, {szOption = "�Ѻ�NPC", bCheck = true, bChecked = ZzLifeBar.bShowAllyNPC, fnAction = function() ZzLifeBar.bShowAllyNPC = not ZzLifeBar.bShowAllyNPC end,fnDisable = function() return not ZzLifeBar.bShowLifeBar end})
	table.insert(m_lifebar, {szOption = "�ж����", bCheck = true, bChecked = ZzLifeBar.bShowEnemyPlayer, fnAction = function() ZzLifeBar.bShowEnemyPlayer = not ZzLifeBar.bShowEnemyPlayer end,fnDisable = function() return not ZzLifeBar.bShowLifeBar end})
	table.insert(m_lifebar, {szOption = "�������", bCheck = true, bChecked = ZzLifeBar.bShowNeutralityPlayer, fnAction = function() ZzLifeBar.bShowNeutralityPlayer = not ZzLifeBar.bShowNeutralityPlayer end,fnDisable = function() return not ZzLifeBar.bShowLifeBar end})
	table.insert(m_lifebar, {szOption = "�Ѻ����", bCheck = true, bChecked = ZzLifeBar.bShowAllyPlayer, fnAction = function() ZzLifeBar.bShowAllyPlayer = not ZzLifeBar.bShowAllyPlayer end,fnDisable = function() return not ZzLifeBar.bShowLifeBar end})
	table.insert(m_lifebar, {szOption = "�������", bCheck = true, bChecked = ZzLifeBar.bShowPartyPlayer, fnAction = function() ZzLifeBar.bShowPartyPlayer = not ZzLifeBar.bShowPartyPlayer end,fnDisable = function() return not ZzLifeBar.bShowLifeBar end})

	table.insert(menu, m_lifebar)

	local m_life = {szOption = "��ʾ��Ѫ����ֵ", bCheck = true, bChecked = ZzLifeBar.bShowLifeText, fnAction = function() ZzLifeBar.bShowLifeText = not ZzLifeBar.bShowLifeText end,}
	local m_life_style = {szOption = "��ʾ��ʽ", bCheck = false, fnDisable = function() return not ZzLifeBar.bShowLifeText end}
	table.insert(m_life, m_life_style)
	table.insert(m_life_style, {szOption = "��ֵ", bCheck = true, bChecked = ZzLifeBar.bShowLifePoint, fnAction = function() ZzLifeBar.bShowLifePoint = not ZzLifeBar.bShowLifePoint end,})
	table.insert(m_life_style, {szOption = "�ٷֱ�", bCheck = true, bChecked = ZzLifeBar.bShowLifePercent, fnAction = function() ZzLifeBar.bShowLifePercent = not ZzLifeBar.bShowLifePercent end,})

	table.insert(m_life, {szOption = "����", bCheck = true, bChecked = ZzLifeBar.bShowSelfLifeText, fnAction = function() ZzLifeBar.bShowSelfLifeText = not ZzLifeBar.bShowSelfLifeText end, fnDisable = function() return not ZzLifeBar.bShowLifeText end})
	table.insert(m_life, {szOption = "�ж�NPC", bCheck = true, bChecked = ZzLifeBar.bShowEnemyNPCLifeText, fnAction = function() ZzLifeBar.bShowEnemyNPCLifeText = not ZzLifeBar.bShowEnemyNPCLifeText end, fnDisable = function() return not ZzLifeBar.bShowLifeText end})
	table.insert(m_life, {szOption = "����NPC", bCheck = true, bChecked = ZzLifeBar.bShowNeutralityNPCLifeText, fnAction = function() ZzLifeBar.bShowNeutralityNPCLifeText = not ZzLifeBar.bShowNeutralityNPCLifeText end, fnDisable = function() return not ZzLifeBar.bShowLifeText end})
	table.insert(m_life, {szOption = "�Ѻ�NPC", bCheck = true, bChecked = ZzLifeBar.bShowAllyNPCLifeText, fnAction = function() ZzLifeBar.bShowAllyNPCLifeText = not ZzLifeBar.bShowAllyNPCLifeText end, fnDisable = function() return not ZzLifeBar.bShowLifeText end})
	table.insert(m_life, {szOption = "�ж����", bCheck = true, bChecked = ZzLifeBar.bShowEnemyPlayerLifeText, fnAction = function() ZzLifeBar.bShowEnemyPlayerLifeText = not ZzLifeBar.bShowEnemyPlayerLifeText end, fnDisable = function() return not ZzLifeBar.bShowLifeText end})
	table.insert(m_life, {szOption = "�������", bCheck = true, bChecked = ZzLifeBar.bShowNeutralityPlayerLifeText, fnAction = function() ZzLifeBar.bShowNeutralityPlayerLifeText = not ZzLifeBar.bShowNeutralityPlayerLifeText end, fnDisable = function() return not ZzLifeBar.bShowLifeText end})
	table.insert(m_life, {szOption = "�Ѿ����", bCheck = true, bChecked = ZzLifeBar.bShowAllyPlayerLifeText, fnAction = function() ZzLifeBar.bShowAllyPlayerLifeText = not ZzLifeBar.bShowAllyPlayerLifeText end, fnDisable = function() return not ZzLifeBar.bShowLifeText end})
	table.insert(m_life, {szOption = "�������", bCheck = true, bChecked = ZzLifeBar.bShowPartyPlayerLifeText, fnAction = function() ZzLifeBar.bShowPartyPlayerLifeText = not ZzLifeBar.bShowPartyPlayerLifeText end, fnDisable = function() return not ZzLifeBar.bShowLifeText end})

	table.insert(menu, m_life)

	table.insert(menu, {szOption = "��ʾ���������", bCheck = true, bChecked = ZzLifeBar.bShowManaBar, fnAction = function() ZzLifeBar.bShowManaBar = not ZzLifeBar.bShowManaBar end,})
	table.insert(menu, {szOption = "��ʾ���˹�����", bCheck = true, bChecked = ZzLifeBar.bShowCastingBar, fnAction = function() ZzLifeBar.bShowCastingBar = not ZzLifeBar.bShowCastingBar end,})

	table.insert(menu, {bDevide = true})

	local m_lifebar_color = {szOption = "Ѫ����ɫ"}

	local m_1 = {szOption = "����",
												bColorTable = true, rgb = ZzLifeBar.SelfColor,
												fnChangeColor = function(UserData, r, g, b) ZzLifeBar.SelfColor={r,g,b} end,
												fnAutoClose = function() return true end,
												fnAction = function()
                            GetUserInput("����RGBֵ����ʽΪxxx,xxx,xxx�����磺\n255,0,0��", function(szText)
                              local tRGB = ZzLifeBar.StringToRGB(szText)
                              if tRGB then
                                ZzLifeBar.SelfColor = tRGB
                              end
                            end, nil, nil, nil, nil)
                        end}
	table.insert(m_lifebar_color, m_1)
	local m_2 = {szOption = "����",
												bColorTable = true, rgb = ZzLifeBar.NeutralityColor,
												fnChangeColor = function(UserData, r, g, b) ZzLifeBar.NeutralityColor={r,g,b} end,
												fnAutoClose = function() return true end,
												fnAction = function()
                            GetUserInput("����RGBֵ����ʽΪxxx,xxx,xxx�����磺\n255,0,0��", function(szText)
                              local tRGB = ZzLifeBar.StringToRGB(szText)
                              if tRGB then
                                ZzLifeBar.NeutralityColor = tRGB
                              end
                            end, nil, nil, nil, nil)
                        end}
	table.insert(m_lifebar_color, m_2)
	local m_3 = {szOption = "����",
												bColorTable = true, rgb = ZzLifeBar.MyPartyColor,
												fnChangeColor = function(UserData, r, g, b) ZzLifeBar.MyPartyColor={r,g,b} end,
												fnAutoClose = function() return true end,
												fnAction = function()
                            GetUserInput("����RGBֵ����ʽΪxxx,xxx,xxx�����磺\n255,0,0��", function(szText)
                              local tRGB = ZzLifeBar.StringToRGB(szText)
                              if tRGB then
                                ZzLifeBar.MyPartyColor = tRGB
                              end
                            end, nil, nil, nil, nil)
                        end}
	table.insert(m_lifebar_color, m_3)
	local m_4 = {szOption = "�Ѻ�",
												bColorTable = true, rgb = ZzLifeBar.AllyColor,
												fnChangeColor = function(UserData, r, g, b) ZzLifeBar.AllyColor={r,g,b} end,
												fnAutoClose = function() return true end,
												fnAction = function()
                            GetUserInput("����RGBֵ����ʽΪxxx,xxx,xxx�����磺\n255,0,0��", function(szText)
                              local tRGB = ZzLifeBar.StringToRGB(szText)
                              if tRGB then
                                ZzLifeBar.AllyColor = tRGB
                              end
                            end, nil, nil, nil, nil)
                        end}
	table.insert(m_lifebar_color, m_4)
	local m_5 = {szOption = "�ж�",
												bColorTable = true, rgb = ZzLifeBar.EnemyColor,
												fnChangeColor = function(UserData, r, g, b) ZzLifeBar.EnemyColor={r,g,b} end,
												fnAutoClose = function() return true end,
												fnAction = function()
                            GetUserInput("����RGBֵ����ʽΪxxx,xxx,xxx�����磺\n255,0,0��", function(szText)
                              local tRGB = ZzLifeBar.StringToRGB(szText)
                              if tRGB then
                                ZzLifeBar.EnemyColor = tRGB
                              end
                            end, nil, nil, nil, nil)
                        end}
	table.insert(m_lifebar_color, m_5)
	table.insert(menu, m_lifebar_color)

	local m_lifetext_color = {szOption = "Ѫ����ֵ��ɫ"}
	local mt_1 = {szOption = "����",
												bColorTable = true, rgb = ZzLifeBar.LifeTextSelfColor,
												fnChangeColor = function(UserData, r, g, b) ZzLifeBar.LifeTextSelfColor={r,g,b} end,
												fnAutoClose = function() return true end,
												fnAction = function()
                            GetUserInput("����RGBֵ����ʽΪxxx,xxx,xxx�����磺\n255,0,0��", function(szText)
                              local tRGB = ZzLifeBar.StringToRGB(szText)
                              if tRGB then
                                ZzLifeBar.LifeTextSelfColor = tRGB
                              end
                            end, nil, nil, nil, nil)
                        end}
	table.insert(m_lifetext_color, mt_1)
	local mt_2 = {szOption = "����",
												bColorTable = true, rgb = ZzLifeBar.LifeTextNeutralityColor,
												fnChangeColor = function(UserData, r, g, b) ZzLifeBar.LifeTextNeutralityColor={r,g,b} end,
												fnAutoClose = function() return true end,
												fnAction = function()
                            GetUserInput("����RGBֵ����ʽΪxxx,xxx,xxx�����磺\n255,0,0��", function(szText)
                              local tRGB = ZzLifeBar.StringToRGB(szText)
                              if tRGB then
                                ZzLifeBar.LifeTextNeutralityColor = tRGB
                              end
                            end, nil, nil, nil, nil)
                        end}
	table.insert(m_lifetext_color, mt_2)
	local mt_3 = {szOption = "����",
												bColorTable = true, rgb = ZzLifeBar.LifeTextMyPartyColor,
												fnChangeColor = function(UserData, r, g, b) ZzLifeBar.LifeTextMyPartyColor={r,g,b} end,
												fnAutoClose = function() return true end,
												fnAction = function()
                            GetUserInput("����RGBֵ����ʽΪxxx,xxx,xxx�����磺\n255,0,0��", function(szText)
                              local tRGB = ZzLifeBar.StringToRGB(szText)
                              if tRGB then
                                ZzLifeBar.LifeTextMyPartyColor = tRGB
                              end
                            end, nil, nil, nil, nil)
                        end}
	table.insert(m_lifetext_color, mt_3)
	local mt_4 = {szOption = "�Ѻ�",
												bColorTable = true, rgb = ZzLifeBar.LifeTextAllyColor,
												fnChangeColor = function(UserData, r, g, b) ZzLifeBar.LifeTextAllyColor={r,g,b} end,
												fnAutoClose = function() return true end,
												fnAction = function()
                            GetUserInput("����RGBֵ����ʽΪxxx,xxx,xxx�����磺\n255,0,0��", function(szText)
                              local tRGB = ZzLifeBar.StringToRGB(szText)
                              if tRGB then
                                ZzLifeBar.LifeTextAllyColor = tRGB
                              end
                            end, nil, nil, nil, nil)
                        end}
	table.insert(m_lifetext_color, mt_4)
	local mt_5 = {szOption = "�ж�",
												bColorTable = true, rgb = ZzLifeBar.LifeTextEnemyColor,
												fnChangeColor = function(UserData, r, g, b) ZzLifeBar.LifeTextEnemyColor={r,g,b} end,
												fnAutoClose = function() return true end,
												fnAction = function()
                            GetUserInput("����RGBֵ����ʽΪxxx,xxx,xxx�����磺\n255,0,0��", function(szText)
                              local tRGB = ZzLifeBar.StringToRGB(szText)
                              if tRGB then
                                ZzLifeBar.LifeTextEnemyColor = tRGB
                              end
                            end, nil, nil, nil, nil)
                        end}
	table.insert(m_lifetext_color, mt_5)
	table.insert(menu, m_lifetext_color)
	table.insert(menu, {bDevide = true})
	table.insert(menu, {szOption = "����ʾ��ս��λ", bCheck = true, bChecked = ZzLifeBar.bShowFight, fnAction = function() ZzLifeBar.bShowFight = not ZzLifeBar.bShowFight end,})

	local m_showSpecial = {szOption = "��ʾ����NPC", bCheck = true, bChecked = ZzLifeBar.bShowSpecialNPC, fnAction = function() ZzLifeBar.bShowSpecialNPC = not ZzLifeBar.bShowSpecialNPC end,}
	table.insert(m_showSpecial, {szOption = "���ֲ��ɼ�", bCheck = true, bChecked = ZzLifeBar.bCanNotSeeName, fnAction = function() ZzLifeBar.bCanNotSeeName = not ZzLifeBar.bCanNotSeeName end, fnDisable = function() return not ZzLifeBar.bShowSpecialNPC end})
--	table.insert(m_showSpecial, {szOption = "Ѫ�����ɼ�", bCheck = true, bChecked = ZzLifeBar.bCanNotSeeLifeBar, fnAction = function() ZzLifeBar.bCanNotSeeLifeBar = not ZzLifeBar.bCanNotSeeLifeBar end, fnDisable = function() return not ZzLifeBar.bShowSpecialNPC end})
	table.insert(m_showSpecial, {szOption = "����ѡ", bCheck = true, bChecked = ZzLifeBar.bIsNotSelectable, fnAction = function() ZzLifeBar.bIsNotSelectable = not ZzLifeBar.bIsNotSelectable end, fnDisable = function() return not ZzLifeBar.bShowSpecialNPC end})
	table.insert(menu, m_showSpecial)

	return menu
end
RegisterEvent("LOGIN_GAME", function()
	local tMenu = {function() return {ZzLifeBar.GetMenu()} end,}
	Player_AppendAddonMenu(tMenu)
end)

function ZzLifeBar.StringToRGB(szRGB)
  local tRGB = SplitString(szRGB, ",")
  local nRGBCount = table.getn(tRGB)
  if nRGBCount < 3 then
    return nil
  end

  local nR = tonumber(tRGB[1])
  local nG = tonumber(tRGB[2])
  local nB = tonumber(tRGB[3])

  if not nR or not nG or not nB then
    return nil
  end

  return {nR, nG, nB}
end

function ZzLifeBar.GetAngleBetween(nSrcX, nSrcY, nTarX, nTarY)
  local nY = nTarY - nSrcY
  local nX = nTarX - nSrcX

  local nInitDeg = math.deg(math.atan(nY/nX))

  local nDeg = 0

  -- 1����
  if nTarY > nSrcY and nTarX > nSrcX then
    nDeg = nInitDeg
  -- 2����
  elseif nTarY > nSrcY and nTarX < nSrcX then
    nDeg = 180 + nInitDeg
  -- 3����
  elseif nTarY < nSrcY and nTarX < nSrcX then
    nDeg = 180 + nInitDeg
  -- 4����
  else
    nDeg = 360 + nInitDeg
  end

  return nDeg
end

function ZzLifeBar.FaceDirectionToAngle(nFaceDirection)
  return nFaceDirection * 360 / 255
end

OutputMessage("MSG_SYS", "ZzLifeBar������ɡ�\n")
