------------------------------------------------------
-- #ģ�������ʼ��ֿ�ģ��
-- #ģ��˵������ǿ�ʼ�����
------------------------------------------------------

AH_MailBank = {
	tItemCache = {},
	szDataPath = "\\Interface\\AH\\data\\mail.AH",
	szCurRole = nil,
	nCurIndex = 1,
	szCurKey = "",
	nFilterType = 1,
	bShowNoReturn = false,
	bMail = true,
}

local ipairs = ipairs
local pairs = pairs
local tonumber = tonumber

local szIniFile = "Interface/AH/AH_MailBank.ini"
local bMailHooked = false
local bBagHooked = false
local tFilterType = {"��Ʒ����", "�ż�����", "������", "����ʱ��"}

-- �����ݷ�ҳ������ÿҳ98�����ݣ����ط�ҳ���ݺ�ҳ��
function AH_MailBank.GetPageMailData(tItemCache)
	--�ȶԴ���ı����ʼ�ID��������
	table.sort(tItemCache, function(a, b)
		local function max(t)
			local index = table.maxn(t)
			return t[index]
		end
		if max(a.tMailIDs) == max(b.tMailIDs) then
			return a.nUiId > b.nUiId
		else
			return max(a.tMailIDs) > max(b.tMailIDs) end
		end
	)
	local tItems, nIndex = {}, 1
	for k, v in ipairs(tItemCache) do
		tItems[nIndex] = tItems[nIndex] or {}
		table.insert(tItems[nIndex], v)
		nIndex = math.ceil(k / 98)
	end
	return tItems, nIndex
end

-- ��ҳ���ظý�ɫ����Ʒ����
function AH_MailBank.LoadMailData(frame, szName, nIndex)
	local handle = frame:Lookup("", "")
	local hBg = handle:Lookup("Handle_Bg")
	local hBox = handle:Lookup("Handle_Box")

	--��������
	local tItemCache = AH_MailBank.bShowNoReturn and AH_MailBank.SaveItemCache(false) or AH_MailBank.tItemCache[szName]
	local tCache, nMax = AH_MailBank.GetPageMailData(tItemCache)
	local i = 0
	for k, v in ipairs(tCache[nIndex] or {}) do
		if v.szName == "money" then
			local img = hBg:Lookup(k - 1)
			local box = hBox:Lookup(k - 1)
			img:Show()
			box:Show()
			box.szType = "money"
			box.szName = "��Ǯ"
			box.data = v
			box:SetObject(UI_OBJECT_NOT_NEED_KNOWN, 0)
			box:SetObjectIcon(582)
			box:SetAlpha(255)
			box:SetOverTextFontScheme(0, 15)
			box:SetOverText(0, "")
		else
			local img = hBg:Lookup(k - 1)
			local box = hBox:Lookup(k - 1)
			img:Show()
			box:Show()
			box.szType = "item"
			box.szName = v.szName
			box.data = v
			box:SetObject(UI_OBJECT_ITEM_ONLY_ID, v.nUiId, v.dwID, v.nVersion, v.dwTabType, v.dwIndex)
			box:SetObjectIcon(Table_GetItemIconID(v.nUiId))
			box:SetAlpha(255)
			box:SetOverTextFontScheme(0, 15)
			if AH_MailBank.bMail then
				local item = GetItem(v.dwID)
				if item then
					UpdateItemBoxExtend(box, item.nGenre, item.nQuality, item.nStrengthLevel)
				end
				local mail = GetMailClient().GetMailInfo(v.tMailIDs[1])
				if mail then
					local nTime = mail.GetLeftTime()
					if nTime <= 86400 * 2 then
						box:SetOverText(1, "������")
					else
						box:SetOverText(1, "")
					end
				end
			end
			if v.nStack > 1 then
				box:SetOverText(0, v.nStack)
			else
				box:SetOverText(0, "")
			end
		end
		i = k
	end
	--��������box
	for j = i, 97, 1 do
		local img = hBg:Lookup(j)
		local box = hBox:Lookup(j)
		if box:IsVisible() then
			img:Hide()
			box:Hide()
		end
	end

	frame:Lookup("", ""):Lookup("Text_Account"):SetText(szName)
	-- ��ҳ����
	local hPrev, hNext = frame:Lookup("Btn_Prev"), frame:Lookup("Btn_Next")
	local hPage = frame:Lookup("", ""):Lookup("Text_Page")
	if nMax > 1 then
		hPrev:Show()
		hNext:Show()
		hPage:Show()
		if nIndex == 1 then
			hPrev:Enable(false)
			hNext:Enable(true)
		elseif nIndex == nMax then
			hPrev:Enable(true)
			hNext:Enable(false)
		else
			hPrev:Enable(true)
			hNext:Enable(true)
		end
		hPage:SetText(string.format("%d/%d", nIndex, nMax))
	else
		hPrev:Hide()
		hNext:Hide()
		hPage:Hide()
	end
	--ɸѡ����
	frame:Lookup("", ""):Lookup("Text_Filter"):SetText(tFilterType[AH_MailBank.nFilterType])
	local hType = frame:Lookup("", ""):Lookup("Text_Type")
	if AH_MailBank.nFilterType == 4 then
		hType:SetText("����(��)��")
	else
		hType:SetText("�����ַ���")
	end
	frame:Lookup("Btn_Filter"):Enable(AH_MailBank.bMail)
	frame:Lookup("Check_NotReturn"):Enable(AH_MailBank.bMail)
	local tColor = AH_MailBank.bMail and {255, 255, 255} or {180, 180, 180}
	frame:Lookup("", ""):Lookup("Text_Filter"):SetFontColor(unpack(tColor))
	frame:Lookup("", ""):Lookup("Text_NotReturn"):SetFontColor(unpack(tColor))
end

-- ���ʼ�����ɸѡ
local function IsMailTitleExist(data, szKey)
	local MailClient = GetMailClient()
	for k, v in ipairs(data) do
		local mail = MailClient.GetMailInfo(v)
		if StringFindW(mail.szTitle, szKey) then
			return true
		end
	end
	return false
end

-- �Լ�����ɸѡ
local function IsMailSenderNameExist(data, szKey)
	local MailClient = GetMailClient()
	for k, v in ipairs(data) do
		local mail = MailClient.GetMailInfo(v)
		if StringFindW(mail.szSenderName, szKey) then
			return true
		end
	end
	return false
end

-- ��ʣ��ʱ��ɸѡ
local function IsLessMailItemTime(data, szKey)
	local nLeft = 86400 * tonumber(szKey) or 0
	local MailClient = GetMailClient()
	for k, v in ipairs(data) do
		local mail = MailClient.GetMailInfo(v)
		if mail.GetLeftTime() < nLeft then
			return true
		end
	end
	return false
end

-- ������Ʒ
function AH_MailBank.FilterMailItem(frame, szKey)
	local handle = frame:Lookup("", "")
	local hBox = handle:Lookup("Handle_Box")
	for i = 0, 97, 1 do
		local box = hBox:Lookup(i)
		if not box:IsEmpty() then
			local bExist = false
			if AH_MailBank.nFilterType == 1 then
				bExist = (StringFindW(box.szName, szKey) ~= nil)
			elseif AH_MailBank.nFilterType == 2 then
				bExist = IsMailTitleExist(box.data[6], szKey)
			elseif AH_MailBank.nFilterType == 3 then
				bExist = IsMailSenderNameExist(box.data[6], szKey)
			elseif AH_MailBank.nFilterType == 4 then
				bExist = IsLessMailItemTime(box.data[6], szKey)
			end
			if bExist then
				box:SetAlpha(255)
				box:SetOverTextFontScheme(0, 15)
			else
				box:SetAlpha(50)
				box:SetOverTextFontScheme(0, 30)
			end
		end
	end
end

-- �����ʼ���Ʒ���ݣ�����ƷnUiIdΪkey�����ݱ���ͬ����Ʒȫ���ۼӣ�ÿ����Ʒ���������ʼ�ID
function AH_MailBank.SaveItemCache(bAll)
	local MailClient = GetMailClient()
	local tMail = MailClient.GetMailList("all") or {}
	local tItems, tCount, tMailIDs, nMoney = {}, {}, {}, 0
	for _, dwID in ipairs(tMail) do
		local mail = MailClient.GetMailInfo(dwID)
		if mail.bGotContentFlag then
			mail.Read()
		else
			local target = Station.Lookup("Normal/Target")
			if target then
				mail.RequestContent(target.dwID)
			end
		end
		if bAll or (not bAll and not (mail.GetType() == MAIL_TYPE.PLAYER and (mail.bMoneyFlag or mail.bItemFlag))) then
			local tItem = AH_MailBank.GetMailItem(mail)
			for k, v in pairs(tItem) do
				--�洢��Ʒ�����ʼ�ID
				if not tMailIDs[k] then
					tMailIDs[k] = {dwID}
				else
					table.insert(tMailIDs[k], dwID)
				end
				--�����������洢��Ʒ���ݣ���������
				if k == "money" then
					--nMoney = MoneyOptAdd(nMoney, v)
					tItems = AH_MailBank.InsertData(tItems, {
						szName = "money",
						nMoney = v,
						nUiId = -1,
						tMailIDs = tMailIDs["money"]
					})
				else
					tItems = AH_MailBank.InsertData(tItems, {
						szName = k,
						dwID = v[1],
						nVersion = v[2],
						dwTabType = v[3],
						dwIndex = v[4],
						nStack = v[5],
						nUiId = v[6],
						tMailIDs = tMailIDs[k]
					})
				end
			end
		end
	end
	return tItems	--��������������Ʒ��
end

function AH_MailBank.InsertData(tItems, tData)
	local function _get(tItems, szName)
		for k, v in ipairs(tItems) do
			if v.szName == szName then
				return v
			end
		end
		return false
	end
	local v = _get(tItems, tData.szName)
	if not v then
		table.insert(tItems, tData)
	else
		if tData.szName == "money" then
			v.nMoney = MoneyOptAdd(v.nMoney, tData.nMoney)
		else
			v.nStack = v.nStack + tData.nStack
		end
	end
	return tItems
end

-- ��ȡ�����ʼ���������Ʒ���ݣ�������Ǯ��ͬ����Ʒ�������ۼӴ���
function AH_MailBank.GetMailItem(mail)
	local tItems, tCount = {}, {}
	if mail.bItemFlag then
		for i = 0, 7, 1 do
			local item = mail.GetItem(i)
			if item then
				local szKey = GetItemNameByItem(item)
				local nStack = (item.bCanStack) and item.nStackNum or 1
				tCount[szKey] = tCount[szKey] or 0	--������ͬ����Ʒ������
				if not tItems[szKey] then
					tCount[szKey] = nStack
					tItems[szKey] = {item.dwID, item.nVersion, item.dwTabType, item.dwIndex, nStack, item.nUiId}
				else
					tCount[szKey] = tCount[szKey] + nStack
					tItems[szKey] = {item.dwID, item.nVersion, item.dwTabType, item.dwIndex, tCount[szKey], item.nUiId}
				end
			end
		end
	end
	if mail.bMoneyFlag and mail.nMoney ~= 0 then
		tItems["money"] = mail.nMoney
	end
	return tItems
end

function AH_MailBank.OnUpdate()
	local frame = Station.Lookup("Normal/MailPanel")
	if frame and frame:IsVisible() then
		if not bMailHooked then	--�ʼ���������һ����ť
			local page = frame:Lookup("PageSet_Total/Page_Receive")
			local temp = Wnd.OpenWindow("interface\\AH\\AH_Widget.ini")
			if not page:Lookup("Btn_MailBank") then
				local hBtnMailBank = temp:Lookup("Btn_MailBank")
				if hBtnMailBank then
					hBtnMailBank:ChangeRelation(page, true, true)
					hBtnMailBank:SetRelPos(600, 8)
					hBtnMailBank.OnLButtonClick = function()
						if not AH_MailBank.IsPanelOpened() then
							AH_MailBank.bMail = true
							AH_MailBank.nFilterType = 1
							AH_MailBank.OpenPanel()
						else
							AH_MailBank.ClosePanel()
						end
					end
				end
			end
			Wnd.CloseWindow(temp)
			bMailHooked = true
		end
		if GetLogicFrameCount() % 4 == 0 then
			local MailClient = GetMailClient()
			local tMail = MailClient.GetMailList("all") or {}
			for _, dwID in ipairs(tMail) do
				local mail = MailClient.GetMailInfo(dwID)
				local target = Station.Lookup("Normal/Target")
				if target then
					mail.RequestContent(target.dwID)
				end
			end
			local szName = GetClientPlayer().szName
			AH_MailBank.tItemCache[szName] = AH_MailBank.SaveItemCache(true)
		end
	elseif not frame or not frame:IsVisible() then
		bMailHooked = false
	end

	local frame = Station.Lookup("Normal/BigBagPanel")
	if not bBagHooked and frame and frame:IsVisible() then --������������һ����ť
		local temp = Wnd.OpenWindow("interface\\AH\\AH_Widget.ini")
		if not frame:Lookup("Btn_Mail") then
			local hBtnMail = temp:Lookup("Btn_Mail")
			if hBtnMail then
				hBtnMail:ChangeRelation(frame, true, true)
				hBtnMail:SetRelPos(55, 0)
				hBtnMail.OnLButtonClick = function()
					if not AH_MailBank.IsPanelOpened() then
						AH_MailBank.bMail = false
						AH_MailBank.OpenPanel()
					else
						AH_MailBank.ClosePanel()
					end
				end
				hBtnMail.OnMouseEnter = function()
					local x, y = this:GetAbsPos()
					local w, h = this:GetSize()
					local szTip = GetFormatText("�ʼ��ֿ�", 163) .. GetFormatText("\n����������Դ������ʼ��ֿ⡣", 162)
					OutputTip(szTip, 400, {x, y, w, h})
				end
				hBtnMail.OnMouseLeave = function()
					HideTip()
				end
			end
		end
		Wnd.CloseWindow(temp)
		bBagHooked = true
	elseif not frame or not frame:IsVisible() then
		bBagHooked = false
	end
end

-- ����ʣ��ʱ���ʽ��
function AH_MailBank.FormatItemLeftTime(nTime)
	if nTime >= 86400 then
		return FormatString(g_tStrings.STR_MAIL_LEFT_DAY, math.floor(nTime / 86400))
	elseif nTime >= 3600 then
		return FormatString(g_tStrings.STR_MAIL_LEFT_HOURE, math.floor(nTime / 3600))
	elseif nTime >= 60 then
		return FormatString(g_tStrings.STR_MAIL_LEFT_MINUTE, math.floor(nTime / 60))
	else
		return g_tStrings.STR_MAIL_LEFT_LESS_ONE_M
	end
end

-- ȡ����
function AH_MailBank.TakeMailItemToBag(fnAction, nCount)
	local dwID, dwType = Target_GetTargetData()
	local hNpc = dwType == TARGET.NPC and GetNpc(dwID) or nil
	if not hNpc or (hNpc and not StringFindW(hNpc.szTitle, "��ʹ")) then
		OutputMessage("MSG_SYS", "��ѡ����ʹ���ռ�\n")
		OutputWarningMessage("MSG_NOTICE_YELLOW", "��ѡ����ʹ���ռ���", 2)
		return
	end
	local tFreeBoxList = AH_Spliter.GetPlayerBagFreeBoxList()
	if nCount > #tFreeBoxList then
		OutputMessage("MSG_SYS", "�����ռ䲻��\n")
		OutputWarningMessage("MSG_NOTICE_YELLOW", "�����ռ䲻�㣡", 2)
		return
	end
	fnAction()
end

-- ����ɸѡ
function AH_MailBank.ReFilter(frame)
	if AH_MailBank.szCurKey ~= "" then
		AH_MailBank.FilterMailItem(frame, AH_MailBank.szCurKey)
	end
end

-- ��鵱ǰ��ɫ
function AH_MailBank.CheckCurRole(frame)
	AH_MailBank.nFilterType = 1
	frame:Lookup("", ""):Lookup("Text_Filter"):SetText(tFilterType[AH_MailBank.nFilterType])
	local bTrue = (AH_MailBank.szCurRole == GetClientPlayer().szName)
	frame:Lookup("Btn_Filter"):Enable(bTrue)
	frame:Lookup("Check_NotReturn"):Enable(bTrue)
end

------------------------------------------------------------
-- �ص�����
------------------------------------------------------------
function AH_MailBank.OnFrameCreate()
	local handle = this:Lookup("", "")
	local hBg = handle:Lookup("Handle_Bg")
	local hBox = handle:Lookup("Handle_Box")
	hBg:Clear()
	hBox:Clear()
	local nIndex = 0
	for i = 1, 7, 1 do
		for j = 1, 14, 1 do
			hBg:AppendItemFromString("<image>w=52 h=52 path=\"ui/Image/LootPanel/LootPanel.UITex\" frame=13 </image>")
			local img = hBg:Lookup(nIndex)
			hBox:AppendItemFromString("<box>w=48 h=48 eventid=304 </box>")
			local box = hBox:Lookup(nIndex)
			box.nIndex = nIndex
			box.bItemBox = true
			local x, y = (j - 1) * 52, (i - 1) * 52
			img:SetRelPos(x, y)
			box:SetRelPos(x + 2, y + 2)
			box:SetOverTextPosition(0, ITEM_POSITION.RIGHT_BOTTOM)
			box:SetOverTextFontScheme(0, 15)
			box:SetOverTextPosition(1, ITEM_POSITION.LEFT_TOP)
			box:SetOverTextFontScheme(1, 16)
			img:Hide()
			box:Hide()

			nIndex = nIndex + 1
		end
	end
	hBg:FormatAllItemPos()
	hBox:FormatAllItemPos()
end

function AH_MailBank.OnEditChanged()
	local szName, frame = this:GetName(), this:GetRoot()
	if szName == "Edit_Search" then
		AH_MailBank.szCurKey = this:GetText()
		AH_MailBank.FilterMailItem(frame, AH_MailBank.szCurKey)
	end
end

function AH_MailBank.OnCheckBoxCheck()
	local szName, frame = this:GetName(), this:GetRoot()
	if szName == "Check_NotReturn" then
		AH_MailBank.bShowNoReturn = true
		AH_MailBank.LoadMailData(frame, AH_MailBank.szCurRole, AH_MailBank.nCurIndex)
		AH_MailBank.ReFilter(frame)
	end
end

function AH_MailBank.OnCheckBoxUncheck()
	local szName, frame = this:GetName(), this:GetRoot()
	if szName == "Check_NotReturn" then
		AH_MailBank.bShowNoReturn = false
		AH_MailBank.LoadMailData(frame, AH_MailBank.szCurRole, AH_MailBank.nCurIndex)
		AH_MailBank.ReFilter(frame)
	end
end

function AH_MailBank.OnLButtonClick()
	local szName, frame = this:GetName(), this:GetRoot()
	if szName == "Btn_Close" then
		AH_MailBank.ClosePanel()
	elseif szName == "Btn_Account" then
		local hText = frame:Lookup("", ""):Lookup("Text_Account")
		local x, y = hText:GetAbsPos()
		local w, h = hText:GetSize()
		local menu = {}
		menu.nMiniWidth = w + 20
		menu.x = x
		menu.y = y + h
		for k, v in pairs(AH_MailBank.tItemCache) do
			local m = {
				szOption = k,
				fnAction = function()
					AH_MailBank.szCurRole = k
					AH_MailBank.LoadMailData(frame, k, 1)
					AH_MailBank.ReFilter(frame)
					AH_MailBank.CheckCurRole(frame)
				end
			}
			table.insert(menu, m)
		end
		PopupMenu(menu)
	elseif szName == "Btn_Filter" then
		local hText = frame:Lookup("", ""):Lookup("Text_Filter")
		local x, y = hText:GetAbsPos()
		local w, h = hText:GetSize()
		local menu = {}
		menu.nMiniWidth = w + 20
		menu.x = x
		menu.y = y + h
		for k, v in ipairs(tFilterType) do
			local m = {
				szOption = v,
				fnAction = function()
					hText:SetText(v)
					AH_MailBank.nFilterType = k
					local hType = frame:Lookup("", ""):Lookup("Text_Type")
					if k == 4 then
						hType:SetText("����(��)��")
					else
						hType:SetText("�����ַ���")
					end
					AH_MailBank.ReFilter(frame)
				end
			}
			table.insert(menu, m)
		end
		PopupMenu(menu)
	elseif szName == "Btn_Setting" then
		local menu = {}
		for k, v in pairs(AH_MailBank.tItemCache) do
			local m = {
				szOption = k,
				{
					szOption = "ɾ��",
					fnAction = function()
						AH_MailBank.tItemCache[k] = nil
						--AH_MailBank.LoadMailData(frame, AH_MailBank.szCurRole, AH_MailBank.nCurIndex)
					end
				}
			}
			table.insert(menu, m)
		end
		PopupMenu(menu)
	elseif szName == "Btn_Prev" then
		AH_MailBank.nCurIndex = AH_MailBank.nCurIndex - 1
		AH_MailBank.LoadMailData(frame, AH_MailBank.szCurRole, AH_MailBank.nCurIndex)
		AH_MailBank.ReFilter(frame)
	elseif szName == "Btn_Next" then
		AH_MailBank.nCurIndex = AH_MailBank.nCurIndex + 1
		AH_MailBank.LoadMailData(frame, AH_MailBank.szCurRole, AH_MailBank.nCurIndex)
		AH_MailBank.ReFilter(frame)
	elseif szName == "Btn_Refresh" then
		AH_MailBank.LoadMailData(frame, AH_MailBank.szCurRole, AH_MailBank.nCurIndex)
		AH_MailBank.ReFilter(frame)
	end
end

function AH_MailBank.OnItemLButtonClick()
	local szName, frame = this:GetName(), this:GetRoot()
	if not this.bItemBox then
		return
	end
	this:SetObjectMouseOver(1)

	if not this:IsEmpty() then
		local d = this.data
		if this.szType == "item" then
			local item = GetItem(d.dwID)
			if item then
				local MailClient = GetMailClient()
				local n = 0	--��Ʒ����������
				for k, v in ipairs(d.tMailIDs) do
					local mail = MailClient.GetMailInfo(v)
					if mail.bItemFlag then
						for i = 0, 7, 1 do
							local item2 = mail.GetItem(i)
							if item2 and item2.nUiId == d.nUiId then
								n = n + 1
								AH_Library.DelayCall(0.25 * n + GetPingValue() / 2000, function()
									AH_MailBank.TakeMailItemToBag(function() mail.TakeItem(i) end, 1)
								end)	--ѭ��ȡ�����ü��һ��ʱ�䣬�����޷�ȫ��ȡ������Ҫ�����ӳ�
							end
						end
					end
				end
				AH_Library.DelayCall(1 + 0.25 * n + GetPingValue() / 2000, function()
					AH_MailBank.LoadMailData(frame, AH_MailBank.szCurRole, AH_MailBank.nCurIndex)
				end)
			end
		elseif this.szType == "money" then
			local MailClient = GetMailClient()
			local n = 0	--��Ʒ����������
			for k, v in ipairs(d.tMailIDs) do
				local mail = MailClient.GetMailInfo(v)
				if mail.bMoneyFlag then
					n = n + 1
					AH_Library.DelayCall(0.25 * n + GetPingValue() / 2000, function()
						AH_MailBank.TakeMailItemToBag(function() mail.TakeMoney() end, 0)
					end)
				end
			end
			AH_Library.DelayCall(1 + 0.25 * n + GetPingValue() / 2000, function()
				AH_MailBank.LoadMailData(frame, AH_MailBank.szCurRole, AH_MailBank.nCurIndex)
			end)
		end
	end
end

function AH_MailBank.OnItemRButtonClick()
	local szName, frame = this:GetName(), this:GetRoot()
	if not this.bItemBox then
		return
	end
	this:SetObjectMouseOver(1)
	local box = this
	if not this:IsEmpty() then
		local d = this.data
		if this.szType == "item" then
			local item = GetItem(d.dwID)
			if item then
				local menu = {}
				local MailClient = GetMailClient()
				for k, v in ipairs(d.tMailIDs) do
					local mail = MailClient.GetMailInfo(v)
					if mail.bItemFlag then
						local m = {
							szOption = string.format(" %s��%s��", mail.szSenderName, mail.szTitle),
							szIcon = "UI\\Image\\UICommon\\CommonPanel2.UITex",
							nFrame = 105,
							nMouseOverFrame = 106,
							szLayer = "ICON_LEFT",
							fnClickIcon = function()
								local n = 0
								for i = 0, 7, 1 do
									local item2 = mail.GetItem(i)
									if item2 and item2.nUiId == d.nUiId then
										n = n + 1
										AH_Library.DelayCall(0.25 * n + GetPingValue() / 2000, function()
											AH_MailBank.TakeMailItemToBag(function() mail.TakeItem(i) end, 1)
										end)
									end
								end
								Wnd.CloseWindow("PopupMenuPanel")
								AH_Library.DelayCall(1 + 0.25 * n + GetPingValue() / 2000, function()
									AH_MailBank.LoadMailData(frame, AH_MailBank.szCurRole, AH_MailBank.nCurIndex)
								end)
							end
						}
						for i = 0, 7, 1 do
							local item2 = mail.GetItem(i)
							if item2 and item2.nUiId == d.nUiId then
								local nStack = (item2.bCanStack) and item2.nStackNum or 1
								local m_1 = {
									szOption = string.format("%s x%d", GetItemNameByItem(item2), nStack),
									fnAction = function()
										AH_MailBank.TakeMailItemToBag(function() mail.TakeItem(i) end, 1)
										AH_Library.DelayCall(0.5, function()
											AH_MailBank.LoadMailData(frame, AH_MailBank.szCurRole, AH_MailBank.nCurIndex)
										end)
									end,
									fnAutoClose = function() return true end
								}
								table.insert(m, m_1)
							end
						end
						table.insert(menu, m)
					end
				end
				PopupMenu(menu)
			end
		elseif this.szType == "money" then
			local menu = {}
			local MailClient = GetMailClient()
			for k, v in ipairs(d.tMailIDs) do
				local mail = MailClient.GetMailInfo(v)
				if mail.bMoneyFlag then
					local m = {
						szOption = string.format("%s��%s��", mail.szSenderName, mail.szTitle),
						{
							szOption = GetMoneyPureText(FormatMoneyTab(mail.nMoney)),
							fnAction = function()
								AH_MailBank.TakeMailItemToBag(function() mail.TakeMoney() end, 0)
								AH_Library.DelayCall(0.5, function()
									AH_MailBank.LoadMailData(frame, AH_MailBank.szCurRole, AH_MailBank.nCurIndex)
								end)
							end,
							fnAutoClose = function() return true end
						}
					}
					table.insert(menu, m)
				end
			end
			PopupMenu(menu)
		end
	end
end

function AH_MailBank.OnItemMouseEnter()
	local szName = this:GetName()
	if not this.bItemBox then
		return
	end
	this:SetObjectMouseOver(1)

	if not this:IsEmpty() then
		local x, y = this:GetAbsPos()
		local w, h = this:GetSize()
		local d = this.data
		if this.szType == "item" then
			if IsAltKeyDown() then
				local _, dwID = this:GetObjectData()
				OutputItemTip(UI_OBJECT_ITEM_ONLY_ID, dwID, nil, nil, {x, y, w, h})
			else
				local item = GetItem(d.dwID)
				if item and AH_MailBank.bMail then
					local szName = GetItemNameByItem(item)
					local szTip = "<Text>text=" .. EncodeComponentsString(szName) .. " font=60" .. GetItemFontColorByQuality(item.nQuality, true) .. " </text>"
					local MailClient = GetMailClient()
					for k, v in ipairs(d.tMailIDs) do
						local mail = MailClient.GetMailInfo(v)
						szTip = szTip .. GetFormatText(string.format("\n\n%s", mail.szSenderName), 164)
						szTip = szTip .. GetFormatText(string.format(" ��%s��\n", mail.szTitle), 163)
						local szLeft = AH_MailBank.FormatItemLeftTime(mail.GetLeftTime())
						szTip = szTip .. GetFormatText(string.format("ʣ��ʱ�䣺%s", szLeft), 162)
						local nCount = AH_MailBank.GetMailItem(mail)[szName][5]
						szTip = szTip .. GetFormatText(string.format("  ������%d", nCount), 162)
					end
					OutputTip(szTip, 300, {x, y, w, h})
				else
					local szTip = GetFormatText(this.szName, 162)
					OutputTip(szTip, 300, {x, y, w, h})
				end
			end
		elseif this.szType == "money" then
			local szTip = GetFormatText(g_tStrings.STR_MAIL_HAVE_MONEY, 101) .. GetMoneyTipText(d.nMoney, 106)
			local MailClient = GetMailClient()
			for k, v in ipairs(d.tMailIDs) do
				local mail = MailClient.GetMailInfo(v)
				szTip = szTip .. GetFormatText(string.format("\n\n%s", mail.szSenderName), 164)
				szTip = szTip .. GetFormatText(string.format(" ��%s��\n", mail.szTitle), 163)
				local szLeft = AH_MailBank.FormatItemLeftTime(mail.GetLeftTime())
				szTip = szTip .. GetFormatText(string.format("ʣ��ʱ�䣺%s ", szLeft), 162)
				szTip = szTip .. GetFormatText(g_tStrings.STR_MAIL_HAVE_MONEY, 162) .. GetMoneyTipText(mail.nMoney, 106)
			end
			OutputTip(szTip, 300, {x, y, w, h})
		end
	end
end

function AH_MailBank.OnItemMouseLeave()
	local szName = this:GetName()
	if not this.bItemBox then
		return
	end

	this:SetObjectMouseOver(0)
	HideTip()
end

function AH_MailBank.IsPanelOpened()
	local frame = Station.Lookup("Normal/AH_MailBank")
	if frame and frame:IsVisible() then
		return true
	end
	return false
end

function AH_MailBank.OpenPanel()
	local frame = Station.Lookup("Normal/AH_MailBank")
	if not frame then
		frame = Wnd.OpenWindow(szIniFile, "AH_MailBank")
	end
	frame:Show()
	frame:BringToTop()
	AH_MailBank.szCurRole = GetClientPlayer().szName
	if not AH_MailBank.tItemCache[AH_MailBank.szCurRole] then
		AH_MailBank.tItemCache[AH_MailBank.szCurRole] = {}
	end
	AH_MailBank.LoadMailData(frame, AH_MailBank.szCurRole, AH_MailBank.nCurIndex)
	PlaySound(SOUND.UI_SOUND,g_sound.OpenFrame)
end

function AH_MailBank.ClosePanel()
	local frame = Station.Lookup("Normal/AH_MailBank")
	if frame and frame:IsVisible() then
		frame:Hide()
	end
	PlaySound(SOUND.UI_SOUND,g_sound.CloseFrame)
end

RegisterEvent("LOGIN_GAME", function()
	if IsFileExist(AH_MailBank.szDataPath) then
		AH_MailBank.tItemCache = LoadLUAData(AH_MailBank.szDataPath)
	end
end)

RegisterEvent("GAME_EXIT", function()
	SaveLUAData(AH_MailBank.szDataPath, AH_MailBank.tItemCache)
end)

RegisterEvent("PLAYER_EXIT_GAME", function()
	SaveLUAData(AH_MailBank.szDataPath, AH_MailBank.tItemCache)
end)

AH_Library.RegisterBreatheEvent("ON_AH_MAILBANK_UPDATE", AH_MailBank.OnUpdate)
