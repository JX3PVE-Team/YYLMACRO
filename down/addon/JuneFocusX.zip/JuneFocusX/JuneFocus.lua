JuneFocus={
FocusList={},
MonitorList="��������,��������,���𡤻���,�������,��Ѫ,��ħɱ��,�ڷ�,ִ��,��ȥ����,�ȱ�,��ʥ,����,�ùⲽ,����,��ŭ,��ħɱ��,�ݲй�",
NorList="�ƳǴ�,��Ѫ��,����,��,������,����˿,���桤����,���桤߱��,���桤�ݷ�,���桤����,������Ƭ,���ʹ��,�������,���ܱ���,���ǹ��,��߶ܱ�,������ʱ�,������,����������,�ڳ���ʿ,�ڳ���ʦ,�ڳݼ�˾,����,С��,����",
nNorID={},
bDragable=false,
bDistance=true,
y0n=true,
number=5,
bShrink=true,
nHight=100,
LMdisp=1,
hideMana=false,
bBuffDisp=true,
bNor=false,
nStep=0,
nScale=1,
tAvatars,
Anchor={nX=500,nY=500},
}
RegisterCustomData("JuneFocus.Anchor")
RegisterCustomData("JuneFocus.bShrink")
RegisterCustomData("JuneFocus.hideMana")
RegisterCustomData("JuneFocus.number")
RegisterCustomData("JuneFocus.LMdisp")
RegisterCustomData("JuneFocus.bDragable")
RegisterCustomData("JuneFocus.bDistance")
RegisterCustomData("JuneFocus.bBuffDisp")
RegisterCustomData("JuneFocus.bNor")
RegisterCustomData("JuneFocus.MonitorList")
RegisterCustomData("JuneFocus.NorList")

function JuneFocus.OnFrameCreate()
	this:RegisterEvent("CUSTOM_DATA_LOADED")
	this:RegisterEvent("UI_SCALED")
	this:RegisterEvent("BUFF_UPDATE")
	this:RegisterEvent("PLAYER_STATE_UPDATE")
	local hFrame = Station.Lookup("Normal/JuneFocus")
	JuneFocus.UpdateAnchor(hFrame)
	JuneFocus.UpdateList()
	if JuneFocus.bDragable then
		hFrame:EnableDrag(false)
	else
		hFrame:EnableDrag(true)
	end
	if not JuneFocus.bShrink then
		hFrame:Lookup("", "Handle_List"):Hide()
		hFrame:Lookup("", "Handle_BG"):Lookup("Image_BG"):Hide()
		hFrame:SetSize(230, 32)
	end
end

JuneFocus.UpdateAnchor=function(frame)
	frame:SetRelPos(JuneFocus.Anchor.nX, JuneFocus.Anchor.nY)
end

JuneFocus.GetTarget=function(dwID)
	local target
	if IsPlayer(dwID) then
		target = GetPlayer(dwID)
	else
		target = GetNpc(dwID)
	end
	return target
end

JuneFocus.ScanList=function(dTable,dwID)
	for i,v in pairs(dTable) do
		if v==dwID then
		    return true
		end
	end
	return false
end

JuneFocus.RemoveList=function(dTable,dwID)
	for i,v in pairs(dTable) do
		if v==dwID then
		    table.remove(dTable,i)
		end
	end
end

JuneFocus.split=function(szFullString, szSeparator)
	local nFindStartIndex = 1
	local nSplitIndex = 1
	local nSplitArray = {}
	while true do
		local nFindLastIndex = string.find(szFullString, szSeparator, nFindStartIndex)
		if not nFindLastIndex then
			nSplitArray[string.sub(szFullString, nFindStartIndex, string.len(szFullString))]=nSplitIndex
			break
		end
		nSplitArray[string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1)]=nSplitIndex
		nFindStartIndex = nFindLastIndex + 1
		nSplitIndex = nSplitIndex + 1
	end
	return nSplitArray
end
function  JuneFocus.Table_GetPlayerMiniAvatars()
	local tAvatar = {}
	local nCount = g_tTable.PlayerAvatar:GetRowCount()

	for i = 1, nCount do
		local tLine = g_tTable.PlayerAvatar:GetRow(i)
		local dwIndex = tLine.dwPlayerMiniAvatarID
		tAvatar[dwIndex] = {}
		tAvatar[dwIndex]["dwType"] = tLine.dwType
		tAvatar[dwIndex]["dwKindID"] = tLine.dwKindID
		tAvatar[dwIndex]["szFileName"] = tLine.szFileName
	end

	return tAvatar
end
function JuneFocus.GetPlayerMiniAvatarFile(dwID,img)
	local t=GetPlayer(dwID)
	local mnt = t.GetKungfuMount()
	if mnt and mnt.dwSkillID ~= 0 then
		img:FromIconID(Table_GetSkillIconID(mnt.dwSkillID, 0))
	else
		img:FromUITex(GetForceImage(t.dwForceID))
	end
end
function JuneFocus.UpdateMember(hListItem,hPlayer)
	local Player = GetClientPlayer()
	if not Player or not hPlayer or not JuneFocus.y0n then return end
	local tType, tID = Player.GetTarget()
	if tID==hPlayer.dwID then
		hListItem:Lookup("Animate_Hot"):Show()
	else
		hListItem:Lookup("Animate_Hot"):Hide()
	end
	local tPartyMark = GetClientTeam().GetTeamMark()
	if tPartyMark and tPartyMark[hPlayer.dwID] then
		local nIconFrame = PARTY_MARK_ICON_FRAME_LIST[tPartyMark[hPlayer.dwID]]
		hListItem:Lookup("Image_Mark"):FromUITex(PARTY_MARK_ICON_PATH, nIconFrame)
		hListItem:Lookup("Image_Mark"):Show()
	end
	local bPrePare, dwID, dwLevel, fP = hPlayer.GetSkillPrepareState()
	local szPath, nFrame = "", 0
	hListItem:Lookup("Image_SchoolBG"):Hide()
	hListItem:Lookup("Image_School"):Show()
	if not hListItem:Lookup("Image_School").bSetImg then
		hListItem:Lookup("Image_School").bSetImg=true
		if hListItem.dwType == TARGET.PLAYER then
			if hPlayer.dwMiniAvatarID == 0 then
				szPath, nFrame = GetForceImage(hPlayer.dwForceID)
				hListItem:Lookup("Image_School"):FromUITex(szPath, nFrame)
			else
				szPath = JuneFocus.GetPlayerMiniAvatarFile(hPlayer.dwID,hListItem:Lookup("Image_School") )--ȡͷ��
				--hListItem:Lookup("Image_School"):FromTextureFile(szPath)
			end
		elseif hListItem.dwType == TARGET.NPC then
			local dwModelID = hPlayer.dwModelID
			local szProtraitPath = NPC_GetProtrait(dwModelID)
			local szHeadImageFilePath = NPC_GetHeadImageFile(dwModelID)
			if szProtraitPath and IsFileExist(szProtraitPath) then
				szPath = szProtraitPath
			else
				szPath = szHeadImageFilePath
			end
			if IsFileExist(szPath) then
				hListItem:Lookup("Image_School"):FromTextureFile(szPath)
			else
				szPath, nFrame = GetNpcHeadImage(hPlayer.dwID)
				hListItem:Lookup("Image_School"):FromUITex(szPath, nFrame)
			end
		end
	end
	if JuneFocus.bDistance then
	local tDis = ("%.1f"):format(GetCharacterDistance(GetClientPlayer().dwID,hPlayer.dwID)/64)
		hListItem:Lookup("Text_Name"):SetText(hPlayer.szName.." ("..tDis.."��)")
	else
		hListItem:Lookup("Text_Name"):SetText(hPlayer.szName)
	end
	local hImgHealth = hListItem:Lookup("Image_Health")
	local hTextHealth = hListItem:Lookup("Text_Health")
	local hImgMana = hListItem:Lookup("Image_Mana")
	local hTextMana = hListItem:Lookup("Text_Mana")
	hImgHealth:Show()
	hTextHealth:Show()
	if hPlayer.nMaxLife > 0 then
		local fPercent = hPlayer.nCurrentLife / hPlayer.nMaxLife
		hImgHealth:SetPercentage(fPercent)
		local hHealth
		if hPlayer.nMaxLife >= 100000 then
			if hPlayer.nCurrentLife >= 100000 then
				hHealth=math.floor(hPlayer.nCurrentLife / 10000) .."��"
			else
				hHealth=hPlayer.nCurrentLife
			end
		else
			hHealth=hPlayer.nCurrentLife
		end
		if JuneFocus.LMdisp==1 then
			hTextHealth:SetText(hHealth.." ("..("%.1f"):format(fPercent*100).."%)")
		elseif JuneFocus.LMdisp==3 then
			hTextHealth:SetText(("%.1f"):format(fPercent*100).."%")
		else
			hTextHealth:SetText(hHealth)
		end
	else
		hImgHealth:SetPercentage(0)
		hTextHealth:SetText("")
	end
	hImgMana:Show()
	hTextMana:Show()
	if hPlayer.nMaxMana > 0 and hPlayer.dwForceID~=7 and hPlayer.dwForceID~=8 then
		local fPercent = hPlayer.nCurrentMana / hPlayer.nMaxMana
		hImgMana:SetPercentage(fPercent)
		if not JuneFocus.hideMana and hListItem.dwType==TARGET.PLAYER then
			if JuneFocus.LMdisp==3 then
				hTextMana:SetText(math.ceil(fPercent*100).."%")
			else
				hTextMana:SetText(hPlayer.nCurrentMana)
			end
			hTextMana:Show()
		else
			hTextMana:Hide()
		end
	else
		hImgMana:SetPercentage(0)
		hTextMana:SetText("")
	end
	local imgProgress = hListItem:Lookup("Image_Progress")
	local textProgress = hListItem:Lookup("Text_Progress")
	if bPrePare then
		hTextMana:Hide()
		textProgress:Show()
		textProgress:SetText(Table_GetSkillName(dwID, dwLevel))
		imgProgress:Show()
		imgProgress:SetPercentage(fP)
	else
		textProgress:Hide()
		imgProgress:Hide()
	end
end
function JuneFocus.UpdateList()
	local Player = GetClientPlayer()
	if not Player or not JuneFocus.y0n then return end
	local hFrame = Station.Lookup("Normal/JuneFocus")
	if not hFrame then
		hFrame = Wnd.OpenWindow("Interface/JuneFocusX/JuneFocus.ini", "JuneFocus")
	elseif hFrame and not hFrame:IsVisible() then
		hFrame:Show()
	end
	local hList = hFrame:Lookup("", "Handle_List")
	local x, y = hList:GetAbsPos()
	hList:Clear()
	local nCount=0
	for i,v in pairs(JuneFocus.FocusList) do
		if nCount>JuneFocus.number-1 then break end
		local hListItem = hList:AppendItemFromIni("Interface/JuneFocusX/JuneFocus.ini", "Handle_ListItem")
		hListItem:SetAbsPos(x, y + 60 * nCount)
		hListItem.dwID=v
		if IsPlayer(v) then
			hPlayer = GetPlayer(v)
			hListItem.dwType=TARGET.PLAYER
		else
			hPlayer = GetNpc(v)
			hListItem.dwType=TARGET.NPC
		end
		if hPlayer then
			JuneFocus.UpdateMember(hListItem,hPlayer)
		else
			hListItem:Lookup("Text_Name"):SetText("��ЧĿ��")
		end
		nCount=nCount+1
	end
	local nWidth, nHight = hFrame:GetSize()
	JuneFocus.nHight=60 * nCount + 32
	hFrame:Lookup("", "Handle_BG"):Lookup("Image_BG"):SetSize(nWidth, JuneFocus.nHight)
	if not JuneFocus.bShrink then
		hFrame:SetSize(nWidth,32)
	else
		hFrame:SetSize(nWidth, JuneFocus.nHight)
	end
end
function JuneFocus.UpdateBuff(hBuff,dwTargerID)
	hBuff:Clear()
	local hPlayer=JuneFocus.GetTarget(dwTargerID)
	if not hPlayer then
		return
	end
	local buffTable = hPlayer.GetBuffList()
	if buffTable then
		for k, v in pairs(buffTable) do
			JuneFocus.UpdateSingleBuff(hBuff, false, v.nIndex, v.dwID, v.nStackNum, v.nEndFrame, v.nLevel)
		end
	end
end
function JuneFocus.UpdateSingleBuff(handle, bDelete, nIndex, dwBuffID, nCount, nEndFrame, nLevel)
	if not Table_BuffIsVisible(dwBuffID, nLevel) then
		return
	end
	local tBuffName = Table_GetBuffName(dwBuffID,nLevel)
	local buffMonitor=JuneFocus.split(JuneFocus.MonitorList,",")
	if bDelete then
		handle:RemoveItem("b"..nIndex)
		handle:FormatAllItemPos()
	else
		if JuneFocus.MonitorList~="" and not buffMonitor[tBuffName] then return end
		local box = handle:Lookup("b"..nIndex)
		if box then
			box.nCount = nCount
			box.nEndFrame = nEndFrame
			box.dwBuffID = dwBuffID
			box.nLevel = nLevel
			box.bSparking = Table_BuffNeedSparking(dwBuffID, nLevel)
			box.bShowTime = Table_BuffNeedShowTime(dwBuffID, nLevel)
			box:SetObject(UI_OBJECT_NOT_NEED_KNOWN, dwBuffID)
			box:SetObjectIcon(Table_GetBuffIconID(dwBuffID, nLevel))
			if nCount > 1 then
				box:SetOverText(0, nCount)
			end
		else
			handle:AppendItemFromIni("Interface/JuneFocusX/JuneFocus.ini", "Box")
			box = handle:Lookup(handle:GetItemCount() - 1)
			box:SetName("b"..nIndex)
			box.nCount = nCount
			box.nEndFrame = nEndFrame
			box.dwBuffID = dwBuffID
			box.nLevel = nLevel
			box.nIndex = nIndex
			box.bSparking = Table_BuffNeedSparking(dwBuffID, nLevel)
			box.bShowTime = Table_BuffNeedShowTime(dwBuffID, nLevel)
			box:SetObject(UI_OBJECT_NOT_NEED_KNOWN, dwBuffID)
			box:SetObjectIcon(Table_GetBuffIconID(dwBuffID, nLevel))
			box:SetOverTextFontScheme(0, 15)
			if nCount > 1 then
				box:SetOverText(0, nCount)
			end
			box.OnItemMouseEnter = function()
				local frame = this:GetRoot()
				this:SetObjectMouseOver(1)
				local nTime = math.floor(this.nEndFrame - GetLogicFrameCount()) / 16 + 1
				local x, y = this:GetAbsPos()
				local w, h = this:GetSize()

				OutputBuffTip(GetClientPlayer().dwID, this.dwBuffID, this.nLevel, this.nCount, true, nTime, {x, y, w, h})
			end
		    box.OnItemMouseHover = box.OnItemMouseEnter
			box.OnItemMouseLeave = function()
				HideTip()
				this:SetObjectMouseOver(0)
			end
			handle:FormatAllItemPos()
		end
	end
end

function JuneFocus.OnFrameBreathe()
	local player = GetClientPlayer()
	if not player or not JuneFocus.y0n then return end
	local hFrame = Station.Lookup("Normal/JuneFocus")
	local hList = hFrame:Lookup("", "Handle_List")
	local nCount = hList:GetItemCount() - 1
	for i = 0, nCount, 1 do
		local hListItem=hList:Lookup(i)
		local dwTargerID=hListItem.dwID
		local hPlayer = JuneFocus.GetTarget(dwTargerID)
		if hPlayer then
			JuneFocus.UpdateMember(hListItem,hPlayer)
		else
			hListItem:Lookup("Text_Name"):SetText("��ЧĿ��")
			hListItem:Lookup("Handle_Buff"):Hide()
			hListItem:Lookup("Image_School"):Hide()
			hListItem:Lookup("Image_SchoolBG"):Show()
			hListItem:Lookup("Image_Health"):Hide()
			hListItem:Lookup("Text_Health"):Hide()
			hListItem:Lookup("Image_Mana"):Hide()
			hListItem:Lookup("Text_Mana"):Hide()
			hListItem:Lookup("Animate_Hot"):Hide()
		end
	end
end
RegisterEvent("NPC_ENTER_SCENE", function()
    if not JuneFocus.bNor or JuneFocus.ScanList(JuneFocus.FocusList,arg0) then return end
    local target=JuneFocus.GetTarget(arg0)
    local targetList=JuneFocus.split(JuneFocus.NorList,",")
	if targetList[target.szName] then
		table.insert(JuneFocus.FocusList,arg0)
		JuneFocus.nNorID[arg0]=target.szName
		JuneFocus.UpdateList()
		OutputMessage("MSG_SYS","������ʾ����"..target.szName.."����֣��Զ����뽹���б������� \n")
	end
end)
RegisterEvent("NPC_LEAVE_SCENE", function()
    if not JuneFocus.bNor or not JuneFocus.ScanList(JuneFocus.FocusList,arg0) or not JuneFocus.nNorID[arg0] then return end
	JuneFocus.RemoveList(JuneFocus.FocusList,arg0)
	JuneFocus.nNorID[arg0]=nil
	JuneFocus.UpdateList()
end)
function JuneFocus.OnLButtonClick()
	local szName = this:GetName()
	local hFrame = Station.Lookup("Normal/JuneFocus")
	local nWidth, nHight = hFrame:GetSize()
	if szName == "Btn_Close" then
		Wnd.CloseWindow("JuneFocus")
	elseif szName == "Btn_Shrink" then
		if JuneFocus.bShrink then
			hFrame:Lookup("", "Handle_List"):Hide()
			hFrame:Lookup("", "Handle_BG"):Lookup("Image_BG"):Hide()
			hFrame:SetSize(nWidth, 32)
			JuneFocus.bShrink=false
			JuneFocus.y0n=false
		else
			hFrame:SetSize(nWidth, JuneFocus.nHight)
			hFrame:Lookup("", "Handle_List"):Show()
			hFrame:Lookup("", "Handle_BG"):Lookup("Image_BG"):Show()
			JuneFocus.bShrink=true
			JuneFocus.y0n=true
			JuneFocus.UpdateList()
		end
	elseif szName == "Btn_Setting" then
		local menu = {}
		local m_1 = {
			szOption = "����λ������",
			bCheck = true,
			bChecked = JuneFocus.bDragable==true,
			fnAction = function()
				if JuneFocus.bDragable then
					JuneFocus.bDragable=false
					Station.Lookup("Normal/JuneFocus"):EnableDrag(true)
				else
					JuneFocus.bDragable=true
					Station.Lookup("Normal/JuneFocus"):EnableDrag(false)
				end
			end,
		}
		local m_3 = {szOption = "�б���������"}
		local m_3_1 = {
			szOption = "5",
			bMCheck = true,
			bChecked = JuneFocus.number == 5,
			fnAction = function()
				JuneFocus.number = 5
				JuneFocus.UpdateList()
			end,
		}
		local m_3_2 = {
			szOption = "10",
			bMCheck = true,
			bChecked = JuneFocus.number == 10,
			fnAction = function()
				JuneFocus.number = 10
				JuneFocus.UpdateList()
			end,
		}
		local m_3_3 = {
			szOption = "25",
			bMCheck = true,
			bChecked = JuneFocus.number == 25,
			fnAction = function()
				JuneFocus.number = 25
				JuneFocus.UpdateList()
			end,
		}
		local m_4 = {
			szOption = "��ʾĿ�����",
			bCheck = true,
			bChecked = JuneFocus.bDistance,
			fnAction = function()
				JuneFocus.bDistance = not JuneFocus.bDistance
				JuneFocus.UpdateList()
			end,
		}
		local m_5 = {szOption = "Ĭ�Ͻ�������"}
		local m_5_1 = {
			szOption = "����Ĭ�Ͻ���",
			bCheck = true,
			bChecked = JuneFocus.bNor,
			fnAction = function()
				JuneFocus.bNor = not JuneFocus.bNor
				JuneFocus.UpdateList()
			end,
		}
		local m_5_2 = {bDevide = true,}
		local m_5_3 = {
			szOption = "�Զ���Ĭ�Ͻ���",
			fnAction = function()
				GetUserInput("������Ҫ���ӵĽ���Ŀ�꣺", function(szText) JuneFocus.NorList=szText end, nil, nil, nil, JuneFocus.NorList)
				JuneFocus.UpdateList()
			end,
		}
		local m_7 = {szOption = "Ѫ����ֵ��ʽ"}
		local m_7_1 = {
			szOption = "��ֵ�Ͱٷֱ�",
			bMCheck = true,
			bChecked = JuneFocus.LMdisp == 1,
			fnAction = function()
				JuneFocus.LMdisp = 1
				JuneFocus.UpdateList()
			end,
		}
		local m_7_2 = {
			szOption = "��ֵ��ʾ",
			bMCheck = true,
			bChecked = JuneFocus.LMdisp == 2,
			fnAction = function()
				JuneFocus.LMdisp = 2
				JuneFocus.UpdateList()
			end,
		}
		local m_7_3 = {
			szOption = "�ٷֱ���ʾ",
			bMCheck = true,
			bChecked = JuneFocus.LMdisp == 3,
			fnAction = function()
				JuneFocus.LMdisp = 3
				JuneFocus.UpdateList()
			end,
		}
		local m_7_4 = {bDevide = true,}
		local m_7_5 = {
			szOption = "����ʾ����ֵ",
			bCheck = true,
			bChecked = JuneFocus.hideMana==true,
			fnAction = function()
				JuneFocus.hideMana = not JuneFocus.hideMana
				JuneFocus.UpdateList()
			end,
		}
		local m_8 = {szOption = "��ʾBUFF����"}
		local m_8_1 = {
			szOption = "��ʾBUFF����",
			bCheck = true,
			bChecked = JuneFocus.bBuffDisp,
			fnAction = function()
				JuneFocus.bBuffDisp = not JuneFocus.bBuffDisp
				JuneFocus.UpdateList()
			end,
		}
		local m_8_2 = {bDevide = true,}
		local m_8_3 = {
			szOption = "����ָ��BUFF",
			fnAction = function()
				GetUserInput("������Ҫ���ӵ�״̬��", function(szText) JuneFocus.MonitorList=szText end, nil, nil, nil, JuneFocus.MonitorList)
				JuneFocus.UpdateList()
			end,
		}

		table.insert(menu, m_1)
		table.insert(menu, m_3)
		table.insert(m_3, m_3_1)
		table.insert(m_3, m_3_2)
		table.insert(m_3, m_3_3)
		table.insert(menu, m_7)
		table.insert(m_7, m_7_1)
		table.insert(m_7, m_7_2)
		table.insert(m_7, m_7_3)
		table.insert(m_7, m_7_4)
		table.insert(m_7, m_7_5)
		table.insert(menu, m_8)
		table.insert(m_8, m_8_1)
		table.insert(m_8, m_8_2)
		table.insert(m_8, m_8_3)
		table.insert(menu, m_5)
		table.insert(m_5, m_5_1)
		table.insert(m_5, m_5_2)
		table.insert(m_5, m_5_3)
		table.insert(menu, m_4)
		PopupMenu(menu)
	end
end

function JuneFocus.OnItemLButtonClick()
	local szName = this:GetName()
	if szName == "Handle_ListItem" then
			if IsCtrlKeyDown() then
				if IsGMPanelReceivePlayer(this.dwID) then
					GMPanel_LinkPlayerID(this.dwID)
				else
					EditBox_AppendLinkPlayer(JuneFocus.GetTarget(this.dwID).szName)
				end
			else
				if not SetTarget then
					SelectTarget(this.dwType, this.dwID)
				else
					SetTarget(this.dwType, this.dwID)
				end
			end
	end
end

function JuneFocus.OnItemRButtonDown()
	local szName = this:GetName()
	if szName == "Handle_ListItem" then
		local menu = {}
		local dwID = this.dwID
		local player = GetClientPlayer()
		local target = JuneFocus.GetTarget(dwID)
		local tName=dwID
		if target then
			if player.IsInParty() then
				local hTeam = GetClientTeam()
				if player.dwID == hTeam.GetAuthorityInfo(TEAM_AUTHORITY_TYPE.MARK) then
					InsertMarkMenu(menu, dwID)
				end
			end
			table.insert(menu, {szOption=g_tStrings.STR_LOOKUP,fnDisable = not JuneFocus.GetTarget(dwID), fnAction = function() ViewInviteToPlayer(dwID) end})
			table.insert(menu, {szOption = g_tStrings.LOOKUP_CHANNEL,fnDisable = not JuneFocus.GetTarget(dwID), fnAction = function() ViewOtherPlayerChannels(dwID) end})
			tName=target.szName
		else
			tName=dwID
		end
		table.insert(menu, {szOption = "ɾ������Ŀ��",bCheck = false,
			fnAction = function()
			JuneFocus.RemoveList(JuneFocus.FocusList,dwID)
			JuneFocus.UpdateList()
			if not tName then
				OutputMessage("MSG_SYS","������ʾ���Ѿ���[��ЧĿ��]�ӽ����б�ɾ����\n")
			else
				OutputMessage("MSG_SYS","������ʾ���Ѿ���["..tName.."]�ӽ����б�ɾ����\n")
			end
			end})
		if menu and #menu > 0 then
			PopupMenu(menu)
		end
	end
end

function JuneFocus.AddTargetMenu()--���FUNC�Ĵ��볭��HMͬѧ��
	local dwID,dwType=Target_GetTargetData()
	Target_AppendAddonMenu({function(dwID)
				return 	{{szOption="����June�����б�",fnAction=function()
				local target = JuneFocus.GetTarget(dwID)
				if target and not JuneFocus.ScanList(JuneFocus.FocusList,dwID) then
					table.insert(JuneFocus.FocusList,dwID)
					OutputMessage("MSG_SYS","������ʾ���Ѿ���["..target.szName.."]���뵽�����б���\n")
					JuneFocus.UpdateList()
				end
			end}}
			end })
end
function JuneFocus.OnFrameDragEnd()
	JuneFocus.Anchor.nX, JuneFocus.Anchor.nY = this:GetRelPos()
end

function JuneFocus.OnEvent(event)
	local hFrame = Station.Lookup("Normal/JuneFocus")
	if event == "CUSTOM_DATA_LOADED" then
		if hFrame and hFrame:IsVisible() then
			JuneFocus.UpdateAnchor(hFrame)
		else
			hFrame=Wnd.OpenWindow("Interface/JuneFocusX/JuneFocus.ini", "JuneFocus")
			hFrame:Show()
		end
		JuneFocus.UpdateList()
		if JuneFocus.bDragable then
			hFrame:EnableDrag(false)
		else
			hFrame:EnableDrag(true)
		end
		if not JuneFocus.bShrink then
			hFrame:Lookup("", "Handle_List"):Hide()
			hFrame:Lookup("", "Handle_BG"):Lookup("Image_BG"):Hide()
			hFrame:SetSize(230, 32)
		end
	elseif event == "UI_SCALED" then
		JuneFocus.UpdateAnchor(hFrame)
		JuneFocus.UpdateList()
	elseif event == "BUFF_UPDATE" then
		if not JuneFocus.bBuffDisp then return end
		local tID=arg0
		local hList = hFrame:Lookup("", "Handle_List")
		local nCount = hList:GetItemCount() - 1
		for i = 0, nCount, 1 do
			local hListItem=hList:Lookup(i)
			local dwTargerID=hListItem.dwID
			if dwTargerID==tID then
				local hBuff = hListItem:Lookup("Handle_Buff")
				hBuff:Show()
				if arg7 then
				JuneFocus.UpdateBuff(hBuff,tID)
				else
				JuneFocus.UpdateSingleBuff(hBuff, arg1, arg2, arg4, arg5, arg6, arg8)
				end
				break
			end
		end
	end
end

function JuneFocus.SwitchActive()
	local hFrame = Station.Lookup("Normal/JuneFocus")
	if not hFrame then
		hFrame = Wnd.OpenWindow("Interface/JuneFocusX/JuneFocus.ini", "JuneFocus")
	elseif hFrame and hFrame:IsVisible() then
		hFrame:Hide()
		return
	end
	hFrame:Show()
	JuneFocus.UpdateList()
end

Wnd.OpenWindow("Interface/JuneFocusX/JuneFocus.ini", "JuneFocus")

-- �󶨿�ݼ�
Hotkey.AddBinding("JuneFocusX", "�򿪻�رս���","JuneFocusX",JuneFocus.SwitchActive,nil)
Hotkey.AddBinding("JuneFocus_Add", "���ӽ���Ŀ��", "",
	function()
		local player = GetClientPlayer()
		local nType, dwID = player.GetTarget()
		local target = JuneFocus.GetTarget(dwID)
		if target and not JuneFocus.ScanList(JuneFocus.FocusList,dwID) then
			table.insert(JuneFocus.FocusList,dwID)
			OutputMessage("MSG_SYS","������ʾ���Ѿ���["..target.szName.."]���뵽�����б���\n")
			JuneFocus.UpdateList()
		end
	end,
	nil)
Hotkey.AddBinding("JuneFocus_Del", "ɾ������Ŀ��", "",
	function()
		local player = GetClientPlayer()
		local nType, dwID = player.GetTarget()
		local target = JuneFocus.GetTarget(dwID)
		if target and JuneFocus.ScanList(JuneFocus.FocusList,dwID) then
			JuneFocus.RemoveList(JuneFocus.FocusList,dwID)
			JuneFocus.UpdateList()
			OutputMessage("MSG_SYS","������ʾ���Ѿ���["..JuneFocus.GetTarget(dwID).szName.."]�ӽ����б�ɾ����\n")
		end
	end,
	nil)

for i = 1, 5 do
	Hotkey.AddBinding("JuneFocus_" .. i, "ѡ�񽹵�" .. i, "",
	function()
		local hFrame = Station.Lookup("Normal/JuneFocus")
		local hList = hFrame:Lookup("", "Handle_List")
		local hListItem = hList:Lookup(i-1)
		local dwID = hListItem.dwID
		local dwType = hListItem.dwType
		local target = JuneFocus.GetTarget(dwID)
		if target then
			if not SetTarget then
				SelectTarget(dwType,dwID)
			else
				SetTarget(dwType,dwID)
			end
		end
	end,
	nil)
end
 JuneFocus.tAvatars= JuneFocus.Table_GetPlayerMiniAvatars()
JuneFocus.AddTargetMenu()
OutputMessage("MSG_SYS","[CMG] JuneFocusX�ཹ�������سɹ���\n")
